//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// hanning.cpp
//
// Code generation for function 'hanning'
//

// Include files
#include "hanning.h"
#include "exstraightsource_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Definitions
namespace legacy_STRAIGHT {
void hanning(double varargin_1, ::coder::array<double, 1U> &w)
{
  ::coder::array<double, 2U> r;
  ::coder::array<double, 1U> b_w;
  double n;
  int i;
  int scalarLB;
  boolean_T guard1;
  if (varargin_1 == std::floor(varargin_1)) {
    n = varargin_1;
  } else {
    n = std::round(varargin_1);
  }
  guard1 = false;
  if (n == 0.0) {
    scalarLB = 0;
    guard1 = true;
  } else if (n == 1.0) {
    scalarLB = 1;
    guard1 = true;
  } else {
    double b;
    if (std::isinf(n)) {
      b = rtNaN;
    } else if (n == 0.0) {
      b = 0.0;
    } else {
      b = std::fmod(n, 2.0);
    }
    if (b == 0.0) {
      __m128d r1;
      int i1;
      int loop_ub;
      int nx_tmp;
      int vectorUB;
      b = n / 2.0;
      if (b < 1.0) {
        r.set_size(1, 0);
      } else {
        r.set_size(1, static_cast<int>(b - 1.0) + 1);
        loop_ub = static_cast<int>(b - 1.0);
        for (i = 0; i <= loop_ub; i++) {
          r[i] = static_cast<double>(i) + 1.0;
        }
      }
      loop_ub = r.size(1);
      w.set_size(r.size(1));
      scalarLB = (r.size(1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&r[i]);
        _mm_storeu_pd(
            &w[i], _mm_div_pd(_mm_mul_pd(_mm_set1_pd(6.2831853071795862), r1),
                              _mm_set1_pd(n + 1.0)));
      }
      for (i = scalarLB; i < loop_ub; i++) {
        w[i] = 6.2831853071795862 * r[i] / (n + 1.0);
      }
      nx_tmp = w.size(0);
      for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
        w[scalarLB] = std::cos(w[scalarLB]);
      }
      scalarLB = (w.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&w[i]);
        _mm_storeu_pd(&w[i], _mm_mul_pd(_mm_set1_pd(0.5),
                                        _mm_sub_pd(_mm_set1_pd(1.0), r1)));
      }
      for (i = scalarLB; i < nx_tmp; i++) {
        w[i] = 0.5 * (1.0 - w[i]);
      }
      if (w.size(0) < 1) {
        i = 0;
        scalarLB = 1;
        i1 = -1;
      } else {
        i = w.size(0) - 1;
        scalarLB = -1;
        i1 = 0;
      }
      loop_ub = div_s32(i1 - i, scalarLB);
      vectorUB = (w.size(0) + loop_ub) + 1;
      b_w.set_size(vectorUB);
      nx_tmp = w.size(0);
      for (i1 = 0; i1 < nx_tmp; i1++) {
        b_w[i1] = w[i1];
      }
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_w[i1 + w.size(0)] = w[i + scalarLB * i1];
      }
      w.set_size(vectorUB);
      for (i = 0; i < vectorUB; i++) {
        w[i] = b_w[i];
      }
    } else {
      __m128d r1;
      int i1;
      int loop_ub;
      int nx_tmp;
      int vectorUB;
      b = (n + 1.0) / 2.0;
      if (b < 1.0) {
        r.set_size(1, 0);
      } else {
        r.set_size(1, static_cast<int>(b - 1.0) + 1);
        loop_ub = static_cast<int>(b - 1.0);
        for (i = 0; i <= loop_ub; i++) {
          r[i] = static_cast<double>(i) + 1.0;
        }
      }
      loop_ub = r.size(1);
      w.set_size(r.size(1));
      scalarLB = (r.size(1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&r[i]);
        _mm_storeu_pd(
            &w[i], _mm_div_pd(_mm_mul_pd(_mm_set1_pd(6.2831853071795862), r1),
                              _mm_set1_pd(n + 1.0)));
      }
      for (i = scalarLB; i < loop_ub; i++) {
        w[i] = 6.2831853071795862 * r[i] / (n + 1.0);
      }
      nx_tmp = w.size(0);
      for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
        w[scalarLB] = std::cos(w[scalarLB]);
      }
      scalarLB = (w.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&w[i]);
        _mm_storeu_pd(&w[i], _mm_mul_pd(_mm_set1_pd(0.5),
                                        _mm_sub_pd(_mm_set1_pd(1.0), r1)));
      }
      for (i = scalarLB; i < nx_tmp; i++) {
        w[i] = 0.5 * (1.0 - w[i]);
      }
      if (w.size(0) - 1 < 1) {
        i = 0;
        scalarLB = 1;
        i1 = -1;
      } else {
        i = w.size(0) - 2;
        scalarLB = -1;
        i1 = 0;
      }
      loop_ub = div_s32(i1 - i, scalarLB);
      vectorUB = (w.size(0) + loop_ub) + 1;
      b_w.set_size(vectorUB);
      nx_tmp = w.size(0);
      for (i1 = 0; i1 < nx_tmp; i1++) {
        b_w[i1] = w[i1];
      }
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_w[i1 + w.size(0)] = w[i + scalarLB * i1];
      }
      w.set_size(vectorUB);
      for (i = 0; i < vectorUB; i++) {
        w[i] = b_w[i];
      }
    }
  }
  if (guard1) {
    w.set_size(scalarLB);
    for (i = 0; i < scalarLB; i++) {
      w[0] = 1.0;
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (hanning.cpp)
