//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// interp1.h
//
// Code generation for function 'interp1'
//

#ifndef INTERP1_H
#define INTERP1_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<creal_T, 2U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<creal_T, 2U> &Vq);

void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<double, 1U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq);

void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<double, 2U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq);

void interp1(const double varargin_1_data[], int varargin_1_size,
             const double varargin_2_data[], int varargin_2_size,
             const double varargin_3[1025], double Vq[1025]);

void interp1(const double varargin_1[1025], const double varargin_2[1025],
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq);

} // namespace legacy_STRAIGHT

#endif
// End of code generation (interp1.h)
