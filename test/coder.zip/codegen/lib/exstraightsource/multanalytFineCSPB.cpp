//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// multanalytFineCSPB.cpp
//
// Code generation for function 'multanalytFineCSPB'
//

// Include files
#include "multanalytFineCSPB.h"
#include "conv.h"
#include "exp.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "fftfilt.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Declarations
static void binary_expand_op_26(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4);

// Function Definitions
static void binary_expand_op_26(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4)
{
  coder::array<creal_T, 2U> b_in2;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in3.size(1) == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in3.size(1);
  }
  b_in2.set_size(1, loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    double d;
    int i1;
    d = in2[i * stride_0_1];
    i1 = i * stride_1_1;
    b_in2[i].re = d * in3[i1].re;
    b_in2[i].im = d * in3[i1].im;
  }
  legacy_STRAIGHT::fftfilt(b_in2, in4, in1);
}

void b_multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs,
                          double f0floor, double nvc, double nvo, double mu,
                          coder::array<creal_T, 2U> &pm)
{
  __m128d r;
  coder::array<creal_T, 2U> b_wwd;
  coder::array<creal_T, 2U> pmtmp1;
  coder::array<creal_T, 2U> r2;
  coder::array<creal_T, 2U> tx;
  coder::array<double, 2U> gent;
  coder::array<double, 2U> tb;
  coder::array<double, 2U> wd1;
  coder::array<double, 2U> wd2;
  coder::array<double, 2U> wwd;
  coder::array<double, 2U> y;
  coder::array<int, 2U> r1;
  double mpv;
  double t0;
  double wl;
  int b_loop_ub;
  int c_loop_ub;
  int i;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  //        Dual waveleta analysis using cardinal spline manipulation
  //                pm=multanalytFineCSPB(x,fs,f0floor,nvc,nvo,mu,mlt)
  //        Input parameters
  //
  //                x       : input signal (2kHz sampling rate is sufficient.)
  //                fs      : sampling frequency (Hz)
  //                f0floor : lower bound for pitch search (60Hz suggested)
  //                nvc     : number of total voices for wavelet analysis
  //                nvo     : number of voices in an octave
  // 				mu		: temporal stretch factor
  // 				mlt		: harmonic ID#
  // 				imgi	: display indicator, 1: dispaly on (default), 0: display
  // off
  //        Outpur parameters
  //                pm      : wavelet transform using iso-metric Gabor function
  //
  //        If you have any questions,  mailto:kawahara@hip.atr.co.jp
  //
  //        Copyright (c) ATR Human Information Processing Research Labs. 1996
  //        Invented and coded by Hideki Kawahara
  //        30/Oct./1996
  //        07/Dec./2002 waitbar was added
  // 		10/Aug./2005 modified by Takahashi on waitbar
  // 		10/Sept./2005 modified by Kawahara on waitbar
  // 10/Sept./2005
  t0 = 1.0 / f0floor;
  wl = rt_powd_snf(2.0, std::ceil(std::log(std::round(6.0 * t0 * fs * mu)) /
                                  0.69314718055994529));
  loop_ub = x.size(1);
  tx.set_size(1, x.size(1));
  for (i = 0; i < loop_ub; i++) {
    tx[i].re = x[i].re;
    tx[i].im = -x[i].im;
  }
  x.set_size(1, loop_ub);
  for (i = 0; i < loop_ub; i++) {
    x[i] = tx[i];
  }
  tx.set_size(1, x.size(1) + static_cast<int>(wl));
  for (i = 0; i < loop_ub; i++) {
    tx[i] = x[i];
  }
  b_loop_ub = static_cast<int>(wl);
  for (i = 0; i < b_loop_ub; i++) {
    tx[i + x.size(1)].re = 0.0;
    tx[i + x.size(1)].im = 0.0;
  }
  if (wl < 1.0) {
    gent.set_size(gent.size(0), 0);
  } else {
    gent.set_size(1, static_cast<int>(wl - 1.0) + 1);
    b_loop_ub = static_cast<int>(wl - 1.0);
    for (i = 0; i <= b_loop_ub; i++) {
      gent[i] = static_cast<double>(i) + 1.0;
    }
  }
  gent.set_size(1, gent.size(1));
  wl /= 2.0;
  b_loop_ub = gent.size(1) - 1;
  scalarLB = (gent.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&gent[i]);
    _mm_storeu_pd(&gent[i],
                  _mm_div_pd(_mm_sub_pd(r, _mm_set1_pd(wl)), _mm_set1_pd(fs)));
  }
  for (i = scalarLB; i <= b_loop_ub; i++) {
    gent[i] = (gent[i] - wl) / fs;
  }
  i = static_cast<int>(nvc);
  pm.set_size(i, loop_ub);
  b_loop_ub = static_cast<int>(nvc) * x.size(1);
  for (int i1{0}; i1 < b_loop_ub; i1++) {
    pm[i1].re = 0.0;
    pm[i1].im = 0.0;
  }
  mpv = 1.0;
  // if imgi==1; hpg=waitbar(0,['wavelet analysis for initial F0 ' ...
  //     'and P/N estimation with HM#:' num2str(mlt)]); end; % 07/Dec./2002 by
  //     H.K.%10/Aug./2005
  if (static_cast<int>(nvc) - 1 >= 0) {
    c_loop_ub = gent.size(1);
  }
  for (int ii{0}; ii < i; ii++) {
    int trueCount;
    int wbias;
    tb.set_size(1, gent.size(1));
    scalarLB = (c_loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&gent[i1]);
      _mm_storeu_pd(&tb[i1], _mm_mul_pd(r, _mm_set1_pd(mpv)));
    }
    for (int i1{scalarLB}; i1 < c_loop_ub; i1++) {
      tb[i1] = gent[i1] * mpv;
    }
    b_loop_ub = tb.size(1);
    y.set_size(1, tb.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(tb[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        trueCount++;
      }
    }
    r1.set_size(1, trueCount);
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        r1[scalarLB] = wbias;
        scalarLB++;
      }
    }
    b_loop_ub = r1.size(1);
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wd2[i1] = tb[r1[i1]] / t0 / mu;
    }
    wd1.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = wd2[i1];
      wd1[i1] = -3.1415926535897931 * rt_powd_snf(wl, 2.0);
    }
    y.set_size(1, r1.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      wd1[scalarLB] = std::exp(wd1[scalarLB]);
      y[scalarLB] = std::abs(wd2[scalarLB]);
    }
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = 1.0 - y[i1];
      wd2[i1] = std::fmax(0.0, wl);
    }
    b_loop_ub = wd2.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        trueCount++;
      }
    }
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        wd2[scalarLB] = wd2[wbias];
        scalarLB++;
      }
    }
    wd2.set_size(1, trueCount);
    legacy_STRAIGHT::conv(wd2, wd1, wwd);
    b_loop_ub = wwd.size(1);
    y.set_size(1, wwd.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(wwd[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] > 1.0E-5) {
        vectorUB = trueCount + 1;
        trueCount++;
        wwd[scalarLB] = wwd[wbias];
        scalarLB = vectorUB;
      }
    }
    wwd.set_size(1, trueCount);
    wbias = static_cast<int>(
        std::round((static_cast<double>(trueCount) - 1.0) / 2.0));
    if (trueCount < 1) {
      y.set_size(y.size(0), 0);
    } else {
      y.set_size(1, trueCount);
      b_loop_ub = trueCount - 1;
      for (int i1{0}; i1 <= b_loop_ub; i1++) {
        y[i1] = static_cast<double>(i1) + 1.0;
      }
    }
    y.set_size(1, y.size(1));
    wl = static_cast<double>(r1.size(1)) / 2.0;
    b_loop_ub = y.size(1) - 1;
    scalarLB = (y.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&y[i1]);
      _mm_storeu_pd(
          &y[i1],
          _mm_add_pd(_mm_sub_pd(r, _mm_set1_pd(static_cast<double>(wbias))),
                     _mm_set1_pd(wl)));
    }
    for (int i1{scalarLB}; i1 <= b_loop_ub; i1++) {
      y[i1] = (y[i1] - static_cast<double>(wbias)) + wl;
    }
    b_loop_ub = y.size(1);
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::round(y[scalarLB]);
    }
    r2.set_size(1, y.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      double ar;
      wl = tb[r1[static_cast<int>(y[i1]) - 1]];
      ar = 0.0 * wl;
      wl *= 18.849555921538759;
      if (wl == 0.0) {
        r2[i1].re = ar / t0;
        r2[i1].im = 0.0;
      } else if (ar == 0.0) {
        r2[i1].re = 0.0;
        r2[i1].im = wl / t0;
      } else {
        r2[i1].re = rtNaN;
        r2[i1].im = wl / t0;
      }
    }
    legacy_STRAIGHT::b_exp(r2);
    if (trueCount == r2.size(1)) {
      b_wwd.set_size(1, trueCount);
      for (int i1{0}; i1 < trueCount; i1++) {
        b_wwd[i1].re = wwd[i1] * r2[i1].re;
        b_wwd[i1].im = wwd[i1] * r2[i1].im;
      }
      legacy_STRAIGHT::fftfilt(b_wwd, tx, pmtmp1);
    } else {
      binary_expand_op_26(pmtmp1, wwd, r2, tx);
    }
    if (static_cast<double>(wbias) + 1.0 >
        static_cast<double>(wbias) + static_cast<double>(x.size(1))) {
      wbias = 0;
    }
    wl = std::sqrt(mpv);
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_loop_ub = wbias + i1;
      pm[ii + pm.size(0) * i1].re = wl * pmtmp1[b_loop_ub].re;
      pm[ii + pm.size(0) * i1].im = wl * pmtmp1[b_loop_ub].im;
    }
    mpv *= rt_powd_snf(2.0, 1.0 / nvo);
    // if imgi==1; waitbar(ii/nvc); end; %,hpg);% 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end; % 07/Dec./2002 by H.K.%10/Aug./2005
}

void c_multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs,
                          double f0floor, double nvc, double nvo, double mu,
                          coder::array<creal_T, 2U> &pm)
{
  __m128d r;
  coder::array<creal_T, 2U> b_wwd;
  coder::array<creal_T, 2U> pmtmp1;
  coder::array<creal_T, 2U> r2;
  coder::array<creal_T, 2U> tx;
  coder::array<double, 2U> gent;
  coder::array<double, 2U> tb;
  coder::array<double, 2U> wd1;
  coder::array<double, 2U> wd2;
  coder::array<double, 2U> wwd;
  coder::array<double, 2U> y;
  coder::array<int, 2U> r1;
  double mpv;
  double t0;
  double wl;
  int b_loop_ub;
  int c_loop_ub;
  int i;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  //        Dual waveleta analysis using cardinal spline manipulation
  //                pm=multanalytFineCSPB(x,fs,f0floor,nvc,nvo,mu,mlt)
  //        Input parameters
  //
  //                x       : input signal (2kHz sampling rate is sufficient.)
  //                fs      : sampling frequency (Hz)
  //                f0floor : lower bound for pitch search (60Hz suggested)
  //                nvc     : number of total voices for wavelet analysis
  //                nvo     : number of voices in an octave
  // 				mu		: temporal stretch factor
  // 				mlt		: harmonic ID#
  // 				imgi	: display indicator, 1: dispaly on (default), 0: display
  // off
  //        Outpur parameters
  //                pm      : wavelet transform using iso-metric Gabor function
  //
  //        If you have any questions,  mailto:kawahara@hip.atr.co.jp
  //
  //        Copyright (c) ATR Human Information Processing Research Labs. 1996
  //        Invented and coded by Hideki Kawahara
  //        30/Oct./1996
  //        07/Dec./2002 waitbar was added
  // 		10/Aug./2005 modified by Takahashi on waitbar
  // 		10/Sept./2005 modified by Kawahara on waitbar
  // 10/Sept./2005
  t0 = 1.0 / f0floor;
  wl = rt_powd_snf(2.0, std::ceil(std::log(std::round(6.0 * t0 * fs * mu)) /
                                  0.69314718055994529));
  loop_ub = x.size(1);
  tx.set_size(1, x.size(1));
  for (i = 0; i < loop_ub; i++) {
    tx[i].re = x[i].re;
    tx[i].im = -x[i].im;
  }
  x.set_size(1, loop_ub);
  for (i = 0; i < loop_ub; i++) {
    x[i] = tx[i];
  }
  tx.set_size(1, x.size(1) + static_cast<int>(wl));
  for (i = 0; i < loop_ub; i++) {
    tx[i] = x[i];
  }
  b_loop_ub = static_cast<int>(wl);
  for (i = 0; i < b_loop_ub; i++) {
    tx[i + x.size(1)].re = 0.0;
    tx[i + x.size(1)].im = 0.0;
  }
  if (wl < 1.0) {
    gent.set_size(gent.size(0), 0);
  } else {
    gent.set_size(1, static_cast<int>(wl - 1.0) + 1);
    b_loop_ub = static_cast<int>(wl - 1.0);
    for (i = 0; i <= b_loop_ub; i++) {
      gent[i] = static_cast<double>(i) + 1.0;
    }
  }
  gent.set_size(1, gent.size(1));
  wl /= 2.0;
  b_loop_ub = gent.size(1) - 1;
  scalarLB = (gent.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&gent[i]);
    _mm_storeu_pd(&gent[i],
                  _mm_div_pd(_mm_sub_pd(r, _mm_set1_pd(wl)), _mm_set1_pd(fs)));
  }
  for (i = scalarLB; i <= b_loop_ub; i++) {
    gent[i] = (gent[i] - wl) / fs;
  }
  i = static_cast<int>(nvc);
  pm.set_size(i, loop_ub);
  b_loop_ub = static_cast<int>(nvc) * x.size(1);
  for (int i1{0}; i1 < b_loop_ub; i1++) {
    pm[i1].re = 0.0;
    pm[i1].im = 0.0;
  }
  mpv = 1.0;
  // if imgi==1; hpg=waitbar(0,['wavelet analysis for initial F0 ' ...
  //     'and P/N estimation with HM#:' num2str(mlt)]); end; % 07/Dec./2002 by
  //     H.K.%10/Aug./2005
  if (static_cast<int>(nvc) - 1 >= 0) {
    c_loop_ub = gent.size(1);
  }
  for (int ii{0}; ii < i; ii++) {
    int trueCount;
    int wbias;
    tb.set_size(1, gent.size(1));
    scalarLB = (c_loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&gent[i1]);
      _mm_storeu_pd(&tb[i1], _mm_mul_pd(r, _mm_set1_pd(mpv)));
    }
    for (int i1{scalarLB}; i1 < c_loop_ub; i1++) {
      tb[i1] = gent[i1] * mpv;
    }
    b_loop_ub = tb.size(1);
    y.set_size(1, tb.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(tb[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        trueCount++;
      }
    }
    r1.set_size(1, trueCount);
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        r1[scalarLB] = wbias;
        scalarLB++;
      }
    }
    b_loop_ub = r1.size(1);
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wd2[i1] = tb[r1[i1]] / t0 / mu;
    }
    wd1.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = wd2[i1];
      wd1[i1] = -3.1415926535897931 * rt_powd_snf(wl, 2.0);
    }
    y.set_size(1, r1.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      wd1[scalarLB] = std::exp(wd1[scalarLB]);
      y[scalarLB] = std::abs(wd2[scalarLB]);
    }
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = 1.0 - y[i1];
      wd2[i1] = std::fmax(0.0, wl);
    }
    b_loop_ub = wd2.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        trueCount++;
      }
    }
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        wd2[scalarLB] = wd2[wbias];
        scalarLB++;
      }
    }
    wd2.set_size(1, trueCount);
    legacy_STRAIGHT::conv(wd2, wd1, wwd);
    b_loop_ub = wwd.size(1);
    y.set_size(1, wwd.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(wwd[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] > 1.0E-5) {
        vectorUB = trueCount + 1;
        trueCount++;
        wwd[scalarLB] = wwd[wbias];
        scalarLB = vectorUB;
      }
    }
    wwd.set_size(1, trueCount);
    wbias = static_cast<int>(
        std::round((static_cast<double>(trueCount) - 1.0) / 2.0));
    if (trueCount < 1) {
      y.set_size(y.size(0), 0);
    } else {
      y.set_size(1, trueCount);
      b_loop_ub = trueCount - 1;
      for (int i1{0}; i1 <= b_loop_ub; i1++) {
        y[i1] = static_cast<double>(i1) + 1.0;
      }
    }
    y.set_size(1, y.size(1));
    wl = static_cast<double>(r1.size(1)) / 2.0;
    b_loop_ub = y.size(1) - 1;
    scalarLB = (y.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&y[i1]);
      _mm_storeu_pd(
          &y[i1],
          _mm_add_pd(_mm_sub_pd(r, _mm_set1_pd(static_cast<double>(wbias))),
                     _mm_set1_pd(wl)));
    }
    for (int i1{scalarLB}; i1 <= b_loop_ub; i1++) {
      y[i1] = (y[i1] - static_cast<double>(wbias)) + wl;
    }
    b_loop_ub = y.size(1);
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::round(y[scalarLB]);
    }
    r2.set_size(1, y.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      double ar;
      wl = tb[r1[static_cast<int>(y[i1]) - 1]];
      ar = 0.0 * wl;
      wl *= 12.566370614359172;
      if (wl == 0.0) {
        r2[i1].re = ar / t0;
        r2[i1].im = 0.0;
      } else if (ar == 0.0) {
        r2[i1].re = 0.0;
        r2[i1].im = wl / t0;
      } else {
        r2[i1].re = rtNaN;
        r2[i1].im = wl / t0;
      }
    }
    legacy_STRAIGHT::b_exp(r2);
    if (trueCount == r2.size(1)) {
      b_wwd.set_size(1, trueCount);
      for (int i1{0}; i1 < trueCount; i1++) {
        b_wwd[i1].re = wwd[i1] * r2[i1].re;
        b_wwd[i1].im = wwd[i1] * r2[i1].im;
      }
      legacy_STRAIGHT::fftfilt(b_wwd, tx, pmtmp1);
    } else {
      binary_expand_op_26(pmtmp1, wwd, r2, tx);
    }
    if (static_cast<double>(wbias) + 1.0 >
        static_cast<double>(wbias) + static_cast<double>(x.size(1))) {
      wbias = 0;
    }
    wl = std::sqrt(mpv);
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_loop_ub = wbias + i1;
      pm[ii + pm.size(0) * i1].re = wl * pmtmp1[b_loop_ub].re;
      pm[ii + pm.size(0) * i1].im = wl * pmtmp1[b_loop_ub].im;
    }
    mpv *= rt_powd_snf(2.0, 1.0 / nvo);
    // if imgi==1; waitbar(ii/nvc); end; %,hpg);% 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end; % 07/Dec./2002 by H.K.%10/Aug./2005
}

void multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs, double f0floor,
                        double nvc, double nvo, double mu,
                        coder::array<creal_T, 2U> &pm)
{
  __m128d r;
  coder::array<creal_T, 2U> b_wwd;
  coder::array<creal_T, 2U> pmtmp1;
  coder::array<creal_T, 2U> r2;
  coder::array<creal_T, 2U> tx;
  coder::array<double, 2U> gent;
  coder::array<double, 2U> tb;
  coder::array<double, 2U> wd1;
  coder::array<double, 2U> wd2;
  coder::array<double, 2U> wwd;
  coder::array<double, 2U> y;
  coder::array<int, 2U> r1;
  double mpv;
  double t0;
  double wl;
  int b_loop_ub;
  int c_loop_ub;
  int i;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  //        Dual waveleta analysis using cardinal spline manipulation
  //                pm=multanalytFineCSPB(x,fs,f0floor,nvc,nvo,mu,mlt)
  //        Input parameters
  //
  //                x       : input signal (2kHz sampling rate is sufficient.)
  //                fs      : sampling frequency (Hz)
  //                f0floor : lower bound for pitch search (60Hz suggested)
  //                nvc     : number of total voices for wavelet analysis
  //                nvo     : number of voices in an octave
  // 				mu		: temporal stretch factor
  // 				mlt		: harmonic ID#
  // 				imgi	: display indicator, 1: dispaly on (default), 0: display
  // off
  //        Outpur parameters
  //                pm      : wavelet transform using iso-metric Gabor function
  //
  //        If you have any questions,  mailto:kawahara@hip.atr.co.jp
  //
  //        Copyright (c) ATR Human Information Processing Research Labs. 1996
  //        Invented and coded by Hideki Kawahara
  //        30/Oct./1996
  //        07/Dec./2002 waitbar was added
  // 		10/Aug./2005 modified by Takahashi on waitbar
  // 		10/Sept./2005 modified by Kawahara on waitbar
  // 10/Sept./2005
  t0 = 1.0 / f0floor;
  wl = rt_powd_snf(2.0, std::ceil(std::log(std::round(6.0 * t0 * fs * mu)) /
                                  0.69314718055994529));
  loop_ub = x.size(1);
  tx.set_size(1, x.size(1));
  for (i = 0; i < loop_ub; i++) {
    tx[i].re = x[i].re;
    tx[i].im = -x[i].im;
  }
  x.set_size(1, loop_ub);
  for (i = 0; i < loop_ub; i++) {
    x[i] = tx[i];
  }
  tx.set_size(1, x.size(1) + static_cast<int>(wl));
  for (i = 0; i < loop_ub; i++) {
    tx[i] = x[i];
  }
  b_loop_ub = static_cast<int>(wl);
  for (i = 0; i < b_loop_ub; i++) {
    tx[i + x.size(1)].re = 0.0;
    tx[i + x.size(1)].im = 0.0;
  }
  if (wl < 1.0) {
    gent.set_size(gent.size(0), 0);
  } else {
    gent.set_size(1, static_cast<int>(wl - 1.0) + 1);
    b_loop_ub = static_cast<int>(wl - 1.0);
    for (i = 0; i <= b_loop_ub; i++) {
      gent[i] = static_cast<double>(i) + 1.0;
    }
  }
  gent.set_size(1, gent.size(1));
  wl /= 2.0;
  b_loop_ub = gent.size(1) - 1;
  scalarLB = (gent.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&gent[i]);
    _mm_storeu_pd(&gent[i],
                  _mm_div_pd(_mm_sub_pd(r, _mm_set1_pd(wl)), _mm_set1_pd(fs)));
  }
  for (i = scalarLB; i <= b_loop_ub; i++) {
    gent[i] = (gent[i] - wl) / fs;
  }
  i = static_cast<int>(nvc);
  pm.set_size(i, loop_ub);
  b_loop_ub = static_cast<int>(nvc) * x.size(1);
  for (int i1{0}; i1 < b_loop_ub; i1++) {
    pm[i1].re = 0.0;
    pm[i1].im = 0.0;
  }
  mpv = 1.0;
  // if imgi==1; hpg=waitbar(0,['wavelet analysis for initial F0 ' ...
  //     'and P/N estimation with HM#:' num2str(mlt)]); end; % 07/Dec./2002 by
  //     H.K.%10/Aug./2005
  if (static_cast<int>(nvc) - 1 >= 0) {
    c_loop_ub = gent.size(1);
  }
  for (int ii{0}; ii < i; ii++) {
    int trueCount;
    int wbias;
    tb.set_size(1, gent.size(1));
    scalarLB = (c_loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&gent[i1]);
      _mm_storeu_pd(&tb[i1], _mm_mul_pd(r, _mm_set1_pd(mpv)));
    }
    for (int i1{scalarLB}; i1 < c_loop_ub; i1++) {
      tb[i1] = gent[i1] * mpv;
    }
    b_loop_ub = tb.size(1);
    y.set_size(1, tb.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(tb[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        trueCount++;
      }
    }
    r1.set_size(1, trueCount);
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] < 3.5 * mu * t0) {
        r1[scalarLB] = wbias;
        scalarLB++;
      }
    }
    b_loop_ub = r1.size(1);
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wd2[i1] = tb[r1[i1]] / t0 / mu;
    }
    wd1.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = wd2[i1];
      wd1[i1] = -3.1415926535897931 * rt_powd_snf(wl, 2.0);
    }
    y.set_size(1, r1.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      wd1[scalarLB] = std::exp(wd1[scalarLB]);
      y[scalarLB] = std::abs(wd2[scalarLB]);
    }
    wd2.set_size(1, r1.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      wl = 1.0 - y[i1];
      wd2[i1] = std::fmax(0.0, wl);
    }
    b_loop_ub = wd2.size(1) - 1;
    trueCount = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        trueCount++;
      }
    }
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (wd2[wbias] > 0.0) {
        wd2[scalarLB] = wd2[wbias];
        scalarLB++;
      }
    }
    wd2.set_size(1, trueCount);
    legacy_STRAIGHT::conv(wd2, wd1, wwd);
    b_loop_ub = wwd.size(1);
    y.set_size(1, wwd.size(1));
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::abs(wwd[scalarLB]);
    }
    b_loop_ub = y.size(1) - 1;
    trueCount = 0;
    scalarLB = 0;
    for (wbias = 0; wbias <= b_loop_ub; wbias++) {
      if (y[wbias] > 1.0E-5) {
        vectorUB = trueCount + 1;
        trueCount++;
        wwd[scalarLB] = wwd[wbias];
        scalarLB = vectorUB;
      }
    }
    wwd.set_size(1, trueCount);
    wbias = static_cast<int>(
        std::round((static_cast<double>(trueCount) - 1.0) / 2.0));
    if (trueCount < 1) {
      y.set_size(y.size(0), 0);
    } else {
      y.set_size(1, trueCount);
      b_loop_ub = trueCount - 1;
      for (int i1{0}; i1 <= b_loop_ub; i1++) {
        y[i1] = static_cast<double>(i1) + 1.0;
      }
    }
    y.set_size(1, y.size(1));
    wl = static_cast<double>(r1.size(1)) / 2.0;
    b_loop_ub = y.size(1) - 1;
    scalarLB = (y.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&y[i1]);
      _mm_storeu_pd(
          &y[i1],
          _mm_add_pd(_mm_sub_pd(r, _mm_set1_pd(static_cast<double>(wbias))),
                     _mm_set1_pd(wl)));
    }
    for (int i1{scalarLB}; i1 <= b_loop_ub; i1++) {
      y[i1] = (y[i1] - static_cast<double>(wbias)) + wl;
    }
    b_loop_ub = y.size(1);
    for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
      y[scalarLB] = std::round(y[scalarLB]);
    }
    r2.set_size(1, y.size(1));
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      double ar;
      wl = tb[r1[static_cast<int>(y[i1]) - 1]];
      ar = 0.0 * wl;
      wl *= 6.2831853071795862;
      if (wl == 0.0) {
        r2[i1].re = ar / t0;
        r2[i1].im = 0.0;
      } else if (ar == 0.0) {
        r2[i1].re = 0.0;
        r2[i1].im = wl / t0;
      } else {
        r2[i1].re = rtNaN;
        r2[i1].im = wl / t0;
      }
    }
    legacy_STRAIGHT::b_exp(r2);
    if (trueCount == r2.size(1)) {
      b_wwd.set_size(1, trueCount);
      for (int i1{0}; i1 < trueCount; i1++) {
        b_wwd[i1].re = wwd[i1] * r2[i1].re;
        b_wwd[i1].im = wwd[i1] * r2[i1].im;
      }
      legacy_STRAIGHT::fftfilt(b_wwd, tx, pmtmp1);
    } else {
      binary_expand_op_26(pmtmp1, wwd, r2, tx);
    }
    if (static_cast<double>(wbias) + 1.0 >
        static_cast<double>(wbias) + static_cast<double>(x.size(1))) {
      wbias = 0;
    }
    wl = std::sqrt(mpv);
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_loop_ub = wbias + i1;
      pm[ii + pm.size(0) * i1].re = wl * pmtmp1[b_loop_ub].re;
      pm[ii + pm.size(0) * i1].im = wl * pmtmp1[b_loop_ub].im;
    }
    mpv *= rt_powd_snf(2.0, 1.0 / nvo);
    // if imgi==1; waitbar(ii/nvc); end; %,hpg);% 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end; % 07/Dec./2002 by H.K.%10/Aug./2005
}

// End of code generation (multanalytFineCSPB.cpp)
