//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// boundmes2.h
//
// Code generation for function 'boundmes2'
//

#ifndef BOUNDMES2_H
#define BOUNDMES2_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_1(coder::array<double, 2U> &in1, int in2,
                        const coder::array<double, 2U> &in3, double in4,
                        const coder::array<double, 2U> &in5,
                        const coder::array<double, 2U> &in6,
                        const coder::array<double, 2U> &in7,
                        const coder::array<double, 1U> &in8);

void binary_expand_op_4(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2,
                        const coder::array<double, 2U> &in3);

#endif
// End of code generation (boundmes2.h)
