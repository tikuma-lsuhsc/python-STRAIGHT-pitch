//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fft.cpp
//
// Code generation for function 'fft'
//

// Include files
#include "fft.h"
#include "FFTImplementationCallback.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>
#include <cstring>

// Function Definitions
namespace legacy_STRAIGHT {
void fft(const creal_T x_data[], const int x_size[2], double varargin_1,
         creal_T y_data[], int y_size[2])
{
  ::coder::array<creal_T, 1U> b_x_data;
  ::coder::array<creal_T, 1U> c_x_data;
  ::coder::array<creal_T, 1U> y;
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  creal_T b_y_data[77];
  int nRows;
  if ((x_size[1] == 0) || (static_cast<int>(varargin_1) == 0)) {
    int N2blue;
    N2blue = static_cast<int>(varargin_1);
    nRows = static_cast<int>(varargin_1);
    if (N2blue - 1 >= 0) {
      std::memset(&b_y_data[0], 0,
                  static_cast<unsigned int>(N2blue) * sizeof(creal_T));
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        static_cast<int>(varargin_1), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      c_x_data.set((creal_T *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          c_x_data, static_cast<int>(varargin_1), costab, sintab, y);
    } else {
      b_x_data.set((creal_T *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          b_x_data, N2blue, static_cast<int>(varargin_1), costab, sintab,
          sintabinv, y);
    }
    N2blue = static_cast<int>(varargin_1);
    nRows = static_cast<int>(varargin_1);
    for (int i{0}; i < N2blue; i++) {
      b_y_data[i] = y[i];
    }
  }
  y_size[0] = 1;
  y_size[1] = nRows;
  if (nRows - 1 >= 0) {
    std::copy(&b_y_data[0], &b_y_data[nRows], &y_data[0]);
  }
}

void fft(const creal_T x_data[], const int x_size[2], creal_T y_data[],
         int y_size[2])
{
  ::coder::array<creal_T, 1U> b_x_data;
  ::coder::array<creal_T, 1U> c_x_data;
  ::coder::array<creal_T, 1U> y;
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if (x_size[1] == 0) {
    y_size[0] = 1;
    y_size[1] = 0;
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x_size[1] & (x_size[1] - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x_size[1], useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      c_x_data.set((creal_T *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          c_x_data, x_size[1], costab, sintab, y);
    } else {
      b_x_data.set((creal_T *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          b_x_data, N2blue, x_size[1], costab, sintab, sintabinv, y);
    }
    y_size[0] = 1;
    N2blue = x_size[1];
    y_size[1] = x_size[1];
    for (nRows = 0; nRows < N2blue; nRows++) {
      y_data[nRows] = y[nRows];
    }
  }
}

void fft(const double x_data[], const int x_size[2], double varargin_1,
         creal_T y_data[], int y_size[2])
{
  ::coder::array<creal_T, 1U> y;
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  ::coder::array<double, 1U> b_x_data;
  ::coder::array<double, 1U> c_x_data;
  creal_T b_y_data[77];
  int nRows;
  if ((x_size[1] == 0) || (static_cast<int>(varargin_1) == 0)) {
    int N2blue;
    N2blue = static_cast<int>(varargin_1);
    nRows = static_cast<int>(varargin_1);
    if (N2blue - 1 >= 0) {
      std::memset(&b_y_data[0], 0,
                  static_cast<unsigned int>(N2blue) * sizeof(creal_T));
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        static_cast<int>(varargin_1), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      c_x_data.set((double *)&x_data[0], x_size[1]);
      N2blue = static_cast<int>(varargin_1);
      y.set_size(N2blue);
      if (static_cast<int>(varargin_1) > c_x_data.size(0)) {
        y.set_size(N2blue);
        for (int i{0}; i < N2blue; i++) {
          y[i].re = 0.0;
          y[i].im = 0.0;
        }
      }
      if (static_cast<int>(varargin_1) != 1) {
        coder::internal::fft::FFTImplementationCallback::doHalfLengthRadix2(
            c_x_data, y, static_cast<int>(varargin_1), costab, sintab);
      } else {
        y[0].re = c_x_data[0];
        y[0].im = 0.0;
      }
    } else {
      b_x_data.set((double *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          b_x_data, N2blue, static_cast<int>(varargin_1), costab, sintab,
          sintabinv, y);
    }
    N2blue = static_cast<int>(varargin_1);
    nRows = static_cast<int>(varargin_1);
    for (int i{0}; i < N2blue; i++) {
      b_y_data[i] = y[i];
    }
  }
  y_size[0] = 1;
  y_size[1] = nRows;
  if (nRows - 1 >= 0) {
    std::copy(&b_y_data[0], &b_y_data[nRows], &y_data[0]);
  }
}

void fft(const double x_data[], const int x_size[2], creal_T y_data[],
         int y_size[2])
{
  ::coder::array<creal_T, 1U> y;
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  ::coder::array<double, 1U> b_x_data;
  ::coder::array<double, 1U> c_x_data;
  int nRows;
  if (x_size[1] == 0) {
    y_size[0] = 1;
    y_size[1] = 0;
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x_size[1] & (x_size[1] - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x_size[1], useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      c_x_data.set((double *)&x_data[0], x_size[1]);
      N2blue = x_size[1];
      y.set_size(x_size[1]);
      if (x_size[1] > c_x_data.size(0)) {
        y.set_size(x_size[1]);
        for (nRows = 0; nRows < N2blue; nRows++) {
          y[nRows].re = 0.0;
          y[nRows].im = 0.0;
        }
      }
      if (x_size[1] != 1) {
        coder::internal::fft::FFTImplementationCallback::doHalfLengthRadix2(
            c_x_data, y, x_size[1], costab, sintab);
      } else {
        y[0].re = c_x_data[0];
        y[0].im = 0.0;
      }
    } else {
      b_x_data.set((double *)&x_data[0], x_size[1]);
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          b_x_data, N2blue, x_size[1], costab, sintab, sintabinv, y);
    }
    y_size[0] = 1;
    N2blue = x_size[1];
    y_size[1] = x_size[1];
    for (nRows = 0; nRows < N2blue; nRows++) {
      y_data[nRows] = y[nRows];
    }
  }
}

void fft(const ::coder::array<creal_T, 2U> &x, double varargin_1,
         ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0) ||
      (static_cast<int>(varargin_1) == 0)) {
    int N2blue;
    y.set_size(static_cast<int>(varargin_1), x.size(1));
    N2blue = static_cast<int>(varargin_1) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        static_cast<int>(varargin_1), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::b_r2br_r2dit_trig(
          x, static_cast<int>(varargin_1), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::b_dobluesteinfft(
          x, N2blue, static_cast<int>(varargin_1), costab, sintab, sintabinv,
          y);
    }
  }
}

void fft(const ::coder::array<double, 2U> &x, double varargin_1,
         ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0) ||
      (static_cast<int>(varargin_1) == 0)) {
    int N2blue;
    y.set_size(static_cast<int>(varargin_1), x.size(1));
    N2blue = static_cast<int>(varargin_1) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        static_cast<int>(varargin_1), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig(
          x, static_cast<int>(varargin_1), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          x, N2blue, static_cast<int>(varargin_1), costab, sintab, sintabinv,
          y);
    }
  }
}

void fft(const ::coder::array<creal_T, 2U> &x, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int N2blue;
    y.set_size(x.size(0), x.size(1));
    N2blue = x.size(0) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x.size(0) & (x.size(0) - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x.size(0), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::b_r2br_r2dit_trig(
          x, x.size(0), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::b_dobluesteinfft(
          x, N2blue, x.size(0), costab, sintab, sintabinv, y);
    }
  }
}

void fft(const ::coder::array<double, 2U> &x, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int N2blue;
    y.set_size(x.size(0), x.size(1));
    N2blue = x.size(0) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x.size(0) & (x.size(0) - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x.size(0), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig(
          x, x.size(0), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          x, N2blue, x.size(0), costab, sintab, sintabinv, y);
    }
  }
}

void fft(const ::coder::array<double, 1U> &x, double varargin_1,
         ::coder::array<creal_T, 1U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (static_cast<int>(varargin_1) == 0)) {
    int N2blue;
    N2blue = static_cast<int>(varargin_1);
    y.set_size(static_cast<int>(varargin_1));
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        static_cast<int>(varargin_1), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig(
          x, static_cast<int>(varargin_1), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          x, N2blue, static_cast<int>(varargin_1), costab, sintab, sintabinv,
          y);
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (fft.cpp)
