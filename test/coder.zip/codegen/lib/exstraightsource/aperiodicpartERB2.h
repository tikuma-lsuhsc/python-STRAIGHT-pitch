//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// aperiodicpartERB2.h
//
// Code generation for function 'aperiodicpartERB2'
//

#ifndef APERIODICPARTERB2_H
#define APERIODICPARTERB2_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void aperiodicpartERB2(const coder::array<double, 1U> &x, double fs,
                       coder::array<double, 2U> &f0, double shiftm,
                       double intshiftm, double mm,
                       coder::array<double, 2U> &apv,
                       coder::array<double, 2U> &dpv,
                       coder::array<double, 2U> &apve,
                       coder::array<double, 2U> &dpve);

#endif
// End of code generation (aperiodicpartERB2.h)
