//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// f0track5.cpp
//
// Code generation for function 'f0track5'
//

// Include files
#include "f0track5.h"
#include "div.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Definitions
void f0track5(const coder::array<double, 2U> &f0v,
              const coder::array<double, 2U> &vrv,
              const coder::array<double, 2U> &dfv,
              const coder::array<creal_T, 2U> &pwt,
              const coder::array<creal_T, 2U> &pwh,
              const coder::array<double, 2U> &aav, double shiftm,
              coder::array<double, 2U> &f0, coder::array<double, 2U> &irms,
              coder::array<double, 2U> &df, coder::array<double, 2U> &amp)
{
  __m128d r;
  coder::array<creal_T, 2U> htr;
  coder::array<double, 2U> ex;
  coder::array<double, 2U> x;
  coder::array<double, 1U> b_x;
  coder::array<double, 1U> varargin_1;
  coder::array<int, 2U> idx;
  double ar;
  double bi;
  double bkls;
  double brm;
  double f0ref;
  double ii;
  double lals;
  double thf0j;
  int b_i;
  int i;
  int m;
  int mm;
  int scalarLB;
  int vectorUB;
  int von;
  // 	F0 trajectory tracker
  // 	[f0,irms,df,amp]=f0track2(f0v,vrv,dfv,shiftm,imgi)
  // 		f0	: extracted F0 (Hz)
  // 		irms	: relative interfering energy in rms
  //
  // 	f0v	: fixed point frequency vector
  // 	vrv	: relative interfering energy vector
  // 	dfv	: fixed point slope vector
  // 	pwt	: total power
  // 	pwh	: power in higher frequency range
  // 	aav	: amplitude list for fixed points
  // 	shiftm	: frame update period (ms)
  // 	imgi	: display indicator, 1: display on (default), 0: off
  //
  // 	This is a very primitive and conventional algorithm.
  // 	coded by Hideki Kawahara
  // 	copyright(c) Wakayama University/CREST/ATR
  // 	10/April/1999 first version
  // 	17/May/1999 relative fq jump thresholding
  // 	01/August/1999 parameter tweeking
  //    07/Dec./2002 waitbar was added
  //    13/Jan./2005 bug fix on lines 58, 97 (Thanx Ishikasa-san)
  // 	30/April/2005 modification for Matlab v7.0 compatibility
  // 	10/Aug./2005 modified  by Takahashi on waitbar
  // 	10/Sept./2005 modified by Kawahara on waitbar
  // 10/Sept./2005
  x.set_size(vrv.size(0), vrv.size(1));
  m = vrv.size(0) * vrv.size(1);
  for (i = 0; i < m; i++) {
    x[i] = vrv[i];
  }
  scalarLB = (m / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int k{0}; k <= vectorUB; k += 2) {
    r = _mm_loadu_pd(&x[k]);
    _mm_storeu_pd(&x[k], _mm_sqrt_pd(r));
  }
  for (int k{scalarLB}; k < m; k++) {
    x[k] = std::sqrt(x[k]);
  }
  mm = static_cast<int>(std::fmin(static_cast<double>(x.size(1)),
                                  static_cast<double>(pwt.size(1))));
  f0.set_size(1, mm);
  irms.set_size(1, mm);
  df.set_size(1, mm);
  amp.set_size(1, mm);
  for (i = 0; i < mm; i++) {
    f0[i] = 0.0;
    irms[i] = 1.0;
    df[i] = 1.0;
    amp[i] = 0.0;
  }
  von = 0;
  m = x.size(0);
  scalarLB = x.size(1);
  ex.set_size(1, x.size(1));
  idx.set_size(1, x.size(1));
  for (i = 0; i < scalarLB; i++) {
    idx[i] = 1;
  }
  if (x.size(1) >= 1) {
    for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
      ex[vectorUB] = x[x.size(0) * vectorUB];
      for (b_i = 2; b_i <= m; b_i++) {
        boolean_T p;
        thf0j = ex[vectorUB];
        ii = x[(b_i + x.size(0) * vectorUB) - 1];
        if (std::isnan(ii)) {
          p = false;
        } else if (std::isnan(thf0j)) {
          p = true;
        } else {
          p = (thf0j > ii);
        }
        if (p) {
          ex[vectorUB] = ii;
          idx[vectorUB] = b_i;
        }
      }
    }
  }
  //  highly confident voiced threshould (updated on 01/August/1999)
  //  threshold to loose confidence
  //  back track length for voicing decision
  //  look ahead length for silence decision
  bkls = 100.0 / shiftm;
  lals = 10.0 / shiftm;
  if (pwh.size(1) == pwt.size(1)) {
    m = pwh.size(1);
    htr.set_size(1, pwh.size(1));
    for (i = 0; i < m; i++) {
      double ai;
      ar = pwh[i].re;
      ai = pwh[i].im;
      f0ref = pwt[i].re;
      bi = pwt[i].im;
      if (bi == 0.0) {
        if (ai == 0.0) {
          htr[i].re = ar / f0ref;
          htr[i].im = 0.0;
        } else if (ar == 0.0) {
          htr[i].re = 0.0;
          htr[i].im = ai / f0ref;
        } else {
          htr[i].re = ar / f0ref;
          htr[i].im = ai / f0ref;
        }
      } else if (f0ref == 0.0) {
        if (ar == 0.0) {
          htr[i].re = ai / bi;
          htr[i].im = 0.0;
        } else if (ai == 0.0) {
          htr[i].re = 0.0;
          htr[i].im = -(ar / bi);
        } else {
          htr[i].re = ai / bi;
          htr[i].im = -(ar / bi);
        }
      } else {
        brm = std::abs(f0ref);
        thf0j = std::abs(bi);
        if (brm > thf0j) {
          ii = bi / f0ref;
          thf0j = f0ref + ii * bi;
          htr[i].re = (ar + ii * ai) / thf0j;
          htr[i].im = (ai - ii * ar) / thf0j;
        } else if (thf0j == brm) {
          if (f0ref > 0.0) {
            ii = 0.5;
          } else {
            ii = -0.5;
          }
          if (bi > 0.0) {
            thf0j = 0.5;
          } else {
            thf0j = -0.5;
          }
          htr[i].re = (ar * ii + ai * thf0j) / brm;
          htr[i].im = (ai * ii - ar * thf0j) / brm;
        } else {
          ii = f0ref / bi;
          thf0j = bi + ii * f0ref;
          htr[i].re = (ii * ar + ai) / thf0j;
          htr[i].im = (ii * ai - ar) / thf0j;
        }
      }
    }
  } else {
    rdivide(htr, pwh, pwt);
  }
  m = htr.size(1);
  for (int k{0}; k < m; k++) {
    if (htr[k].im == 0.0) {
      if (htr[k].re < 0.0) {
        htr[k].re = std::log10(std::abs(htr[k].re));
        htr[k].im = 1.3643763538418412;
      } else {
        htr[k].re = std::log10(std::abs(htr[k].re));
        htr[k].im = 0.0;
      }
    } else if ((std::abs(htr[k].re) > 8.9884656743115785E+307) ||
               (std::abs(htr[k].im) > 8.9884656743115785E+307)) {
      thf0j = htr[k].re;
      ii = htr[k].im;
      htr[k].re =
          std::log10(rt_hypotd_snf(thf0j / 2.0, ii / 2.0)) + 0.3010299956639812;
      htr[k].im = rt_atan2d_snf(ii, thf0j) / 2.3025850929940459;
    } else {
      thf0j = htr[k].re;
      ii = htr[k].im;
      htr[k].re = std::log10(rt_hypotd_snf(thf0j, ii));
      htr[k].im = rt_atan2d_snf(ii, thf0j) / 2.3025850929940459;
    }
  }
  htr.set_size(1, htr.size(1));
  m = htr.size(1) - 1;
  for (i = 0; i <= m; i++) {
    htr[i].re = 10.0 * htr[i].re;
    htr[i].im = 10.0 * htr[i].im;
  }
  thf0j = 0.04 * std::sqrt(shiftm);
  //   4 % of F0 is the limit of jump
  ii = 1.0;
  f0ref = 0.0;
  //  was -3 mod 2002.6.3
  // if imgi==1; hpg=waitbar(0,'F0 tracking'); end; % 07/Dec./2002 by
  // H.K.%10/Aug./2005
  while (ii < static_cast<double>(mm) + 1.0) {
    int jj;
    boolean_T exitg1;
    m = 0;
    if ((von == 0) && (ex[static_cast<int>(ii) - 1] < 0.12) &&
        (htr[static_cast<int>(ii) - 1].re < -2.0)) {
      von = 1;
      b_i = idx[static_cast<int>(ii) - 1] - 1;
      f0ref = f0v[b_i + f0v.size(0) * (static_cast<int>(ii) - 1)];
      //  start value for search
      i = static_cast<int>(-(std::fmax(1.0, ii - bkls) + (-1.0 - ii)));
      jj = 0;
      exitg1 = false;
      while ((!exitg1) && (jj <= i - 1)) {
        bi = ii - static_cast<double>(jj);
        m = f0v.size(0);
        b_x.set_size(f0v.size(0));
        scalarLB = (f0v.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (int k{0}; k <= vectorUB; k += 2) {
          r = _mm_set1_pd(f0ref);
          _mm_storeu_pd(
              &b_x[k],
              _mm_div_pd(
                  _mm_sub_pd(
                      _mm_loadu_pd(
                          &f0v[k + f0v.size(0) * (static_cast<int>(bi) - 1)]),
                      r),
                  r));
        }
        for (int k{scalarLB}; k < m; k++) {
          b_x[k] = (f0v[k + f0v.size(0) * (static_cast<int>(bi) - 1)] - f0ref) /
                   f0ref;
        }
        m = b_x.size(0);
        varargin_1.set_size(b_x.size(0));
        for (int k{0}; k < m; k++) {
          varargin_1[k] = std::abs(b_x[k]);
        }
        brm = legacy_STRAIGHT::coder::internal::minimum(varargin_1, scalarLB);
        m = scalarLB - 1;
        ar = f0v[(scalarLB + f0v.size(0) * (static_cast<int>(bi) - 1)) - 1];
        brm = (brm + static_cast<double>(f0ref > 10000.0)) +
              static_cast<double>(ar > 10000.0);
        if ((((brm > thf0j) ||
              (x[(scalarLB + x.size(0) * (static_cast<int>(bi) - 1)) - 1] >
               0.9) ||
              (htr[static_cast<int>(bi) - 1].re > -2.0)) &&
             (ar < 1000.0) && (htr[static_cast<int>(bi) - 1].re > -18.0)) ||
            (brm > thf0j)) {
          // 				disp(['break pt1 at ' num2str(jj)])
          // 				disp(['break pt2 at ' num2str(jj)])
          exitg1 = true;
        } else {
          f0[static_cast<int>(bi) - 1] = ar;
          irms[static_cast<int>(bi) - 1] =
              x[(scalarLB + x.size(0) * (static_cast<int>(bi) - 1)) - 1];
          df[static_cast<int>(bi) - 1] =
              dfv[(scalarLB + dfv.size(0) * (static_cast<int>(bi) - 1)) - 1];
          amp[static_cast<int>(bi) - 1] =
              aav[(scalarLB + aav.size(0) * (static_cast<int>(bi) - 1)) - 1];
          f0ref = f0[static_cast<int>(bi) - 1];
          jj++;
        }
      }
      f0ref = f0v[b_i + f0v.size(0) * (static_cast<int>(ii) - 1)];
    }
    if ((f0ref > 0.0) && (f0ref < 10000.0)) {
      m = f0v.size(0);
      b_x.set_size(f0v.size(0));
      scalarLB = (f0v.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_set1_pd(f0ref);
        _mm_storeu_pd(
            &b_x[i],
            _mm_div_pd(
                _mm_sub_pd(
                    _mm_loadu_pd(
                        &f0v[i + f0v.size(0) * (static_cast<int>(ii) - 1)]),
                    r),
                r));
      }
      for (i = scalarLB; i < m; i++) {
        b_x[i] =
            (f0v[i + f0v.size(0) * (static_cast<int>(ii) - 1)] - f0ref) / f0ref;
      }
      m = b_x.size(0);
      varargin_1.set_size(b_x.size(0));
      for (int k{0}; k < m; k++) {
        varargin_1[k] = std::abs(b_x[k]);
      }
      brm = legacy_STRAIGHT::coder::internal::minimum(varargin_1, scalarLB);
      m = scalarLB - 1;
    } else {
      brm = 10.0;
    }
    if ((von == 1) && (ex[static_cast<int>(ii) - 1] > 0.12)) {
      b_i = static_cast<int>(ii);
      i = static_cast<int>(std::fmin(static_cast<double>(mm), ii + lals) +
                           (1.0 - ii));
      jj = 0;
      exitg1 = false;
      while ((!exitg1) && (jj <= i - 1)) {
        bi = static_cast<double>(b_i) + static_cast<double>(jj);
        ii = bi;
        m = f0v.size(0);
        b_x.set_size(f0v.size(0));
        scalarLB = (f0v.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (int k{0}; k <= vectorUB; k += 2) {
          r = _mm_set1_pd(f0ref);
          _mm_storeu_pd(
              &b_x[k],
              _mm_div_pd(
                  _mm_sub_pd(
                      _mm_loadu_pd(
                          &f0v[k + f0v.size(0) * (static_cast<int>(bi) - 1)]),
                      r),
                  r));
        }
        for (int k{scalarLB}; k < m; k++) {
          b_x[k] = (f0v[k + f0v.size(0) * (static_cast<int>(bi) - 1)] - f0ref) /
                   f0ref;
        }
        m = b_x.size(0);
        varargin_1.set_size(b_x.size(0));
        for (int k{0}; k < m; k++) {
          varargin_1[k] = std::abs(b_x[k]);
        }
        brm = legacy_STRAIGHT::coder::internal::minimum(varargin_1, scalarLB);
        ar = f0v[(scalarLB + f0v.size(0) * (static_cast<int>(bi) - 1)) - 1];
        brm = (brm + static_cast<double>(f0ref > 10000.0)) +
              static_cast<double>(ar > 10000.0);
        if ((brm < thf0j) &&
            ((htr[static_cast<int>(bi) - 1].re < -2.0) || (ar >= 1000.0))) {
          f0[static_cast<int>(bi) - 1] = ar;
          irms[static_cast<int>(bi) - 1] =
              x[(scalarLB + x.size(0) * (static_cast<int>(bi) - 1)) - 1];
          df[static_cast<int>(bi) - 1] =
              dfv[(scalarLB + dfv.size(0) * (static_cast<int>(bi) - 1)) - 1];
          amp[static_cast<int>(bi) - 1] =
              aav[(scalarLB + aav.size(0) * (static_cast<int>(bi) - 1)) - 1];
          f0ref = f0[static_cast<int>(bi) - 1];
        }
        if ((brm > thf0j) ||
            (x[(scalarLB + x.size(0) * (static_cast<int>(bi) - 1)) - 1] >
             0.9) ||
            ((htr[static_cast<int>(bi) - 1].re > -2.0) && (ar < 1000.0))) {
          von = 0;
          f0ref = 0.0;
          exitg1 = true;
        } else {
          jj++;
        }
      }
    } else if ((von == 1) && (brm < thf0j) &&
               ((htr[static_cast<int>(ii) - 1].re < -2.0) ||
                (f0v[m + f0v.size(0) * (static_cast<int>(ii) - 1)] >=
                 1000.0))) {
      f0[static_cast<int>(ii) - 1] =
          f0v[m + f0v.size(0) * (static_cast<int>(ii) - 1)];
      irms[static_cast<int>(ii) - 1] =
          x[m + x.size(0) * (static_cast<int>(ii) - 1)];
      df[static_cast<int>(ii) - 1] =
          dfv[m + dfv.size(0) * (static_cast<int>(ii) - 1)];
      amp[static_cast<int>(ii) - 1] =
          aav[m + aav.size(0) * (static_cast<int>(ii) - 1)];
      f0ref = f0[static_cast<int>(ii) - 1];
    } else {
      von = 0;
    }
    // if imgi==1; waitbar(ii/mm); end; %,hpg); % 07/Dec./2002 by
    // H.K.%10/Aug./2005
    ii++;
  }
  // if imgi==1; close(hpg); end;%10/Aug./2005
}

// End of code generation (f0track5.cpp)
