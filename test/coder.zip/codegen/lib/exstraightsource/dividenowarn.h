//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// dividenowarn.h
//
// Code generation for function 'dividenowarn'
//

#ifndef DIVIDENOWARN_H
#define DIVIDENOWARN_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_19(creal_T in1_data[], int in1_size[2],
                         const creal_T in2_data[], const int in2_size[2]);

#endif
// End of code generation (dividenowarn.h)
