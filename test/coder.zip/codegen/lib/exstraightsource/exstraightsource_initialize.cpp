//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource_initialize.cpp
//
// Code generation for function 'exstraightsource_initialize'
//

// Include files
#include "exstraightsource_initialize.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"
#include "omp.h"

// Function Definitions
void exstraightsource_initialize()
{
  omp_init_nest_lock(&exstraightsource_nestLockGlobal);
  eml_rand_mt19937ar_stateful_init();
  isInitialized_exstraightsource = true;
}

// End of code generation (exstraightsource_initialize.cpp)
