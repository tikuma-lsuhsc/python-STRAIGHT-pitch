//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// poly2rc.cpp
//
// Code generation for function 'poly2rc'
//

// Include files
#include "poly2rc.h"
#include "exstraightsource_rtwutil.h"
#include "rt_nonfinite.h"
#include <algorithm>

// Function Definitions
void binary_expand_op_23(double in1_data[], int in4, int in6, int in7, int in8,
                         int in9, int in10, double in11)
{
  double b_in1_data[32];
  double in1;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  in1 = in1_data[in7];
  i = div_s32(in10 - in8, in9) + 1;
  if (i == 1) {
    loop_ub = in6 + 1;
  } else {
    loop_ub = i;
  }
  stride_0_0 = (in6 + 1 != 1);
  stride_1_0 = (i != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in1_data[i] =
        (in1_data[static_cast<signed char>(in4 - 1) + i * stride_0_0] -
         in1 * in1_data[(static_cast<signed char>(in4 - 1) + in8) +
                        in9 * (i * stride_1_0)]) /
        (1.0 - in11);
  }
  in1_data[0] = 1.0;
  if (loop_ub - 1 >= 0) {
    std::copy(&b_in1_data[0], &b_in1_data[loop_ub], &in1_data[1]);
  }
}

// End of code generation (poly2rc.cpp)
