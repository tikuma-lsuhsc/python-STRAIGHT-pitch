//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// grpdelay.h
//
// Code generation for function 'grpdelay'
//

#ifndef GRPDELAY_H
#define GRPDELAY_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_18(double in1[8], const creal_T in2_data[],
                         const coder::array<double, 2U> &in3,
                         const int in4_size[2]);

void binary_expand_op_51(double in1_data[], int in1_size[2],
                         const double in2_data[], const int in2_size[2],
                         const coder::array<double, 2U> &in3);

#endif
// End of code generation (grpdelay.h)
