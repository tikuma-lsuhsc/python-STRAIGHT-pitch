//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// islinphase.h
//
// Code generation for function 'islinphase'
//

#ifndef ISLINPHASE_H
#define ISLINPHASE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
namespace b_signal {
namespace internal {
boolean_T determineiflinphase(const creal_T b_data[], const int b_size[2]);

boolean_T determineiflinphase(const double b_data[], const int b_size[2]);

} // namespace internal
} // namespace b_signal
} // namespace legacy_STRAIGHT

#endif
// End of code generation (islinphase.h)
