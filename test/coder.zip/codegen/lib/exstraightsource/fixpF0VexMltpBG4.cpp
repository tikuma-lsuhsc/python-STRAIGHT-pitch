//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fixpF0VexMltpBG4.cpp
//
// Code generation for function 'fixpF0VexMltpBG4'
//

// Include files
#include "fixpF0VexMltpBG4.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "decimate.h"
#include "diff.h"
#include "div.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "fftfilt.h"
#include "fir1.h"
#include "firls.h"
#include "hamming.h"
#include "minOrMax.h"
#include "multanalytFineCSPB.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>
#include <emmintrin.h>

// Function Declarations
static void binary_expand_op_10(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3, double in4,
                                double in5);

static void binary_expand_op_11(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, int in5, double in6, double in7);

static void binary_expand_op_30(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2, int in3,
                                const signed char in4[2], int in5,
                                const int in6[2]);

static void binary_expand_op_34(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                const double in4[9], int in5, int in6, int in7,
                                int in8);

static void binary_expand_op_35(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, int in5, double in6, int in7, int in8,
                                int in9, int in10);

static void binary_expand_op_39(
    coder::array<double, 1U> &in1, const coder::array<double, 1U> &in2,
    const coder::array<unsigned int, 1U> &in3, const coder::array<int, 1U> &in4,
    const coder::array<double, 1U> &in5, const coder::array<double, 1U> &in6,
    const coder::array<double, 1U> &in7, const coder::array<double, 1U> &in8);

static void binary_expand_op_42(coder::array<boolean_T, 1U> &in1,
                                const coder::array<double, 1U> &in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5);

static void binary_expand_op_5(coder::array<double, 2U> &in1, int in2,
                               const coder::array<double, 2U> &in3,
                               const coder::array<double, 1U> &in5, double in6,
                               const coder::array<double, 1U> &in7,
                               const coder::array<double, 1U> &in8,
                               const coder::array<double, 1U> &in9);

static void binary_expand_op_6(
    coder::array<double, 2U> &in1, int in2, const coder::array<double, 2U> &in3,
    const coder::array<double, 1U> &in5, double in6,
    const coder::array<double, 1U> &in7, const coder::array<double, 2U> &in8,
    const coder::array<double, 1U> &in9, const coder::array<double, 1U> &in10,
    const coder::array<double, 1U> &in11, const coder::array<double, 1U> &in12);

static void binary_expand_op_7(coder::array<double, 2U> &in1, int in2,
                               const coder::array<double, 2U> &in4,
                               const coder::array<double, 2U> &in5,
                               const coder::array<double, 2U> &in6);

static void binary_expand_op_8(coder::array<double, 2U> &in1,
                               const coder::array<double, 2U> &in2, int in3,
                               const coder::array<double, 2U> &in4, double in5);

static void cleaninglownoise(const coder::array<double, 1U> &x, double fs,
                             double f0floor, coder::array<creal_T, 2U> &b_x);

static void minus(coder::array<double, 1U> &in1,
                  const coder::array<double, 1U> &in2,
                  const coder::array<double, 1U> &in3);

static void zfixpfreq3(
    const coder::array<double, 1U> &fxx, const coder::array<double, 1U> &pif2,
    const coder::array<double, 1U> &mmp, const coder::array<double, 1U> &dfv,
    const coder::array<creal_T, 1U> &pm, coder::array<double, 1U> &ff,
    coder::array<double, 1U> &vv, coder::array<double, 1U> &df,
    coder::array<double, 1U> &aa);

static void zifq2gpm2(const coder::array<double, 2U> &pif, double f0floor,
                      double nvo, coder::array<double, 2U> &slp,
                      coder::array<double, 2U> &pbl);

static void zsmoothmapB(const coder::array<double, 2U> &map, double fs,
                        double f0floor, double nvo, double mu, double mlim,
                        coder::array<double, 2U> &smap);

static void zwvlt2ifq(coder::array<creal_T, 2U> &pm, double fs,
                      coder::array<double, 2U> &pif);

// Function Definitions
static void binary_expand_op_10(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3, double in4,
                                double in5)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] =
          (in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] -
           in3[i1 * stride_1_0 + in3.size(0) * aux_1_1]) *
          in4 / in5;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op_11(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, int in5, double in6, double in7)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  loop_ub = in2.size(0);
  in1.set_size(loop_ub, in1.size(1));
  i = (in4 - in3) + 1;
  if (in5 + 1 == 1) {
    b_loop_ub = i;
  } else {
    b_loop_ub = in5 + 1;
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_1 = (i != 1);
  stride_1_1 = (in5 + 1 != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    int scalarLB;
    int vectorUB;
    scalarLB = (loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      __m128d r;
      __m128d r1;
      r = _mm_loadu_pd(&in2[i1 + in2.size(0) * (in3 + aux_0_1)]);
      r1 = _mm_loadu_pd(&in2[i1 + in2.size(0) * aux_1_1]);
      _mm_storeu_pd(&in1[i1 + in1.size(0) * i],
                    _mm_div_pd(_mm_mul_pd(_mm_sub_pd(r, r1), _mm_set1_pd(in6)),
                               _mm_set1_pd(in7)));
    }
    for (int i1{scalarLB}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = (in2[i1 + in2.size(0) * (in3 + aux_0_1)] -
                                   in2[i1 + in2.size(0) * aux_1_1]) *
                                  in6 / in7;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op_30(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2, int in3,
                                const signed char in4[2], int in5,
                                const int in6[2])
{
  coder::array<creal_T, 2U> c_in2;
  coder::array<creal_T, 2U> d_in2;
  coder::array<creal_T, 1U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_in3_idx_1;
  int in3_idx_1;
  int loop_ub;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  loop_ub = in2.size(0);
  b_in2.set_size(loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    b_in2[i] = in2[i];
  }
  in3_idx_1 = in4[1];
  c_in2.set_size(loop_ub, in5);
  for (int i{0}; i < in5; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      c_in2[i1 + c_in2.size(0) * i] = in2[i1 + in2.size(0) * i];
    }
  }
  b_in3_idx_1 = in6[1];
  in1.set_size(in3, in3_idx_1 + b_in3_idx_1);
  for (int i{0}; i < in3_idx_1; i++) {
    for (int i1{0}; i1 < in3; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + in3 * i];
    }
  }
  for (int i{0}; i < b_in3_idx_1; i++) {
    for (int i1{0}; i1 < in3; i1++) {
      in1[i1 + in1.size(0) * (i + in3_idx_1)] = c_in2[i1 + in3 * i];
    }
  }
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_in3_idx_1 = in2.size(1);
  } else {
    b_in3_idx_1 = in1.size(1);
  }
  d_in2.set_size(loop_ub, b_in3_idx_1);
  in3_idx_1 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_in3_idx_1; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      int i2;
      int i3;
      i2 = i1 * in3_idx_1;
      i3 = i1 * stride_1_0;
      d_in2[i1 + d_in2.size(0) * i].re = in2[i2 + in2.size(0) * aux_0_1].re -
                                         in1[i3 + in1.size(0) * aux_1_1].re;
      d_in2[i1 + d_in2.size(0) * i].im = in2[i2 + in2.size(0) * aux_0_1].im -
                                         in1[i3 + in1.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_in3_idx_1);
  for (int i{0}; i < b_in3_idx_1; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = d_in2[i1 + d_in2.size(0) * i];
    }
  }
}

static void binary_expand_op_34(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                const double in4[9], int in5, int in6, int in7,
                                int in8)
{
  double b_in4;
  double c_in4;
  double d_in4;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  b_in4 = in4[1];
  c_in4 = in4[4];
  d_in4 = in4[7];
  i = (in6 - in5) + 1;
  i1 = (in8 - in7) + 1;
  if (i1 == 1) {
    if (i == 1) {
      loop_ub = in3 + 1;
    } else {
      loop_ub = i;
    }
  } else {
    loop_ub = i1;
  }
  in1.set_size(loop_ub, in1.size(1));
  b_loop_ub = in2.size(1);
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in3 + 1 != 1);
  stride_1_0 = (i != 1);
  stride_2_0 = (i1 != 1);
  for (i = 0; i < b_loop_ub; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] =
          (in2[i1 * stride_0_0 + in2.size(0) * i] * b_in4 +
           in2[(in5 + i1 * stride_1_0) + in2.size(0) * i] * c_in4) +
          in2[(in7 + i1 * stride_2_0) + in2.size(0) * i] * d_in4;
    }
  }
}

static void binary_expand_op_35(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, int in5, double in6, int in7, int in8,
                                int in9, int in10)
{
  double d;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  int stride_3_0;
  d = 1.0 - 1.0 / in6;
  i = (in10 - in9) + 1;
  i1 = (in8 - in7) + 1;
  if (i == 1) {
    stride_0_0 = i1;
  } else {
    stride_0_0 = i;
  }
  stride_1_0 = (in4 - in3) + 1;
  if (stride_0_0 == 1) {
    if (in5 + 1 == 1) {
      loop_ub = stride_1_0;
    } else {
      loop_ub = in5 + 1;
    }
  } else {
    loop_ub = stride_0_0;
  }
  in1.set_size(loop_ub, in1.size(1));
  b_loop_ub = in2.size(1);
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (stride_1_0 != 1);
  stride_1_0 = (in5 + 1 != 1);
  stride_2_0 = (i1 != 1);
  stride_3_0 = (i != 1);
  for (i = 0; i < b_loop_ub; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] =
          ((in2[(in3 + i1 * stride_0_0) + in2.size(0) * i] -
            in2[i1 * stride_1_0 + in2.size(0) * i]) /
               d +
           (in2[(in7 + i1 * stride_2_0) + in2.size(0) * i] -
            in2[(in9 + i1 * stride_3_0) + in2.size(0) * i]) /
               (in6 - 1.0)) /
          2.0;
    }
  }
}

static void binary_expand_op_39(
    coder::array<double, 1U> &in1, const coder::array<double, 1U> &in2,
    const coder::array<unsigned int, 1U> &in3, const coder::array<int, 1U> &in4,
    const coder::array<double, 1U> &in5, const coder::array<double, 1U> &in6,
    const coder::array<double, 1U> &in7, const coder::array<double, 1U> &in8)
{
  int i;
  int loop_ub;
  int stride_0_0_tmp;
  int stride_1_0;
  int stride_2_0;
  int stride_4_0;
  if (in4.size(0) == 1) {
    i = in6.size(0);
  } else {
    i = in4.size(0);
  }
  if (in8.size(0) == 1) {
    if (i == 1) {
      i = in5.size(0);
    }
  } else {
    i = in8.size(0);
  }
  if (i == 1) {
    loop_ub = in4.size(0);
  } else {
    loop_ub = i;
  }
  in1.set_size(loop_ub);
  stride_0_0_tmp = (in4.size(0) != 1);
  stride_1_0 = (in5.size(0) != 1);
  stride_2_0 = (in6.size(0) != 1);
  stride_4_0 = (in8.size(0) != 1);
  for (i = 0; i < loop_ub; i++) {
    int i1;
    int i2;
    int i3;
    i1 = i * stride_1_0;
    i2 = static_cast<int>(in3[in4[i * stride_0_0_tmp]]) - 1;
    i3 = i * stride_4_0;
    in1[i] = in2[i2] + (in5[i1] - in2[static_cast<int>(in3[in4[i1]]) - 1]) *
                           (in6[i * stride_2_0] - in7[i2]) /
                           (in8[i3] - in7[static_cast<int>(in3[in4[i3]]) - 1]);
  }
}

static void binary_expand_op_42(coder::array<boolean_T, 1U> &in1,
                                const coder::array<double, 1U> &in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5)
{
  coder::array<int, 1U> b_in4;
  int loop_ub_tmp;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  b_in4.set_size(in4.size(0) + 1);
  loop_ub_tmp = in4.size(0);
  for (int i{0}; i < loop_ub_tmp; i++) {
    b_in4[i] = (in4[i] < 0.0);
  }
  b_in4[loop_ub_tmp] = (in2[in5.size(0) - 1] - in2[in5.size(0) - 2] < 0.0);
  if (b_in4.size(0) == 1) {
    if (in3.size(0) == 1) {
      loop_ub_tmp = in2.size(0);
    } else {
      loop_ub_tmp = in3.size(0);
    }
  } else {
    loop_ub_tmp = b_in4.size(0);
  }
  in1.set_size(loop_ub_tmp);
  stride_0_0 = (in2.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_2_0 = (b_in4.size(0) != 1);
  for (int i{0}; i < loop_ub_tmp; i++) {
    in1[i] = ((in2[i * stride_0_0] * in3[i * stride_1_0] < 0.0) *
                  b_in4[i * stride_2_0] >
              0);
  }
}

static void binary_expand_op_5(coder::array<double, 2U> &in1, int in2,
                               const coder::array<double, 2U> &in3,
                               const coder::array<double, 1U> &in5, double in6,
                               const coder::array<double, 1U> &in7,
                               const coder::array<double, 1U> &in8,
                               const coder::array<double, 1U> &in9)
{
  coder::array<double, 1U> b_in3;
  int in1_idx_0_tmp;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  int stride_3_0;
  int stride_4_0;
  int stride_5_0;
  in1_idx_0_tmp = in1.size(0);
  b_in3.set_size(in1_idx_0_tmp);
  stride_0_0 = (in3.size(0) != 1);
  stride_1_0 = (in5.size(0) != 1);
  stride_2_0 = (in1.size(0) != 1);
  stride_3_0 = (in7.size(0) != 1);
  stride_4_0 = (in8.size(0) != 1);
  stride_5_0 = (in9.size(0) != 1);
  for (int i{0}; i < in1_idx_0_tmp; i++) {
    double b_varargin_1;
    double c_varargin_1;
    double d_varargin_1;
    double varargin_1;
    varargin_1 = in5[i * stride_1_0];
    b_varargin_1 = in7[i * stride_3_0];
    c_varargin_1 = in8[i * stride_4_0];
    d_varargin_1 = in9[i * stride_5_0];
    b_in3[i] =
        (in3[i * stride_0_0 + in3.size(0) * in2] *
             rt_powd_snf(varargin_1, in6) +
         in1[i * stride_2_0 + in1.size(0) * in2] / 2.0 *
             rt_powd_snf(b_varargin_1, in6)) /
        (rt_powd_snf(c_varargin_1, in6) + rt_powd_snf(d_varargin_1, in6));
  }
  for (int i{0}; i < in1_idx_0_tmp; i++) {
    in1[i + in1.size(0) * in2] = b_in3[i];
  }
}

static void binary_expand_op_6(
    coder::array<double, 2U> &in1, int in2, const coder::array<double, 2U> &in3,
    const coder::array<double, 1U> &in5, double in6,
    const coder::array<double, 1U> &in7, const coder::array<double, 2U> &in8,
    const coder::array<double, 1U> &in9, const coder::array<double, 1U> &in10,
    const coder::array<double, 1U> &in11, const coder::array<double, 1U> &in12)
{
  coder::array<double, 1U> b_in3;
  int in1_idx_0_tmp;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  int stride_3_0;
  int stride_4_0;
  int stride_5_0;
  int stride_6_0;
  int stride_7_0;
  int stride_8_0;
  in1_idx_0_tmp = in1.size(0);
  b_in3.set_size(in1_idx_0_tmp);
  stride_0_0 = (in3.size(0) != 1);
  stride_1_0 = (in5.size(0) != 1);
  stride_2_0 = (in1.size(0) != 1);
  stride_3_0 = (in7.size(0) != 1);
  stride_4_0 = (in8.size(0) != 1);
  stride_5_0 = (in9.size(0) != 1);
  stride_6_0 = (in10.size(0) != 1);
  stride_7_0 = (in11.size(0) != 1);
  stride_8_0 = (in12.size(0) != 1);
  for (int i{0}; i < in1_idx_0_tmp; i++) {
    double b_varargin_1;
    double c_varargin_1;
    double d_varargin_1;
    double e_varargin_1;
    double f_varargin_1;
    double varargin_1;
    varargin_1 = in5[i * stride_1_0];
    b_varargin_1 = in7[i * stride_3_0];
    c_varargin_1 = in9[i * stride_5_0];
    d_varargin_1 = in10[i * stride_6_0];
    e_varargin_1 = in11[i * stride_7_0];
    f_varargin_1 = in12[i * stride_8_0];
    b_in3[i] =
        ((in3[i * stride_0_0 + in3.size(0) * in2] *
              rt_powd_snf(varargin_1, in6) +
          in1[i * stride_2_0 + in1.size(0) * in2] / 2.0 *
              rt_powd_snf(b_varargin_1, in6)) +
         in8[i * stride_4_0 + in8.size(0) * in2] / 3.0 *
             rt_powd_snf(c_varargin_1, in6)) /
        ((rt_powd_snf(d_varargin_1, in6) + rt_powd_snf(e_varargin_1, in6)) +
         rt_powd_snf(f_varargin_1, in6));
  }
  for (int i{0}; i < in1_idx_0_tmp; i++) {
    in1[i + in1.size(0) * in2] = b_in3[i];
  }
}

static void binary_expand_op_7(coder::array<double, 2U> &in1, int in2,
                               const coder::array<double, 2U> &in4,
                               const coder::array<double, 2U> &in5,
                               const coder::array<double, 2U> &in6)
{
  coder::array<double, 2U> b_in5;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in6.size(1) == 1) {
    loop_ub = in5.size(1);
  } else {
    loop_ub = in6.size(1);
  }
  b_in5.set_size(1, loop_ub);
  stride_0_1 = (in5.size(1) != 1);
  stride_1_1 = (in6.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in5[i] = in5[in2 + in5.size(0) * (i * stride_0_1)] / in6[i * stride_1_1] /
               0.607835129511774;
  }
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (b_in5.size(1) != 1);
  loop_ub = in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    double b_varargin_1;
    double varargin_1;
    varargin_1 = in4[i * stride_0_1];
    b_varargin_1 = b_in5[i * stride_1_1];
    in1[in2 + in1.size(0) * i] =
        rt_powd_snf(varargin_1, 2.0) + rt_powd_snf(b_varargin_1, 2.0);
  }
}

static void binary_expand_op_8(coder::array<double, 2U> &in1,
                               const coder::array<double, 2U> &in2, int in3,
                               const coder::array<double, 2U> &in4, double in5)
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1.set_size(1, in1.size(1));
  if (in4.size(1) == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in4.size(1);
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in4.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] =
        in2[in3 + in2.size(0) * (i * stride_0_1)] / in4[i * stride_1_1] / in5;
  }
}

static void cleaninglownoise(const coder::array<double, 1U> &x, double fs,
                             double f0floor, coder::array<creal_T, 2U> &b_x)
{
  __m128d r;
  coder::array<creal_T, 2U> ttx;
  coder::array<double, 2U> hh;
  coder::array<double, 2U> wind;
  coder::array<double, 1U> a;
  double flp;
  double varargin_1;
  double varargin_2;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  // --------------------------------------------
  flp = std::round(fs * 50.0 / 1000.0);
  varargin_1 = flp * 2.0;
  varargin_2 = f0floor / (fs / 2.0);
  legacy_STRAIGHT::hamming(varargin_1 + 1.0, a);
  loop_ub = a.size(0);
  wind.set_size(1, a.size(0));
  for (int i{0}; i < loop_ub; i++) {
    wind[i] = a[i];
  }
  double b_dv[4];
  b_dv[0] = 0.0;
  b_dv[1] = varargin_2;
  b_dv[2] = varargin_2;
  b_dv[3] = 1.0;
  legacy_STRAIGHT::eFirls((varargin_1 + 1.0) - 1.0, b_dv, hh, a);
  if (hh.size(1) == wind.size(1)) {
    loop_ub = hh.size(1) - 1;
    hh.set_size(1, hh.size(1));
    scalarLB = (hh.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i{0}; i <= vectorUB; i += 2) {
      __m128d r1;
      r = _mm_loadu_pd(&hh[i]);
      r1 = _mm_loadu_pd(&wind[i]);
      _mm_storeu_pd(&hh[i], _mm_mul_pd(r, r1));
    }
    for (int i{scalarLB}; i <= loop_ub; i++) {
      hh[i] = hh[i] * wind[i];
    }
  } else {
    times(hh, wind);
  }
  varargin_1 = legacy_STRAIGHT::combineVectorElements(hh);
  hh.set_size(1, hh.size(1));
  loop_ub = hh.size(1) - 1;
  scalarLB = (hh.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&hh[i]);
    _mm_storeu_pd(&hh[i], _mm_div_pd(r, _mm_set1_pd(varargin_1)));
  }
  for (int i{scalarLB}; i <= loop_ub; i++) {
    hh[i] = hh[i] / varargin_1;
  }
  hh[static_cast<int>(flp + 1.0) - 1] =
      hh[static_cast<int>(flp + 1.0) - 1] - 1.0;
  hh.set_size(1, hh.size(1));
  loop_ub = hh.size(1) - 1;
  scalarLB = (hh.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&hh[i]);
    _mm_storeu_pd(&hh[i], _mm_mul_pd(r, _mm_set1_pd(-1.0)));
  }
  for (int i{scalarLB}; i <= loop_ub; i++) {
    hh[i] = -hh[i];
  }
  loop_ub = 2 * hh.size(1);
  wind.set_size(1, x.size(0) + loop_ub);
  scalarLB = x.size(0);
  for (int i{0}; i < scalarLB; i++) {
    wind[i] = x[i];
  }
  for (int i{0}; i < loop_ub; i++) {
    wind[i + x.size(0)] = 0.0;
  }
  legacy_STRAIGHT::fftfilt(hh, wind, ttx);
  if (x.size(0) < 1) {
    wind.set_size(1, 0);
  } else {
    wind.set_size(1, x.size(0));
    loop_ub = x.size(0) - 1;
    for (int i{0}; i <= loop_ub; i++) {
      wind[i] = static_cast<double>(i) + 1.0;
    }
  }
  loop_ub = wind.size(1);
  b_x.set_size(1, wind.size(1));
  for (int i{0}; i < loop_ub; i++) {
    b_x[i] = ttx[static_cast<int>(wind[i] + flp) - 1];
  }
}

static void minus(coder::array<double, 1U> &in1,
                  const coder::array<double, 1U> &in2,
                  const coder::array<double, 1U> &in3)
{
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = in2[i * stride_0_0] - in3[i * stride_1_0];
  }
}

static void zfixpfreq3(
    const coder::array<double, 1U> &fxx, const coder::array<double, 1U> &pif2,
    const coder::array<double, 1U> &mmp, const coder::array<double, 1U> &dfv,
    const coder::array<creal_T, 1U> &pm, coder::array<double, 1U> &ff,
    coder::array<double, 1U> &vv, coder::array<double, 1U> &df,
    coder::array<double, 1U> &aa)
{
  coder::array<double, 1U> aav;
  coder::array<double, 1U> cd1;
  coder::array<double, 1U> cdd1;
  coder::array<double, 1U> r;
  coder::array<unsigned int, 2U> y;
  coder::array<unsigned int, 1U> iix;
  coder::array<int, 1U> r2;
  coder::array<int, 1U> r3;
  coder::array<boolean_T, 1U> r1;
  double cdd1_tmp;
  double ff_tmp;
  int i;
  int i1;
  int k;
  int loop_ub;
  int nx_tmp;
  // --------------------------------------------
  // function [ff,vv,df]=zfixpfreq2(fxx,pif2,mmp,dfv)
  //
  // nn=length(fxx);
  // iix=(1:nn)';
  // cd1=pif2-fxx;
  // cd2=[diff(cd1);cd1(nn)-cd1(nn-1)];
  // cdd1=[cd1(2:nn);cd1(nn)];
  // fp=(cd1.*cdd1<0).*(cd2<0);
  // ixx=iix(fp>0);
  // ff=pif2(ixx)+(pif2(ixx+1)-pif2(ixx)).*cd1(ixx)./(cd1(ixx)-cdd1(ixx));
  // vv=mmp(ixx);
  // vv=mmp(ixx)+(mmp(ixx+1)-mmp(ixx)).*(ff-fxx(ixx))./(fxx(ixx+1)-fxx(ixx));
  // df=dfv(ixx)+(dfv(ixx+1)-dfv(ixx)).*(ff-fxx(ixx))./(fxx(ixx+1)-fxx(ixx));
  // --------------------------------------------
  nx_tmp = pm.size(0);
  aav.set_size(pm.size(0));
  for (k = 0; k < nx_tmp; k++) {
    aav[k] = rt_hypotd_snf(pm[k].re, pm[k].im);
  }
  if (fxx.size(0) < 1) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, fxx.size(0));
    loop_ub = fxx.size(0) - 1;
    for (i = 0; i <= loop_ub; i++) {
      y[i] = static_cast<unsigned int>(i) + 1U;
    }
  }
  loop_ub = y.size(1);
  iix.set_size(y.size(1));
  for (i = 0; i < loop_ub; i++) {
    iix[i] = y[i];
  }
  if (pif2.size(0) == fxx.size(0)) {
    loop_ub = pif2.size(0);
    cd1.set_size(pif2.size(0));
    nx_tmp = (pif2.size(0) / 2) << 1;
    k = nx_tmp - 2;
    for (i = 0; i <= k; i += 2) {
      _mm_storeu_pd(&cd1[i],
                    _mm_sub_pd(_mm_loadu_pd(&pif2[i]), _mm_loadu_pd(&fxx[i])));
    }
    for (i = nx_tmp; i < loop_ub; i++) {
      cd1[i] = pif2[i] - fxx[i];
    }
  } else {
    minus(cd1, pif2, fxx);
  }
  if (fxx.size(0) < 2) {
    i = 0;
    nx_tmp = 0;
  } else {
    i = 1;
    nx_tmp = fxx.size(0);
  }
  loop_ub = nx_tmp - i;
  cdd1.set_size(loop_ub + 1);
  for (nx_tmp = 0; nx_tmp < loop_ub; nx_tmp++) {
    cdd1[nx_tmp] = cd1[i + nx_tmp];
  }
  cdd1_tmp = cd1[fxx.size(0) - 1];
  cdd1[loop_ub] = cdd1_tmp;
  legacy_STRAIGHT::diff(cd1, r);
  if (cd1.size(0) == 1) {
    i = cdd1.size(0);
  } else {
    i = cd1.size(0);
  }
  if ((cd1.size(0) == cdd1.size(0)) && (i == r.size(0) + 1)) {
    r2.set_size(r.size(0) + 1);
    k = r.size(0);
    for (i = 0; i < k; i++) {
      r2[i] = (r[i] < 0.0);
    }
    r2[r.size(0)] = (cdd1_tmp - cd1[fxx.size(0) - 2] < 0.0);
    loop_ub = cd1.size(0);
    r1.set_size(cd1.size(0));
    for (i = 0; i < loop_ub; i++) {
      r1[i] = ((cd1[i] * cdd1[i] < 0.0) * r2[i] > 0);
    }
  } else {
    binary_expand_op_42(r1, cd1, cdd1, r, fxx);
  }
  k = r1.size(0) - 1;
  nx_tmp = 0;
  for (loop_ub = 0; loop_ub <= k; loop_ub++) {
    if (r1[loop_ub]) {
      nx_tmp++;
    }
  }
  r3.set_size(nx_tmp);
  nx_tmp = 0;
  for (loop_ub = 0; loop_ub <= k; loop_ub++) {
    if (r1[loop_ub]) {
      r3[nx_tmp] = loop_ub;
      nx_tmp++;
    }
  }
  k = r3.size(0);
  ff.set_size(r3.size(0));
  for (i = 0; i < k; i++) {
    nx_tmp = static_cast<int>(iix[r3[i]]);
    cdd1_tmp = pif2[nx_tmp - 1];
    ff_tmp = cd1[nx_tmp - 1];
    ff[i] = cdd1_tmp +
            (pif2[nx_tmp] - cdd1_tmp) * ff_tmp / (ff_tmp - cdd1[nx_tmp - 1]);
  }
  // vv=mmp(ixx);
  r.set_size(r3.size(0));
  cd1.set_size(r3.size(0));
  for (i = 0; i < k; i++) {
    nx_tmp = static_cast<int>(iix[r3[i]]);
    r[i] = mmp[nx_tmp];
    cd1[i] = fxx[nx_tmp];
  }
  if (ff.size(0) == 1) {
    i = r3.size(0);
  } else {
    i = ff.size(0);
  }
  if (r.size(0) == 1) {
    nx_tmp = i;
  } else {
    nx_tmp = r.size(0);
  }
  if (nx_tmp == 1) {
    i1 = cd1.size(0);
  } else {
    i1 = nx_tmp;
  }
  if ((ff.size(0) == r3.size(0)) && (r.size(0) == i) &&
      (nx_tmp == cd1.size(0)) && (r3.size(0) == i1)) {
    vv.set_size(r3.size(0));
    for (i = 0; i < k; i++) {
      nx_tmp = static_cast<int>(iix[r3[i]]) - 1;
      cdd1_tmp = mmp[nx_tmp];
      ff_tmp = fxx[nx_tmp];
      vv[i] =
          cdd1_tmp + (r[i] - cdd1_tmp) * (ff[i] - ff_tmp) / (cd1[i] - ff_tmp);
    }
  } else {
    binary_expand_op_39(vv, mmp, iix, r3, r, ff, fxx, cd1);
  }
  loop_ub = r3.size(0);
  r.set_size(r3.size(0));
  cd1.set_size(r3.size(0));
  for (i = 0; i < loop_ub; i++) {
    nx_tmp = static_cast<int>(iix[r3[i]]);
    r[i] = dfv[nx_tmp];
    cd1[i] = fxx[nx_tmp];
  }
  if (ff.size(0) == 1) {
    i = r3.size(0);
  } else {
    i = ff.size(0);
  }
  if (r.size(0) == 1) {
    nx_tmp = i;
  } else {
    nx_tmp = r.size(0);
  }
  if (nx_tmp == 1) {
    i1 = cd1.size(0);
  } else {
    i1 = nx_tmp;
  }
  if ((ff.size(0) == r3.size(0)) && (r.size(0) == i) &&
      (nx_tmp == cd1.size(0)) && (r3.size(0) == i1)) {
    df.set_size(r3.size(0));
    for (i = 0; i < loop_ub; i++) {
      nx_tmp = static_cast<int>(iix[r3[i]]) - 1;
      cdd1_tmp = dfv[nx_tmp];
      ff_tmp = fxx[nx_tmp];
      df[i] =
          cdd1_tmp + (r[i] - cdd1_tmp) * (ff[i] - ff_tmp) / (cd1[i] - ff_tmp);
    }
  } else {
    binary_expand_op_39(df, dfv, iix, r3, r, ff, fxx, cd1);
  }
  loop_ub = r3.size(0);
  r.set_size(r3.size(0));
  cd1.set_size(r3.size(0));
  for (i = 0; i < loop_ub; i++) {
    nx_tmp = static_cast<int>(iix[r3[i]]);
    r[i] = aav[nx_tmp];
    cd1[i] = fxx[nx_tmp];
  }
  if (ff.size(0) == 1) {
    i = r3.size(0);
  } else {
    i = ff.size(0);
  }
  if (r.size(0) == 1) {
    nx_tmp = i;
  } else {
    nx_tmp = r.size(0);
  }
  if (nx_tmp == 1) {
    i1 = cd1.size(0);
  } else {
    i1 = nx_tmp;
  }
  if ((ff.size(0) == r3.size(0)) && (r.size(0) == i) &&
      (nx_tmp == cd1.size(0)) && (r3.size(0) == i1)) {
    aa.set_size(r3.size(0));
    for (i = 0; i < loop_ub; i++) {
      nx_tmp = static_cast<int>(iix[r3[i]]) - 1;
      cdd1_tmp = aav[nx_tmp];
      ff_tmp = fxx[nx_tmp];
      aa[i] =
          cdd1_tmp + (r[i] - cdd1_tmp) * (ff[i] - ff_tmp) / (cd1[i] - ff_tmp);
    }
  } else {
    binary_expand_op_39(aa, aav, iix, r3, r, ff, fxx, cd1);
  }
}

static void zifq2gpm2(const coder::array<double, 2U> &pif, double f0floor,
                      double nvo, coder::array<double, 2U> &slp,
                      coder::array<double, 2U> &pbl)
{
  coder::array<double, 2U> b_slp;
  coder::array<double, 2U> c_slp;
  coder::array<double, 2U> d_slp;
  coder::array<double, 2U> fx;
  double h[9];
  double x[9];
  double c;
  double t1;
  double t2;
  int b_loop_ub;
  int i;
  int i1;
  int i2;
  int i3;
  int i4;
  int itmp;
  int loop_ub;
  int p1;
  int p2;
  int p3;
  int result_tmp;
  signed char input_sizes_idx_0;
  signed char sizes_idx_0;
  boolean_T empty_non_axis_sizes;
  // ----------------------------------------------------------------
  // 	Instantaneous frequency 2 geometric parameters
  // 	[slp,pbl]=ifq2gpm(pif,f0floor,nvo)
  // 	slp		: first order coefficient
  // 	pbl		: second order coefficient
  // 	Coded by Hideki Kawahara
  // 	02/March/1999
  if (pif.size(0) - 1 < 0) {
    fx.set_size(fx.size(0), 0);
  } else {
    fx.set_size(1, pif.size(0));
    loop_ub = pif.size(0) - 1;
    for (i = 0; i <= loop_ub; i++) {
      fx[i] = i;
    }
  }
  fx.set_size(1, fx.size(1));
  loop_ub = fx.size(1) - 1;
  for (i = 0; i <= loop_ub; i++) {
    t1 = fx[i] / nvo;
    fx[i] = f0floor * rt_powd_snf(2.0, t1) * 2.0 * 3.1415926535897931;
  }
  c = rt_powd_snf(2.0, 1.0 / nvo);
  h[0] = 1.0 / c / c;
  h[3] = 1.0 / c;
  h[6] = 1.0;
  h[1] = 1.0;
  h[4] = 1.0;
  h[7] = 1.0;
  h[2] = c * c;
  h[5] = c;
  h[8] = 1.0;
  std::copy(&h[0], &h[9], &x[0]);
  p1 = 0;
  p2 = 3;
  p3 = 6;
  if ((h[0] < 1.0) && (h[2] < 1.0)) {
    p1 = 3;
    p2 = 0;
    x[0] = 1.0;
    x[1] = h[0];
    x[3] = 1.0;
    x[4] = h[3];
    x[6] = 1.0;
    x[7] = 1.0;
  } else if (h[2] > h[0]) {
    p1 = 6;
    p3 = 0;
    x[0] = h[2];
    x[2] = h[0];
    x[3] = c;
    x[5] = h[3];
    x[6] = 1.0;
    x[8] = 1.0;
  }
  x[1] /= x[0];
  x[2] /= x[0];
  x[4] -= x[1] * x[3];
  x[5] -= x[2] * x[3];
  x[7] -= x[1] * x[6];
  x[8] -= x[2] * x[6];
  if (std::abs(x[5]) > std::abs(x[4])) {
    itmp = p2;
    p2 = p3;
    p3 = itmp;
    t1 = x[1];
    x[1] = x[2];
    x[2] = t1;
    t1 = x[4];
    x[4] = x[5];
    x[5] = t1;
    t1 = x[7];
    x[7] = x[8];
    x[8] = t1;
  }
  x[5] /= x[4];
  x[8] -= x[5] * x[7];
  t1 = (x[1] * x[5] - x[2]) / x[8];
  t2 = -(x[1] + x[7] * t1) / x[4];
  h[p1] = ((1.0 - x[3] * t2) - x[6] * t1) / x[0];
  h[p1 + 1] = t2;
  h[p1 + 2] = t1;
  t1 = -x[5] / x[8];
  t2 = (1.0 - x[7] * t1) / x[4];
  h[p2] = -(x[3] * t2 + x[6] * t1) / x[0];
  h[p2 + 1] = t2;
  h[p2 + 2] = t1;
  t1 = 1.0 / x[8];
  t2 = -x[7] * t1 / x[4];
  h[p3] = -(x[3] * t2 + x[6] * t1) / x[0];
  h[p3 + 1] = t2;
  h[p3 + 2] = t1;
  // slp=pif(1:nn-2,:)*h(1,1)+pif(2:nn-1,:)*h(1,2)+pif(3:nn,:)*h(1,3);
  if (pif.size(0) - 1 < 2) {
    i = -1;
    i1 = -1;
  } else {
    i = 0;
    i1 = pif.size(0) - 2;
  }
  if (pif.size(0) - 2 < 1) {
    loop_ub = 0;
  } else {
    loop_ub = pif.size(0) - 2;
  }
  if (pif.size(0) < 3) {
    i2 = -1;
    i3 = -1;
    itmp = -1;
    p1 = -1;
  } else {
    i2 = 1;
    i3 = pif.size(0) - 1;
    itmp = 0;
    p1 = pif.size(0) - 2;
  }
  b_loop_ub = i1 - i;
  p2 = i3 - i2;
  p3 = p1 - itmp;
  if (b_loop_ub == 1) {
    i4 = loop_ub;
  } else {
    i4 = b_loop_ub;
  }
  if (p2 == 1) {
    result_tmp = p3;
  } else {
    result_tmp = p2;
  }
  if ((b_loop_ub == loop_ub) && (p2 == p3) && (i4 == result_tmp)) {
    t1 = 1.0 - 1.0 / c;
    p1 = pif.size(1);
    slp.set_size(b_loop_ub, pif.size(1));
    for (i1 = 0; i1 < p1; i1++) {
      p2 = (b_loop_ub / 2) << 1;
      p3 = p2 - 2;
      for (i3 = 0; i3 <= p3; i3 += 2) {
        _mm_storeu_pd(
            &slp[i3 + slp.size(0) * i1],
            _mm_div_pd(
                _mm_add_pd(
                    _mm_div_pd(
                        _mm_sub_pd(_mm_loadu_pd(
                                       &pif[((i + i3) + pif.size(0) * i1) + 1]),
                                   _mm_loadu_pd(&pif[i3 + pif.size(0) * i1])),
                        _mm_set1_pd(t1)),
                    _mm_div_pd(
                        _mm_sub_pd(
                            _mm_loadu_pd(
                                &pif[((i2 + i3) + pif.size(0) * i1) + 1]),
                            _mm_loadu_pd(
                                &pif[((itmp + i3) + pif.size(0) * i1) + 1])),
                        _mm_set1_pd(c - 1.0))),
                _mm_set1_pd(2.0)));
      }
      for (i3 = p2; i3 < b_loop_ub; i3++) {
        slp[i3 + slp.size(0) * i1] =
            ((pif[((i + i3) + pif.size(0) * i1) + 1] -
              pif[i3 + pif.size(0) * i1]) /
                 t1 +
             (pif[((i2 + i3) + pif.size(0) * i1) + 1] -
              pif[((itmp + i3) + pif.size(0) * i1) + 1]) /
                 (c - 1.0)) /
            2.0;
      }
    }
  } else {
    binary_expand_op_35(slp, pif, i + 1, i1, loop_ub - 1, c, i2 + 1, i3,
                        itmp + 1, p1);
  }
  if (slp.size(1) != 0) {
    result_tmp = slp.size(1);
  } else {
    result_tmp = 0;
  }
  empty_non_axis_sizes = (result_tmp == 0);
  if (empty_non_axis_sizes || (slp.size(1) != 0)) {
    input_sizes_idx_0 = 1;
  } else {
    input_sizes_idx_0 = 0;
  }
  if (empty_non_axis_sizes || ((slp.size(0) != 0) && (slp.size(1) != 0))) {
    p2 = slp.size(0);
  } else {
    p2 = 0;
  }
  if (empty_non_axis_sizes || (slp.size(1) != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }
  p1 = slp.size(1);
  b_slp.set_size(1, slp.size(1));
  p3 = input_sizes_idx_0;
  c_slp.set_size(1, slp.size(1));
  for (i = 0; i < p1; i++) {
    b_slp[i] = slp[slp.size(0) * i];
    c_slp[i] = slp[(pif.size(0) + slp.size(0) * i) - 3];
  }
  p1 = sizes_idx_0;
  i = input_sizes_idx_0 + p2;
  i1 = i + sizes_idx_0;
  d_slp.set_size(i1, result_tmp);
  for (i2 = 0; i2 < result_tmp; i2++) {
    for (i3 = 0; i3 < p3; i3++) {
      d_slp[d_slp.size(0) * i2] = b_slp[input_sizes_idx_0 * i2];
    }
    for (i3 = 0; i3 < p2; i3++) {
      d_slp[(i3 + input_sizes_idx_0) + d_slp.size(0) * i2] = slp[i3 + p2 * i2];
    }
    for (i3 = 0; i3 < p1; i3++) {
      d_slp[i + d_slp.size(0) * i2] = c_slp[sizes_idx_0 * i2];
    }
  }
  slp.set_size(i1, result_tmp);
  b_loop_ub = d_slp.size(0) * d_slp.size(1);
  for (i = 0; i < b_loop_ub; i++) {
    slp[i] = d_slp[i];
  }
  if (pif.size(0) - 1 < 2) {
    i = -1;
    i1 = -1;
  } else {
    i = 0;
    i1 = pif.size(0) - 2;
  }
  if (pif.size(0) < 3) {
    i2 = 0;
    i3 = 0;
  } else {
    i2 = 2;
    i3 = pif.size(0);
  }
  itmp = i1 - i;
  if (loop_ub == 1) {
    i4 = itmp;
  } else {
    i4 = loop_ub;
  }
  if ((loop_ub == itmp) && (i4 == i3 - i2)) {
    t1 = h[1];
    t2 = h[4];
    c = h[7];
    b_loop_ub = pif.size(1);
    pbl.set_size(loop_ub, pif.size(1));
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      p2 = (loop_ub / 2) << 1;
      p3 = p2 - 2;
      for (i3 = 0; i3 <= p3; i3 += 2) {
        _mm_storeu_pd(
            &pbl[i3 + pbl.size(0) * i1],
            _mm_add_pd(
                _mm_add_pd(
                    _mm_mul_pd(_mm_loadu_pd(&pif[i3 + pif.size(0) * i1]),
                               _mm_set1_pd(t1)),
                    _mm_mul_pd(
                        _mm_loadu_pd(&pif[((i + i3) + pif.size(0) * i1) + 1]),
                        _mm_set1_pd(t2))),
                _mm_mul_pd(_mm_loadu_pd(&pif[(i2 + i3) + pif.size(0) * i1]),
                           _mm_set1_pd(c))));
      }
      for (i3 = p2; i3 < loop_ub; i3++) {
        pbl[i3 + pbl.size(0) * i1] =
            (pif[i3 + pif.size(0) * i1] * t1 +
             pif[((i + i3) + pif.size(0) * i1) + 1] * t2) +
            pif[(i2 + i3) + pif.size(0) * i1] * c;
      }
    }
  } else {
    binary_expand_op_34(pbl, pif, loop_ub - 1, h, i + 1, i1, i2, i3 - 1);
  }
  if (pbl.size(1) != 0) {
    itmp = pbl.size(1);
  } else {
    itmp = 0;
  }
  empty_non_axis_sizes = (itmp == 0);
  if (empty_non_axis_sizes || (pbl.size(1) != 0)) {
    input_sizes_idx_0 = 1;
  } else {
    input_sizes_idx_0 = 0;
  }
  if (empty_non_axis_sizes || ((pbl.size(0) != 0) && (pbl.size(1) != 0))) {
    p2 = pbl.size(0);
  } else {
    p2 = 0;
  }
  if (empty_non_axis_sizes || (pbl.size(1) != 0)) {
    sizes_idx_0 = 1;
  } else {
    sizes_idx_0 = 0;
  }
  p1 = pbl.size(1);
  b_slp.set_size(1, pbl.size(1));
  p3 = input_sizes_idx_0;
  c_slp.set_size(1, pbl.size(1));
  for (i = 0; i < p1; i++) {
    b_slp[i] = pbl[pbl.size(0) * i];
    c_slp[i] = pbl[(pif.size(0) + pbl.size(0) * i) - 3];
  }
  p1 = sizes_idx_0;
  i = input_sizes_idx_0 + p2;
  i1 = i + sizes_idx_0;
  d_slp.set_size(i1, itmp);
  for (i2 = 0; i2 < itmp; i2++) {
    for (i3 = 0; i3 < p3; i3++) {
      d_slp[d_slp.size(0) * i2] = b_slp[input_sizes_idx_0 * i2];
    }
    for (i3 = 0; i3 < p2; i3++) {
      d_slp[(i3 + input_sizes_idx_0) + d_slp.size(0) * i2] = pbl[i3 + p2 * i2];
    }
    for (i3 = 0; i3 < p1; i3++) {
      d_slp[i + d_slp.size(0) * i2] = c_slp[sizes_idx_0 * i2];
    }
  }
  pbl.set_size(i1, itmp);
  loop_ub = d_slp.size(0) * d_slp.size(1);
  for (i = 0; i < loop_ub; i++) {
    pbl[i] = d_slp[i];
  }
  i = pif.size(0);
  for (p1 = 0; p1 < i; p1++) {
    t1 = fx[p1];
    for (i1 = 0; i1 < result_tmp; i1++) {
      slp[p1 + slp.size(0) * i1] = slp[p1 + slp.size(0) * i1] / t1;
    }
    t1 = fx[p1];
    for (i1 = 0; i1 < itmp; i1++) {
      pbl[p1 + pbl.size(0) * i1] = pbl[p1 + pbl.size(0) * i1] / t1;
    }
  }
}

static void zsmoothmapB(const coder::array<double, 2U> &map, double fs,
                        double f0floor, double nvo, double mu, double mlim,
                        coder::array<double, 2U> &smap)
{
  __m128d r;
  coder::array<creal_T, 2U> b_tm;
  coder::array<creal_T, 2U> r1;
  coder::array<double, 2U> b_map;
  coder::array<double, 2U> gent;
  coder::array<double, 2U> t;
  coder::array<double, 2U> wd1;
  coder::array<double, 2U> zt;
  coder::array<unsigned int, 2U> iiv;
  double mpv;
  double t0;
  double wl;
  int b_loop_ub;
  int i;
  int loop_ub;
  int scalarLB;
  int scalarLB_tmp;
  int vectorUB;
  int vectorUB_tmp;
  // --------------------------------------------
  // mu=0.4;
  t0 = 1.0 / f0floor;
  wl = rt_powd_snf(2.0, std::ceil(std::log(std::round(6.0 * t0 * fs * mu)) /
                                  0.69314718055994529));
  if (std::isnan(wl)) {
    gent.set_size(1, 1);
    gent[0] = rtNaN;
  } else if (wl < 1.0) {
    gent.set_size(gent.size(0), 0);
  } else {
    gent.set_size(1, static_cast<int>(wl - 1.0) + 1);
    loop_ub = static_cast<int>(wl - 1.0);
    for (i = 0; i <= loop_ub; i++) {
      gent[i] = static_cast<double>(i) + 1.0;
    }
  }
  gent.set_size(1, gent.size(1));
  wl /= 2.0;
  loop_ub = gent.size(1) - 1;
  scalarLB = (gent.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&gent[i]);
    _mm_storeu_pd(&gent[i],
                  _mm_div_pd(_mm_sub_pd(r, _mm_set1_pd(wl)), _mm_set1_pd(fs)));
  }
  for (i = scalarLB; i <= loop_ub; i++) {
    gent[i] = (gent[i] - wl) / fs;
  }
  i = map.size(0);
  loop_ub = map.size(1);
  smap.set_size(map.size(0), map.size(1));
  b_loop_ub = map.size(0) * map.size(1);
  for (int i1{0}; i1 < b_loop_ub; i1++) {
    smap[i1] = map[i1];
  }
  mpv = 1.0;
  b_loop_ub = gent.size(1);
  zt.set_size(1, gent.size(1));
  scalarLB_tmp = (gent.size(1) / 2) << 1;
  vectorUB_tmp = scalarLB_tmp - 2;
  for (int i1{0}; i1 <= vectorUB_tmp; i1 += 2) {
    r = _mm_loadu_pd(&gent[i1]);
    _mm_storeu_pd(&zt[i1], _mm_mul_pd(_mm_set1_pd(0.0), r));
  }
  for (int i1{scalarLB_tmp}; i1 < b_loop_ub; i1++) {
    zt[i1] = 0.0 * gent[i1];
  }
  if (map.size(1) < 1) {
    iiv.set_size(1, 0);
  } else {
    iiv.set_size(1, map.size(1));
    scalarLB = map.size(1) - 1;
    for (int i1{0}; i1 <= scalarLB; i1++) {
      iiv[i1] = static_cast<unsigned int>(i1) + 1U;
    }
  }
  for (int ii{0}; ii < i; ii++) {
    double bi;
    double br;
    double brm;
    double varargin_1;
    int b_i;
    int trueCount;
    int wbias;
    t.set_size(1, b_loop_ub);
    for (int i1{0}; i1 <= vectorUB_tmp; i1 += 2) {
      r = _mm_loadu_pd(&gent[i1]);
      _mm_storeu_pd(&t[i1], _mm_mul_pd(r, _mm_set1_pd(mpv)));
    }
    for (int i1{scalarLB_tmp}; i1 < b_loop_ub; i1++) {
      t[i1] = gent[i1] * mpv;
    }
    // t0*mu/mpv*1000
    scalarLB = t.size(1);
    wd1.set_size(1, t.size(1));
    for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
      wd1[vectorUB] = std::abs(t[vectorUB]);
    }
    scalarLB = wd1.size(1) - 1;
    trueCount = 0;
    vectorUB = 0;
    for (b_i = 0; b_i <= scalarLB; b_i++) {
      if (wd1[b_i] < 3.5 * mu * t0) {
        wbias = trueCount + 1;
        trueCount++;
        t[vectorUB] = t[b_i];
        vectorUB = wbias;
      }
    }
    t.set_size(1, trueCount);
    wbias = static_cast<int>(
        std::round((static_cast<double>(trueCount) - 1.0) / 2.0));
    wd1.set_size(1, trueCount);
    wl = t0 * 0.6;
    for (int i1{0}; i1 < trueCount; i1++) {
      varargin_1 = t[i1] / wl / mu;
      wd1[i1] = -3.1415926535897931 * rt_powd_snf(varargin_1, 2.0);
    }
    scalarLB = wd1.size(1);
    for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
      wd1[vectorUB] = std::exp(wd1[vectorUB]);
    }
    t.set_size(1, t.size(1));
    wl = t0 * 1.4;
    b_i = trueCount - 1;
    for (int i1{0}; i1 <= b_i; i1++) {
      varargin_1 = t[i1] / wl / mu;
      t[i1] = -3.1415926535897931 * rt_powd_snf(varargin_1, 2.0);
    }
    for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
      t[vectorUB] = std::exp(t[vectorUB]);
    }
    wl = legacy_STRAIGHT::combineVectorElements(wd1);
    wd1.set_size(1, wd1.size(1));
    scalarLB = (wd1.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&wd1[i1]);
      _mm_storeu_pd(&wd1[i1], _mm_div_pd(r, _mm_set1_pd(wl)));
    }
    for (int i1{scalarLB}; i1 <= b_i; i1++) {
      wd1[i1] = wd1[i1] / wl;
    }
    wl = legacy_STRAIGHT::combineVectorElements(t);
    t.set_size(1, t.size(1));
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&t[i1]);
      _mm_storeu_pd(&t[i1], _mm_div_pd(r, _mm_set1_pd(wl)));
    }
    for (int i1{scalarLB}; i1 <= b_i; i1++) {
      t[i1] = t[i1] / wl;
    }
    b_map.set_size(1, map.size(1) + zt.size(1));
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_map[i1] = map[ii + map.size(0) * i1];
    }
    b_i = zt.size(1);
    for (int i1{0}; i1 < b_i; i1++) {
      b_map[i1 + map.size(1)] = zt[i1];
    }
    legacy_STRAIGHT::fftfilt(wd1, b_map, b_tm);
    vectorUB = iiv.size(1);
    wd1.set_size(1, iiv.size(1));
    for (int i1{0}; i1 < vectorUB; i1++) {
      wd1[i1] = static_cast<double>(iiv[i1]) + static_cast<double>(wbias);
    }
    r1.set_size(1, wd1.size(1) + zt.size(1));
    for (int i1{0}; i1 < vectorUB; i1++) {
      scalarLB = static_cast<int>(wd1[i1]) - 1;
      br = b_tm[scalarLB].re;
      bi = b_tm[scalarLB].im;
      if (bi == 0.0) {
        r1[i1].re = 1.0 / br;
        r1[i1].im = 0.0;
      } else if (br == 0.0) {
        r1[i1].re = 0.0;
        r1[i1].im = -(1.0 / bi);
      } else {
        brm = std::abs(br);
        wl = std::abs(bi);
        if (brm > wl) {
          varargin_1 = bi / br;
          wl = br + varargin_1 * bi;
          r1[i1].re = (varargin_1 * 0.0 + 1.0) / wl;
          r1[i1].im = (0.0 - varargin_1) / wl;
        } else if (wl == brm) {
          if (br > 0.0) {
            varargin_1 = 0.5;
          } else {
            varargin_1 = -0.5;
          }
          if (bi > 0.0) {
            wl = 0.5;
          } else {
            wl = -0.5;
          }
          r1[i1].re = (varargin_1 + 0.0 * wl) / brm;
          r1[i1].im = (0.0 * varargin_1 - wl) / brm;
        } else {
          varargin_1 = br / bi;
          wl = bi + varargin_1 * br;
          r1[i1].re = varargin_1 / wl;
          r1[i1].im = (varargin_1 * 0.0 - 1.0) / wl;
        }
      }
    }
    for (int i1{0}; i1 < b_i; i1++) {
      r1[i1 + wd1.size(1)].re = zt[i1];
      r1[i1 + wd1.size(1)].im = 0.0;
    }
    legacy_STRAIGHT::fftfilt(t, r1, b_tm);
    for (int i1{0}; i1 < loop_ub; i1++) {
      scalarLB = static_cast<int>(wd1[i1]) - 1;
      br = b_tm[scalarLB].re;
      bi = b_tm[scalarLB].im;
      if (bi == 0.0) {
        wl = 1.0 / br;
      } else if (br == 0.0) {
        wl = 0.0;
      } else {
        brm = std::abs(br);
        wl = std::abs(bi);
        if (brm > wl) {
          varargin_1 = bi / br;
          wl = (varargin_1 * 0.0 + 1.0) / (br + varargin_1 * bi);
        } else if (wl == brm) {
          if (br > 0.0) {
            varargin_1 = 0.5;
          } else {
            varargin_1 = -0.5;
          }
          if (bi > 0.0) {
            wl = 0.5;
          } else {
            wl = -0.5;
          }
          wl = (varargin_1 + 0.0 * wl) / brm;
        } else {
          varargin_1 = br / bi;
          wl = varargin_1 / (bi + varargin_1 * br);
        }
      }
      smap[ii + smap.size(0) * i1] = wl;
    }
    if (t0 * mu / mpv * 1000.0 > mlim) {
      mpv *= rt_powd_snf(2.0, 1.0 / nvo);
    }
  }
}

static void zwvlt2ifq(coder::array<creal_T, 2U> &pm, double fs,
                      coder::array<double, 2U> &pif)
{
  __m128d r;
  coder::array<creal_T, 2U> b_pm;
  coder::array<creal_T, 2U> d_pm;
  coder::array<creal_T, 1U> c_pm;
  coder::array<double, 2U> y;
  coder::array<double, 1U> b_pif;
  double im;
  int sizes[2];
  int i;
  int k;
  int loop_ub;
  int nx;
  int nx_tmp;
  signed char input_sizes[2];
  boolean_T empty_non_axis_sizes;
  // ------------------------------------------------------------------
  // function pm=zmultanalytFineCSPm(x,fs,f0floor,nvc,nvo,mu,mlt);
  //        Dual waveleta analysis using cardinal spline manipulation
  //                pm=multanalytFineCSP(x,fs,f0floor,nvc,nvo);
  //        Input parameters
  //
  //                x       : input signal (2kHz sampling rate is sufficient.)
  //                fs      : sampling frequency (Hz)
  //                f0floor : lower bound for pitch search (60Hz suggested)
  //                nvc     : number of total voices for wavelet analysis
  //                nvo     : number of voices in an octave
  // 				mu		: temporal stretch factor
  //        Outpur parameters
  //                pm      : wavelet transform using iso-metric Gabor function
  //
  //        If you have any questions,  mailto:kawahara@hip.atr.co.jp
  //
  //        Copyright (c) ATR Human Information Processing Research Labs. 1996
  //        Invented and coded by Hideki Kawahara
  //        30/Oct./1996
  // t0=1/f0floor;
  // lmx=round(6*t0*fs*mu);
  // wl=2^ceil(log(lmx)/log(2));
  // x=x(:)';
  // nx=length(x);
  // tx=[x,zeros(1,wl)];
  // gent=((1:wl)-wl/2)/fs;
  // nvc=18;
  // wd=zeros(nvc,wl);
  // wd2=zeros(nvc,wl);
  // ym=zeros(nvc,nx);
  // pm=zeros(nvc,nx);
  // mpv=1;
  // mu=1.0;
  // for ii=1:nvc
  //   t=gent*mpv;
  //   t=t(abs(t)<3.5*mu*t0);
  //   wbias=round((length(t)-1)/2);
  //   wd1=exp(-pi*(t/t0/mu).^2);%.*exp(i*2*pi*t/t0);
  //   wd2=max(0,1-abs(t/t0/mu));
  //   wd2=wd2(wd2>0);
  //   wwd=conv(wd2,wd1);
  //   wwd=wwd(abs(wwd)>0.0001);
  //   wbias=round((length(wwd)-1)/2);
  //   wwd=wwd.*exp(i*2*pi*mlt*t(round((1:length(wwd))-wbias+length(t)/2))/t0);
  //   pmtmp1=fftfilt(wwd,tx);
  //   pm(ii,:)=pmtmp1(wbias+1:wbias+nx)*sqrt(mpv);
  //   mpv=mpv*(2.0^(1/nvo));
  //   keyboard;
  // end;
  // [nn,mm]=size(pm);
  // pm=pm(:,1:mlt:mm);
  // ----------------------------------------------------------------
  // 	Wavelet to instantaneous frequency map
  // 	fqv=wvlt2ifq(pm,fs)
  // 	Coded by Hideki Kawahara
  // 	02/March/1999
  nx = pm.size(1) - 1;
  nx_tmp = pm.size(0) * pm.size(1);
  y.set_size(pm.size(0), pm.size(1));
  for (k = 0; k < nx_tmp; k++) {
    y[k] = rt_hypotd_snf(pm[k].re, pm[k].im);
  }
  if ((pm.size(0) == y.size(0)) && (pm.size(1) == y.size(1))) {
    for (i = 0; i < nx_tmp; i++) {
      double ai;
      double br;
      double re;
      im = pm[i].re;
      ai = pm[i].im;
      br = y[i];
      if (ai == 0.0) {
        re = im / br;
        im = 0.0;
      } else if (im == 0.0) {
        re = 0.0;
        im = ai / br;
      } else {
        re = im / br;
        im = ai / br;
      }
      pm[i].re = re;
      pm[i].im = im;
    }
  } else {
    binary_expand_op_31(pm, y);
  }
  if (nx < 1) {
    loop_ub = 0;
  } else {
    loop_ub = nx;
  }
  if (pm.size(0) != 0) {
    nx = pm.size(0);
  } else {
    nx = 0;
  }
  empty_non_axis_sizes = (nx == 0);
  if (empty_non_axis_sizes || (pm.size(0) != 0)) {
    input_sizes[1] = 1;
  } else {
    input_sizes[1] = 0;
  }
  if (empty_non_axis_sizes || ((pm.size(0) != 0) && (loop_ub != 0))) {
    sizes[1] = loop_ub;
  } else {
    sizes[1] = 0;
  }
  i = input_sizes[1] + sizes[1];
  if ((pm.size(0) == nx) && (pm.size(1) == i)) {
    nx_tmp = pm.size(0);
    c_pm.set_size(pm.size(0));
    for (int i1{0}; i1 < nx_tmp; i1++) {
      c_pm[i1] = pm[i1];
    }
    k = input_sizes[1];
    d_pm.set_size(pm.size(0), loop_ub);
    for (int i1{0}; i1 < loop_ub; i1++) {
      for (int i2{0}; i2 < nx_tmp; i2++) {
        d_pm[i2 + d_pm.size(0) * i1] = pm[i2 + pm.size(0) * i1];
      }
    }
    b_pm.set_size(nx, i);
    loop_ub = input_sizes[1];
    for (i = 0; i < loop_ub; i++) {
      for (int i1{0}; i1 < nx; i1++) {
        b_pm[i1] = c_pm[i1];
      }
    }
    loop_ub = sizes[1];
    for (i = 0; i < loop_ub; i++) {
      for (int i1{0}; i1 < nx; i1++) {
        b_pm[i1 + b_pm.size(0) * (i + k)] = d_pm[i1 + nx * i];
      }
    }
    loop_ub = pm.size(1);
    b_pm.set_size(pm.size(0), pm.size(1));
    for (i = 0; i < loop_ub; i++) {
      for (int i1{0}; i1 < nx_tmp; i1++) {
        b_pm[i1 + b_pm.size(0) * i].re =
            pm[i1 + pm.size(0) * i].re - b_pm[i1 + b_pm.size(0) * i].re;
        b_pm[i1 + b_pm.size(0) * i].im =
            pm[i1 + pm.size(0) * i].im - b_pm[i1 + b_pm.size(0) * i].im;
      }
    }
  } else {
    binary_expand_op_30(b_pm, pm, nx, input_sizes, loop_ub, sizes);
  }
  nx = b_pm.size(0) * b_pm.size(1);
  pif.set_size(b_pm.size(0), b_pm.size(1));
  for (k = 0; k < nx; k++) {
    pif[k] = rt_hypotd_snf(b_pm[k].re, b_pm[k].im);
  }
  im = fs / 3.1415926535897931;
  loop_ub = pif.size(0) * pif.size(1);
  nx = (loop_ub / 2) << 1;
  k = nx - 2;
  for (i = 0; i <= k; i += 2) {
    r = _mm_loadu_pd(&pif[i]);
    _mm_storeu_pd(&pif[i], _mm_div_pd(r, _mm_set1_pd(2.0)));
  }
  for (i = nx; i < loop_ub; i++) {
    pif[i] = pif[i] / 2.0;
  }
  nx_tmp = pif.size(0) * pif.size(1);
  for (k = 0; k < nx_tmp; k++) {
    pif[k] = std::asin(pif[k]);
  }
  nx = (nx_tmp / 2) << 1;
  k = nx - 2;
  for (i = 0; i <= k; i += 2) {
    r = _mm_loadu_pd(&pif[i]);
    _mm_storeu_pd(&pif[i], _mm_mul_pd(_mm_set1_pd(im), r));
  }
  for (i = nx; i < nx_tmp; i++) {
    pif[i] = im * pif[i];
  }
  loop_ub = pif.size(0);
  b_pif.set_size(pif.size(0));
  for (i = 0; i < loop_ub; i++) {
    b_pif[i] = pif[i + pif.size(0)];
  }
  for (i = 0; i < loop_ub; i++) {
    pif[i] = b_pif[i];
  }
}

void fixpF0VexMltpBG4(const coder::array<double, 1U> &x, double fs,
                      double f0floor, double nvc, double nvo, double mu,
                      double shiftm, double smp, double minm, double pc,
                      double nc, coder::array<double, 2U> &f0v,
                      coder::array<double, 2U> &vrv,
                      coder::array<double, 2U> &dfv,
                      coder::array<double, 2U> &nf,
                      coder::array<double, 2U> &aav)
{
  __m128d r1;
  __m128d r2;
  coder::array<creal_T, 2U> b_pm1;
  coder::array<creal_T, 2U> b_x;
  coder::array<creal_T, 2U> pm1;
  coder::array<creal_T, 2U> pm2;
  coder::array<creal_T, 2U> pm3;
  coder::array<creal_T, 2U> r;
  coder::array<creal_T, 1U> c_x;
  coder::array<double, 2U> a;
  coder::array<double, 2U> dpif;
  coder::array<double, 2U> fixav;
  coder::array<double, 2U> fixdf;
  coder::array<double, 2U> mmp;
  coder::array<double, 2U> pif1;
  coder::array<double, 2U> pif2;
  coder::array<double, 2U> pif3;
  coder::array<double, 2U> smap;
  coder::array<double, 2U> y;
  coder::array<double, 1U> b_f0floor;
  coder::array<double, 1U> b_pif2;
  coder::array<double, 1U> b_smap;
  coder::array<double, 1U> b_y;
  coder::array<double, 1U> c_y;
  coder::array<double, 1U> d_y;
  coder::array<double, 1U> e_y;
  coder::array<double, 1U> fxx;
  double b_pm1_tmp;
  double b_varargin_1;
  double c_varargin_1;
  double d_varargin_1;
  double dn;
  double eeps;
  double pm1_tmp;
  double varargin_1;
  int b_loop_ub;
  int c_loop_ub;
  int end_tmp;
  int i;
  int i1;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  int mm2;
  int nx;
  int vectorUB;
  boolean_T b;
  // 	Fixed point analysis to extract F0
  // 	[f0v,vrv,dfv,nf]=fixpF0VexMltpBG4(x,fs,f0floor,nvc,nvo,mu,imgi,shiftm,smp,minm,pc,nc)
  // 	x	: input signal
  // 	fs	: sampling frequency (Hz)
  // 	f0floor	: lowest frequency for F0 search
  // 	nvc	: total number of filter channels
  // 	nvo	: number of channels per octave
  // 	mu	: temporal stretching factor
  // 	imgi	: image display indicator (1: display image, default)
  // 	shiftm	: frame shift in ms
  // 	smp	: smoothing length relative to fc (ratio)
  // 	minm	: minimum smoothing length (ms)
  // 	pc	: exponent to represent nonlinear summation
  // 	nc	: number of harmonic component to use (1,2,3)
  // 	Designed and coded by Hideki Kawahara
  // 	28/March/1999
  // 	04/April/1999 revised to multi component version
  // 	07/April/1999 bi-reciprocal smoothing for multi component compensation
  // 	01/May/1999 first derivative of Amplitude is taken into account
  // 	17/Dec./2000 display bug fix
  // 	19/Sep./2002 bug fix (mu information was discarded.)
  //    07/Dec./2002 waitbar was added
  // 	30/April/2005 modification for Matlab v7.0 compatibility
  // 	10/Aug./2005 modified by Takahashi on waitbar
  // 	10/Sept./2005 mofidied by Kawahara on waitbar
  //    11/Sept./2005 fixed waitbar problem
  // f0floor=40;
  // nvo=12;
  // nvc=52;
  // mu=1.1;
  cleaninglownoise(x, fs, f0floor, b_x);
  if (std::isnan(nvc - 1.0)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (nvc - 1.0 < 0.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(nvc - 1.0) + 1);
    loop_ub = static_cast<int>(nvc - 1.0);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = i;
    }
  }
  loop_ub = y.size(1);
  b_f0floor.set_size(y.size(1));
  for (i = 0; i < loop_ub; i++) {
    eeps = y[i] / nvo;
    b_f0floor[i] = f0floor * rt_powd_snf(2.0, eeps);
  }
  dn = std::fmax(
      1.0,
      std::floor(fs /
                 (legacy_STRAIGHT::coder::internal::maximum(b_f0floor) * 6.3)));
  legacy_STRAIGHT::decimate(b_x, dn * 3.0, r);
  pm1_tmp = fs / (dn * 3.0);
  multanalytFineCSPB(r, pm1_tmp, f0floor, nvc, nvo, mu, pm1);
  //  error crrect 2002.9.19(mu was fixed 1.1)
  // %%% safe guard added on 15/Jan./2003
  nx = pm1.size(0) * pm1.size(1);
  pif3.set_size(pm1.size(0), pm1.size(1));
  for (k = 0; k < nx; k++) {
    pif3[k] = rt_hypotd_snf(pm1[k].re, pm1[k].im);
  }
  legacy_STRAIGHT::coder::internal::maximum(pif3, y);
  eeps = legacy_STRAIGHT::coder::internal::maximum(y) / 1.0E+7;
  end_tmp = pm1.size(0) * pm1.size(1);
  nx = end_tmp - 1;
  for (mm2 = 0; mm2 <= nx; mm2++) {
    b_pm1_tmp = pm1[mm2].re;
    if ((b_pm1_tmp == 0.0) && (pm1[mm2].im == 0.0)) {
      pm1[mm2].re = b_pm1_tmp + eeps;
    }
  }
  // %%% safe guard end
  b_pm1.set_size(pm1.size(0), pm1.size(1));
  loop_ub = pm1.size(0) * pm1.size(1) - 1;
  for (i = 0; i <= loop_ub; i++) {
    b_pm1[i] = pm1[i];
  }
  zwvlt2ifq(b_pm1, pm1_tmp, pif3);
  i = pif3.size(0);
  mm2 = pif3.size(1);
  pif1.set_size(pif3.size(0), pif3.size(1));
  loop_ub_tmp = pif3.size(0) * pif3.size(1);
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    pif1[i1] = pif3[i1];
  }
  // keyboard;
  loop_ub = pm1.size(0);
  pm2.set_size(pm1.size(0), pm1.size(1));
  for (i1 = 0; i1 < end_tmp; i1++) {
    pm2[i1] = pm1[i1];
  }
  pm3.set_size(pm1.size(0), pm1.size(1));
  for (i1 = 0; i1 < end_tmp; i1++) {
    pm3[i1] = pm1[i1];
  }
  pif3.set_size(i, mm2);
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    pif3[i1] = pif1[i1];
  }
  if (nc > 2.0) {
    legacy_STRAIGHT::decimate(b_x, dn, r);
    eeps = fs / dn;
    b_multanalytFineCSPB(r, eeps, f0floor, nvc, nvo, mu, pm3);
    //  error crrect 2002.9.19 (mu was fixed 1.1)
    b_pm1.set_size(pm3.size(0), pm3.size(1));
    b_loop_ub = pm3.size(0) * pm3.size(1) - 1;
    for (i1 = 0; i1 <= b_loop_ub; i1++) {
      b_pm1[i1] = pm3[i1];
    }
    zwvlt2ifq(b_pm1, eeps, pif3);
    end_tmp = pif3.size(1);
    if (pif3.size(1) < 1) {
      i1 = 1;
      k = -1;
    } else {
      i1 = 3;
      k = pif3.size(1) - 1;
    }
    nx = pif3.size(0);
    b_loop_ub = div_s32(k, i1);
    fixav.set_size(pif3.size(0), b_loop_ub + 1);
    for (k = 0; k <= b_loop_ub; k++) {
      for (vectorUB = 0; vectorUB < nx; vectorUB++) {
        fixav[vectorUB + fixav.size(0) * k] =
            pif3[vectorUB + pif3.size(0) * (i1 * k)];
      }
    }
    pif3.set_size(nx, b_loop_ub + 1);
    b_loop_ub = fixav.size(0) * fixav.size(1);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      pif3[i1] = fixav[i1];
    }
    if (end_tmp < 1) {
      i1 = 1;
      k = -1;
    } else {
      i1 = 3;
      k = end_tmp - 1;
    }
    nx = pm3.size(0);
    b_loop_ub = div_s32(k, i1);
    b_pm1.set_size(pm3.size(0), b_loop_ub + 1);
    for (k = 0; k <= b_loop_ub; k++) {
      for (vectorUB = 0; vectorUB < nx; vectorUB++) {
        b_pm1[vectorUB + b_pm1.size(0) * k] =
            pm3[vectorUB + pm3.size(0) * (i1 * k)];
      }
    }
    pm3.set_size(nx, b_loop_ub + 1);
    b_loop_ub = b_pm1.size(0) * b_pm1.size(1);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      pm3[i1] = b_pm1[i1];
    }
  }
  pif2.set_size(i, mm2);
  for (i = 0; i < loop_ub_tmp; i++) {
    pif2[i] = pif1[i];
  }
  if (nc > 1.0) {
    legacy_STRAIGHT::decimate(b_x, dn, r);
    eeps = fs / dn;
    c_multanalytFineCSPB(r, eeps, f0floor, nvc, nvo, mu, pm2);
    //  error crrect 2002.9.19(mu was fixed 1.1)
    b_pm1.set_size(pm2.size(0), pm2.size(1));
    b_loop_ub = pm2.size(0) * pm2.size(1) - 1;
    for (i = 0; i <= b_loop_ub; i++) {
      b_pm1[i] = pm2[i];
    }
    zwvlt2ifq(b_pm1, eeps, pif2);
    end_tmp = pif2.size(1);
    if (pif2.size(1) < 1) {
      i = 1;
      i1 = -1;
    } else {
      i = 3;
      i1 = pif2.size(1) - 1;
    }
    nx = pif2.size(0);
    b_loop_ub = div_s32(i1, i);
    fixav.set_size(pif2.size(0), b_loop_ub + 1);
    for (i1 = 0; i1 <= b_loop_ub; i1++) {
      for (k = 0; k < nx; k++) {
        fixav[k + fixav.size(0) * i1] = pif2[k + pif2.size(0) * (i * i1)];
      }
    }
    pif2.set_size(nx, b_loop_ub + 1);
    b_loop_ub = fixav.size(0) * fixav.size(1);
    for (i = 0; i < b_loop_ub; i++) {
      pif2[i] = fixav[i];
    }
    if (end_tmp < 1) {
      i = 1;
      i1 = -1;
    } else {
      i = 3;
      i1 = end_tmp - 1;
    }
    nx = pm2.size(0);
    b_loop_ub = div_s32(i1, i);
    b_pm1.set_size(pm2.size(0), b_loop_ub + 1);
    for (i1 = 0; i1 <= b_loop_ub; i1++) {
      for (k = 0; k < nx; k++) {
        b_pm1[k + b_pm1.size(0) * i1] = pm2[k + pm2.size(0) * (i * i1)];
      }
    }
    pm2.set_size(nx, b_loop_ub + 1);
    b_loop_ub = b_pm1.size(0) * b_pm1.size(1);
    for (i = 0; i < b_loop_ub; i++) {
      pm2[i] = b_pm1[i];
    }
  }
  eeps = pif1.size(1);
  if (nc > 1.0) {
    mm2 = pif2.size(1);
    eeps = std::fmin(static_cast<double>(pif1.size(1)),
                     static_cast<double>(pif2.size(1)));
  }
  if (nc > 2.0) {
    double b_pif1[3];
    b_pif1[0] = pif1.size(1);
    b_pif1[1] = mm2;
    b_pif1[2] = pif3.size(1);
    eeps = legacy_STRAIGHT::coder::internal::minimum(b_pif1);
  }
  if (nc == 2.0) {
    i = static_cast<int>(eeps);
    for (int ii{0}; ii < i; ii++) {
      fxx.set_size(loop_ub);
      for (k = 0; k < loop_ub; k++) {
        fxx[k] = rt_hypotd_snf(pm1[k + pm1.size(0) * ii].re,
                               pm1[k + pm1.size(0) * ii].im);
      }
      loop_ub_tmp = pm2.size(0);
      b_y.set_size(pm2.size(0));
      for (k = 0; k < loop_ub_tmp; k++) {
        b_y[k] = rt_hypotd_snf(pm2[k + pm2.size(0) * ii].re,
                               pm2[k + pm2.size(0) * ii].im);
      }
      c_y.set_size(loop_ub);
      for (k = 0; k < loop_ub; k++) {
        c_y[k] = rt_hypotd_snf(pm1[k + pm1.size(0) * ii].re,
                               pm1[k + pm1.size(0) * ii].im);
      }
      d_y.set_size(pm2.size(0));
      for (k = 0; k < loop_ub_tmp; k++) {
        d_y[k] = rt_hypotd_snf(pm2[k + pm2.size(0) * ii].re,
                               pm2[k + pm2.size(0) * ii].im);
      }
      if (pif1.size(0) == 1) {
        i1 = fxx.size(0);
      } else {
        i1 = pif1.size(0);
      }
      if (pif2.size(0) == 1) {
        k = b_y.size(0);
      } else {
        k = pif2.size(0);
      }
      if (i1 == 1) {
        loop_ub_tmp = k;
      } else {
        loop_ub_tmp = i1;
      }
      if (c_y.size(0) == 1) {
        b_loop_ub = d_y.size(0);
      } else {
        b_loop_ub = c_y.size(0);
      }
      if ((pif1.size(0) == fxx.size(0)) && (pif2.size(0) == b_y.size(0)) &&
          (i1 == k) && (c_y.size(0) == d_y.size(0)) &&
          (loop_ub_tmp == b_loop_ub)) {
        b_loop_ub = pif2.size(0);
        for (i1 = 0; i1 < b_loop_ub; i1++) {
          varargin_1 = fxx[i1];
          b_varargin_1 = b_y[i1];
          c_varargin_1 = c_y[i1];
          d_varargin_1 = d_y[i1];
          pif2[i1 + pif2.size(0) * ii] =
              (pif1[i1 + pif1.size(0) * ii] * rt_powd_snf(varargin_1, pc) +
               pif2[i1 + pif2.size(0) * ii] / 2.0 *
                   rt_powd_snf(b_varargin_1, pc)) /
              (rt_powd_snf(c_varargin_1, pc) + rt_powd_snf(d_varargin_1, pc));
        }
      } else {
        binary_expand_op_5(pif2, ii, pif1, fxx, pc, b_y, c_y, d_y);
      }
    }
  }
  if (nc == 3.0) {
    i = static_cast<int>(eeps);
    for (int ii{0}; ii < i; ii++) {
      fxx.set_size(loop_ub);
      for (k = 0; k < loop_ub; k++) {
        fxx[k] = rt_hypotd_snf(pm1[k + pm1.size(0) * ii].re,
                               pm1[k + pm1.size(0) * ii].im);
      }
      loop_ub_tmp = pm2.size(0);
      b_y.set_size(pm2.size(0));
      for (k = 0; k < loop_ub_tmp; k++) {
        b_y[k] = rt_hypotd_snf(pm2[k + pm2.size(0) * ii].re,
                               pm2[k + pm2.size(0) * ii].im);
      }
      end_tmp = pm3.size(0);
      c_y.set_size(pm3.size(0));
      for (k = 0; k < end_tmp; k++) {
        c_y[k] = rt_hypotd_snf(pm3[k + pm3.size(0) * ii].re,
                               pm3[k + pm3.size(0) * ii].im);
      }
      d_y.set_size(loop_ub);
      for (k = 0; k < loop_ub; k++) {
        d_y[k] = rt_hypotd_snf(pm1[k + pm1.size(0) * ii].re,
                               pm1[k + pm1.size(0) * ii].im);
      }
      e_y.set_size(pm2.size(0));
      for (k = 0; k < loop_ub_tmp; k++) {
        e_y[k] = rt_hypotd_snf(pm2[k + pm2.size(0) * ii].re,
                               pm2[k + pm2.size(0) * ii].im);
      }
      b_f0floor.set_size(pm3.size(0));
      for (k = 0; k < end_tmp; k++) {
        b_f0floor[k] = rt_hypotd_snf(pm3[k + pm3.size(0) * ii].re,
                                     pm3[k + pm3.size(0) * ii].im);
      }
      if (pif1.size(0) == 1) {
        i1 = fxx.size(0);
      } else {
        i1 = pif1.size(0);
      }
      if (pif2.size(0) == 1) {
        k = b_y.size(0);
      } else {
        k = pif2.size(0);
      }
      if (i1 == 1) {
        vectorUB = k;
      } else {
        vectorUB = i1;
      }
      if (pif3.size(0) == 1) {
        nx = c_y.size(0);
      } else {
        nx = pif3.size(0);
      }
      if (d_y.size(0) == 1) {
        end_tmp = e_y.size(0);
      } else {
        end_tmp = d_y.size(0);
      }
      if (vectorUB == 1) {
        loop_ub_tmp = nx;
      } else {
        loop_ub_tmp = vectorUB;
      }
      if (end_tmp == 1) {
        b_loop_ub = b_f0floor.size(0);
      } else {
        b_loop_ub = end_tmp;
      }
      if ((pif1.size(0) == fxx.size(0)) && (pif2.size(0) == b_y.size(0)) &&
          (i1 == k) && (pif3.size(0) == c_y.size(0)) && (vectorUB == nx) &&
          (d_y.size(0) == e_y.size(0)) && (end_tmp == b_f0floor.size(0)) &&
          (loop_ub_tmp == b_loop_ub)) {
        b_loop_ub = pif2.size(0);
        for (i1 = 0; i1 < b_loop_ub; i1++) {
          varargin_1 = fxx[i1];
          b_varargin_1 = b_y[i1];
          c_varargin_1 = c_y[i1];
          d_varargin_1 = d_y[i1];
          eeps = e_y[i1];
          b_pm1_tmp = b_f0floor[i1];
          pif2[i1 + pif2.size(0) * ii] =
              ((pif1[i1 + pif1.size(0) * ii] * rt_powd_snf(varargin_1, pc) +
                pif2[i1 + pif2.size(0) * ii] / 2.0 *
                    rt_powd_snf(b_varargin_1, pc)) +
               pif3[i1 + pif3.size(0) * ii] / 3.0 *
                   rt_powd_snf(c_varargin_1, pc)) /
              ((rt_powd_snf(d_varargin_1, pc) + rt_powd_snf(eeps, pc)) +
               rt_powd_snf(b_pm1_tmp, pc));
        }
      } else {
        binary_expand_op_6(pif2, ii, pif1, fxx, pc, b_y, pif3, c_y, d_y, e_y,
                           b_f0floor);
      }
    }
  }
  if (nc == 1.0) {
    pif2.set_size(pif1.size(0), pif1.size(1));
    b_loop_ub = pif1.size(0) * pif1.size(1);
    for (i = 0; i < b_loop_ub; i++) {
      pif2[i] = pif1[i];
    }
  }
  // pif2=zwvlt2ifq(pm,fs/dn)*2*pi;
  b_loop_ub = pif2.size(0) * pif2.size(1);
  mm2 = (b_loop_ub / 2) << 1;
  vectorUB = mm2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r1 = _mm_loadu_pd(&pif2[i]);
    _mm_storeu_pd(&pif2[i], _mm_mul_pd(_mm_mul_pd(r1, _mm_set1_pd(2.0)),
                                       _mm_set1_pd(3.1415926535897931)));
  }
  for (i = mm2; i < b_loop_ub; i++) {
    pif2[i] = pif2[i] * 2.0 * 3.1415926535897931;
  }
  dn *= 3.0;
  zifq2gpm2(pif2, f0floor, nvo, fixav, pif3);
  if (pif2.size(1) < 2) {
    i = 0;
    i1 = 0;
  } else {
    i = 1;
    i1 = pif2.size(1);
  }
  if (pif2.size(1) - 1 < 1) {
    k = 0;
  } else {
    k = pif2.size(1) - 1;
  }
  b_loop_ub = i1 - i;
  if (b_loop_ub == k) {
    c_loop_ub = pif2.size(0);
    dpif.set_size(pif2.size(0), b_loop_ub);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      mm2 = (pif2.size(0) / 2) << 1;
      vectorUB = mm2 - 2;
      for (k = 0; k <= vectorUB; k += 2) {
        r1 = _mm_loadu_pd(&pif2[k + pif2.size(0) * (i + i1)]);
        r2 = _mm_loadu_pd(&pif2[k + pif2.size(0) * i1]);
        _mm_storeu_pd(
            &dpif[k + dpif.size(0) * i1],
            _mm_div_pd(_mm_mul_pd(_mm_sub_pd(r1, r2), _mm_set1_pd(fs)),
                       _mm_set1_pd(dn)));
      }
      for (k = mm2; k < c_loop_ub; k++) {
        dpif[k + dpif.size(0) * i1] =
            (pif2[k + pif2.size(0) * (i + i1)] - pif2[k + pif2.size(0) * i1]) *
            fs / dn;
      }
    }
  } else {
    binary_expand_op_11(dpif, pif2, i, i1 - 1, k - 1, fs, dn);
  }
  b_loop_ub = dpif.size(0);
  b_f0floor.set_size(dpif.size(0));
  for (i = 0; i < b_loop_ub; i++) {
    b_f0floor[i] = dpif[i + dpif.size(0) * (pif2.size(1) - 2)];
  }
  for (i = 0; i < b_loop_ub; i++) {
    dpif[i + dpif.size(0) * (pif2.size(1) - 1)] = b_f0floor[i];
  }
  zifq2gpm2(dpif, f0floor, nvo, fixdf, pif3);
  if (pif2.size(1) < 2) {
    i = 0;
    i1 = 0;
  } else {
    i = 1;
    i1 = pif2.size(1);
  }
  if (pif2.size(1) - 1 < 1) {
    c_loop_ub = 0;
  } else {
    c_loop_ub = pif2.size(1) - 1;
  }
  nx = i1 - i;
  b_pm1.set_size(pm1.size(0), nx);
  for (i1 = 0; i1 < nx; i1++) {
    for (k = 0; k < loop_ub; k++) {
      b_pm1[k + b_pm1.size(0) * i1] = pm1[k + pm1.size(0) * (i + i1)];
    }
  }
  nx = b_pm1.size(0) * b_pm1.size(1);
  pif3.set_size(b_pm1.size(0), b_pm1.size(1));
  for (k = 0; k < nx; k++) {
    pif3[k] = rt_hypotd_snf(b_pm1[k].re, b_pm1[k].im);
  }
  b_pm1.set_size(pm1.size(0), c_loop_ub);
  for (i = 0; i < c_loop_ub; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_pm1[i1 + b_pm1.size(0) * i] = pm1[i1 + pm1.size(0) * i];
    }
  }
  nx = b_pm1.size(0) * b_pm1.size(1);
  mmp.set_size(b_pm1.size(0), b_pm1.size(1));
  for (k = 0; k < nx; k++) {
    mmp[k] = rt_hypotd_snf(b_pm1[k].re, b_pm1[k].im);
  }
  if ((pif3.size(0) == mmp.size(0)) && (pif3.size(1) == mmp.size(1))) {
    pif1.set_size(pif3.size(0), pif3.size(1));
    c_loop_ub = pif3.size(0) * pif3.size(1);
    mm2 = (c_loop_ub / 2) << 1;
    vectorUB = mm2 - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      r1 = _mm_loadu_pd(&pif3[i]);
      r2 = _mm_loadu_pd(&mmp[i]);
      _mm_storeu_pd(&pif1[i],
                    _mm_div_pd(_mm_mul_pd(_mm_sub_pd(r1, r2), _mm_set1_pd(fs)),
                               _mm_set1_pd(dn)));
    }
    for (i = mm2; i < c_loop_ub; i++) {
      pif1[i] = (pif3[i] - mmp[i]) * fs / dn;
    }
  } else {
    binary_expand_op_10(pif1, pif3, mmp, fs, dn);
  }
  c_loop_ub = pif1.size(0);
  b_f0floor.set_size(pif1.size(0));
  for (i = 0; i < c_loop_ub; i++) {
    b_f0floor[i] = pif1[i + pif1.size(0) * (pif2.size(1) - 2)];
  }
  for (i = 0; i < c_loop_ub; i++) {
    pif1[i + pif1.size(0) * (pif2.size(1) - 1)] = b_f0floor[i];
  }
  nx = pm1.size(0) * pm1.size(1);
  pif3.set_size(pm1.size(0), pm1.size(1));
  for (k = 0; k < nx; k++) {
    pif3[k] = rt_hypotd_snf(pm1[k].re, pm1[k].im);
  }
  if ((pif1.size(0) == pif3.size(0)) && (pif1.size(1) == pif3.size(1))) {
    c_loop_ub = pif1.size(0) * pif1.size(1);
    pif3.set_size(pif1.size(0), pif1.size(1));
    mm2 = (c_loop_ub / 2) << 1;
    vectorUB = mm2 - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      r1 = _mm_loadu_pd(&pif1[i]);
      r2 = _mm_loadu_pd(&pif3[i]);
      _mm_storeu_pd(&pif3[i], _mm_div_pd(r1, r2));
    }
    for (i = mm2; i < c_loop_ub; i++) {
      pif3[i] = pif1[i] / pif3[i];
    }
  } else {
    binary_expand_op_9(pif3, pif1);
  }
  // [c1,c2]=znormwght(1000);
  if (pif2.size(0) - 1 < 0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, pif2.size(0));
    c_loop_ub = pif2.size(0) - 1;
    for (i = 0; i <= c_loop_ub; i++) {
      y[i] = i;
    }
  }
  c_loop_ub = y.size(1);
  fxx.set_size(y.size(1));
  for (i = 0; i < c_loop_ub; i++) {
    eeps = y[i] / nvo;
    fxx[i] = f0floor * rt_powd_snf(2.0, eeps) * 2.0 * 3.1415926535897931;
  }
  mmp.set_size(fixdf.size(0), fixdf.size(1));
  c_loop_ub = fixdf.size(0) * fixdf.size(1);
  mm2 = (c_loop_ub / 2) << 1;
  vectorUB = mm2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r1 = _mm_loadu_pd(&fixdf[i]);
    _mm_storeu_pd(&mmp[i], _mm_mul_pd(_mm_set1_pd(0.0), r1));
  }
  for (i = mm2; i < c_loop_ub; i++) {
    mmp[i] = 0.0 * fixdf[i];
  }
  // if imgi==1; hpg=waitbar(0,'P/N map calculation'); end; % 07/Dec./2002 by
  // H.K.%10/Aug./2005
  c_loop_ub = pif2.size(0);
  for (int ii{0}; ii < c_loop_ub; ii++) {
    // 	[c1,c2]=znrmlcf2(fxx(ii)/2/pi); % This is OK, but the next Eq is much
    // faster.
    eeps = fxx[ii] / 2.0 / 3.1415926535897931;
    loop_ub_tmp = pif3.size(1);
    y.set_size(1, pif3.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      varargin_1 = pif3[ii + pif3.size(0) * i] / fxx[ii] * 2.0 *
                   3.1415926535897931 * 0.0;
      y[i] = rt_powd_snf(varargin_1, 2.0) + 1.0;
    }
    eeps = std::sqrt(2.679634240937665 * (eeps * eeps));
    loop_ub_tmp = fixdf.size(1);
    if (fixdf.size(1) == y.size(1)) {
      a.set_size(1, fixdf.size(1));
      for (i = 0; i < loop_ub_tmp; i++) {
        a[i] = fixdf[ii + fixdf.size(0) * i] / y[i] / eeps;
      }
    } else {
      binary_expand_op_8(a, fixdf, ii, y, eeps);
    }
    nx = y.size(1);
    mm2 = (y.size(1) / 2) << 1;
    vectorUB = mm2 - 2;
    for (k = 0; k <= vectorUB; k += 2) {
      r1 = _mm_loadu_pd(&y[k]);
      _mm_storeu_pd(&y[k], _mm_sqrt_pd(r1));
    }
    for (k = mm2; k < nx; k++) {
      y[k] = std::sqrt(y[k]);
    }
    if (fixav.size(1) == 1) {
      i = y.size(1);
    } else {
      i = fixav.size(1);
    }
    if ((fixav.size(1) == y.size(1)) && (a.size(1) == i)) {
      nx = mmp.size(1);
      for (i = 0; i < nx; i++) {
        varargin_1 = a[i];
        b_varargin_1 = fixav[ii + fixav.size(0) * i] / y[i] / 0.607835129511774;
        mmp[ii + mmp.size(0) * i] =
            rt_powd_snf(varargin_1, 2.0) + rt_powd_snf(b_varargin_1, 2.0);
      }
    } else {
      binary_expand_op_7(mmp, ii, a, fixav, y);
    }
    // if imgi==1; waitbar(ii/nn); end; %,hpg); % 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end;%10/Aug./2005
  if (smp != 0.0) {
    zsmoothmapB(mmp, pm1_tmp, f0floor, nvo, smp, minm, smap);
  } else {
    smap.set_size(mmp.size(0), mmp.size(1));
    nx = mmp.size(0) * mmp.size(1);
    for (i = 0; i < nx; i++) {
      smap[i] = mmp[i];
    }
  }
  nx = static_cast<int>(std::round(static_cast<double>(pif2.size(0)) / 3.0));
  i = pif2.size(1);
  pif3.set_size(nx, pif2.size(1));
  loop_ub_tmp = nx * pif2.size(1);
  mmp.set_size(nx, pif2.size(1));
  fixdf.set_size(nx, pif2.size(1));
  fixav.set_size(nx, pif2.size(1));
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    pif3[i1] = 0.0;
    mmp[i1] = 1.0E+8;
    fixdf[i1] = 1.0E+8;
    fixav[i1] = 1.0E+9;
  }
  nf.set_size(1, pif2.size(1));
  // if imgi==1; hpg=waitbar(0,'Fixed pints calculation'); end; % 07/Dec./2002
  // by H.K.%10/Aug./2005
  end_tmp = smap.size(0);
  mm2 = (b_loop_ub / 2) << 1;
  vectorUB = mm2 - 2;
  for (int ii{0}; ii < i; ii++) {
    b_pif2.set_size(c_loop_ub);
    for (i1 = 0; i1 < c_loop_ub; i1++) {
      b_pif2[i1] = pif2[i1 + pif2.size(0) * ii];
    }
    b_smap.set_size(end_tmp);
    for (i1 = 0; i1 < end_tmp; i1++) {
      b_smap[i1] = smap[i1 + smap.size(0) * ii];
    }
    b_f0floor.set_size(b_loop_ub);
    for (i1 = 0; i1 <= vectorUB; i1 += 2) {
      r1 = _mm_loadu_pd(&dpif[i1 + dpif.size(0) * ii]);
      _mm_storeu_pd(&b_f0floor[i1],
                    _mm_div_pd(_mm_div_pd(r1, _mm_set1_pd(2.0)),
                               _mm_set1_pd(3.1415926535897931)));
    }
    for (i1 = mm2; i1 < b_loop_ub; i1++) {
      b_f0floor[i1] = dpif[i1 + dpif.size(0) * ii] / 2.0 / 3.1415926535897931;
    }
    c_x.set_size(loop_ub);
    for (i1 = 0; i1 < loop_ub; i1++) {
      c_x[i1] = pm1[i1 + pm1.size(0) * ii];
    }
    zfixpfreq3(fxx, b_pif2, b_smap, b_f0floor, c_x, b_y, c_y, d_y, e_y);
    nx = b_y.size(0);
    for (i1 = 0; i1 < nx; i1++) {
      pif3[i1 + pif3.size(0) * ii] = b_y[i1];
    }
    for (i1 = 0; i1 < nx; i1++) {
      mmp[i1 + mmp.size(0) * ii] = c_y[i1];
    }
    for (i1 = 0; i1 < nx; i1++) {
      fixdf[i1 + fixdf.size(0) * ii] = d_y[i1];
    }
    for (i1 = 0; i1 < nx; i1++) {
      fixav[i1 + fixav.size(0) * ii] = e_y[i1];
    }
    nf[ii] = b_y.size(0);
    // if imgi==1 && rem(ii,10)==0; waitbar(ii/mm); end;% 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end; % 07/Dec./2002 by H.K.%10/Aug./2005
  nx = loop_ub_tmp - 1;
  for (mm2 = 0; mm2 <= nx; mm2++) {
    if (pif3[mm2] == 0.0) {
      pif3[mm2] = pif3[mm2] + 1.0E+6;
    }
  }
  // keyboard
  // [vvm,ivv]=min(fixvv);
  //
  // for ii=1:mm
  // 	ff00(ii)=fixpp(ivv(ii),ii);
  // 	esgm(ii)=fixvv(ivv(ii),ii);
  // end;
  eeps = legacy_STRAIGHT::coder::internal::maximum(nf);
  if (eeps < 1.0) {
    loop_ub_tmp = 0;
  } else {
    loop_ub_tmp = static_cast<int>(eeps);
  }
  eeps = shiftm / dn * fs / 1000.0;
  b = std::isnan(eeps);
  if (b) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if ((eeps == 0.0) || ((pif2.size(1) > 1) && (eeps < 0.0))) {
    y.set_size(1, 0);
  } else if (std::isinf(eeps)) {
    y.set_size(1, 1);
    y[0] = 1.0;
  } else if (std::floor(eeps) == eeps) {
    loop_ub =
        static_cast<int>((static_cast<double>(pif2.size(1)) - 1.0) / eeps);
    y.set_size(1, loop_ub + 1);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = eeps * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(eeps, static_cast<double>(pif2.size(1)),
                                     y);
  }
  nx = y.size(1);
  for (k = 0; k < nx; k++) {
    y[k] = std::round(y[k]);
  }
  f0v.set_size(loop_ub_tmp, y.size(1));
  for (i = 0; i < nx; i++) {
    mm2 = (loop_ub_tmp / 2) << 1;
    vectorUB = mm2 - 2;
    for (i1 = 0; i1 <= vectorUB; i1 += 2) {
      r1 =
          _mm_loadu_pd(&pif3[i1 + pif3.size(0) * (static_cast<int>(y[i]) - 1)]);
      _mm_storeu_pd(&f0v[i1 + f0v.size(0) * i],
                    _mm_div_pd(_mm_div_pd(r1, _mm_set1_pd(2.0)),
                               _mm_set1_pd(3.1415926535897931)));
    }
    for (i1 = mm2; i1 < loop_ub_tmp; i1++) {
      f0v[i1 + f0v.size(0) * i] =
          pif3[i1 + pif3.size(0) * (static_cast<int>(y[i]) - 1)] / 2.0 /
          3.1415926535897931;
    }
  }
  if (b) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if ((eeps == 0.0) || ((pif2.size(1) > 1) && (eeps < 0.0))) {
    y.set_size(1, 0);
  } else if (std::isinf(eeps)) {
    y.set_size(1, 1);
    y[0] = 1.0;
  } else if (std::floor(eeps) == eeps) {
    loop_ub =
        static_cast<int>((static_cast<double>(pif2.size(1)) - 1.0) / eeps);
    y.set_size(1, loop_ub + 1);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = eeps * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(eeps, static_cast<double>(pif2.size(1)),
                                     y);
  }
  nx = y.size(1);
  for (k = 0; k < nx; k++) {
    y[k] = std::round(y[k]);
  }
  vrv.set_size(loop_ub_tmp, y.size(1));
  for (i = 0; i < nx; i++) {
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      vrv[i1 + vrv.size(0) * i] =
          mmp[i1 + mmp.size(0) * (static_cast<int>(y[i]) - 1)];
    }
  }
  if (b) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if ((eeps == 0.0) || ((pif2.size(1) > 1) && (eeps < 0.0))) {
    y.set_size(1, 0);
  } else if (std::isinf(eeps)) {
    y.set_size(1, 1);
    y[0] = 1.0;
  } else if (std::floor(eeps) == eeps) {
    loop_ub =
        static_cast<int>((static_cast<double>(pif2.size(1)) - 1.0) / eeps);
    y.set_size(1, loop_ub + 1);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = eeps * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(eeps, static_cast<double>(pif2.size(1)),
                                     y);
  }
  nx = y.size(1);
  for (k = 0; k < nx; k++) {
    y[k] = std::round(y[k]);
  }
  dfv.set_size(loop_ub_tmp, y.size(1));
  for (i = 0; i < nx; i++) {
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      dfv[i1 + dfv.size(0) * i] =
          fixdf[i1 + fixdf.size(0) * (static_cast<int>(y[i]) - 1)];
    }
  }
  if (b) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if ((eeps == 0.0) || ((pif2.size(1) > 1) && (eeps < 0.0))) {
    y.set_size(1, 0);
  } else if (std::isinf(eeps)) {
    y.set_size(1, 1);
    y[0] = 1.0;
  } else if (std::floor(eeps) == eeps) {
    loop_ub =
        static_cast<int>((static_cast<double>(pif2.size(1)) - 1.0) / eeps);
    y.set_size(1, loop_ub + 1);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = eeps * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(eeps, static_cast<double>(pif2.size(1)),
                                     y);
  }
  nx = y.size(1);
  for (k = 0; k < nx; k++) {
    y[k] = std::round(y[k]);
  }
  aav.set_size(loop_ub_tmp, y.size(1));
  for (i = 0; i < nx; i++) {
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      aav[i1 + aav.size(0) * i] =
          fixav[i1 + fixav.size(0) * (static_cast<int>(y[i]) - 1)];
    }
  }
  if (b) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if ((eeps == 0.0) || ((pif2.size(1) > 1) && (eeps < 0.0))) {
    y.set_size(1, 0);
  } else if (std::isinf(eeps)) {
    y.set_size(1, 1);
    y[0] = 1.0;
  } else if (std::floor(eeps) == eeps) {
    loop_ub =
        static_cast<int>((static_cast<double>(pif2.size(1)) - 1.0) / eeps);
    y.set_size(1, loop_ub + 1);
    for (i = 0; i <= loop_ub; i++) {
      y[i] = eeps * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(eeps, static_cast<double>(pif2.size(1)),
                                     y);
  }
  nx = y.size(1);
  for (k = 0; k < nx; k++) {
    y[k] = std::round(y[k]);
  }
  a.set_size(1, y.size(1));
  for (i = 0; i < nx; i++) {
    a[i] = nf[static_cast<int>(y[i]) - 1];
  }
  nf.set_size(1, y.size(1));
  for (i = 0; i < nx; i++) {
    nf[i] = a[i];
  }
  // ff00=ff00(round(1:shiftm/dn*fs/1000:mm));
  // esgm=sqrt(esgm(round(1:shiftm/dn*fs/1000:mm)));
  // keyboard;
}

// End of code generation (fixpF0VexMltpBG4.cpp)
