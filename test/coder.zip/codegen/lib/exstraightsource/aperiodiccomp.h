//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// aperiodiccomp.h
//
// Code generation for function 'aperiodiccomp'
//

#ifndef APERIODICCOMP_H
#define APERIODICCOMP_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_3(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2,
                        const coder::array<double, 2U> &in3);

#endif
// End of code generation (aperiodiccomp.h)
