//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// main.cpp
//
// Code generation for function 'main'
//

/*************************************************************************/
/* This automatically generated example C++ main file shows how to call  */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/

// Include files
#include "main.h"
#include "exstraightsource.h"
#include "exstraightsource_terminate.h"
#include "exstraightsource_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Declarations
static coder::array<double, 1U> argInit_Unboundedx1_real_T();

static char argInit_char_T();

static double argInit_real_T();

static void argInit_struct0_T(struct0_T &result);

// Function Definitions
static coder::array<double, 1U> argInit_Unboundedx1_real_T()
{
  coder::array<double, 1U> result;
  // Set the size of the array.
  // Change this size to the value that the application requires.
  result.set_size(2);
  // Loop over the array to initialize each element.
  for (int idx0{0}; idx0 < result.size(0); idx0++) {
    // Set the value of the array element.
    // Change this value to the value that the application requires.
    result[idx0] = argInit_real_T();
  }
  return result;
}

static char argInit_char_T()
{
  return '?';
}

static double argInit_real_T()
{
  return 0.0;
}

static void argInit_struct0_T(struct0_T &result)
{
  double result_tmp;
  // Set the value of each structure field.
  // Change this value to the value that the application requires.
  result_tmp = argInit_real_T();
  result.F0searchUpperBound = result_tmp;
  result.F0defaultWindowLength = result_tmp;
  result.F0frameUpdateInterval = result_tmp;
  result.NofChannelsInOctave = result_tmp;
  result.IFWindowStretch = result_tmp;
  result.DisplayPlots = result_tmp;
  result.IFsmoothingLengthRelToFc = result_tmp;
  result.IFminimumSmoothingLength = result_tmp;
  result.IFexponentForNonlinearSum = result_tmp;
  result.IFnumberOfHarmonicForInitialEstimate = result_tmp;
  result.refineFftLength = result_tmp;
  result.refineTimeStretchingFactor = result_tmp;
  result.refineNumberofHarmonicComponent = result_tmp;
  result.periodicityFrameUpdateInterval = result_tmp;
  result.F0searchLowerBound = result_tmp;
  result.note = argInit_char_T();
}

int main(int, char **)
{
  // The initialize function is being called automatically from your entry-point
  // function. So, a call to initialize is not included here. Invoke the
  // entry-point functions.
  // You can call entry-point functions multiple times.
  main_exstraightsource();
  // Terminate the application.
  // You do not need to do this more than one time.
  exstraightsource_terminate();
  return 0;
}

void main_exstraightsource()
{
  coder::array<double, 2U> ap;
  coder::array<double, 2U> f0raw;
  coder::array<double, 1U> x;
  struct0_T analysisParams;
  struct0_T r;
  // Initialize function 'exstraightsource' input arguments.
  // Initialize function input argument 'x'.
  x = argInit_Unboundedx1_real_T();
  // Initialize function input argument 'optionalParams'.
  // Call the entry-point 'exstraightsource'.
  argInit_struct0_T(r);
  exstraightsource(x, argInit_real_T(), &r, f0raw, ap, &analysisParams);
}

// End of code generation (main.cpp)
