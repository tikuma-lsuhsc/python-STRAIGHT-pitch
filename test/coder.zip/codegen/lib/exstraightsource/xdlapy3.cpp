//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xdlapy3.cpp
//
// Code generation for function 'xdlapy3'
//

// Include files
#include "xdlapy3.h"
#include "rt_nonfinite.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
double xdlapy3(double x1, double x2, double x3)
{
  double a;
  double b;
  double c;
  double y;
  a = std::abs(x1);
  b = std::abs(x2);
  c = std::abs(x3);
  if (a > b) {
    y = a;
  } else {
    y = b;
  }
  if (c > y) {
    y = c;
  }
  if ((y > 0.0) && (!std::isinf(y))) {
    a /= y;
    b /= y;
    c /= y;
    y *= std::sqrt((a * a + c * c) + b * b);
  } else {
    y = (a + b) + c;
  }
  return y;
}

} // namespace internal
} // namespace coder
} // namespace legacy_STRAIGHT

// End of code generation (xdlapy3.cpp)
