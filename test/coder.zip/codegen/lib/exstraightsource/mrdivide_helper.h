//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mrdivide_helper.h
//
// Code generation for function 'mrdivide_helper'
//

#ifndef MRDIVIDE_HELPER_H
#define MRDIVIDE_HELPER_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
void mrdiv(const ::coder::array<creal_T, 2U> &A,
           const ::coder::array<creal_T, 2U> &B,
           ::coder::array<creal_T, 1U> &Y);

}
} // namespace coder
} // namespace legacy_STRAIGHT

#endif
// End of code generation (mrdivide_helper.h)
