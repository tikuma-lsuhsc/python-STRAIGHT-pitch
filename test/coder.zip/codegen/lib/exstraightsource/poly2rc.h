//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// poly2rc.h
//
// Code generation for function 'poly2rc'
//

#ifndef POLY2RC_H
#define POLY2RC_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_23(double in1_data[], int in4, int in6, int in7, int in8,
                         int in9, int in10, double in11);

#endif
// End of code generation (poly2rc.h)
