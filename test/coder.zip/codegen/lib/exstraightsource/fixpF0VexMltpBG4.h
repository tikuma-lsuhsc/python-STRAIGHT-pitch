//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fixpF0VexMltpBG4.h
//
// Code generation for function 'fixpF0VexMltpBG4'
//

#ifndef FIXPF0VEXMLTPBG4_H
#define FIXPF0VEXMLTPBG4_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void fixpF0VexMltpBG4(const coder::array<double, 1U> &x, double fs,
                      double f0floor, double nvc, double nvo, double mu,
                      double shiftm, double smp, double minm, double pc,
                      double nc, coder::array<double, 2U> &f0v,
                      coder::array<double, 2U> &vrv,
                      coder::array<double, 2U> &dfv,
                      coder::array<double, 2U> &nf,
                      coder::array<double, 2U> &aav);

#endif
// End of code generation (fixpF0VexMltpBG4.h)
