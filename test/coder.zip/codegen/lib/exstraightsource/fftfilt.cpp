//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fftfilt.cpp
//
// Code generation for function 'fftfilt'
//

// Include files
#include "fftfilt.h"
#include "FFTImplementationCallback.h"
#include "exstraightsource_rtwutil.h"
#include "fft.h"
#include "ifft.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Variable Definitions
static const int iv[21]{2,     4,     8,      16,     32,     64,      128,
                        256,   512,   1024,   2048,   4096,   8192,    16384,
                        32768, 65536, 131072, 262144, 524288, 1048576, 2097152};

static const double dv[21]{
    18.0,           59.0,        138.0,        303.0,        660.0,
    1441.0,         3150.0,      6875.0,       14952.0,      32373.0,
    69762.0,        149647.0,    319644.0,     680105.0,     1.441974E+6,
    3.047619E+6,    6.422736E+6, 1.3500637E+7, 2.8311786E+7, 5.9244791E+7,
    1.2382161319E+8};

// Function Declarations
static void binary_expand_op_14(coder::array<creal_T, 2U> &in1, int in2,
                                int in3, int in4, int in5,
                                const coder::array<creal_T, 2U> &in6, int in7);

static void binary_expand_op_15(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2);

static void binary_expand_op_43(coder::array<creal_T, 1U> &in1, int in2,
                                int in3, int in4, int in5,
                                const coder::array<creal_T, 1U> &in6, int in7);

static void binary_expand_op_44(coder::array<creal_T, 1U> &in1,
                                const coder::array<creal_T, 1U> &in2,
                                const coder::array<creal_T, 1U> &in3);

static void binary_expand_op_80(creal_T in1_data[], int in2, int in3, int in4,
                                int in5, const coder::array<creal_T, 1U> &in6,
                                int in7);

static void binary_expand_op_81(coder::array<creal_T, 1U> &in1,
                                const coder::array<creal_T, 1U> &in2);

// Function Definitions
static void binary_expand_op_14(coder::array<creal_T, 2U> &in1, int in2,
                                int in3, int in4, int in5,
                                const coder::array<creal_T, 2U> &in6, int in7)
{
  coder::array<creal_T, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  i = (in5 - in4) + 1;
  if (in7 + 1 == 1) {
    loop_ub = i;
  } else {
    loop_ub = in7 + 1;
  }
  if (in6.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in6.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (i != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in7 + 1 != 1);
  stride_1_1 = (in6.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      int i2;
      int i3;
      i2 = in4 + i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      b_in1[i1 + b_in1.size(0) * i].re = in1[i2 + in1.size(0) * aux_0_1].re +
                                         in6[i3 + in6.size(0) * aux_1_1].re;
      b_in1[i1 + b_in1.size(0) * i].im = in1[i2 + in1.size(0) * aux_0_1].im +
                                         in6[i3 + in6.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  loop_ub = in3 - in2;
  b_loop_ub = in1.size(1);
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[(in2 + i1) + in1.size(0) * i] = b_in1[i1 + loop_ub * i];
    }
  }
}

static void binary_expand_op_15(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double d;
      double d1;
      double d2;
      double d3;
      int i2;
      int i3;
      i2 = i1 * stride_0_0;
      d = in1[i2 + in1.size(0) * aux_0_1].re;
      i3 = i1 * stride_1_0;
      d1 = in2[i3 + in2.size(0) * aux_1_1].im;
      d2 = in1[i2 + in1.size(0) * aux_0_1].im;
      d3 = in2[i3 + in2.size(0) * aux_1_1].re;
      b_in1[i1 + b_in1.size(0) * i].re = d * d3 - d2 * d1;
      b_in1[i1 + b_in1.size(0) * i].im = d * d1 + d2 * d3;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  legacy_STRAIGHT::ifft(b_in1, in1);
}

static void binary_expand_op_43(coder::array<creal_T, 1U> &in1, int in2,
                                int in3, int in4, int in5,
                                const coder::array<creal_T, 1U> &in6, int in7)
{
  coder::array<creal_T, 1U> b_in1;
  int in3_idx_0_tmp;
  int stride_0_0;
  int stride_1_0;
  in3_idx_0_tmp = in3 - in2;
  b_in1.set_size(in3_idx_0_tmp);
  stride_0_0 = ((in5 - in4) + 1 != 1);
  stride_1_0 = (in7 + 1 != 1);
  for (int i{0}; i < in3_idx_0_tmp; i++) {
    int i1;
    i1 = i * stride_1_0;
    b_in1[i].re = in1[in4 + i * stride_0_0].re + in6[i1].re;
    b_in1[i].im = in1[in4 + i * stride_0_0].im + in6[i1].im;
  }
  for (int i{0}; i < in3_idx_0_tmp; i++) {
    in1[in2 + i] = b_in1[i];
  }
}

static void binary_expand_op_44(coder::array<creal_T, 1U> &in1,
                                const coder::array<creal_T, 1U> &in2,
                                const coder::array<creal_T, 1U> &in3)
{
  coder::array<creal_T, 1U> b_in2;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  b_in2.set_size(loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    double d;
    double d1;
    double d2;
    double d3;
    int i1;
    int i2;
    i1 = i * stride_0_0;
    d = in2[i1].re;
    i2 = i * stride_1_0;
    d1 = in3[i2].im;
    d2 = in2[i1].im;
    d3 = in3[i2].re;
    b_in2[i].re = d * d3 - d2 * d1;
    b_in2[i].im = d * d1 + d2 * d3;
  }
  legacy_STRAIGHT::ifft(b_in2, in1);
}

static void binary_expand_op_80(creal_T in1_data[], int in2, int in3, int in4,
                                int in5, const coder::array<creal_T, 1U> &in6,
                                int in7)
{
  creal_T b_in1_data[3076];
  int in3_idx_0_tmp;
  int stride_0_0;
  int stride_1_0;
  in3_idx_0_tmp = in3 - in2;
  stride_0_0 = ((in5 - in4) + 1 != 1);
  stride_1_0 = (in7 + 1 != 1);
  for (int i{0}; i < in3_idx_0_tmp; i++) {
    int i1;
    i1 = i * stride_1_0;
    b_in1_data[i].re = in1_data[in4 + i * stride_0_0].re + in6[i1].re;
    b_in1_data[i].im = in1_data[in4 + i * stride_0_0].im + in6[i1].im;
  }
  for (int i{0}; i < in3_idx_0_tmp; i++) {
    in1_data[in2 + i] = b_in1_data[i];
  }
}

static void binary_expand_op_81(coder::array<creal_T, 1U> &in1,
                                const coder::array<creal_T, 1U> &in2)
{
  coder::array<creal_T, 1U> b_in1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in2.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    double d;
    double d1;
    double d2;
    double d3;
    int i1;
    int i2;
    i1 = i * stride_0_0;
    d = in1[i1].re;
    i2 = i * stride_1_0;
    d1 = in2[i2].im;
    d2 = in1[i1].im;
    d3 = in2[i2].re;
    b_in1[i].re = d * d3 - d2 * d1;
    b_in1[i].im = d * d1 + d2 * d3;
  }
  legacy_STRAIGHT::ifft(b_in1, in1);
}

namespace legacy_STRAIGHT {
void b_fftfilt(const ::coder::array<double, 1U> &b,
               const ::coder::array<creal_T, 2U> &x,
               ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B1;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> b_xCol;
  ::coder::array<creal_T, 2U> xCol;
  ::coder::array<creal_T, 1U> B;
  ::coder::array<double, 2U> b_x;
  ::coder::array<double, 1U> bCol;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx;
  int trueCount;
  signed char tmp_data[21];
  boolean_T exitg1;
  boolean_T varargout_1;
  if (x.size(0) == 1) {
    nx = x.size(1);
    xCol.set_size(x.size(1), 1);
    for (i = 0; i < nx; i++) {
      xCol[i] = x[i];
    }
  } else {
    xCol.set_size(x.size(0), x.size(1));
    loop_ub = x.size(0) * x.size(1);
    for (i = 0; i < loop_ub; i++) {
      xCol[i] = x[i];
    }
    nx = x.size(0);
  }
  if (b.size(0) > 1) {
    i = 1;
  } else {
    i = b.size(0);
  }
  if (i > 1) {
    loop_ub = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < loop_ub; i++) {
      bCol[i] = b[i];
    }
    nb = b.size(0);
  } else {
    nb_tmp = b.size(0);
    nb = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= nx) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs((static_cast<double>(nb) + static_cast<double>(nx)) - 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = nx;
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      b_tmp_data[nb_tmp] = std::ceil(static_cast<double>(nx) /
                                     static_cast<double>(L1_data[nb_tmp]));
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  loop_ub = B.size(0);
  trueCount = xCol.size(1);
  B1.set_size(B.size(0), xCol.size(1));
  for (i = 0; i < trueCount; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      B1[i1 + B1.size(0) * i] = B[i1];
    }
  }
  if (xCol.size(1) == 1) {
    nb_tmp = xCol.size(0);
    B.set_size(xCol.size(0));
    for (i = 0; i < nb_tmp; i++) {
      B[i] = xCol[i];
    }
    xCol.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      xCol[i] = B[i];
    }
  }
  y.set_size(xCol.size(0), xCol.size(1));
  loop_ub = xCol.size(0) * xCol.size(1);
  for (i = 0; i < loop_ub; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx; istart += static_cast<double>(L)) {
    double d;
    int i2;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx));
    if (iend - istart == 0.0) {
      b_i = static_cast<int>(nfft);
      loop_ub = xCol.size(1);
      X.set_size(b_i, xCol.size(1));
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < b_i; i1++) {
          X[i1 + X.size(0) * i] =
              xCol[(static_cast<int>(istart) + xCol.size(0) * i) - 1];
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      loop_ub = i1 - i;
      trueCount = xCol.size(1);
      b_xCol.set_size(loop_ub, xCol.size(1));
      for (i1 = 0; i1 < trueCount; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_xCol[i2 + b_xCol.size(0) * i1] = xCol[(i + i2) + xCol.size(0) * i1];
        }
      }
      fft(b_xCol, nfft, X);
    }
    if ((X.size(0) == B1.size(0)) && (X.size(1) == B1.size(1))) {
      b_xCol.set_size(X.size(0), X.size(1));
      loop_ub = X.size(0) * X.size(1);
      for (i = 0; i < loop_ub; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B1[i].im;
        d1 = X[i].im;
        d2 = B1[i].re;
        b_xCol[i].re = d * d2 - d1 * iend;
        b_xCol[i].im = d * iend + d1 * d2;
      }
      ifft(b_xCol, X);
    } else {
      binary_expand_op_15(X, B1);
    }
    iend = std::fmin(static_cast<double>(nx), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = 0;
      i1 = 0;
    } else {
      i = static_cast<int>(istart) - 1;
      i1 = static_cast<int>(iend);
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      nb = 0;
      nb_tmp = 0;
    } else {
      nb = static_cast<int>(istart) - 1;
      nb_tmp = static_cast<int>(iend);
    }
    loop_ub = i1 - i;
    if ((loop_ub == i2) && (y.size(1) == X.size(1))) {
      trueCount = y.size(1);
      b_xCol.set_size(loop_ub, y.size(1));
      for (i1 = 0; i1 < trueCount; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_i = i + i2;
          b_xCol[i2 + b_xCol.size(0) * i1].re =
              y[b_i + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          b_xCol[i2 + b_xCol.size(0) * i1].im =
              y[b_i + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      nb_tmp -= nb;
      for (i = 0; i < trueCount; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(nb + i1) + y.size(0) * i] = b_xCol[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, nb, nb_tmp, i, i1 - 1, X, i2 - 1);
    }
  }
  b_x.set_size(x.size(0), x.size(1));
  b_i = x.size(0) * x.size(1);
  for (i = 0; i < b_i; i++) {
    b_x[i] = x[i].im;
  }
  varargout_1 = false;
  nb_tmp = 0;
  exitg1 = false;
  while ((!exitg1) && (nb_tmp + 1 <= b_i)) {
    if ((b_x[nb_tmp] == 0.0) || std::isnan(b_x[nb_tmp])) {
      nb_tmp++;
    } else {
      varargout_1 = true;
      exitg1 = true;
    }
  }
  if (!varargout_1) {
    loop_ub = y.size(0) * y.size(1);
    for (i = 0; i < loop_ub; i++) {
      y[i].re = y[i].re;
      y[i].im = 0.0;
    }
  }
  if ((x.size(0) == 1) && (y.size(1) == 1)) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<creal_T, 2U> &b,
             const ::coder::array<creal_T, 2U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> bCol;
  ::coder::array<creal_T, 2U> xCol1;
  ::coder::array<creal_T, 1U> b_B;
  ::coder::array<double, 2U> b_x;
  double d;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx_tmp;
  int trueCount;
  signed char tmp_data[21];
  boolean_T exitg1;
  boolean_T varargout_1;
  nx_tmp = x.size(1);
  if (b.size(1) < 1) {
    i = b.size(1);
  } else {
    i = 1;
  }
  if (i > 1) {
    loop_ub = b.size(1);
    bCol.set_size(1, b.size(1));
    for (i = 0; i < loop_ub; i++) {
      bCol[i] = b[i];
    }
    nb = 1;
  } else {
    nb_tmp = b.size(1);
    nb = b.size(1);
    bCol.set_size(b.size(1), 1);
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= x.size(1)) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                     static_cast<unsigned int>(x.size(1))) -
                 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = x.size(1);
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      d = static_cast<double>(x.size(1)) / static_cast<double>(L1_data[nb_tmp]);
      d = std::ceil(d);
      b_tmp_data[nb_tmp] = d;
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  if (bCol.size(1) == 1) {
    nb_tmp = B.size(0);
    b_B.set_size(B.size(0));
    for (i = 0; i < nb_tmp; i++) {
      b_B[i] = B[i];
    }
    B.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      B[i] = b_B[i];
    }
  }
  loop_ub = bCol.size(1);
  xCol1.set_size(x.size(1), bCol.size(1));
  for (i = 0; i < loop_ub; i++) {
    for (i1 = 0; i1 < nx_tmp; i1++) {
      xCol1[i1 + xCol1.size(0) * i] = x[i1];
    }
  }
  y.set_size(x.size(1), bCol.size(1));
  nb_tmp = x.size(1) * bCol.size(1);
  for (i = 0; i < nb_tmp; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx_tmp; istart += static_cast<double>(L)) {
    int i2;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx_tmp));
    if (iend - istart == 0.0) {
      nb_tmp = static_cast<int>(nfft);
      X.set_size(nb_tmp, loop_ub);
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          X[i1 + X.size(0) * i] =
              xCol1[(static_cast<int>(istart) + xCol1.size(0) * i) - 1];
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb_tmp = i1 - i;
      bCol.set_size(nb_tmp, loop_ub);
      for (i1 = 0; i1 < loop_ub; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          bCol[i2 + bCol.size(0) * i1] = xCol1[(i + i2) + xCol1.size(0) * i1];
        }
      }
      fft(bCol, nfft, X);
    }
    if ((X.size(0) == B.size(0)) && (X.size(1) == B.size(1))) {
      bCol.set_size(X.size(0), X.size(1));
      nb_tmp = X.size(0) * X.size(1);
      for (i = 0; i < nb_tmp; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B[i].im;
        d1 = X[i].im;
        d2 = B[i].re;
        bCol[i].re = d * d2 - d1 * iend;
        bCol[i].im = d * iend + d1 * d2;
      }
      ifft(bCol, X);
    } else {
      binary_expand_op_15(X, B);
    }
    iend = std::fmin(static_cast<double>(nx_tmp), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = 0;
      i1 = 0;
    } else {
      i = static_cast<int>(istart) - 1;
      i1 = static_cast<int>(iend);
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      nb = 0;
      b_i = 0;
    } else {
      nb = static_cast<int>(istart) - 1;
      b_i = static_cast<int>(iend);
    }
    nb_tmp = i1 - i;
    if ((nb_tmp == i2) && (y.size(1) == X.size(1))) {
      int b_loop_ub;
      b_loop_ub = y.size(1);
      bCol.set_size(nb_tmp, y.size(1));
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          trueCount = i + i2;
          bCol[i2 + bCol.size(0) * i1].re =
              y[trueCount + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          bCol[i2 + bCol.size(0) * i1].im =
              y[trueCount + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      nb_tmp = b_i - nb;
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(nb + i1) + y.size(0) * i] = bCol[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, nb, b_i, i, i1 - 1, X, i2 - 1);
    }
  }
  loop_ub = b.size(1);
  b_x.set_size(1, b.size(1));
  for (i = 0; i < loop_ub; i++) {
    b_x[i] = b[i].im;
  }
  varargout_1 = false;
  nb_tmp = 0;
  exitg1 = false;
  while ((!exitg1) && (nb_tmp + 1 <= b_x.size(1))) {
    if ((b_x[nb_tmp] == 0.0) || std::isnan(b_x[nb_tmp])) {
      nb_tmp++;
    } else {
      varargout_1 = true;
      exitg1 = true;
    }
  }
  if (!varargout_1) {
    b_x.set_size(1, x.size(1));
    for (i = 0; i < nx_tmp; i++) {
      b_x[i] = x[i].im;
    }
    varargout_1 = false;
    nb_tmp = 0;
    exitg1 = false;
    while ((!exitg1) && (nb_tmp + 1 <= b_x.size(1))) {
      if ((b_x[nb_tmp] == 0.0) || std::isnan(b_x[nb_tmp])) {
        nb_tmp++;
      } else {
        varargout_1 = true;
        exitg1 = true;
      }
    }
    if (!varargout_1) {
      loop_ub = y.size(0) * y.size(1);
      for (i = 0; i < loop_ub; i++) {
        y[i].re = y[i].re;
        y[i].im = 0.0;
      }
    }
  }
  if (y.size(1) == 1) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<double, 2U> &b,
             const ::coder::array<creal_T, 2U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> b_xCol1;
  ::coder::array<creal_T, 2U> xCol1;
  ::coder::array<creal_T, 1U> b_B;
  ::coder::array<double, 2U> bCol;
  ::coder::array<double, 2U> b_x;
  double d;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx_tmp;
  int trueCount;
  signed char tmp_data[21];
  boolean_T exitg1;
  boolean_T varargout_1;
  nx_tmp = x.size(1);
  if (b.size(1) < 1) {
    i = b.size(1);
  } else {
    i = 1;
  }
  if (i > 1) {
    loop_ub = b.size(1);
    bCol.set_size(1, b.size(1));
    for (i = 0; i < loop_ub; i++) {
      bCol[i] = b[i];
    }
    nb = 1;
  } else {
    nb_tmp = b.size(1);
    nb = b.size(1);
    bCol.set_size(b.size(1), 1);
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= x.size(1)) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                     static_cast<unsigned int>(x.size(1))) -
                 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = x.size(1);
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      d = static_cast<double>(x.size(1)) / static_cast<double>(L1_data[nb_tmp]);
      d = std::ceil(d);
      b_tmp_data[nb_tmp] = d;
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  if (bCol.size(1) == 1) {
    nb_tmp = B.size(0);
    b_B.set_size(B.size(0));
    for (i = 0; i < nb_tmp; i++) {
      b_B[i] = B[i];
    }
    B.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      B[i] = b_B[i];
    }
  }
  loop_ub = bCol.size(1);
  xCol1.set_size(x.size(1), bCol.size(1));
  for (i = 0; i < loop_ub; i++) {
    for (i1 = 0; i1 < nx_tmp; i1++) {
      xCol1[i1 + xCol1.size(0) * i] = x[i1];
    }
  }
  y.set_size(x.size(1), bCol.size(1));
  nb_tmp = x.size(1) * bCol.size(1);
  for (i = 0; i < nb_tmp; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx_tmp; istart += static_cast<double>(L)) {
    int i2;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx_tmp));
    if (iend - istart == 0.0) {
      nb_tmp = static_cast<int>(nfft);
      X.set_size(nb_tmp, loop_ub);
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          X[i1 + X.size(0) * i] =
              xCol1[(static_cast<int>(istart) + xCol1.size(0) * i) - 1];
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb_tmp = i1 - i;
      b_xCol1.set_size(nb_tmp, loop_ub);
      for (i1 = 0; i1 < loop_ub; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          b_xCol1[i2 + b_xCol1.size(0) * i1] =
              xCol1[(i + i2) + xCol1.size(0) * i1];
        }
      }
      fft(b_xCol1, nfft, X);
    }
    if ((X.size(0) == B.size(0)) && (X.size(1) == B.size(1))) {
      b_xCol1.set_size(X.size(0), X.size(1));
      nb_tmp = X.size(0) * X.size(1);
      for (i = 0; i < nb_tmp; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B[i].im;
        d1 = X[i].im;
        d2 = B[i].re;
        b_xCol1[i].re = d * d2 - d1 * iend;
        b_xCol1[i].im = d * iend + d1 * d2;
      }
      ifft(b_xCol1, X);
    } else {
      binary_expand_op_15(X, B);
    }
    iend = std::fmin(static_cast<double>(nx_tmp), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = 0;
      i1 = 0;
    } else {
      i = static_cast<int>(istart) - 1;
      i1 = static_cast<int>(iend);
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      nb = 0;
      b_i = 0;
    } else {
      nb = static_cast<int>(istart) - 1;
      b_i = static_cast<int>(iend);
    }
    nb_tmp = i1 - i;
    if ((nb_tmp == i2) && (y.size(1) == X.size(1))) {
      int b_loop_ub;
      b_loop_ub = y.size(1);
      b_xCol1.set_size(nb_tmp, y.size(1));
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          trueCount = i + i2;
          b_xCol1[i2 + b_xCol1.size(0) * i1].re =
              y[trueCount + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          b_xCol1[i2 + b_xCol1.size(0) * i1].im =
              y[trueCount + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      nb_tmp = b_i - nb;
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(nb + i1) + y.size(0) * i] = b_xCol1[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, nb, b_i, i, i1 - 1, X, i2 - 1);
    }
  }
  b_x.set_size(1, x.size(1));
  for (i = 0; i < nx_tmp; i++) {
    b_x[i] = x[i].im;
  }
  varargout_1 = false;
  nb_tmp = 0;
  exitg1 = false;
  while ((!exitg1) && (nb_tmp + 1 <= b_x.size(1))) {
    if ((b_x[nb_tmp] == 0.0) || std::isnan(b_x[nb_tmp])) {
      nb_tmp++;
    } else {
      varargout_1 = true;
      exitg1 = true;
    }
  }
  if (!varargout_1) {
    loop_ub = y.size(0) * y.size(1);
    for (i = 0; i < loop_ub; i++) {
      y[i].re = y[i].re;
      y[i].im = 0.0;
    }
  }
  if (y.size(1) == 1) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<double, 1U> &b,
             const ::coder::array<creal_T, 2U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> B;
  ::coder::array<creal_T, 1U> X;
  ::coder::array<creal_T, 1U> Y;
  ::coder::array<creal_T, 1U> b_y1;
  ::coder::array<creal_T, 1U> xCol1;
  ::coder::array<double, 2U> b_x;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  ::coder::array<double, 1U> bCol;
  double iend;
  double nfft;
  int tmp_size[2];
  int i;
  int nb;
  int nb_tmp;
  int nx_tmp;
  int partialTrueCount;
  int trueCount;
  signed char tmp_data[21];
  boolean_T exitg1;
  boolean_T useRadix2;
  nx_tmp = x.size(1);
  if (b.size(0) > 1) {
    i = 1;
  } else {
    i = b.size(0);
  }
  if (i > 1) {
    nb_tmp = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
    nb = b.size(0);
  } else {
    nb_tmp = b.size(0);
    nb = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= x.size(1)) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                     static_cast<unsigned int>(x.size(1))) -
                 1.0),
        &partialTrueCount);
    if (iend == 0.5) {
      partialTrueCount--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(partialTrueCount));
    nb = x.size(1);
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    partialTrueCount = 0;
    for (nb_tmp = 0; nb_tmp < 21; nb_tmp++) {
      if (nb - 1 < iv[nb_tmp]) {
        trueCount++;
        tmp_data[partialTrueCount] = static_cast<signed char>(nb_tmp);
        partialTrueCount++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    partialTrueCount = nb_tmp - 4;
    for (i = 0; i <= partialTrueCount; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      iend =
          static_cast<double>(x.size(1)) / static_cast<double>(L1_data[nb_tmp]);
      iend = std::ceil(iend);
      b_tmp_data[nb_tmp] = iend;
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    nb = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  xCol1.set_size(x.size(1));
  b_y1.set_size(x.size(1));
  for (i = 0; i < nx_tmp; i++) {
    xCol1[i] = x[i];
    b_y1[i].re = 0.0;
    b_y1[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx_tmp;
       istart += static_cast<double>(nb)) {
    double yend;
    int i1;
    iend = std::fmin((istart + static_cast<double>(nb)) - 1.0,
                     static_cast<double>(nx_tmp));
    if (iend - istart == 0.0) {
      nb_tmp = static_cast<int>(nfft);
      X.set_size(nb_tmp);
      for (i = 0; i < nb_tmp; i++) {
        X[i] = xCol1[static_cast<int>(istart) - 1];
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb_tmp = i1 - i;
      Y.set_size(nb_tmp);
      for (i1 = 0; i1 < nb_tmp; i1++) {
        Y[i1] = xCol1[i + i1];
      }
      if ((nb_tmp == 0) || (static_cast<int>(nfft) == 0)) {
        nb_tmp = static_cast<int>(nfft);
        X.set_size(static_cast<int>(nfft));
        for (i = 0; i < nb_tmp; i++) {
          X[i].re = 0.0;
          X[i].im = 0.0;
        }
      } else {
        useRadix2 =
            ((static_cast<int>(nfft) > 0) &&
             ((static_cast<int>(nfft) & (static_cast<int>(nfft) - 1)) == 0));
        nb_tmp =
            coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
                static_cast<int>(nfft), useRadix2, partialTrueCount);
        coder::internal::fft::FFTImplementationCallback::
            generate_twiddle_tables(partialTrueCount, useRadix2, b_x, sintab,
                                    sintabinv);
        if (useRadix2) {
          coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
              Y, static_cast<int>(nfft), b_x, sintab, X);
        } else {
          coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
              Y, nb_tmp, static_cast<int>(nfft), b_x, sintab, sintabinv, X);
        }
      }
    }
    if (X.size(0) == B.size(0)) {
      nb_tmp = X.size(0);
      for (i = 0; i < nb_tmp; i++) {
        double b_re_tmp;
        double re_tmp;
        iend = X[i].re;
        yend = B[i].im;
        re_tmp = X[i].im;
        b_re_tmp = B[i].re;
        X[i].re = iend * b_re_tmp - re_tmp * yend;
        X[i].im = iend * yend + re_tmp * b_re_tmp;
      }
      ifft(X, Y);
    } else {
      binary_expand_op_44(Y, X, B);
    }
    yend = std::fmin(static_cast<double>(nx_tmp), (istart + nfft) - 1.0);
    if (istart > yend) {
      i = 0;
      i1 = 0;
    } else {
      i = static_cast<int>(istart) - 1;
      i1 = static_cast<int>(yend);
    }
    iend = (yend - istart) + 1.0;
    if (iend < 1.0) {
      partialTrueCount = 0;
    } else {
      partialTrueCount = static_cast<int>(iend);
    }
    if (istart > yend) {
      trueCount = 0;
      nb_tmp = 0;
    } else {
      trueCount = static_cast<int>(istart) - 1;
      nb_tmp = static_cast<int>(yend);
    }
    if (i1 - i == partialTrueCount) {
      nb_tmp -= trueCount;
      X.set_size(nb_tmp);
      for (i1 = 0; i1 < nb_tmp; i1++) {
        partialTrueCount = i + i1;
        X[i1].re = b_y1[partialTrueCount].re + Y[i1].re;
        X[i1].im = b_y1[partialTrueCount].im + Y[i1].im;
      }
      for (i = 0; i < nb_tmp; i++) {
        b_y1[trueCount + i] = X[i];
      }
    } else {
      binary_expand_op_43(b_y1, trueCount, nb_tmp, i, i1 - 1, Y,
                          partialTrueCount - 1);
    }
  }
  b_x.set_size(1, x.size(1));
  for (i = 0; i < nx_tmp; i++) {
    b_x[i] = x[i].im;
  }
  useRadix2 = false;
  nb_tmp = 0;
  exitg1 = false;
  while ((!exitg1) && (nb_tmp + 1 <= b_x.size(1))) {
    if ((b_x[nb_tmp] == 0.0) || std::isnan(b_x[nb_tmp])) {
      nb_tmp++;
    } else {
      useRadix2 = true;
      exitg1 = true;
    }
  }
  if (!useRadix2) {
    nb_tmp = b_y1.size(0);
    for (i = 0; i < nb_tmp; i++) {
      b_y1[i].im = 0.0;
    }
  }
  nb_tmp = b_y1.size(0);
  y.set_size(1, b_y1.size(0));
  for (i = 0; i < nb_tmp; i++) {
    y[i] = b_y1[i];
  }
}

void fftfilt(const ::coder::array<double, 2U> &b,
             const ::coder::array<double, 1U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> b_X;
  ::coder::array<creal_T, 1U> b_B;
  ::coder::array<double, 2U> bCol;
  ::coder::array<double, 2U> xCol1;
  ::coder::array<double, 1U> xCol;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx;
  int trueCount;
  signed char tmp_data[21];
  if (x.size(0) == 1) {
    nx = 1;
    xCol.set_size(1);
    xCol[0] = x[0];
  } else {
    nb = x.size(0);
    xCol.set_size(x.size(0));
    for (i = 0; i < nb; i++) {
      xCol[i] = x[i];
    }
    nx = x.size(0);
  }
  if (b.size(1) < 1) {
    i = b.size(1);
  } else {
    i = 1;
  }
  if (i > 1) {
    nb = b.size(1);
    bCol.set_size(1, b.size(1));
    for (i = 0; i < nb; i++) {
      bCol[i] = b[i];
    }
    nb = 1;
  } else {
    nb_tmp = b.size(1);
    nb = b.size(1);
    bCol.set_size(b.size(1), 1);
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= nx) || (nb > 1048576)) {
    iend =
        std::frexp(std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                                static_cast<unsigned int>(nx)) -
                            1.0),
                   &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = nx;
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      b_tmp_data[nb_tmp] = std::ceil(static_cast<double>(nx) /
                                     static_cast<double>(L1_data[nb_tmp]));
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  if (bCol.size(1) == 1) {
    nb_tmp = B.size(0);
    b_B.set_size(B.size(0));
    for (i = 0; i < nb_tmp; i++) {
      b_B[i] = B[i];
    }
    B.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      B[i] = b_B[i];
    }
  }
  nb = xCol.size(0);
  loop_ub = bCol.size(1);
  xCol1.set_size(xCol.size(0), bCol.size(1));
  for (i = 0; i < loop_ub; i++) {
    for (i1 = 0; i1 < nb; i1++) {
      xCol1[i1 + xCol1.size(0) * i] = xCol[i1];
    }
  }
  y.set_size(xCol.size(0), bCol.size(1));
  nb = xCol.size(0) * bCol.size(1);
  for (i = 0; i < nb; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx; istart += static_cast<double>(L)) {
    double d;
    int i2;
    int i3;
    int loop_ub_tmp;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx));
    if (iend - istart == 0.0) {
      loop_ub_tmp = static_cast<int>(nfft);
      X.set_size(loop_ub_tmp, loop_ub);
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          X[i1 + X.size(0) * i].re =
              xCol1[(static_cast<int>(istart) + xCol1.size(0) * i) - 1];
          X[i1 + X.size(0) * i].im = 0.0;
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb = i1 - i;
      bCol.set_size(nb, loop_ub);
      for (i1 = 0; i1 < loop_ub; i1++) {
        for (i2 = 0; i2 < nb; i2++) {
          bCol[i2 + bCol.size(0) * i1] = xCol1[(i + i2) + xCol1.size(0) * i1];
        }
      }
      fft(bCol, nfft, X);
    }
    if ((X.size(0) == B.size(0)) && (X.size(1) == B.size(1))) {
      b_X.set_size(X.size(0), X.size(1));
      nb = X.size(0) * X.size(1);
      for (i = 0; i < nb; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B[i].im;
        d1 = X[i].im;
        d2 = B[i].re;
        b_X[i].re = d * d2 - d1 * iend;
        b_X[i].im = d * iend + d1 * d2;
      }
      ifft(b_X, X);
    } else {
      binary_expand_op_15(X, B);
    }
    iend = std::fmin(static_cast<double>(nx), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = -1;
      i1 = -1;
    } else {
      i = static_cast<int>(istart) - 2;
      i1 = static_cast<int>(iend) - 1;
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      i3 = 0;
      nb_tmp = 0;
    } else {
      i3 = static_cast<int>(istart) - 1;
      nb_tmp = static_cast<int>(iend);
    }
    nb = i1 - i;
    if ((nb == i2) && (y.size(1) == X.size(1))) {
      loop_ub_tmp = y.size(1);
      for (i1 = 0; i1 < loop_ub_tmp; i1++) {
        for (i2 = 0; i2 < nb; i2++) {
          b_i = (i + i2) + 1;
          trueCount = i2 + nb * i1;
          X[trueCount].re =
              y[b_i + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          X[trueCount].im =
              y[b_i + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      X.set_size(nb, y.size(1));
      nb_tmp -= i3;
      for (i = 0; i < loop_ub_tmp; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(i3 + i1) + y.size(0) * i] = X[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, i3, nb_tmp, i + 1, i1, X, i2 - 1);
    }
  }
  nb = y.size(0) * y.size(1);
  for (i = 0; i < nb; i++) {
    y[i].re = y[i].re;
    y[i].im = 0.0;
  }
  if ((x.size(0) == 1) && (y.size(1) == 1)) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<double, 1U> &b,
             const ::coder::array<double, 2U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B1;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> b_X;
  ::coder::array<creal_T, 1U> B;
  ::coder::array<double, 2U> b_xCol;
  ::coder::array<double, 2U> xCol;
  ::coder::array<double, 1U> bCol;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx;
  int trueCount;
  signed char tmp_data[21];
  if (x.size(0) == 1) {
    nx = x.size(1);
    xCol.set_size(x.size(1), 1);
    for (i = 0; i < nx; i++) {
      xCol[i] = x[i];
    }
  } else {
    xCol.set_size(x.size(0), x.size(1));
    loop_ub = x.size(0) * x.size(1);
    for (i = 0; i < loop_ub; i++) {
      xCol[i] = x[i];
    }
    nx = x.size(0);
  }
  if (b.size(0) > 1) {
    i = 1;
  } else {
    i = b.size(0);
  }
  if (i > 1) {
    loop_ub = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < loop_ub; i++) {
      bCol[i] = b[i];
    }
    nb = b.size(0);
  } else {
    nb_tmp = b.size(0);
    nb = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= nx) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs((static_cast<double>(nb) + static_cast<double>(nx)) - 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = nx;
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      b_tmp_data[nb_tmp] = std::ceil(static_cast<double>(nx) /
                                     static_cast<double>(L1_data[nb_tmp]));
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  loop_ub = B.size(0);
  nb_tmp = xCol.size(1);
  B1.set_size(B.size(0), xCol.size(1));
  for (i = 0; i < nb_tmp; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      B1[i1 + B1.size(0) * i] = B[i1];
    }
  }
  if (xCol.size(1) == 1) {
    nb_tmp = xCol.size(0);
    bCol.set_size(xCol.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = xCol[i];
    }
    xCol.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      xCol[i] = bCol[i];
    }
  }
  y.set_size(xCol.size(0), xCol.size(1));
  loop_ub = xCol.size(0) * xCol.size(1);
  for (i = 0; i < loop_ub; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx; istart += static_cast<double>(L)) {
    double d;
    int i2;
    int i3;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx));
    if (iend - istart == 0.0) {
      nb = static_cast<int>(nfft);
      loop_ub = xCol.size(1);
      X.set_size(nb, xCol.size(1));
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < nb; i1++) {
          X[i1 + X.size(0) * i].re =
              xCol[(static_cast<int>(istart) + xCol.size(0) * i) - 1];
          X[i1 + X.size(0) * i].im = 0.0;
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      loop_ub = i1 - i;
      nb_tmp = xCol.size(1);
      b_xCol.set_size(loop_ub, xCol.size(1));
      for (i1 = 0; i1 < nb_tmp; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_xCol[i2 + b_xCol.size(0) * i1] = xCol[(i + i2) + xCol.size(0) * i1];
        }
      }
      fft(b_xCol, nfft, X);
    }
    if ((X.size(0) == B1.size(0)) && (X.size(1) == B1.size(1))) {
      b_X.set_size(X.size(0), X.size(1));
      loop_ub = X.size(0) * X.size(1);
      for (i = 0; i < loop_ub; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B1[i].im;
        d1 = X[i].im;
        d2 = B1[i].re;
        b_X[i].re = d * d2 - d1 * iend;
        b_X[i].im = d * iend + d1 * d2;
      }
      ifft(b_X, X);
    } else {
      binary_expand_op_15(X, B1);
    }
    iend = std::fmin(static_cast<double>(nx), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = -1;
      i1 = -1;
    } else {
      i = static_cast<int>(istart) - 2;
      i1 = static_cast<int>(iend) - 1;
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      i3 = 0;
      nb_tmp = 0;
    } else {
      i3 = static_cast<int>(istart) - 1;
      nb_tmp = static_cast<int>(iend);
    }
    loop_ub = i1 - i;
    if ((loop_ub == i2) && (y.size(1) == X.size(1))) {
      nb = y.size(1);
      for (i1 = 0; i1 < nb; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_i = (i + i2) + 1;
          trueCount = i2 + loop_ub * i1;
          X[trueCount].re =
              y[b_i + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          X[trueCount].im =
              y[b_i + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      X.set_size(loop_ub, y.size(1));
      nb_tmp -= i3;
      for (i = 0; i < nb; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(i3 + i1) + y.size(0) * i] = X[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, i3, nb_tmp, i + 1, i1, X, i2 - 1);
    }
  }
  loop_ub = y.size(0) * y.size(1);
  for (i = 0; i < loop_ub; i++) {
    y[i].re = y[i].re;
    y[i].im = 0.0;
  }
  if ((x.size(0) == 1) && (y.size(1) == 1)) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<double, 2U> &b,
             const ::coder::array<double, 2U> &x,
             ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> B;
  ::coder::array<creal_T, 2U> X;
  ::coder::array<creal_T, 2U> b_X;
  ::coder::array<creal_T, 1U> b_B;
  ::coder::array<double, 2U> bCol;
  ::coder::array<double, 2U> xCol1;
  double d;
  double iend;
  double nfft;
  int tmp_size[2];
  int L;
  int b_i;
  int i;
  int i1;
  int loop_ub;
  int nb;
  int nb_tmp;
  int nx_tmp;
  int trueCount;
  signed char tmp_data[21];
  nx_tmp = x.size(1);
  if (b.size(1) < 1) {
    i = b.size(1);
  } else {
    i = 1;
  }
  if (i > 1) {
    loop_ub = b.size(1);
    bCol.set_size(1, b.size(1));
    for (i = 0; i < loop_ub; i++) {
      bCol[i] = b[i];
    }
    nb = 1;
  } else {
    nb_tmp = b.size(1);
    nb = b.size(1);
    bCol.set_size(b.size(1), 1);
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if ((nb >= x.size(1)) || (nb > 1048576)) {
    iend = std::frexp(
        std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                     static_cast<unsigned int>(x.size(1))) -
                 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    L = x.size(1);
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      d = static_cast<double>(x.size(1)) / static_cast<double>(L1_data[nb_tmp]);
      d = std::ceil(d);
      b_tmp_data[nb_tmp] = d;
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    L = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  if (bCol.size(1) == 1) {
    nb_tmp = B.size(0);
    b_B.set_size(B.size(0));
    for (i = 0; i < nb_tmp; i++) {
      b_B[i] = B[i];
    }
    B.set_size(nb_tmp, 1);
    for (i = 0; i < nb_tmp; i++) {
      B[i] = b_B[i];
    }
  }
  loop_ub = bCol.size(1);
  xCol1.set_size(x.size(1), bCol.size(1));
  for (i = 0; i < loop_ub; i++) {
    for (i1 = 0; i1 < nx_tmp; i1++) {
      xCol1[i1 + xCol1.size(0) * i] = x[i1];
    }
  }
  y.set_size(x.size(1), bCol.size(1));
  nb_tmp = x.size(1) * bCol.size(1);
  for (i = 0; i < nb_tmp; i++) {
    y[i].re = 0.0;
    y[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx_tmp; istart += static_cast<double>(L)) {
    int i2;
    int i3;
    int loop_ub_tmp;
    iend = std::fmin((istart + static_cast<double>(L)) - 1.0,
                     static_cast<double>(nx_tmp));
    if (iend - istart == 0.0) {
      loop_ub_tmp = static_cast<int>(nfft);
      X.set_size(loop_ub_tmp, loop_ub);
      for (i = 0; i < loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub_tmp; i1++) {
          X[i1 + X.size(0) * i].re =
              xCol1[(static_cast<int>(istart) + xCol1.size(0) * i) - 1];
          X[i1 + X.size(0) * i].im = 0.0;
        }
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb_tmp = i1 - i;
      bCol.set_size(nb_tmp, loop_ub);
      for (i1 = 0; i1 < loop_ub; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          bCol[i2 + bCol.size(0) * i1] = xCol1[(i + i2) + xCol1.size(0) * i1];
        }
      }
      fft(bCol, nfft, X);
    }
    if ((X.size(0) == B.size(0)) && (X.size(1) == B.size(1))) {
      b_X.set_size(X.size(0), X.size(1));
      nb_tmp = X.size(0) * X.size(1);
      for (i = 0; i < nb_tmp; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B[i].im;
        d1 = X[i].im;
        d2 = B[i].re;
        b_X[i].re = d * d2 - d1 * iend;
        b_X[i].im = d * iend + d1 * d2;
      }
      ifft(b_X, X);
    } else {
      binary_expand_op_15(X, B);
    }
    iend = std::fmin(static_cast<double>(nx_tmp), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = -1;
      i1 = -1;
    } else {
      i = static_cast<int>(istart) - 2;
      i1 = static_cast<int>(iend) - 1;
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      i2 = 0;
    } else {
      i2 = static_cast<int>(d);
    }
    if (istart > iend) {
      i3 = 0;
      b_i = 0;
    } else {
      i3 = static_cast<int>(istart) - 1;
      b_i = static_cast<int>(iend);
    }
    nb_tmp = i1 - i;
    if ((nb_tmp == i2) && (y.size(1) == X.size(1))) {
      loop_ub_tmp = y.size(1);
      for (i1 = 0; i1 < loop_ub_tmp; i1++) {
        for (i2 = 0; i2 < nb_tmp; i2++) {
          trueCount = (i + i2) + 1;
          nb = i2 + nb_tmp * i1;
          X[nb].re =
              y[trueCount + y.size(0) * i1].re + X[i2 + X.size(0) * i1].re;
          X[nb].im =
              y[trueCount + y.size(0) * i1].im + X[i2 + X.size(0) * i1].im;
        }
      }
      X.set_size(nb_tmp, y.size(1));
      nb_tmp = b_i - i3;
      for (i = 0; i < loop_ub_tmp; i++) {
        for (i1 = 0; i1 < nb_tmp; i1++) {
          y[(i3 + i1) + y.size(0) * i] = X[i1 + nb_tmp * i];
        }
      }
    } else {
      binary_expand_op_14(y, i3, b_i, i + 1, i1, X, i2 - 1);
    }
  }
  loop_ub = y.size(0) * y.size(1);
  for (i = 0; i < loop_ub; i++) {
    y[i].re = y[i].re;
    y[i].im = 0.0;
  }
  if (y.size(1) == 1) {
    nb_tmp = y.size(0);
    y.set_size(1, nb_tmp);
  }
}

void fftfilt(const ::coder::array<double, 1U> &b, const double x_data[],
             const int x_size[2], creal_T y_data[], int y_size[2])
{
  static creal_T b_y1_data[3076];
  static creal_T y1_data[3076];
  ::coder::array<creal_T, 1U> B;
  ::coder::array<creal_T, 1U> X;
  ::coder::array<creal_T, 1U> b_X;
  ::coder::array<double, 1U> bCol;
  ::coder::array<double, 1U> c_xCol1_data;
  double b_xCol1_data[3076];
  double xCol1_data[3076];
  double iend;
  double nfft;
  int tmp_size[2];
  int b_i;
  int i;
  int nb;
  int nb_tmp;
  int nx_tmp;
  int trueCount;
  int y1_size;
  signed char tmp_data[21];
  nx_tmp = x_size[1];
  if (b.size(0) > 1) {
    i = 1;
  } else {
    i = b.size(0);
  }
  if (i > 1) {
    nb_tmp = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
    nb = b.size(0);
  } else {
    nb_tmp = b.size(0);
    nb = b.size(0);
    bCol.set_size(b.size(0));
    for (i = 0; i < nb_tmp; i++) {
      bCol[i] = b[i];
    }
  }
  if (nb >= x_size[1]) {
    iend = std::frexp(
        std::abs(static_cast<double>(static_cast<unsigned int>(nb) +
                                     static_cast<unsigned int>(x_size[1])) -
                 1.0),
        &b_i);
    if (iend == 0.5) {
      b_i--;
    }
    nfft = rt_powd_snf(2.0, static_cast<double>(b_i));
    nb = x_size[1];
  } else {
    double b_tmp_data[21];
    double c_tmp_data[21];
    int L1_data[21];
    int nValid_data[21];
    trueCount = 0;
    nb_tmp = 0;
    for (b_i = 0; b_i < 21; b_i++) {
      if (nb - 1 < iv[b_i]) {
        trueCount++;
        tmp_data[nb_tmp] = static_cast<signed char>(b_i);
        nb_tmp++;
      }
    }
    for (i = 0; i < trueCount; i++) {
      nValid_data[i] = iv[tmp_data[i]];
    }
    nb_tmp = (trueCount / 4) << 2;
    b_i = nb_tmp - 4;
    for (i = 0; i <= b_i; i += 4) {
      __m128i r;
      r = _mm_loadu_si128((const __m128i *)&nValid_data[i]);
      _mm_storeu_si128((__m128i *)&L1_data[i],
                       _mm_add_epi32(_mm_sub_epi32(r, _mm_set1_epi32(nb)),
                                     _mm_set1_epi32(1)));
    }
    for (i = nb_tmp; i < trueCount; i++) {
      L1_data[i] = (nValid_data[i] - nb) + 1;
    }
    for (nb_tmp = 0; nb_tmp < trueCount; nb_tmp++) {
      b_tmp_data[nb_tmp] = std::ceil(static_cast<double>(x_size[1]) /
                                     static_cast<double>(L1_data[nb_tmp]));
    }
    tmp_size[0] = 1;
    tmp_size[1] = trueCount;
    for (i = 0; i < trueCount; i++) {
      c_tmp_data[i] = b_tmp_data[i] * dv[tmp_data[i]];
    }
    coder::internal::minimum(c_tmp_data, tmp_size, nb_tmp);
    nfft = nValid_data[nb_tmp - 1];
    nb = L1_data[nb_tmp - 1];
  }
  fft(bCol, nfft, B);
  y1_size = x_size[1];
  for (i = 0; i < nx_tmp; i++) {
    xCol1_data[i] = x_data[i];
    y1_data[i].re = 0.0;
    y1_data[i].im = 0.0;
  }
  for (double istart{1.0}; istart <= nx_tmp;
       istart += static_cast<double>(nb)) {
    double d;
    int i1;
    iend = std::fmin((istart + static_cast<double>(nb)) - 1.0,
                     static_cast<double>(nx_tmp));
    if (iend - istart == 0.0) {
      nb_tmp = static_cast<int>(nfft);
      X.set_size(nb_tmp);
      for (i = 0; i < nb_tmp; i++) {
        X[i].re = xCol1_data[static_cast<int>(istart) - 1];
        X[i].im = 0.0;
      }
    } else {
      if (istart > iend) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(istart) - 1;
        i1 = static_cast<int>(iend);
      }
      nb_tmp = i1 - i;
      for (i1 = 0; i1 < nb_tmp; i1++) {
        b_xCol1_data[i1] = xCol1_data[i + i1];
      }
      c_xCol1_data.set(&b_xCol1_data[0], nb_tmp);
      fft(c_xCol1_data, nfft, X);
    }
    if (X.size(0) == B.size(0)) {
      nb_tmp = X.size(0);
      b_X.set_size(X.size(0));
      for (i = 0; i < nb_tmp; i++) {
        double d1;
        double d2;
        d = X[i].re;
        iend = B[i].im;
        d1 = X[i].im;
        d2 = B[i].re;
        b_X[i].re = d * d2 - d1 * iend;
        b_X[i].im = d * iend + d1 * d2;
      }
      ifft(b_X, X);
    } else {
      binary_expand_op_81(X, B);
    }
    iend = std::fmin(static_cast<double>(nx_tmp), (istart + nfft) - 1.0);
    if (istart > iend) {
      i = 0;
      i1 = 0;
    } else {
      i = static_cast<int>(istart) - 1;
      i1 = static_cast<int>(iend);
    }
    d = (iend - istart) + 1.0;
    if (d < 1.0) {
      b_i = 0;
    } else {
      b_i = static_cast<int>(d);
    }
    if (istart > iend) {
      trueCount = 0;
      nb_tmp = 0;
    } else {
      trueCount = static_cast<int>(istart) - 1;
      nb_tmp = static_cast<int>(iend);
    }
    if (i1 - i == b_i) {
      nb_tmp -= trueCount;
      for (i1 = 0; i1 < nb_tmp; i1++) {
        b_i = i + i1;
        b_y1_data[i1].re = y1_data[b_i].re + X[i1].re;
        b_y1_data[i1].im = y1_data[b_i].im + X[i1].im;
      }
      for (i = 0; i < nb_tmp; i++) {
        y1_data[trueCount + i] = b_y1_data[i];
      }
    } else {
      binary_expand_op_80(y1_data, trueCount, nb_tmp, i, i1 - 1, X, b_i - 1);
    }
  }
  y_size[0] = 1;
  y_size[1] = x_size[1];
  for (i = 0; i < y1_size; i++) {
    y1_data[i].im = 0.0;
    y_data[i] = y1_data[i];
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (fftfilt.cpp)
