//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// conv.h
//
// Code generation for function 'conv'
//

#ifndef CONV_H
#define CONV_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void conv(const ::coder::array<double, 2U> &A,
          const ::coder::array<double, 2U> &B, ::coder::array<double, 2U> &C);

}

#endif
// End of code generation (conv.h)
