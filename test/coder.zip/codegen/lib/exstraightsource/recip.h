//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// recip.h
//
// Code generation for function 'recip'
//

#ifndef RECIP_H
#define RECIP_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
creal_T recip(const creal_T y);

}
} // namespace coder
} // namespace legacy_STRAIGHT

#endif
// End of code generation (recip.h)
