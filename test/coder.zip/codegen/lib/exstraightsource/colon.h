//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// colon.h
//
// Code generation for function 'colon'
//

#ifndef COLON_H
#define COLON_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void b_eml_float_colon(double d, double b, ::coder::array<double, 2U> &y);

void b_eml_float_colon(double b, ::coder::array<double, 2U> &y);

void eml_float_colon(double d, double b, ::coder::array<double, 2U> &y);

void eml_float_colon(double d, ::coder::array<double, 2U> &y);

void eml_float_colon(double a, double d, double b,
                     ::coder::array<double, 2U> &y);

} // namespace legacy_STRAIGHT

#endif
// End of code generation (colon.h)
