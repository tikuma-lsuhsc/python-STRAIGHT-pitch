//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// aperiodiccomp.cpp
//
// Code generation for function 'aperiodiccomp'
//

// Include files
#include "aperiodiccomp.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
void binary_expand_op_3(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2,
                        const coder::array<double, 2U> &in3)
{
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(1) == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in3.size(1);
  }
  in1.set_size(loop_ub, in1.size(1));
  b_loop_ub = in2.size(0);
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(1) != 1);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = in2[i + in2.size(0) * (i1 * stride_0_0)] -
                                  in3[i + in3.size(0) * (i1 * stride_1_0)];
    }
  }
}

// End of code generation (aperiodiccomp.cpp)
