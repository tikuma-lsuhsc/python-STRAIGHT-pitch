//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// std.cpp
//
// Code generation for function 'std'
//

// Include files
#include "std.h"
#include "blockedSummation.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
double b_std(const ::coder::array<double, 2U> &x)
{
  ::coder::array<double, 1U> c_x;
  double y;
  int n_tmp;
  n_tmp = x.size(1);
  if (x.size(1) == 0) {
    y = rtNaN;
  } else if (x.size(1) == 1) {
    if ((!std::isinf(x[0])) && (!std::isnan(x[0]))) {
      y = 0.0;
    } else {
      y = rtNaN;
    }
  } else {
    double scale;
    double xbar;
    int b_x;
    b_x = x.size(1);
    c_x = x.reshape(b_x);
    xbar = blockedSummation(c_x, x.size(1)) / static_cast<double>(x.size(1));
    y = 0.0;
    scale = 3.3121686421112381E-170;
    for (b_x = 0; b_x < n_tmp; b_x++) {
      double d;
      d = std::abs(x[b_x] - xbar);
      if (d > scale) {
        double t;
        t = scale / d;
        y = y * t * t + 1.0;
        scale = d;
      } else {
        double t;
        t = d / scale;
        y += t * t;
      }
    }
    y = scale * std::sqrt(y);
    y /= std::sqrt(static_cast<double>(x.size(1)) - 1.0);
  }
  return y;
}

} // namespace legacy_STRAIGHT

// End of code generation (std.cpp)
