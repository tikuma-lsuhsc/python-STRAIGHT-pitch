//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// refineF06.cpp
//
// Code generation for function 'refineF06'
//

// Include files
#include "refineF06.h"
#include "blockedSummation.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "div.h"
#include "eml_mtimes_helper.h"
#include "exp.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "fft.h"
#include "fftfilt.h"
#include "hanning.h"
#include "interp1.h"
#include "minOrMax.h"
#include "randn.h"
#include "rt_nonfinite.h"
#include "std.h"
#include "sum.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Declarations
static void b_times(coder::array<double, 2U> &in1,
                    const coder::array<double, 2U> &in2);

static void binary_expand_op_52(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4,
                                double in6);

static void binary_expand_op_53(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4,
                                const coder::array<double, 2U> &in6,
                                double in7);

static void binary_expand_op_54(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4);

static void binary_expand_op_55(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3);

static void binary_expand_op_56(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2, double in3,
                                double in4);

static void binary_expand_op_57(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3, double in4,
                                const coder::array<creal_T, 2U> &in5,
                                double in6);

static void binary_expand_op_58(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2, double in3,
                                const coder::array<creal_T, 2U> &in4,
                                double in5);

static void binary_expand_op_59(coder::array<double, 2U> &in1, int in2,
                                const coder::array<double, 2U> &in4, double in5,
                                const coder::array<double, 2U> &in6,
                                double in7);

static void binary_expand_op_60(coder::array<double, 2U> &in1,
                                const coder::array<double, 1U> &in2);

static void binary_expand_op_61(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3);

static void binary_expand_op_62(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3,
                                const coder::array<double, 2U> &in4);

static void binary_expand_op_63(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3);

static void binary_expand_op_65(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, const int in5[2], int in6,
                                const coder::array<double, 2U> &in7,
                                const int in8[2], double in9, double in10);

static double znrmlcf2(double f, double &c2);

// Function Definitions
static void b_times(coder::array<double, 2U> &in1,
                    const coder::array<double, 2U> &in2)
{
  coder::array<double, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] *
          in2[i1 * stride_1_0 + in2.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

static void binary_expand_op_52(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4,
                                double in6)
{
  coder::array<double, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int aux_3_1_tmp;
  int aux_4_1_tmp;
  int aux_5_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_0_tmp;
  int stride_1_1_tmp;
  int stride_2_0_tmp;
  int stride_2_1_tmp;
  int stride_5_0;
  int stride_5_1;
  if (in1.size(0) == 1) {
    if (in4.size(0) == 1) {
      loop_ub = in3.size(0);
    } else {
      loop_ub = in4.size(0);
    }
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    if (in4.size(1) == 1) {
      i = in3.size(1);
    } else {
      i = in4.size(1);
    }
  } else {
    i = in1.size(1);
  }
  if (i == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = i;
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0_tmp = (in3.size(0) != 1);
  stride_1_1_tmp = (in3.size(1) != 1);
  stride_2_0_tmp = (in4.size(0) != 1);
  stride_2_1_tmp = (in4.size(1) != 1);
  stride_5_0 = (in1.size(0) != 1);
  stride_5_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  aux_3_1_tmp = 0;
  aux_4_1_tmp = 0;
  aux_5_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double varargin_1;
      varargin_1 = in1[i1 * stride_5_0 + in1.size(0) * aux_5_1];
      b_in2[i1 + b_in2.size(0) * i] =
          in2[aux_0_1] +
          (in3[i1 * stride_1_0_tmp + in3.size(0) * aux_1_1].re *
               in4[i1 * stride_2_0_tmp + in4.size(0) * aux_2_1].im -
           in3[i1 * stride_1_0_tmp + in3.size(0) * aux_3_1_tmp].im *
               in4[i1 * stride_2_0_tmp + in4.size(0) * aux_4_1_tmp].re) /
              rt_powd_snf(varargin_1, 2.0) * in6 / 3.1415926535897931 / 2.0;
    }
    aux_5_1 += stride_5_1;
    aux_4_1_tmp += stride_2_1_tmp;
    aux_3_1_tmp += stride_1_1_tmp;
    aux_2_1 = aux_4_1_tmp;
    aux_1_1 = aux_3_1_tmp;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

static void binary_expand_op_53(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4,
                                const coder::array<double, 2U> &in6, double in7)
{
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int aux_3_1_tmp;
  int aux_4_1_tmp;
  int aux_5_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_0_tmp;
  int stride_1_1_tmp;
  int stride_2_0_tmp;
  int stride_2_1_tmp;
  int stride_5_0;
  int stride_5_1;
  if (in6.size(0) == 1) {
    if (in4.size(0) == 1) {
      loop_ub = in3.size(0);
    } else {
      loop_ub = in4.size(0);
    }
  } else {
    loop_ub = in6.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in6.size(1) == 1) {
    if (in4.size(1) == 1) {
      i = in3.size(1);
    } else {
      i = in4.size(1);
    }
  } else {
    i = in6.size(1);
  }
  if (i == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = i;
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0_tmp = (in3.size(0) != 1);
  stride_1_1_tmp = (in3.size(1) != 1);
  stride_2_0_tmp = (in4.size(0) != 1);
  stride_2_1_tmp = (in4.size(1) != 1);
  stride_5_0 = (in6.size(0) != 1);
  stride_5_1 = (in6.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  aux_3_1_tmp = 0;
  aux_4_1_tmp = 0;
  aux_5_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double varargin_1;
      varargin_1 = in6[i1 * stride_5_0 + in6.size(0) * aux_5_1];
      in1[i1 + in1.size(0) * i] =
          in2[aux_0_1] +
          (in3[i1 * stride_1_0_tmp + in3.size(0) * aux_1_1].re *
               in4[i1 * stride_2_0_tmp + in4.size(0) * aux_2_1].im -
           in3[i1 * stride_1_0_tmp + in3.size(0) * aux_3_1_tmp].im *
               in4[i1 * stride_2_0_tmp + in4.size(0) * aux_4_1_tmp].re) /
              rt_powd_snf(varargin_1, 2.0) * in7 / 3.1415926535897931 / 2.0;
    }
    aux_5_1 += stride_5_1;
    aux_4_1_tmp += stride_2_1_tmp;
    aux_3_1_tmp += stride_1_1_tmp;
    aux_2_1 = aux_4_1_tmp;
    aux_1_1 = aux_3_1_tmp;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op_54(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3,
                                const coder::array<creal_T, 2U> &in4)
{
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in4.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in4.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in4.size(1) == 1) {
    if (in3.size(1) == 1) {
      b_loop_ub = in2.size(1);
    } else {
      b_loop_ub = in3.size(1);
    }
  } else {
    b_loop_ub = in4.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  stride_2_0 = (in4.size(0) != 1);
  stride_2_1 = (in4.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double b_in2_re_tmp;
      double c_in2_re_tmp;
      double d_in2_re_tmp;
      double in2_re_tmp;
      int in2_re_tmp_tmp;
      in2_re_tmp_tmp = i1 * stride_0_0;
      in2_re_tmp = in2[in2_re_tmp_tmp + in2.size(0) * aux_0_1].re;
      b_in2_re_tmp = in3[aux_1_1].im;
      c_in2_re_tmp = in2[in2_re_tmp_tmp + in2.size(0) * aux_0_1].im;
      d_in2_re_tmp = in3[aux_1_1].re;
      in2_re_tmp_tmp = i1 * stride_2_0;
      in1[i1 + in1.size(0) * i].re =
          (in2_re_tmp * d_in2_re_tmp - c_in2_re_tmp * b_in2_re_tmp) -
          in4[in2_re_tmp_tmp + in4.size(0) * aux_2_1].re;
      in1[i1 + in1.size(0) * i].im =
          (in2_re_tmp * b_in2_re_tmp + c_in2_re_tmp * d_in2_re_tmp) -
          in4[in2_re_tmp_tmp + in4.size(0) * aux_2_1].im;
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op_55(coder::array<creal_T, 2U> &in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 2U> &in3)
{
  coder::array<creal_T, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in3.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  if (in3.size(1) == 1) {
    if (in2.size(1) == 1) {
      b_loop_ub = in1.size(1);
    } else {
      b_loop_ub = in2.size(1);
    }
  } else {
    b_loop_ub = in3.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_1 = (in2.size(1) != 1);
  stride_2_0 = (in3.size(0) != 1);
  stride_2_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double b_in1_re_tmp;
      double c_in1_re_tmp;
      double d_in1_re_tmp;
      double in1_re_tmp;
      int in1_re_tmp_tmp;
      in1_re_tmp_tmp = i1 * stride_0_0;
      in1_re_tmp = in1[in1_re_tmp_tmp + in1.size(0) * aux_0_1].re;
      b_in1_re_tmp = in2[aux_1_1].im;
      c_in1_re_tmp = in1[in1_re_tmp_tmp + in1.size(0) * aux_0_1].im;
      d_in1_re_tmp = in2[aux_1_1].re;
      in1_re_tmp_tmp = i1 * stride_2_0;
      b_in1[i1 + b_in1.size(0) * i].re =
          (in1_re_tmp * d_in1_re_tmp - c_in1_re_tmp * b_in1_re_tmp) -
          in3[in1_re_tmp_tmp + in3.size(0) * aux_2_1].re;
      b_in1[i1 + b_in1.size(0) * i].im =
          (in1_re_tmp * b_in1_re_tmp + c_in1_re_tmp * d_in1_re_tmp) -
          in3[in1_re_tmp_tmp + in3.size(0) * aux_2_1].im;
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

static void binary_expand_op_56(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2, double in3,
                                double in4)
{
  coder::array<creal_T, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  loop_ub = in1.size(0);
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double d;
      d = in2[aux_0_1] - in3;
      b_in2[i1 + b_in2.size(0) * i].re = d * in1[i1 + in1.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im = d * in1[i1 + in1.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  legacy_STRAIGHT::fft(b_in2, in4, in1);
}

static void binary_expand_op_57(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3, double in4,
                                const coder::array<creal_T, 2U> &in5,
                                double in6)
{
  coder::array<creal_T, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  loop_ub = in5.size(0);
  if (in5.size(1) == 1) {
    b_loop_ub = in3.size(1);
  } else {
    b_loop_ub = in5.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_1 = (in3.size(1) != 1);
  stride_1_1 = (in5.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double d;
      d = in2[static_cast<int>(in3[aux_0_1]) - 1] - in4;
      b_in2[i1 + b_in2.size(0) * i].re = d * in5[i1 + in5.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im = d * in5[i1 + in5.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  legacy_STRAIGHT::fft(b_in2, in6, in1);
}

static void binary_expand_op_58(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2, double in3,
                                const coder::array<creal_T, 2U> &in4,
                                double in5)
{
  coder::array<creal_T, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  loop_ub = in4.size(0);
  if (in4.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in4.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in4.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double d;
      d = in2[aux_0_1] - in3;
      b_in2[i1 + b_in2.size(0) * i].re = d * in4[i1 + in4.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im = d * in4[i1 + in4.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  legacy_STRAIGHT::fft(b_in2, in5, in1);
}

static void binary_expand_op_59(coder::array<double, 2U> &in1, int in2,
                                const coder::array<double, 2U> &in4, double in5,
                                const coder::array<double, 2U> &in6, double in7)
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (in6.size(1) != 1);
  loop_ub = in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    double b_varargin_1;
    double varargin_1;
    varargin_1 = in4[in2 + in4.size(0) * (i * stride_0_1)] / in5;
    b_varargin_1 = in6[in2 + in6.size(0) * (i * stride_1_1)] / in7;
    in1[in2 + in1.size(0) * i] =
        rt_powd_snf(varargin_1, 2.0) + rt_powd_snf(b_varargin_1, 2.0);
  }
}

static void binary_expand_op_60(coder::array<double, 2U> &in1,
                                const coder::array<double, 1U> &in2)
{
  coder::array<double, 2U> b_in2;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in1.size(1) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(1);
  }
  b_in2.set_size(1, loop_ub);
  stride_0_1 = (in2.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in2[i] = in2[i * stride_0_1] + in1[i * stride_1_1];
  }
  in1.set_size(1, loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in2[i];
  }
}

static void binary_expand_op_61(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3)
{
  int in3_idx_0_tmp;
  int loop_ub;
  int stride_0_1;
  in3_idx_0_tmp = in3.size(1);
  in1.set_size(1, in1.size(1));
  if (in3_idx_0_tmp == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in3_idx_0_tmp;
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  in3_idx_0_tmp = (in3_idx_0_tmp != 1);
  for (int i{0}; i < loop_ub; i++) {
    double d;
    d = in3[i * in3_idx_0_tmp];
    in1[i] = in2[i * stride_0_1] * static_cast<double>(d > 0.0) +
             static_cast<double>(d <= 0.0);
  }
}

static void binary_expand_op_62(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3,
                                const coder::array<double, 2U> &in4)
{
  int in4_idx_0;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in4_idx_0 = in4.size(1);
  in1.set_size(1, in1.size(1));
  if (in4_idx_0 == 1) {
    if (in3.size(1) == 1) {
      loop_ub = in2.size(1);
    } else {
      loop_ub = in3.size(1);
    }
  } else {
    loop_ub = in4_idx_0;
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  in4_idx_0 = (in4_idx_0 != 1);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = in2[i * stride_0_1] / in3[i * stride_1_1] *
             static_cast<double>(in4[i * in4_idx_0] > 0.0);
  }
}

static void binary_expand_op_63(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3)
{
  coder::array<double, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] /
          in3[i1 * stride_1_0 + in3.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  legacy_STRAIGHT::sum(b_in2, in1);
}

static void binary_expand_op_65(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2, int in3,
                                int in4, const int in5[2], int in6,
                                const coder::array<double, 2U> &in7,
                                const int in8[2], double in9, double in10)
{
  coder::array<double, 2U> b_in2;
  double b_in9;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  loop_ub = in4 - in3;
  b_loop_ub = in2.size(1);
  b_in2.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] = in2[(in3 + i1) + in2.size(0) * i];
    }
  }
  loop_ub = in5[0];
  b_loop_ub = in8[0];
  in1.set_size(loop_ub + b_loop_ub, in6);
  for (int i{0}; i < in6; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + loop_ub * i];
    }
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[(i1 + loop_ub) + in1.size(0) * i] = in7[i1 + b_loop_ub * i];
    }
  }
  b_in9 = in9 / in10 * 2.0 * 3.1415926535897931;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          (in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] -
           in2[i1 * stride_1_0 + in2.size(0) * aux_1_1]) /
          b_in9;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

static double znrmlcf2(double f, double &c2)
{
  static const double b[301]{0.0,
                             0.01,
                             0.02,
                             0.03,
                             0.04,
                             0.05,
                             0.06,
                             0.07,
                             0.08,
                             0.09,
                             0.1,
                             0.11,
                             0.12,
                             0.13,
                             0.14,
                             0.15,
                             0.16,
                             0.17,
                             0.18,
                             0.19,
                             0.2,
                             0.21,
                             0.22,
                             0.23,
                             0.24,
                             0.25,
                             0.26,
                             0.27,
                             0.28,
                             0.29,
                             0.3,
                             0.31,
                             0.32,
                             0.33,
                             0.34,
                             0.35000000000000003,
                             0.36,
                             0.37,
                             0.38,
                             0.39,
                             0.4,
                             0.41000000000000003,
                             0.42,
                             0.43,
                             0.44,
                             0.45,
                             0.46,
                             0.47000000000000003,
                             0.48,
                             0.49,
                             0.5,
                             0.51,
                             0.52,
                             0.53,
                             0.54,
                             0.55,
                             0.56,
                             0.57000000000000006,
                             0.58,
                             0.59,
                             0.6,
                             0.61,
                             0.62,
                             0.63,
                             0.64,
                             0.65,
                             0.66,
                             0.67,
                             0.68,
                             0.69000000000000006,
                             0.70000000000000007,
                             0.71,
                             0.72,
                             0.73,
                             0.74,
                             0.75,
                             0.76,
                             0.77,
                             0.78,
                             0.79,
                             0.8,
                             0.81,
                             0.82000000000000006,
                             0.83000000000000007,
                             0.84,
                             0.85,
                             0.86,
                             0.87,
                             0.88,
                             0.89,
                             0.9,
                             0.91,
                             0.92,
                             0.93,
                             0.94000000000000006,
                             0.95000000000000007,
                             0.96,
                             0.97,
                             0.98,
                             0.99,
                             1.0,
                             1.01,
                             1.02,
                             1.03,
                             1.04,
                             1.05,
                             1.06,
                             1.07,
                             1.08,
                             1.09,
                             1.1,
                             1.11,
                             1.12,
                             1.1300000000000001,
                             1.1400000000000001,
                             1.1500000000000001,
                             1.16,
                             1.17,
                             1.18,
                             1.19,
                             1.2,
                             1.21,
                             1.22,
                             1.23,
                             1.24,
                             1.25,
                             1.26,
                             1.27,
                             1.28,
                             1.29,
                             1.3,
                             1.31,
                             1.32,
                             1.33,
                             1.34,
                             1.35,
                             1.36,
                             1.37,
                             1.3800000000000001,
                             1.3900000000000001,
                             1.4000000000000001,
                             1.41,
                             1.42,
                             1.43,
                             1.44,
                             1.45,
                             1.46,
                             1.47,
                             1.48,
                             1.49,
                             1.5,
                             1.51,
                             1.52,
                             1.53,
                             1.54,
                             1.55,
                             1.56,
                             1.57,
                             1.58,
                             1.59,
                             1.5999999999999999,
                             1.6099999999999999,
                             1.6199999999999999,
                             1.63,
                             1.64,
                             1.65,
                             1.66,
                             1.67,
                             1.68,
                             1.69,
                             1.7,
                             1.71,
                             1.72,
                             1.73,
                             1.74,
                             1.75,
                             1.76,
                             1.77,
                             1.78,
                             1.79,
                             1.8,
                             1.81,
                             1.82,
                             1.83,
                             1.84,
                             1.8499999999999999,
                             1.8599999999999999,
                             1.8699999999999999,
                             1.88,
                             1.89,
                             1.9,
                             1.91,
                             1.92,
                             1.93,
                             1.94,
                             1.95,
                             1.96,
                             1.97,
                             1.98,
                             1.99,
                             2.0,
                             2.01,
                             2.02,
                             2.0300000000000002,
                             2.04,
                             2.05,
                             2.06,
                             2.07,
                             2.08,
                             2.09,
                             2.1,
                             2.11,
                             2.12,
                             2.13,
                             2.14,
                             2.15,
                             2.16,
                             2.17,
                             2.1799999999999997,
                             2.19,
                             2.2,
                             2.21,
                             2.2199999999999998,
                             2.23,
                             2.24,
                             2.25,
                             2.26,
                             2.27,
                             2.2800000000000002,
                             2.29,
                             2.3,
                             2.31,
                             2.32,
                             2.33,
                             2.34,
                             2.35,
                             2.36,
                             2.37,
                             2.38,
                             2.39,
                             2.4,
                             2.41,
                             2.42,
                             2.4299999999999997,
                             2.44,
                             2.45,
                             2.46,
                             2.4699999999999998,
                             2.48,
                             2.49,
                             2.5,
                             2.51,
                             2.52,
                             2.53,
                             2.54,
                             2.55,
                             2.56,
                             2.57,
                             2.58,
                             2.59,
                             2.6,
                             2.61,
                             2.62,
                             2.63,
                             2.64,
                             2.65,
                             2.66,
                             2.67,
                             2.68,
                             2.69,
                             2.7,
                             2.71,
                             2.7199999999999998,
                             2.73,
                             2.74,
                             2.75,
                             2.76,
                             2.77,
                             2.78,
                             2.79,
                             2.8,
                             2.81,
                             2.82,
                             2.83,
                             2.84,
                             2.85,
                             2.86,
                             2.87,
                             2.88,
                             2.89,
                             2.9,
                             2.91,
                             2.92,
                             2.93,
                             2.94,
                             2.95,
                             2.96,
                             2.97,
                             2.98,
                             2.99,
                             3.0};
  static const double b_dv[301]{-0.010266387630488916,
                                -0.03069461344862566,
                                -0.051010753441611469,
                                -0.071140885623955735,
                                -0.09101216819485955,
                                -0.11055325949628274,
                                -0.12969472625441653,
                                -0.14836943695509688,
                                -0.16651293734755218,
                                -0.18406380524377522,
                                -0.20096398198000825,
                                -0.21715907813078955,
                                -0.23259865131152471,
                                -0.24723645416952106,
                                -0.26103065094479827,
                                -0.27394400127454488,
                                -0.28594401021860338,
                                -0.29700304379238912,
                                -0.30709840960597407,
                                -0.31621240251981841,
                                -0.32433231553548986,
                                -0.331450416441006,
                                -0.33756389102116824,
                                -0.34267475392140373,
                                -0.34678972851593026,
                                -0.34992009737518126,
                                -0.35208152515093216,
                                -0.35329385589917472,
                                -0.35358088703777413,
                                -0.35297012228787955,
                                -0.35149250607345378,
                                -0.34918214195175196,
                                -0.34607599771806591,
                                -0.34221359987179317,
                                -0.33763672014653523,
                                -0.332389056796598,
                                -0.32651591329570467,
                                -0.32006387704271583,
                                -0.313080500584901,
                                -0.30561398776324955,
                                -0.2977128870586262,
                                -0.28942579427402687,
                                -0.280801066528862,
                                -0.27188654936840734,
                                -0.26272931860790327,
                                -0.25337543833787507,
                                -0.24386973631833025,
                                -0.23425559778637522,
                                -0.22457477849690957,
                                -0.2148672376117565,
                                -0.20517099085100871,
                                -0.19552198412324376,
                                -0.18595398766115834,
                                -0.17649851050692295,
                                -0.16718473501952882,
                                -0.15803947091557938,
                                -0.149087128206506,
                                -0.140349708260285,
                                -0.13184681209506927,
                                -0.12359566490624332,
                                -0.11561115573776004,
                                -0.10790589113341098,
                                -0.10049026154378266,
                                -0.093372519220102909,
                                -0.08655886629643908,
                                -0.080053551746408533,
                                -0.073858975898984922,
                                -0.067975801209465711,
                                -0.062403068005222259,
                                -0.057138313960591422,
                                -0.052177696100209829,
                                -0.047516114183969192,
                                -0.04314733438868832,
                                -0.039064112270183145,
                                -0.035258314063660978,
                                -0.031721035459017125,
                                -0.02844271706962475,
                                -0.025413255897359609,
                                -0.022622112181997,
                                -0.020058411108581278,
                                -0.01771103893113329,
                                -0.015568733154121796,
                                -0.013620166493813023,
                                -0.011854024419130851,
                                -0.010259076145478706,
                                -0.0088242390244781619,
                                -0.0075386363374227083,
                                -0.0063916485599718187,
                                -0.0053729582200555395,
                                -0.0044725885198485821,
                                -0.0036809359359695039,
                                -0.0029887970496789455,
                                -0.0023873898908706604,
                                -0.0018683701061389375,
                                -0.0014238422823420651,
                                -0.0010463667730671537,
                                -0.00072896238648376675,
                                -0.00046510529955203059,
                                -0.00024872456573595084,
                                -7.4194581615604028E-5,
                                6.367512754898578E-5,
                                0.000169652451798121,
                                0.00024809722987125833,
                                0.00030297744572549824,
                                0.0003378867777747486,
                                0.00035606320805611882,
                                0.00036040841748688761,
                                0.00035350771334448968,
                                0.00033765025576509118,
                                0.00031484937111332033,
                                0.00028686276125421112,
                                0.00025521243880496518,
                                0.0002212042391373868,
                                0.0001859467800391933,
                                0.00015036975935483037,
                                0.00011524149946356339,
                                8.1185664996042488E-5,
                                4.86970966393421E-5,
                                1.8156719164747817E-5,
                                -1.015450412508981E-5,
                                -3.6042585519329451E-5,
                                -5.9388499035128977E-5,
                                -8.0137131721923918E-5,
                                -9.828718424497361E-5,
                                -0.00011388199702369638,
                                -0.00012700127153376605,
                                -0.00013775365082581458,
                                -0.00014627011881214374,
                                -0.00015269817435399686,
                                -0.00015719673357627049,
                                -0.00015993171206724567,
                                -0.00016107223761091034,
                                -0.00016078744377047167,
                                -0.00015924379491647885,
                                -0.0001566028940949423,
                                -0.0001530197263863715,
                                -0.00014864129204470521,
                                -0.00014360558565871474,
                                -0.00013804087978395044,
                                -0.00013206527389248145,
                                -0.00012578647202633771,
                                -0.0001193017551695248,
                                -0.00011269811702870594,
                                -0.00010605253459522251,
                                -9.943234751593273E-5,
                                -9.2895722898935236E-5,
                                -8.649218469660252E-5,
                                -8.0263189222441508E-5,
                                -7.42427306530617E-5,
                                -6.8457962529548956E-5,
                                -6.29298232938797E-5,
                                -5.7673655769970879E-5,
                                -5.2699812221625926E-5,
                                -4.801423819041555E-5,
                                -4.3619029736489885E-5,
                                -3.9512959977550615E-5,
                                -3.5691971950544755E-5,
                                -3.2149635812852075E-5,
                                -2.8877569262012866E-5,
                                -2.5865820793042613E-5,
                                -2.3103216038550726E-5,
                                -2.0577667957913427E-5,
                                -1.8276452066623877E-5,
                                -1.6186448234520248E-5,
                                -1.429435084087329E-5,
                                -1.2586849263834075E-5,
                                -1.1050780809909043E-5,
                                -9.6732582638695463E-6,
                                -8.4417742683480251E-6,
                                -7.3442847323259792E-6,
                                -6.3692734252882231E-6,
                                -5.5057998449634641E-6,
                                -4.7435323566857058E-6,
                                -4.07276849639566E-6,
                                -3.484444211443163E-6,
                                -2.9701336874944695E-6,
                                -2.5220412792939561E-6,
                                -2.132986930628988E-6,
                                -1.7963863370039372E-6,
                                -1.5062269752520156E-6,
                                -1.2570409992229526E-6,
                                -1.043875881081224E-6,
                                -8.6226356460697963E-7,
                                -7.0818879094063818E-7,
                                -5.7805715892108866E-7,
                                -4.6866339181707443E-7,
                                -3.7716019993622753E-7,
                                -3.0102805426933289E-7,
                                -2.3804611981129961E-7,
                                -1.8626453822983516E-7,
                                -1.4397819777250084E-7,
                                -1.0970208330872827E-7,
                                -8.2148260743840358E-8,
                                -6.0204517240373071E-8,
                                -4.2914651247212464E-8,
                                -2.9460383773320345E-8,
                                -1.9144844161294863E-8,
                                -1.1377569339243251E-8,
                                -5.660944699645137E-9,
                                -1.5780069358133515E-9,
                                1.2184760479305805E-9,
                                3.0157360267169761E-9,
                                4.0496351360626587E-9,
                                4.5122848918376489E-9,
                                4.5587403869547344E-9,
                                4.3128537789051085E-9,
                                3.8723676735148717E-9,
                                3.313324915800231E-9,
                                2.6938667916406221E-9,
                                2.0574868725874896E-9,
                                1.4358028261145037E-9,
                                8.5090356993179452E-10,
                                3.1732425767681517E-10,
                                -1.5630318636924746E-10,
                                -5.6588085963179939E-10,
                                -9.1071825340304223E-10,
                                -1.192613587352017E-9,
                                -1.4151123519283332E-9,
                                -1.582915888734215E-9,
                                -1.7014161403317702E-9,
                                -1.7763357202273267E-9,
                                -1.8134551965362866E-9,
                                -1.8184119584057194E-9,
                                -1.7965572546531494E-9,
                                -1.7528599733843087E-9,
                                -1.691847484997109E-9,
                                -1.6175754152943916E-9,
                                -1.5336195670715706E-9,
                                -1.4430843842217074E-9,
                                -1.3486233685061591E-9,
                                -1.2524677315467408E-9,
                                -1.1564603084834484E-9,
                                -1.0620923894112981E-9,
                                -9.7054165357557645E-10,
                                -8.8270983176821283E-10,
                                -7.992590858117645E-10,
                                -7.2064639084433472E-10,
                                -6.4715544569467025E-10,
                                -5.789258274025161E-10,
                                -5.1597925538367367E-10,
                                -4.5824294552078335E-10,
                                -4.0557012039365189E-10,
                                -3.5775780405379679E-10,
                                -3.1456207258537292E-10,
                                -2.7571095898115079E-10,
                                -2.4091522581549711E-10,
                                -2.0987722455497013E-10,
                                -1.8229805839981145E-10,
                                -1.5788325819782416E-10,
                                -1.363471697800723E-10,
                                -1.1741623730417813E-10,
                                -1.0083135187401841E-10,
                                -8.6349418633880011E-11,
                                -7.3744279332749057E-11,
                                -6.2807111485399051E-11,
                                -5.3346410064593258E-11,
                                -4.5187643378317675E-11,
                                -3.8172661573408283E-11,
                                -3.2158924147106144E-11,
                                -2.7018601977312014E-11,
                                -2.2637599693453278E-11,
                                -1.891453566846677E-11,
                                -1.5759709460386494E-11,
                                -1.3094080098292756E-11,
                                -1.0848273110399938E-11,
                                -8.9616295467171037E-12,
                                -7.3813063677785728E-12,
                                -6.0614343691427862E-12,
                                -4.96233720625897E-12,
                                -4.0498129984910661E-12,
                                -3.2944783522846678E-12,
                                -2.6711733858490232E-12,
                                -2.1584254014004284E-12,
                                -1.7379681827077112E-12,
                                -1.3943134480214629E-12,
                                -1.1143707201096343E-12,
                                -8.8711175015278673E-13,
                                -7.0327561983384561E-13,
                                -5.5511071991874144E-13,
                                -4.3614994192759629E-13,
                                -3.4101560384050384E-13,
                                -2.6525084612334661E-13,
                                -2.0517446852191659E-13,
                                -1.5775642133696009E-13,
                                -1.2051140966108021E-13,
                                -9.1408309506125136E-14,
                                -6.8793326564409363E-14,
                                -5.13250484412931E-14,
                                -3.7919747509645651E-14,
                                -2.7705482816661211E-14,
                                -1.9983725124188528E-14,
                                -1.4197389091103304E-14,
                                -9.9043011037369156E-15,
                                -6.755260902943688E-15,
                                -4.4759707218482308E-15,
                                -2.8522080455031893E-15,
                                -1.7177083213343748E-15,
                                -9.4430301090774346E-16,
                                -4.3392730572933097E-16,
                                -1.1217163623701553E-16,
                                0.0};
  double dgs[301];
  double xx[301];
  double y[301];
  double a;
  double c1;
  // if imgi==1; close(hpg); end;%10/Aug./2005
  // keyboard;
  // --------------------
  a = 6.2831853071795862 * f;
  for (int k{0}; k < 301; k++) {
    double d;
    double d1;
    d = b_dv[k] / f;
    dgs[k] = d;
    d1 = a * b[k];
    xx[k] = d1;
    y[k] = rt_powd_snf(d1 * d, 2.0);
  }
  a = y[0];
  for (int k{0}; k < 300; k++) {
    a += y[k + 1];
  }
  c1 = a / 100.0;
  for (int k{0}; k < 301; k++) {
    dgs[k] = rt_powd_snf(rt_powd_snf(xx[k], 2.0) * dgs[k], 2.0);
  }
  a = dgs[0];
  for (int k{0}; k < 300; k++) {
    a += dgs[k + 1];
  }
  c2 = a / 100.0;
  return c1;
}

void refineF06(const coder::array<double, 1U> &x, double fs,
               const coder::array<double, 2U> &f0raw, double fftl, double eta,
               double nhmx, double shiftm, double nu,
               coder::array<double, 2U> &f0r, coder::array<double, 2U> &ecr)
{
  __m128d r;
  __m128d r3;
  coder::array<creal_T, 2U> b_tt;
  coder::array<creal_T, 2U> fd0;
  coder::array<creal_T, 2U> ff0;
  coder::array<creal_T, 2U> ff1;
  coder::array<creal_T, 2U> rr;
  coder::array<creal_T, 2U> wa;
  coder::array<creal_T, 2U> wo;
  coder::array<creal_T, 1U> f_x;
  coder::array<double, 2U> b_fax;
  coder::array<double, 2U> b_pif;
  coder::array<double, 2U> b_x;
  coder::array<double, 2U> bx;
  coder::array<double, 2U> c_x;
  coder::array<double, 2U> crf;
  coder::array<double, 2U> crf0;
  coder::array<double, 2U> d_x;
  coder::array<double, 2U> dpif;
  coder::array<double, 2U> e_x;
  coder::array<double, 2U> fax;
  coder::array<double, 2U> fqv;
  coder::array<double, 2U> pif;
  coder::array<double, 2U> pwm;
  coder::array<double, 2U> r2;
  coder::array<double, 2U> tt;
  coder::array<double, 2U> vvv;
  coder::array<double, 2U> xo;
  coder::array<double, 1U> a;
  coder::array<double, 1U> f0i;
  coder::array<double, 1U> w1;
  coder::array<double, 1U> y;
  coder::array<int, 2U> r1;
  coder::array<int, 1U> r4;
  double b;
  double bias;
  double c2;
  double d;
  double rmsValue;
  double shiftl;
  double smb;
  double sml;
  double varargin_1;
  double wa_re_tmp;
  int b_input_sizes[2];
  int input_sizes[2];
  int sizes[2];
  int b_i;
  int b_loop_ub;
  int b_loop_ub_tmp;
  int c_loop_ub;
  int d_loop_ub;
  int end_tmp;
  int i;
  int i1;
  int i2;
  int input_sizes_idx_1;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  int nx;
  int trueCount;
  int vectorUB;
  boolean_T b_b;
  boolean_T empty_non_axis_sizes;
  // 	F0 estimation refinement
  // 	[f0r,ecr]=refineF06(x,fs,f0raw,fftl,nhmx,shiftm,nl,nu,imgi)
  // 		x		: input waveform
  // 		fs		: sampling frequency (Hz)
  // 		f0raw	: F0 candidate (Hz)
  // 		fftl	: FFT length
  // 		eta		: temporal stretch factor
  // 		nhmx	: highest harmonic number
  // 		shiftm	: frame shift period (ms)
  // 		nl		: lower frame number
  // 		nu		: uppter frame number
  // 		imgi	: display indicator, 1: display on (default), 0: off
  //
  // 	Example of usage (with STRAIGHT)
  //
  // 	global xold fs f0shiftm f0raw
  //
  // 	dn=floor(fs/(800*3*2));
  // 	[f0raw,ecr]=refineF02(decimate(xold,dn),fs/dn,f0raw,512,1.1,3,f0shiftm,1,length(f0raw));
  // 	Designed and coded by Hideki Kawahara
  // 	28/July/1999
  // 	29/July/1999 test version using power weighting
  // 	30/July/1999 GcBs is added (bug fix)
  // 	07/August/1999 small bug fix
  //    07/Dec./2002 wqitbar was added
  //    13.May/2005 minor vulnerability fix
  // 	10/Aug./2005 modified by Takahashi on waitbar
  // 	10/Sept./2005 modified by Kawahara on waitbar
  //    16/Sept./2005 minor bug fix
  //    26/Sept./2005 bug fix
  loop_ub = f0raw.size(1);
  f0i.set_size(f0raw.size(1));
  for (i = 0; i < loop_ub; i++) {
    f0i[i] = f0raw[i];
  }
  end_tmp = f0raw.size(1) - 1;
  for (b_i = 0; b_i <= end_tmp; b_i++) {
    if (f0raw[b_i] == 0.0) {
      f0i[b_i] = 160.0;
    }
  }
  if (std::isnan(fftl - 1.0)) {
    xo.set_size(1, 1);
    xo[0] = rtNaN;
  } else if (fftl - 1.0 < 0.0) {
    xo.set_size(xo.size(0), 0);
  } else {
    xo.set_size(1, static_cast<int>(fftl - 1.0) + 1);
    b_loop_ub = static_cast<int>(fftl - 1.0);
    for (i = 0; i <= b_loop_ub; i++) {
      xo[i] = i;
    }
  }
  xo.set_size(1, xo.size(1));
  b_loop_ub = xo.size(1) - 1;
  b_i = (xo.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&xo[i]);
    _mm_storeu_pd(&xo[i], _mm_div_pd(r, _mm_set1_pd(fftl)));
  }
  for (i = b_i; i <= b_loop_ub; i++) {
    xo[i] = xo[i] / fftl;
  }
  b_loop_ub = xo.size(1);
  fax.set_size(1, xo.size(1));
  b_i = (xo.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&xo[i]);
    _mm_storeu_pd(&fax[i], _mm_mul_pd(r, _mm_set1_pd(fs)));
  }
  for (i = b_i; i < b_loop_ub; i++) {
    fax[i] = xo[i] * fs;
  }
  //  07/August/1999
  shiftl = shiftm / 1000.0 * fs;
  b_x.set_size(1,
               (static_cast<int>(fftl) + x.size(0)) + static_cast<int>(fftl));
  loop_ub_tmp = static_cast<int>(fftl);
  for (i = 0; i < loop_ub_tmp; i++) {
    b_x[i] = 0.0;
  }
  c_loop_ub = x.size(0);
  for (i = 0; i < c_loop_ub; i++) {
    b_x[i + static_cast<int>(fftl)] = x[i];
  }
  for (i = 0; i < loop_ub_tmp; i++) {
    b_x[(i + static_cast<int>(fftl)) + x.size(0)] = 0.0;
  }
  if (fftl < 1.0) {
    tt.set_size(tt.size(0), 0);
  } else {
    tt.set_size(1, static_cast<int>(fftl - 1.0) + 1);
    c_loop_ub = static_cast<int>(fftl - 1.0);
    for (i = 0; i <= c_loop_ub; i++) {
      tt[i] = static_cast<double>(i) + 1.0;
    }
  }
  tt.set_size(1, tt.size(1));
  sml = fftl / 2.0;
  c_loop_ub = tt.size(1) - 1;
  b_i = (tt.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&tt[i]);
    _mm_storeu_pd(&tt[i],
                  _mm_div_pd(_mm_sub_pd(r, _mm_set1_pd(sml)), _mm_set1_pd(fs)));
  }
  for (i = b_i; i <= c_loop_ub; i++) {
    tt[i] = (tt[i] - sml) / fs;
  }
  rr.set_size(1, xo.size(1));
  for (i = 0; i < b_loop_ub; i++) {
    d = xo[i] * 2.0 * 3.1415926535897931;
    rr[i].re = d * 0.0;
    rr[i].im = -d;
  }
  legacy_STRAIGHT::b_exp(rr);
  b_loop_ub = tt.size(1);
  w1.set_size(tt.size(1));
  b_i = (tt.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&tt[i]);
    _mm_storeu_pd(&w1[i], _mm_div_pd(_mm_mul_pd(r, _mm_set1_pd(100.0)),
                                     _mm_set1_pd(eta)));
  }
  for (i = b_i; i < b_loop_ub; i++) {
    w1[i] = tt[i] * 100.0 / eta;
  }
  nx = w1.size(0);
  y.set_size(w1.size(0));
  for (k = 0; k < nx; k++) {
    y[k] = std::abs(w1[k]);
  }
  w1.set_size(nx);
  for (i = 0; i < nx; i++) {
    bias = 1.0 - y[i];
    w1[i] = std::fmax(0.0, bias);
  }
  nx = w1.size(0) - 1;
  trueCount = 0;
  for (b_i = 0; b_i <= nx; b_i++) {
    if (w1[b_i] > 0.0) {
      trueCount++;
    }
  }
  c_loop_ub = 0;
  for (b_i = 0; b_i <= nx; b_i++) {
    if (w1[b_i] > 0.0) {
      w1[c_loop_ub] = w1[b_i];
      c_loop_ub++;
    }
  }
  w1.set_size(trueCount);
  tt.set_size(1, tt.size(1));
  loop_ub_tmp = tt.size(1) - 1;
  for (i = 0; i <= loop_ub_tmp; i++) {
    varargin_1 = tt[i] * 100.0 / eta;
    tt[i] = -3.1415926535897931 * rt_powd_snf(varargin_1, 2.0);
  }
  for (k = 0; k < b_loop_ub; k++) {
    tt[k] = std::exp(tt[k]);
  }
  xo.set_size(1, tt.size(1));
  for (k = 0; k < b_loop_ub; k++) {
    xo[k] = std::abs(tt[k]);
  }
  nx = 0;
  for (b_i = 0; b_i <= loop_ub_tmp; b_i++) {
    if (xo[b_i] > 0.0002) {
      nx++;
    }
  }
  r1.set_size(1, nx);
  c_loop_ub = 0;
  for (b_i = 0; b_i <= loop_ub_tmp; b_i++) {
    if (xo[b_i] > 0.0002) {
      r1[c_loop_ub] = b_i;
      c_loop_ub++;
    }
  }
  b_loop_ub = r1.size(1);
  xo.set_size(1, r1.size(1));
  for (i = 0; i < b_loop_ub; i++) {
    xo[i] = tt[r1[i]];
  }
  y.set_size(trueCount + r1.size(1));
  for (i = 0; i < trueCount; i++) {
    y[i] = w1[i];
  }
  for (i = 0; i < b_loop_ub; i++) {
    y[i + trueCount] = 0.0;
  }
  legacy_STRAIGHT::fftfilt(xo, y, ff1);
  b_loop_ub = ff1.size(1);
  c_loop_ub = ff1.size(0);
  wo.set_size(ff1.size(1), ff1.size(0));
  for (i = 0; i < c_loop_ub; i++) {
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      wo[i1 + wo.size(0) * i].re = ff1[i + ff1.size(0) * i1].re;
      wo[i1 + wo.size(0) * i].im = -ff1[i + ff1.size(0) * i1].im;
    }
  }
  if ((wo.size(0) == 0) || (wo.size(1) == 0)) {
    xo.set_size(xo.size(0), 0);
  } else {
    nx = wo.size(0);
    input_sizes_idx_1 = wo.size(1);
    if (nx >= input_sizes_idx_1) {
      input_sizes_idx_1 = nx;
    }
    xo.set_size(1, input_sizes_idx_1);
    b_loop_ub = input_sizes_idx_1 - 1;
    for (i = 0; i <= b_loop_ub; i++) {
      xo[i] = i;
    }
  }
  if ((wo.size(0) == 0) || (wo.size(1) == 0)) {
    input_sizes_idx_1 = 0;
  } else {
    nx = wo.size(0);
    input_sizes_idx_1 = wo.size(1);
    if (nx >= input_sizes_idx_1) {
      input_sizes_idx_1 = nx;
    }
  }
  xo.set_size(1, xo.size(1));
  b_loop_ub = xo.size(1) - 1;
  b_i = (xo.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&xo[i]);
    _mm_storeu_pd(
        &xo[i],
        _mm_div_pd(r,
                   _mm_set1_pd(static_cast<double>(input_sizes_idx_1) - 1.0)));
  }
  for (i = b_i; i <= b_loop_ub; i++) {
    xo[i] = xo[i] / (static_cast<double>(input_sizes_idx_1) - 1.0);
  }
  if ((wo.size(0) == 0) || (wo.size(1) == 0)) {
    input_sizes_idx_1 = 0;
  } else {
    nx = wo.size(0);
    input_sizes_idx_1 = wo.size(1);
    if (nx >= input_sizes_idx_1) {
      input_sizes_idx_1 = nx;
    }
  }
  b = fftl / 2.0 + 1.0;
  i = static_cast<int>(b - 1.0) + 1;
  bx.set_size(1, i);
  b_loop_ub = static_cast<int>(b - 1.0);
  for (i1 = 0; i1 <= b_loop_ub; i1++) {
    bx[i1] = static_cast<double>(i1) + 1.0;
  }
  loop_ub_tmp = static_cast<int>(b);
  pif.set_size(loop_ub_tmp, f0raw.size(1));
  b_loop_ub_tmp = static_cast<int>(b) * f0i.size(0);
  dpif.set_size(loop_ub_tmp, f0raw.size(1));
  pwm.set_size(loop_ub_tmp, f0raw.size(1));
  for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
    pif[i1] = 0.0;
    dpif[i1] = 0.0;
    pwm[i1] = 0.0;
  }
  rmsValue = legacy_STRAIGHT::b_std(b_x);
  //  26/Sept./2005 by HK
  // if imgi==1; hpg=waitbar(0,'F0 refinement using F0 adaptive analysis'); end;
  // % 07/Dec./2002 by H.K.%10/Aug./2005
  i1 = static_cast<int>(nu);
  if (static_cast<int>(nu) - 1 >= 0) {
    d_loop_ub = static_cast<int>(b - 1.0) + 1;
  }
  for (int kk{0}; kk < i1; kk++) {
    d = f0i[kk];
    if (f0i[kk] < 40.0) {
      d = 40.0;
      f0i[kk] = 40.0;
    }
    d = 1.0 / (static_cast<double>(input_sizes_idx_1) - 1.0) * d / 100.0;
    if (std::isnan(d)) {
      tt.set_size(1, 1);
      tt[0] = rtNaN;
    } else if ((d == 0.0) || (d < 0.0)) {
      tt.set_size(1, 0);
    } else if (std::isinf(d)) {
      tt.set_size(1, 1);
      tt[0] = 0.0;
    } else if (std::floor(d) == d) {
      b_loop_ub = static_cast<int>(1.0 / d);
      tt.set_size(1, b_loop_ub + 1);
      for (i2 = 0; i2 <= b_loop_ub; i2++) {
        tt[i2] = d * static_cast<double>(i2);
      }
    } else {
      legacy_STRAIGHT::eml_float_colon(d, tt);
    }
    legacy_STRAIGHT::interp1(xo, wo, tt, wa);
    if ((wa.size(0) == 0) || (wa.size(1) == 0)) {
      trueCount = 0;
      tt.set_size(1, 0);
    } else {
      nx = wa.size(0);
      trueCount = wa.size(1);
      if (nx >= trueCount) {
        trueCount = nx;
      }
      tt.set_size(1, trueCount);
      b_loop_ub = trueCount - 1;
      for (i2 = 0; i2 <= b_loop_ub; i2++) {
        tt[i2] = static_cast<double>(i2) + 1.0;
      }
    }
    bias = std::round((fftl - static_cast<double>(trueCount) / 2.0) +
                      ((static_cast<double>(kk) + 1.0) - 1.0) * shiftl);
    b_loop_ub = tt.size(1);
    r2.set_size(1, tt.size(1));
    b_i = (tt.size(1) / 2) << 1;
    vectorUB = b_i - 2;
    for (i2 = 0; i2 <= vectorUB; i2 += 2) {
      r = _mm_loadu_pd(&tt[i2]);
      _mm_storeu_pd(&r2[i2], _mm_add_pd(r, _mm_set1_pd(bias)));
    }
    for (i2 = b_i; i2 < b_loop_ub; i2++) {
      r2[i2] = tt[i2] + bias;
    }
    b_loop_ub = r2.size(1);
    c_x.set_size(1, r2.size(1));
    d_x.set_size(1, r2.size(1));
    e_x.set_size(1, r2.size(1));
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      d = r2[i2];
      c_x[i2] = b_x[static_cast<int>(d) - 1];
      d_x[i2] = b_x[static_cast<int>(d) - 2];
      e_x[i2] = b_x[static_cast<int>(static_cast<unsigned int>(d))];
    }
    if (legacy_STRAIGHT::b_std(c_x) * legacy_STRAIGHT::b_std(d_x) *
            legacy_STRAIGHT::b_std(e_x) ==
        0.0) {
      //  26/Sept./2005 by HK
      r1.set_size(1, r2.size(1));
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        r1[i2] = static_cast<int>(r2[i2]);
      }
      legacy_STRAIGHT::randn(static_cast<double>(tt.size(1)), a);
      c_loop_ub = r1.size(1) - 1;
      for (i2 = 0; i2 <= c_loop_ub; i2++) {
        b_x[r1[i2] - 1] = a[i2] * rmsValue / 100000.0;
      }
    }
    c_x.set_size(1, r2.size(1));
    tt.set_size(1, r2.size(1));
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      d = r2[i2];
      c_x[i2] = b_x[static_cast<int>(d) - 1];
      tt[i2] = b_x[static_cast<int>(d) - 2];
    }
    bias = legacy_STRAIGHT::combineVectorElements(c_x) /
           static_cast<double>(r2.size(1));
    if (tt.size(1) == wa.size(1)) {
      c_loop_ub = wa.size(0);
      b_tt.set_size(wa.size(0), r2.size(1));
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        for (nx = 0; nx < c_loop_ub; nx++) {
          d = tt[i2] - bias;
          b_tt[nx + b_tt.size(0) * i2].re = d * wa[nx + wa.size(0) * i2].re;
          b_tt[nx + b_tt.size(0) * i2].im = d * wa[nx + wa.size(0) * i2].im;
        }
      }
      legacy_STRAIGHT::fft(b_tt, fftl, ff0);
    } else {
      binary_expand_op_58(ff0, tt, bias, wa, fftl);
    }
    if (r2.size(1) == wa.size(1)) {
      c_loop_ub = wa.size(0);
      b_tt.set_size(wa.size(0), r2.size(1));
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        for (nx = 0; nx < c_loop_ub; nx++) {
          d = b_x[static_cast<int>(r2[i2]) - 1] - bias;
          b_tt[nx + b_tt.size(0) * i2].re = d * wa[nx + wa.size(0) * i2].re;
          b_tt[nx + b_tt.size(0) * i2].im = d * wa[nx + wa.size(0) * i2].im;
        }
      }
      legacy_STRAIGHT::fft(b_tt, fftl, ff1);
    } else {
      binary_expand_op_57(ff1, b_x, r2, bias, wa, fftl);
    }
    b_loop_ub = r2.size(1);
    tt.set_size(1, r2.size(1));
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      tt[i2] = b_x[static_cast<int>(static_cast<unsigned int>(r2[i2]))];
    }
    if (tt.size(1) == wa.size(1)) {
      c_loop_ub = wa.size(0);
      b_tt.set_size(wa.size(0), r2.size(1));
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        for (nx = 0; nx < c_loop_ub; nx++) {
          d = tt[i2] - bias;
          b_tt[nx + b_tt.size(0) * i2].re = d * wa[nx + wa.size(0) * i2].re;
          b_tt[nx + b_tt.size(0) * i2].im = d * wa[nx + wa.size(0) * i2].im;
        }
      }
      legacy_STRAIGHT::fft(b_tt, fftl, wa);
    } else {
      binary_expand_op_56(wa, tt, bias, fftl);
    }
    if (wa.size(1) == 1) {
      i2 = rr.size(1);
    } else {
      i2 = wa.size(1);
    }
    if ((wa.size(1) == rr.size(1)) && (wa.size(0) == ff1.size(0)) &&
        (i2 == ff1.size(1))) {
      b_loop_ub = ff1.size(0);
      c_loop_ub = ff1.size(1);
      b_tt.set_size(ff1.size(0), ff1.size(1));
      for (i2 = 0; i2 < c_loop_ub; i2++) {
        for (nx = 0; nx < b_loop_ub; nx++) {
          bias = wa[nx + wa.size(0) * i2].re;
          d = rr[i2].im;
          wa_re_tmp = wa[nx + wa.size(0) * i2].im;
          c2 = rr[i2].re;
          b_tt[nx + b_tt.size(0) * i2].re =
              (bias * c2 - wa_re_tmp * d) - ff1[nx + ff1.size(0) * i2].re;
          b_tt[nx + b_tt.size(0) * i2].im =
              (bias * d + wa_re_tmp * c2) - ff1[nx + ff1.size(0) * i2].im;
        }
      }
      wa.set_size(ff1.size(0), ff1.size(1));
      b_loop_ub = b_tt.size(0) * b_tt.size(1);
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        wa[i2] = b_tt[i2];
      }
    } else {
      binary_expand_op_55(wa, rr, ff1);
    }
    if (ff1.size(1) == 1) {
      i2 = rr.size(1);
    } else {
      i2 = ff1.size(1);
    }
    if ((ff1.size(1) == rr.size(1)) && (ff1.size(0) == ff0.size(0)) &&
        (i2 == ff0.size(1))) {
      b_loop_ub = ff0.size(0);
      c_loop_ub = ff0.size(1);
      fd0.set_size(ff0.size(0), ff0.size(1));
      for (i2 = 0; i2 < c_loop_ub; i2++) {
        for (nx = 0; nx < b_loop_ub; nx++) {
          bias = ff1[nx + ff1.size(0) * i2].re;
          d = rr[i2].im;
          wa_re_tmp = ff1[nx + ff1.size(0) * i2].im;
          c2 = rr[i2].re;
          fd0[nx + fd0.size(0) * i2].re =
              (bias * c2 - wa_re_tmp * d) - ff0[nx + ff0.size(0) * i2].re;
          fd0[nx + fd0.size(0) * i2].im =
              (bias * d + wa_re_tmp * c2) - ff0[nx + ff0.size(0) * i2].im;
        }
      }
    } else {
      binary_expand_op_54(fd0, ff1, rr, ff0);
    }
    nx = ff1.size(0) * ff1.size(1);
    crf0.set_size(ff1.size(0), ff1.size(1));
    for (k = 0; k < nx; k++) {
      crf0[k] = rt_hypotd_snf(ff1[k].re, ff1[k].im);
    }
    c_loop_ub = fax.size(1);
    if (ff1.size(1) == 1) {
      i2 = wa.size(1);
    } else {
      i2 = ff1.size(1);
    }
    if (ff1.size(0) == 1) {
      b_loop_ub = wa.size(0);
    } else {
      b_loop_ub = ff1.size(0);
    }
    if (i2 == 1) {
      vectorUB = crf0.size(1);
    } else {
      vectorUB = i2;
    }
    if ((ff1.size(0) == wa.size(0)) && (ff1.size(1) == wa.size(1)) &&
        (ff1.size(0) == wa.size(0)) && (ff1.size(1) == wa.size(1)) &&
        (b_loop_ub == crf0.size(0)) && (i2 == crf0.size(1)) &&
        (fax.size(1) == vectorUB)) {
      b_loop_ub = ff1.size(0);
      crf.set_size(ff1.size(0), fax.size(1));
      for (i2 = 0; i2 < c_loop_ub; i2++) {
        for (nx = 0; nx < b_loop_ub; nx++) {
          varargin_1 = crf0[nx + crf0.size(0) * i2];
          crf[nx + crf.size(0) * i2] =
              fax[i2] +
              (ff1[nx + ff1.size(0) * i2].re * wa[nx + wa.size(0) * i2].im -
               ff1[nx + ff1.size(0) * i2].im * wa[nx + wa.size(0) * i2].re) /
                  rt_powd_snf(varargin_1, 2.0) * fs / 3.1415926535897931 / 2.0;
        }
      }
    } else {
      binary_expand_op_53(crf, fax, ff1, wa, crf0, fs);
    }
    nx = ff0.size(0) * ff0.size(1);
    crf0.set_size(ff0.size(0), ff0.size(1));
    for (k = 0; k < nx; k++) {
      crf0[k] = rt_hypotd_snf(ff0[k].re, ff0[k].im);
    }
    c_loop_ub = fax.size(1);
    if (ff0.size(1) == 1) {
      i2 = fd0.size(1);
    } else {
      i2 = ff0.size(1);
    }
    if (ff0.size(0) == 1) {
      b_loop_ub = fd0.size(0);
    } else {
      b_loop_ub = ff0.size(0);
    }
    if (i2 == 1) {
      vectorUB = crf0.size(1);
    } else {
      vectorUB = i2;
    }
    if ((ff0.size(0) == fd0.size(0)) && (ff0.size(1) == fd0.size(1)) &&
        (ff0.size(0) == fd0.size(0)) && (ff0.size(1) == fd0.size(1)) &&
        (b_loop_ub == crf0.size(0)) && (i2 == crf0.size(1)) &&
        (fax.size(1) == vectorUB)) {
      b_loop_ub = ff0.size(0);
      b_fax.set_size(ff0.size(0), fax.size(1));
      for (i2 = 0; i2 < c_loop_ub; i2++) {
        for (nx = 0; nx < b_loop_ub; nx++) {
          varargin_1 = crf0[nx + crf0.size(0) * i2];
          b_fax[nx + b_fax.size(0) * i2] =
              fax[i2] +
              (ff0[nx + ff0.size(0) * i2].re * fd0[nx + fd0.size(0) * i2].im -
               ff0[nx + ff0.size(0) * i2].im * fd0[nx + fd0.size(0) * i2].re) /
                  rt_powd_snf(varargin_1, 2.0) * fs / 3.1415926535897931 / 2.0;
        }
      }
      crf0.set_size(ff0.size(0), fax.size(1));
      b_loop_ub = b_fax.size(0) * b_fax.size(1);
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        crf0[i2] = b_fax[i2];
      }
    } else {
      binary_expand_op_52(crf0, fax, ff0, fd0, fs);
    }
    for (i2 = 0; i2 < loop_ub_tmp; i2++) {
      pif[i2 + pif.size(0) * kk] =
          crf[static_cast<int>(bx[i2]) - 1] * 2.0 * 3.1415926535897931;
    }
    b_loop_ub = dpif.size(0);
    b_i = (dpif.size(0) / 2) << 1;
    vectorUB = b_i - 2;
    for (i2 = 0; i2 <= vectorUB; i2 += 2) {
      r = _mm_loadu_pd(&crf[i2]);
      r3 = _mm_loadu_pd(&crf0[i2]);
      _mm_storeu_pd(&dpif[i2 + dpif.size(0) * kk],
                    _mm_mul_pd(_mm_mul_pd(_mm_sub_pd(r, r3), _mm_set1_pd(2.0)),
                               _mm_set1_pd(3.1415926535897931)));
    }
    for (i2 = b_i; i2 < b_loop_ub; i2++) {
      dpif[i2 + dpif.size(0) * kk] =
          (crf[i2] - crf0[i2]) * 2.0 * 3.1415926535897931;
    }
    f_x.set_size(i);
    for (i2 = 0; i2 < d_loop_ub; i2++) {
      nx = static_cast<int>(bx[i2]) - 1;
      f_x[i2].re = ff1[nx].re;
      f_x[i2].im = -ff1[nx].im;
    }
    y.set_size(i);
    for (k = 0; k < i; k++) {
      y[k] = rt_hypotd_snf(f_x[k].re, f_x[k].im);
    }
    for (i2 = 0; i2 < loop_ub_tmp; i2++) {
      pwm[i2 + pwm.size(0) * kk] = y[i2];
    }
    //  29/July/1999
    // if imgi==1; waitbar((kk-nl)/(nu-nl)); end; % ,hpg) % 07/Dec./2002 by
    // H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end;
  if (b < 2.0) {
    i = 0;
    i1 = 0;
  } else {
    i = 1;
    i1 = static_cast<int>(b);
  }
  tt.set_size(1, f0raw.size(1));
  for (i2 = 0; i2 < loop_ub; i2++) {
    tt[i2] = pif[(static_cast<int>(b) + pif.size(0) * i2) - 1];
  }
  b_loop_ub = i1 - i;
  b_b = ((b_loop_ub != 0) && (pif.size(1) != 0));
  if (b_b) {
    k = f0raw.size(1);
  } else if (pif.size(1) != 0) {
    k = f0raw.size(1);
  } else {
    k = 0;
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes || b_b) {
    input_sizes[0] = i1 - i;
  } else {
    input_sizes[0] = 0;
  }
  if (empty_non_axis_sizes || (pif.size(1) != 0)) {
    sizes[0] = 1;
  } else {
    sizes[0] = 0;
  }
  c_loop_ub = input_sizes[0] + sizes[0];
  if ((c_loop_ub == pif.size(0)) && (k == pif.size(1))) {
    b_fax.set_size(b_loop_ub, f0raw.size(1));
    for (i1 = 0; i1 < loop_ub; i1++) {
      for (i2 = 0; i2 < b_loop_ub; i2++) {
        b_fax[i2 + b_fax.size(0) * i1] = pif[(i + i2) + pif.size(0) * i1];
      }
    }
    nx = input_sizes[0];
    trueCount = sizes[0];
    b_pif.set_size(c_loop_ub, k);
    for (i = 0; i < k; i++) {
      for (i1 = 0; i1 < nx; i1++) {
        b_pif[i1 + b_pif.size(0) * i] = b_fax[i1 + nx * i];
      }
      for (i1 = 0; i1 < trueCount; i1++) {
        b_pif[nx + b_pif.size(0) * i] = tt[trueCount * i];
      }
    }
    bias = fs / fftl * 2.0 * 3.1415926535897931;
    crf0.set_size(c_loop_ub, b_pif.size(1));
    b_loop_ub = b_pif.size(0) * b_pif.size(1);
    b_i = (b_loop_ub / 2) << 1;
    vectorUB = b_i - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&b_pif[i]);
      r3 = _mm_loadu_pd(&pif[i]);
      _mm_storeu_pd(&crf0[i], _mm_div_pd(_mm_sub_pd(r, r3), _mm_set1_pd(bias)));
    }
    for (i = b_i; i < b_loop_ub; i++) {
      crf0[i] = (b_pif[i] - pif[i]) / bias;
    }
  } else {
    binary_expand_op_65(crf0, pif, i, i1, input_sizes, k, tt, sizes, fs, fftl);
  }
  if (b < 2.0) {
    i = 0;
    i1 = 0;
  } else {
    i = 1;
    i1 = static_cast<int>(b);
  }
  b_loop_ub = dpif.size(1);
  tt.set_size(1, dpif.size(1));
  for (i2 = 0; i2 < b_loop_ub; i2++) {
    tt[i2] = dpif[(static_cast<int>(b) + dpif.size(0) * i2) - 1];
  }
  c_loop_ub = i1 - i;
  b_b = ((c_loop_ub != 0) && (dpif.size(1) != 0));
  if (b_b) {
    k = dpif.size(1);
  } else if (dpif.size(1) != 0) {
    k = dpif.size(1);
  } else {
    k = 0;
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes || b_b) {
    b_input_sizes[0] = i1 - i;
  } else {
    b_input_sizes[0] = 0;
  }
  if (empty_non_axis_sizes || (dpif.size(1) != 0)) {
    sizes[0] = 1;
  } else {
    sizes[0] = 0;
  }
  nx = b_input_sizes[0] + sizes[0];
  if ((nx == dpif.size(0)) && (k == dpif.size(1))) {
    b_fax.set_size(c_loop_ub, dpif.size(1));
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      for (i2 = 0; i2 < c_loop_ub; i2++) {
        b_fax[i2 + b_fax.size(0) * i1] = dpif[(i + i2) + dpif.size(0) * i1];
      }
    }
    input_sizes[0] = b_input_sizes[0];
    trueCount = sizes[0];
    b_pif.set_size(nx, k);
    for (i = 0; i < k; i++) {
      b_loop_ub = input_sizes[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_pif[i1 + b_pif.size(0) * i] = b_fax[i1 + input_sizes[0] * i];
      }
      for (i1 = 0; i1 < trueCount; i1++) {
        b_pif[input_sizes[0] + b_pif.size(0) * i] = tt[trueCount * i];
      }
    }
    bias = fs / fftl * 2.0 * 3.1415926535897931;
    crf.set_size(nx, b_pif.size(1));
    b_loop_ub = b_pif.size(0) * b_pif.size(1);
    b_i = (b_loop_ub / 2) << 1;
    vectorUB = b_i - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&b_pif[i]);
      r3 = _mm_loadu_pd(&dpif[i]);
      _mm_storeu_pd(&crf[i],
                    _mm_mul_pd(_mm_div_pd(_mm_sub_pd(r, r3), _mm_set1_pd(bias)),
                               _mm_set1_pd(fs)));
    }
    for (i = b_i; i < b_loop_ub; i++) {
      crf[i] = (b_pif[i] - dpif[i]) / bias * fs;
    }
  } else {
    binary_expand_op_64(crf, dpif, i, i1, b_input_sizes, k, tt, sizes, fs,
                        fftl);
  }
  dpif.set_size(crf0.size(0), crf0.size(1));
  b_loop_ub = crf0.size(0) * crf0.size(1);
  b_i = (b_loop_ub / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&crf0[i]);
    _mm_storeu_pd(&dpif[i], _mm_mul_pd(r, _mm_set1_pd(0.0)));
  }
  for (i = b_i; i < b_loop_ub; i++) {
    dpif[i] = crf0[i] * 0.0;
  }
  bias = znrmlcf2(shiftm, c2);
  tt.set_size(1, static_cast<int>(sml) + 1);
  b_loop_ub = static_cast<int>(sml);
  for (i = 0; i <= b_loop_ub; i++) {
    tt[i] =
        (static_cast<double>(i) + 0.5) / fftl * fs * 2.0 * 3.1415926535897931;
  }
  // --- calculation of relative noise level
  // if imgi==1; hpg=waitbar(0,'P/N calculation'); end; % 07/Dec./2002 by
  // H.K.%10/Aug./2005
  wa_re_tmp = std::sqrt(bias);
  for (c_loop_ub = 0; c_loop_ub < loop_ub_tmp; c_loop_ub++) {
    bias = tt[c_loop_ub] / 2.0 / 3.1415926535897931;
    c2 *= bias * bias;
    bias = std::sqrt(c2);
    if (crf.size(1) == crf0.size(1)) {
      b_loop_ub = dpif.size(1);
      for (i = 0; i < b_loop_ub; i++) {
        varargin_1 = crf[c_loop_ub + crf.size(0) * i] / bias;
        d = crf0[c_loop_ub + crf0.size(0) * i] / wa_re_tmp;
        dpif[c_loop_ub + dpif.size(0) * i] =
            rt_powd_snf(varargin_1, 2.0) + rt_powd_snf(d, 2.0);
      }
    } else {
      binary_expand_op_59(dpif, c_loop_ub, crf, bias, crf0, wa_re_tmp);
    }
    // if imgi==1 && rem(ii,10)==0;waitbar(ii/(fftl/2+1));end;  % 07/Dec./2002
    // by H.K.%10/Aug./2005
  }
  // if imgi==1; close(hpg); end; % 07/Dec./2002 by H.K.%10/Aug./2005
  // --- Temporal smoothing
  sml = std::round(1.5 * fs / 1000.0 / 2.0 / shiftm) * 2.0 + 1.0;
  //  3 ms, and odd number
  smb = std::round((sml - 1.0) / 2.0);
  //  bias due to filtering
  // if imgi==1; hpg=waitbar(0,'P/N smoothing'); end; % 07/Dec./2002 by
  // H.K.%10/Aug./2005 This smoothing is modified (30 Nov. 2000).
  i = static_cast<int>(sml * 2.0);
  b_b = ((dpif.size(0) != 0) && (dpif.size(1) != 0));
  if (b_b) {
    k = dpif.size(0);
  } else if ((static_cast<int>(b) != 0) && (i != 0)) {
    k = static_cast<int>(b);
  } else {
    k = dpif.size(0);
    if (static_cast<int>(b) > dpif.size(0)) {
      k = static_cast<int>(b);
    }
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes || b_b) {
    input_sizes_idx_1 = dpif.size(1);
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes || ((static_cast<int>(b) != 0) && (i != 0))) {
    sizes[1] = i;
  } else {
    sizes[1] = 0;
  }
  nx = dpif.size(0) * dpif.size(1);
  nx--;
  trueCount = 0;
  for (b_i = 0; b_i <= nx; b_i++) {
    if ((!std::isnan(dpif[b_i])) && (dpif[b_i] < rtInf)) {
      trueCount++;
    }
  }
  r4.set_size(trueCount);
  c_loop_ub = 0;
  for (b_i = 0; b_i <= nx; b_i++) {
    if ((!std::isnan(dpif[b_i])) && (dpif[b_i] < rtInf)) {
      r4[c_loop_ub] = b_i;
      c_loop_ub++;
    }
  }
  b_loop_ub = r4.size(0);
  y.set_size(r4.size(0));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    y[i1] = dpif[r4[i1]];
  }
  bias = legacy_STRAIGHT::coder::internal::maximum(y);
  legacy_STRAIGHT::hanning(sml, a);
  legacy_STRAIGHT::hanning(sml, w1);
  b_loop_ub = w1.size(0);
  y.set_size(w1.size(0));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    varargin_1 = w1[i1];
    y[i1] = rt_powd_snf(varargin_1, 2.0);
  }
  wa_re_tmp = legacy_STRAIGHT::blockedSummation(y, y.size(0));
  input_sizes[1] = sizes[1];
  bias *= 1.0E-7;
  b_loop_ub = a.size(0);
  y.set_size(a.size(0));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    varargin_1 = a[i1];
    y[i1] = rt_powd_snf(varargin_1, 2.0) / wa_re_tmp;
  }
  b_fax.set_size(input_sizes_idx_1 + sizes[1], k);
  for (i1 = 0; i1 < k; i1++) {
    for (i2 = 0; i2 < input_sizes_idx_1; i2++) {
      b_fax[i2 + b_fax.size(0) * i1] = dpif[i1 + k * i2] + bias;
    }
    b_loop_ub = input_sizes[1];
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      b_fax[(i2 + input_sizes_idx_1) + b_fax.size(0) * i1] = bias;
    }
  }
  legacy_STRAIGHT::fftfilt(y, b_fax, ff1);
  b_loop_ub = ff1.size(1);
  c_loop_ub = ff1.size(0);
  wa.set_size(ff1.size(1), ff1.size(0));
  for (i1 = 0; i1 < c_loop_ub; i1++) {
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      wa[i2 + wa.size(0) * i1].re = ff1[i1 + ff1.size(0) * i2].re;
      wa[i2 + wa.size(0) * i1].im = -ff1[i1 + ff1.size(0) * i2].im;
    }
  }
  //  26/Sept./2005 by H.K.
  // if imgi==1; waitbar(0.2); end;%10/Aug./2005
  legacy_STRAIGHT::hanning(sml, w1);
  wa_re_tmp = legacy_STRAIGHT::blockedSummation(w1, w1.size(0));
  legacy_STRAIGHT::hanning(sml, w1);
  d_loop_ub = w1.size(0);
  b_i = (w1.size(0) / 2) << 1;
  vectorUB = b_i - 2;
  for (i1 = 0; i1 <= vectorUB; i1 += 2) {
    r = _mm_loadu_pd(&w1[i1]);
    _mm_storeu_pd(&w1[i1], _mm_div_pd(r, _mm_set1_pd(wa_re_tmp)));
  }
  for (i1 = b_i; i1 < d_loop_ub; i1++) {
    w1[i1] = w1[i1] / wa_re_tmp;
  }
  b_tt.set_size(ff1.size(0), ff1.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    for (i2 = 0; i2 < c_loop_ub; i2++) {
      wa_re_tmp = wa[i1 + wa.size(0) * i2].re;
      c2 = -wa[i1 + wa.size(0) * i2].im;
      if (c2 == 0.0) {
        b_tt[i2 + b_tt.size(0) * i1].re = 1.0 / wa_re_tmp;
        b_tt[i2 + b_tt.size(0) * i1].im = 0.0;
      } else if (wa_re_tmp == 0.0) {
        b_tt[i2 + b_tt.size(0) * i1].re = 0.0;
        b_tt[i2 + b_tt.size(0) * i1].im = -(1.0 / c2);
      } else {
        varargin_1 = std::abs(wa_re_tmp);
        bias = std::abs(c2);
        if (varargin_1 > bias) {
          bias = c2 / wa_re_tmp;
          d = wa_re_tmp + bias * c2;
          b_tt[i2 + b_tt.size(0) * i1].re = (bias * 0.0 + 1.0) / d;
          b_tt[i2 + b_tt.size(0) * i1].im = (0.0 - bias) / d;
        } else if (bias == varargin_1) {
          if (wa_re_tmp > 0.0) {
            d = 0.5;
          } else {
            d = -0.5;
          }
          if (c2 > 0.0) {
            bias = 0.5;
          } else {
            bias = -0.5;
          }
          b_tt[i2 + b_tt.size(0) * i1].re = (d + 0.0 * bias) / varargin_1;
          b_tt[i2 + b_tt.size(0) * i1].im = (0.0 * d - bias) / varargin_1;
        } else {
          bias = wa_re_tmp / c2;
          d = c2 + bias * wa_re_tmp;
          b_tt[i2 + b_tt.size(0) * i1].re = bias / d;
          b_tt[i2 + b_tt.size(0) * i1].im = (bias * 0.0 - 1.0) / d;
        }
      }
    }
  }
  legacy_STRAIGHT::b_fftfilt(w1, b_tt, ff1);
  b_loop_ub = ff1.size(1);
  c_loop_ub = ff1.size(0);
  wa.set_size(ff1.size(1), ff1.size(0));
  for (i1 = 0; i1 < c_loop_ub; i1++) {
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      wa[i2 + wa.size(0) * i1].re = ff1[i1 + ff1.size(0) * i2].re;
      wa[i2 + wa.size(0) * i1].im = -ff1[i1 + ff1.size(0) * i2].im;
    }
  }
  c_loop_ub = wa.size(0) * wa.size(1);
  for (i1 = 0; i1 < c_loop_ub; i1++) {
    wa_re_tmp = wa[i1].re;
    c2 = wa[i1].im;
    if (c2 == 0.0) {
      rmsValue = 1.0 / wa_re_tmp;
      d = 0.0;
    } else if (wa_re_tmp == 0.0) {
      rmsValue = 0.0;
      d = -(1.0 / c2);
    } else {
      varargin_1 = std::abs(wa_re_tmp);
      bias = std::abs(c2);
      if (varargin_1 > bias) {
        bias = c2 / wa_re_tmp;
        d = wa_re_tmp + bias * c2;
        rmsValue = (bias * 0.0 + 1.0) / d;
        d = (0.0 - bias) / d;
      } else if (bias == varargin_1) {
        if (wa_re_tmp > 0.0) {
          d = 0.5;
        } else {
          d = -0.5;
        }
        if (c2 > 0.0) {
          bias = 0.5;
        } else {
          bias = -0.5;
        }
        rmsValue = (d + 0.0 * bias) / varargin_1;
        d = (0.0 * d - bias) / varargin_1;
      } else {
        bias = wa_re_tmp / c2;
        d = c2 + bias * wa_re_tmp;
        rmsValue = bias / d;
        d = (bias * 0.0 - 1.0) / d;
      }
    }
    wa[i1].re = rmsValue;
    wa[i1].im = d;
  }
  // if imgi==1; waitbar(0.4); end;
  if (f0i.size(0) < 1) {
    tt.set_size(1, 0);
  } else {
    tt.set_size(1, f0raw.size(1));
    for (i1 = 0; i1 <= end_tmp; i1++) {
      tt[i1] = static_cast<double>(i1) + 1.0;
    }
  }
  c_loop_ub = tt.size(1);
  b_tt.set_size(ff1.size(1), tt.size(1));
  for (i1 = 0; i1 < c_loop_ub; i1++) {
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      bias = (tt[i1] + sml) - 2.0;
      bias = std::fmax(1.0, bias);
      b_tt[i2 + b_tt.size(0) * i1].re =
          wa[i2 + wa.size(0) * (static_cast<int>(bias) - 1)].re;
      b_tt[i2 + b_tt.size(0) * i1].im =
          wa[i2 + wa.size(0) * (static_cast<int>(bias) - 1)].im;
    }
  }
  wa.set_size(ff1.size(1), tt.size(1));
  loop_ub_tmp = b_tt.size(0) * b_tt.size(1);
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    wa[i1] = b_tt[i1];
  }
  //  fixed by H.K. on 10/Dec./2002
  // --- Power adaptive weighting (29/July/1999)
  b_b = ((pwm.size(0) != 0) && (pwm.size(1) != 0));
  if (b_b) {
    k = static_cast<int>(b);
  } else if ((static_cast<int>(b) != 0) && (i != 0)) {
    k = static_cast<int>(b);
  } else {
    k = static_cast<int>(b);
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes || b_b) {
    input_sizes_idx_1 = pwm.size(1);
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes || ((static_cast<int>(b) != 0) && (i != 0))) {
    sizes[1] = i;
  } else {
    sizes[1] = 0;
  }
  legacy_STRAIGHT::hanning(sml, w1);
  wa_re_tmp = legacy_STRAIGHT::blockedSummation(w1, w1.size(0));
  legacy_STRAIGHT::hanning(sml, w1);
  input_sizes[1] = sizes[1];
  b_loop_ub = w1.size(0);
  b_i = (w1.size(0) / 2) << 1;
  vectorUB = b_i - 2;
  for (i1 = 0; i1 <= vectorUB; i1 += 2) {
    r = _mm_loadu_pd(&w1[i1]);
    _mm_storeu_pd(&w1[i1], _mm_div_pd(r, _mm_set1_pd(wa_re_tmp)));
  }
  for (i1 = b_i; i1 < b_loop_ub; i1++) {
    w1[i1] = w1[i1] / wa_re_tmp;
  }
  b_fax.set_size(input_sizes_idx_1 + sizes[1], k);
  for (i1 = 0; i1 < k; i1++) {
    for (i2 = 0; i2 < input_sizes_idx_1; i2++) {
      b_fax[i2 + b_fax.size(0) * i1] = pwm[i1 + k * i2] + 1.0E-5;
    }
    b_loop_ub = input_sizes[1];
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      b_fax[(i2 + input_sizes_idx_1) + b_fax.size(0) * i1] = 1.0E-5;
    }
  }
  legacy_STRAIGHT::fftfilt(w1, b_fax, ff1);
  b_loop_ub = ff1.size(1);
  d_loop_ub = ff1.size(0);
  fd0.set_size(ff1.size(1), ff1.size(0));
  for (i1 = 0; i1 < d_loop_ub; i1++) {
    for (i2 = 0; i2 < b_loop_ub; i2++) {
      fd0[i2 + fd0.size(0) * i1].re = ff1[i1 + ff1.size(0) * i2].re;
      fd0[i2 + fd0.size(0) * i1].im = -ff1[i1 + ff1.size(0) * i2].im;
    }
  }
  // if imgi==1; waitbar(0.6); end;%10/Aug./2005
  if ((pwm.size(0) == pif.size(0)) && (pwm.size(1) == pif.size(1))) {
    b_i = (b_loop_ub_tmp / 2) << 1;
    vectorUB = b_i - 2;
    for (i1 = 0; i1 <= vectorUB; i1 += 2) {
      r = _mm_loadu_pd(&pwm[i1]);
      r3 = _mm_loadu_pd(&pif[i1]);
      _mm_storeu_pd(&pwm[i1], _mm_mul_pd(r, r3));
    }
    for (i1 = b_i; i1 < b_loop_ub_tmp; i1++) {
      pwm[i1] = pwm[i1] * pif[i1];
    }
  } else {
    b_times(pwm, pif);
  }
  b_b = ((pwm.size(0) != 0) && (pwm.size(1) != 0));
  if (b_b) {
    k = pwm.size(0);
  } else if ((static_cast<int>(b) != 0) && (i != 0)) {
    k = static_cast<int>(b);
  } else {
    k = pwm.size(0);
    if (static_cast<int>(b) > pwm.size(0)) {
      k = static_cast<int>(b);
    }
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes || b_b) {
    input_sizes_idx_1 = pwm.size(1);
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes || ((static_cast<int>(b) != 0) && (i != 0))) {
    sizes[1] = i;
  } else {
    sizes[1] = 0;
  }
  legacy_STRAIGHT::hanning(sml, w1);
  wa_re_tmp = legacy_STRAIGHT::blockedSummation(w1, w1.size(0));
  legacy_STRAIGHT::hanning(sml, w1);
  input_sizes[1] = sizes[1];
  b_loop_ub = w1.size(0);
  b_i = (w1.size(0) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&w1[i]);
    _mm_storeu_pd(&w1[i], _mm_div_pd(r, _mm_set1_pd(wa_re_tmp)));
  }
  for (i = b_i; i < b_loop_ub; i++) {
    w1[i] = w1[i] / wa_re_tmp;
  }
  b_fax.set_size(input_sizes_idx_1 + sizes[1], k);
  for (i = 0; i < k; i++) {
    for (i1 = 0; i1 < input_sizes_idx_1; i1++) {
      b_fax[i1 + b_fax.size(0) * i] = pwm[i + k * i1] + 1.0E-5;
    }
    b_loop_ub = input_sizes[1];
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      b_fax[(i1 + input_sizes_idx_1) + b_fax.size(0) * i] = 1.0E-5;
    }
  }
  legacy_STRAIGHT::fftfilt(w1, b_fax, ff1);
  b_loop_ub = ff1.size(1);
  d_loop_ub = ff1.size(0);
  ff0.set_size(ff1.size(1), ff1.size(0));
  for (i = 0; i < d_loop_ub; i++) {
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      ff0[i1 + ff0.size(0) * i].re = ff1[i + ff1.size(0) * i1].re;
      ff0[i1 + ff0.size(0) * i].im = -ff1[i + ff1.size(0) * i1].im;
    }
  }
  // if imgi==1; waitbar(0.8); end;%10/Aug./2005
  if ((ff0.size(0) == fd0.size(0)) && (ff0.size(1) == fd0.size(1))) {
    b_loop_ub = ff0.size(0) * ff0.size(1);
    for (i = 0; i < b_loop_ub; i++) {
      sml = ff0[i].re;
      shiftl = ff0[i].im;
      wa_re_tmp = fd0[i].re;
      c2 = fd0[i].im;
      if (c2 == 0.0) {
        if (shiftl == 0.0) {
          rmsValue = sml / wa_re_tmp;
          d = 0.0;
        } else if (sml == 0.0) {
          rmsValue = 0.0;
          d = shiftl / wa_re_tmp;
        } else {
          rmsValue = sml / wa_re_tmp;
          d = shiftl / wa_re_tmp;
        }
      } else if (wa_re_tmp == 0.0) {
        if (sml == 0.0) {
          rmsValue = shiftl / c2;
          d = 0.0;
        } else if (shiftl == 0.0) {
          rmsValue = 0.0;
          d = -(sml / c2);
        } else {
          rmsValue = shiftl / c2;
          d = -(sml / c2);
        }
      } else {
        varargin_1 = std::abs(wa_re_tmp);
        bias = std::abs(c2);
        if (varargin_1 > bias) {
          bias = c2 / wa_re_tmp;
          d = wa_re_tmp + bias * c2;
          rmsValue = (sml + bias * shiftl) / d;
          d = (shiftl - bias * sml) / d;
        } else if (bias == varargin_1) {
          if (wa_re_tmp > 0.0) {
            d = 0.5;
          } else {
            d = -0.5;
          }
          if (c2 > 0.0) {
            bias = 0.5;
          } else {
            bias = -0.5;
          }
          rmsValue = (sml * d + shiftl * bias) / varargin_1;
          d = (shiftl * d - sml * bias) / varargin_1;
        } else {
          bias = wa_re_tmp / c2;
          d = c2 + bias * wa_re_tmp;
          rmsValue = (bias * sml + shiftl) / d;
          d = (bias * shiftl - sml) / d;
        }
      }
      ff0[i].re = rmsValue;
      ff0[i].im = d;
    }
  } else {
    rdivide(ff0, fd0);
  }
  nx = ff0.size(0);
  b_tt.set_size(ff0.size(0), tt.size(1));
  for (i = 0; i < c_loop_ub; i++) {
    for (i1 = 0; i1 < nx; i1++) {
      b_tt[i1 + b_tt.size(0) * i] =
          ff0[i1 + ff0.size(0) * (static_cast<int>(tt[i] + smb) - 1)];
    }
  }
  ff0.set_size(nx, tt.size(1));
  loop_ub_tmp = b_tt.size(0) * b_tt.size(1);
  for (i = 0; i < loop_ub_tmp; i++) {
    ff0[i] = b_tt[i];
  }
  w1.set_size(f0raw.size(1));
  for (i = 0; i < loop_ub; i++) {
    bias = f0i[i] / fs * fftl;
    w1[i] = std::fmax(0.0, bias);
  }
  trueCount = static_cast<int>(nhmx);
  fqv.set_size(trueCount, f0raw.size(1));
  vvv.set_size(trueCount, f0raw.size(1));
  if (f0i.size(0) - 1 < 0) {
    tt.set_size(tt.size(0), 0);
  } else {
    tt.set_size(1, f0raw.size(1));
    for (i = 0; i <= end_tmp; i++) {
      tt[i] = i;
    }
  }
  tt.set_size(1, tt.size(1));
  b_loop_ub = tt.size(1) - 1;
  b_i = (tt.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&tt[i]);
    _mm_storeu_pd(&tt[i],
                  _mm_add_pd(_mm_mul_pd(r, _mm_set1_pd(b)), _mm_set1_pd(1.0)));
  }
  for (i = b_i; i <= b_loop_ub; i++) {
    tt[i] = tt[i] * b + 1.0;
  }
  for (c_loop_ub = 0; c_loop_ub < trueCount; c_loop_ub++) {
    loop_ub_tmp = w1.size(0);
    if (w1.size(0) == tt.size(1)) {
      tt.set_size(1, w1.size(0));
      b_i = (w1.size(0) / 2) << 1;
      vectorUB = b_i - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&w1[i]);
        r3 = _mm_loadu_pd(&tt[i]);
        _mm_storeu_pd(&tt[i], _mm_add_pd(r, r3));
      }
      for (i = b_i; i < loop_ub_tmp; i++) {
        tt[i] = w1[i] + tt[i];
      }
    } else {
      binary_expand_op_60(tt, w1);
    }
    loop_ub_tmp = tt.size(1);
    r2.set_size(1, tt.size(1));
    for (k = 0; k < loop_ub_tmp; k++) {
      r2[k] = std::floor(tt[k]);
    }
    rr.set_size(1, tt.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      rr[i] = wa[static_cast<int>(r2[i] + 1.0) - 1];
    }
    wa_re_tmp = (static_cast<double>(c_loop_ub) + 1.0) *
                (static_cast<double>(c_loop_ub) + 1.0);
    for (i = 0; i < loop_ub; i++) {
      d = r2[i];
      bias = tt[i] - d;
      sml = wa[static_cast<int>(d) - 1].re +
            bias * (rr[i].re - wa[static_cast<int>(d) - 1].re);
      if (wa[static_cast<int>(d) - 1].im +
              bias * (rr[i].im - wa[static_cast<int>(d) - 1].im) ==
          0.0) {
        bias = sml / wa_re_tmp;
      } else if (sml == 0.0) {
        bias = 0.0;
      } else {
        bias = sml / wa_re_tmp;
      }
      vvv[c_loop_ub + vvv.size(0) * i] = bias;
    }
    rr.set_size(1, tt.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      rr[i] = ff0[static_cast<int>(static_cast<unsigned int>(r2[i]))];
    }
    for (i = 0; i < loop_ub; i++) {
      d = r2[i];
      bias = tt[i] - d;
      sml = ff0[static_cast<int>(d) - 1].re +
            bias * (rr[i].re - ff0[static_cast<int>(d) - 1].re);
      shiftl = ff0[static_cast<int>(d) - 1].im +
               bias * (rr[i].im - ff0[static_cast<int>(d) - 1].im);
      if (shiftl == 0.0) {
        d = sml / 2.0;
        bias = 0.0;
      } else if (sml == 0.0) {
        d = 0.0;
        bias = shiftl / 2.0;
      } else {
        d = sml / 2.0;
        bias = shiftl / 2.0;
      }
      if (bias == 0.0) {
        d /= 3.1415926535897931;
        bias = 0.0;
      } else if (d == 0.0) {
        d = 0.0;
        bias /= 3.1415926535897931;
      } else {
        d /= 3.1415926535897931;
        bias /= 3.1415926535897931;
      }
      if (bias == 0.0) {
        d /= static_cast<double>(c_loop_ub) + 1.0;
      } else if (d == 0.0) {
        d = 0.0;
      } else {
        d /= static_cast<double>(c_loop_ub) + 1.0;
      }
      fqv[c_loop_ub + fqv.size(0) * i] = d;
    }
    //  29/July/199
  }
  // if imgi==1; waitbar(1); end;%10/Aug./2005
  crf0.set_size(trueCount, f0raw.size(1));
  loop_ub_tmp = vvv.size(0) * vvv.size(1);
  for (i = 0; i < loop_ub_tmp; i++) {
    crf0[i] = vvv[i];
  }
  nx = (loop_ub_tmp / 2) << 1;
  c_loop_ub = nx - 2;
  for (k = 0; k <= c_loop_ub; k += 2) {
    r = _mm_loadu_pd(&crf0[k]);
    _mm_storeu_pd(&crf0[k], _mm_sqrt_pd(r));
  }
  for (k = nx; k < loop_ub_tmp; k++) {
    crf0[k] = std::sqrt(crf0[k]);
  }
  if ((fqv.size(0) == crf0.size(0)) && (fqv.size(1) == crf0.size(1))) {
    b_fax.set_size(trueCount, f0raw.size(1));
    for (i = 0; i <= c_loop_ub; i += 2) {
      r = _mm_loadu_pd(&fqv[i]);
      r3 = _mm_loadu_pd(&crf0[i]);
      _mm_storeu_pd(&b_fax[i], _mm_div_pd(r, r3));
    }
    for (i = nx; i < loop_ub_tmp; i++) {
      b_fax[i] = fqv[i] / crf0[i];
    }
    legacy_STRAIGHT::sum(b_fax, r2);
  } else {
    binary_expand_op_63(r2, fqv, crf0);
  }
  b_fax.set_size(crf0.size(0), crf0.size(1));
  loop_ub = crf0.size(0) * crf0.size(1);
  b_i = (loop_ub / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&crf0[i]);
    _mm_storeu_pd(&b_fax[i], _mm_div_pd(_mm_set1_pd(1.0), r));
  }
  for (i = b_i; i < loop_ub; i++) {
    b_fax[i] = 1.0 / crf0[i];
  }
  legacy_STRAIGHT::sum(b_fax, tt);
  if (r2.size(1) == 1) {
    i = tt.size(1);
  } else {
    i = r2.size(1);
  }
  if ((r2.size(1) == tt.size(1)) && (i == f0raw.size(1))) {
    loop_ub = r2.size(1);
    f0r.set_size(1, r2.size(1));
    for (i = 0; i < loop_ub; i++) {
      f0r[i] = r2[i] / tt[i] * static_cast<double>(f0raw[i] > 0.0);
    }
  } else {
    binary_expand_op_62(f0r, r2, tt, f0raw);
  }
  b_fax.set_size(trueCount, f0raw.size(1));
  for (i = 0; i <= c_loop_ub; i += 2) {
    r = _mm_loadu_pd(&vvv[i]);
    _mm_storeu_pd(&b_fax[i], _mm_div_pd(_mm_set1_pd(1.0), r));
  }
  for (i = nx; i < loop_ub_tmp; i++) {
    b_fax[i] = 1.0 / vvv[i];
  }
  legacy_STRAIGHT::sum(b_fax, b_x);
  b_x.set_size(1, b_x.size(1));
  loop_ub = b_x.size(1) - 1;
  b_i = (b_x.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&b_x[i]);
    r3 = _mm_set1_pd(1.0);
    _mm_storeu_pd(&b_x[i], _mm_div_pd(r3, _mm_div_pd(r3, r)));
  }
  for (i = b_i; i <= loop_ub; i++) {
    b_x[i] = 1.0 / (1.0 / b_x[i]);
  }
  nx = b_x.size(1);
  b_i = (b_x.size(1) / 2) << 1;
  vectorUB = b_i - 2;
  for (k = 0; k <= vectorUB; k += 2) {
    r = _mm_loadu_pd(&b_x[k]);
    _mm_storeu_pd(&b_x[k], _mm_sqrt_pd(r));
  }
  for (k = b_i; k < nx; k++) {
    b_x[k] = std::sqrt(b_x[k]);
  }
  if (b_x.size(1) == 1) {
    i = f0raw.size(1);
  } else {
    i = b_x.size(1);
  }
  if ((b_x.size(1) == f0raw.size(1)) && (i == f0raw.size(1))) {
    loop_ub = b_x.size(1);
    ecr.set_size(1, b_x.size(1));
    for (i = 0; i < loop_ub; i++) {
      d = f0raw[i];
      ecr[i] =
          b_x[i] * static_cast<double>(d > 0.0) + static_cast<double>(d <= 0.0);
    }
  } else {
    binary_expand_op_61(ecr, b_x, f0raw);
  }
}

// End of code generation (refineF06.cpp)
