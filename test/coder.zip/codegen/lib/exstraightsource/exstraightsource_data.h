//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource_data.h
//
// Code generation for function 'exstraightsource_data'
//

#ifndef EXSTRAIGHTSOURCE_DATA_H
#define EXSTRAIGHTSOURCE_DATA_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern unsigned int state[625];
extern omp_nest_lock_t exstraightsource_nestLockGlobal;
extern boolean_T isInitialized_exstraightsource;

#endif
// End of code generation (exstraightsource_data.h)
