//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// find.h
//
// Code generation for function 'find'
//

#ifndef FIND_H
#define FIND_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void eml_find(const creal_T x_data[], const int x_size[2], int i_data[],
              int i_size[2]);

void eml_find(const double x_data[], const int x_size[2], int i_data[],
              int i_size[2]);

} // namespace legacy_STRAIGHT

#endif
// End of code generation (find.h)
