//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource_terminate.cpp
//
// Code generation for function 'exstraightsource_terminate'
//

// Include files
#include "exstraightsource_terminate.h"
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"
#include "omp.h"

// Function Definitions
void exstraightsource_terminate()
{
  omp_destroy_nest_lock(&exstraightsource_nestLockGlobal);
  isInitialized_exstraightsource = false;
}

// End of code generation (exstraightsource_terminate.cpp)
