//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// boundmes2.cpp
//
// Code generation for function 'boundmes2'
//

// Include files
#include "boundmes2.h"
#include "blockedSummation.h"
#include "combineVectorElements.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <emmintrin.h>

// Function Definitions
void binary_expand_op_1(coder::array<double, 2U> &in1, int in2,
                        const coder::array<double, 2U> &in3, double in4,
                        const coder::array<double, 2U> &in5,
                        const coder::array<double, 2U> &in6,
                        const coder::array<double, 2U> &in7,
                        const coder::array<double, 1U> &in8)
{
  coder::array<double, 2U> b_in3;
  int loop_ub;
  int stride_0_1_tmp;
  int stride_1_1;
  int stride_3_1;
  if (in7.size(1) == 1) {
    if (static_cast<int>(in4) - 1 == 1) {
      if (in5.size(1) == 1) {
        loop_ub = static_cast<int>(in4) - 1;
      } else {
        loop_ub = in5.size(1);
      }
    } else {
      loop_ub = static_cast<int>(in4) - 1;
    }
  } else {
    loop_ub = in7.size(1);
  }
  b_in3.set_size(1, loop_ub);
  stride_0_1_tmp = (static_cast<int>(in4) - 1 != 1);
  stride_1_1 = (in5.size(1) != 1);
  stride_3_1 = (in7.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    int in3_tmp;
    in3_tmp = i * stride_0_1_tmp + 1;
    b_in3[i] = (in3[in3_tmp + in3.size(0) * in2] - in5[i * stride_1_1]) *
               in6[in3_tmp + in6.size(0) * in2] / in7[i * stride_3_1];
  }
  in1[in2] = legacy_STRAIGHT::combineVectorElements(b_in3) /
             legacy_STRAIGHT::blockedSummation(in8, in8.size(0));
}

void binary_expand_op_4(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2,
                        const coder::array<double, 2U> &in3)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  loop_ub = in2.size(0);
  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    int scalarLB;
    int vectorUB;
    scalarLB = (loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      __m128d r;
      __m128d r1;
      r = _mm_loadu_pd(&in2[i1 + in2.size(0) * aux_0_1]);
      r1 = _mm_loadu_pd(&in3[i1 + in3.size(0) * aux_1_1]);
      _mm_storeu_pd(&in1[i1 + in1.size(0) * i],
                    _mm_div_pd(_mm_sub_pd(r, r1), _mm_set1_pd(20.0)));
    }
    for (int i1{scalarLB}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] =
          (in2[i1 + in2.size(0) * aux_0_1] - in3[i1 + in3.size(0) * aux_1_1]) /
          20.0;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

// End of code generation (boundmes2.cpp)
