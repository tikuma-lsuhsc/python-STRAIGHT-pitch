//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// div.cpp
//
// Code generation for function 'div'
//

// Include files
#include "div.h"
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
void binary_expand_op_17(coder::array<creal_T, 2U> &in1,
                         const creal_T in2_data[], const int in2_size[2],
                         const creal_T in3_data[], const int in3_size[2])
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1.set_size(1, in1.size(1));
  if (in3_size[1] == 1) {
    loop_ub = in2_size[1];
  } else {
    loop_ub = in3_size[1];
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2_size[1] != 1);
  stride_1_1 = (in3_size[1] != 1);
  for (int i{0}; i < loop_ub; i++) {
    double ai;
    double ar;
    double bi;
    double br;
    double im;
    double re;
    int ar_tmp;
    ar_tmp = i * stride_0_1;
    ar = in2_data[ar_tmp].re;
    ai = in2_data[ar_tmp].im;
    ar_tmp = i * stride_1_1;
    br = in3_data[ar_tmp].re;
    bi = in3_data[ar_tmp].im;
    if (bi == 0.0) {
      if (ai == 0.0) {
        re = ar / br;
        im = 0.0;
      } else if (ar == 0.0) {
        re = 0.0;
        im = ai / br;
      } else {
        re = ar / br;
        im = ai / br;
      }
    } else if (br == 0.0) {
      if (ar == 0.0) {
        re = ai / bi;
        im = 0.0;
      } else if (ai == 0.0) {
        re = 0.0;
        im = -(ar / bi);
      } else {
        re = ai / bi;
        im = -(ar / bi);
      }
    } else {
      double brm;
      brm = std::abs(br);
      im = std::abs(bi);
      if (brm > im) {
        double s;
        s = bi / br;
        im = br + s * bi;
        re = (ar + s * ai) / im;
        im = (ai - s * ar) / im;
      } else if (im == brm) {
        double s;
        if (br > 0.0) {
          s = 0.5;
        } else {
          s = -0.5;
        }
        if (bi > 0.0) {
          im = 0.5;
        } else {
          im = -0.5;
        }
        re = (ar * s + ai * im) / brm;
        im = (ai * s - ar * im) / brm;
      } else {
        double s;
        s = br / bi;
        im = bi + s * br;
        re = (s * ar + ai) / im;
        im = (s * ai - ar) / im;
      }
    }
    in1[i].re = re;
    in1[i].im = im;
  }
}

void binary_expand_op_2(coder::array<double, 1U> &in1,
                        const coder::array<double, 2U> &in2, double in3,
                        int in4, const coder::array<double, 2U> &in5)
{
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in5.size(1) == 1) {
    loop_ub = static_cast<int>(in3) - 1;
  } else {
    loop_ub = in5.size(1);
  }
  in1.set_size(loop_ub);
  stride_0_0 = (static_cast<int>(in3) - 1 != 1);
  stride_1_0 = (in5.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] =
        in2[(i * stride_0_0 + in2.size(0) * in4) + 1] / in5[i * stride_1_0];
  }
}

void binary_expand_op_31(coder::array<creal_T, 2U> &in1,
                         const coder::array<double, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double ai;
      double ar;
      double br;
      int ar_tmp;
      ar_tmp = i1 * stride_0_0;
      ar = in1[ar_tmp + in1.size(0) * aux_0_1].re;
      ai = in1[ar_tmp + in1.size(0) * aux_0_1].im;
      br = in2[i1 * stride_1_0 + in2.size(0) * aux_1_1];
      if (ai == 0.0) {
        b_in1[i1 + b_in1.size(0) * i].re = ar / br;
        b_in1[i1 + b_in1.size(0) * i].im = 0.0;
      } else if (ar == 0.0) {
        b_in1[i1 + b_in1.size(0) * i].re = 0.0;
        b_in1[i1 + b_in1.size(0) * i].im = ai / br;
      } else {
        b_in1[i1 + b_in1.size(0) * i].re = ar / br;
        b_in1[i1 + b_in1.size(0) * i].im = ai / br;
      }
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

void binary_expand_op_9(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2)
{
  coder::array<double, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] /
          in1[i1 * stride_1_0 + in1.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

void rdivide(coder::array<creal_T, 2U> &in1,
             const coder::array<creal_T, 2U> &in2,
             const coder::array<creal_T, 2U> &in3)
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1.set_size(1, in1.size(1));
  if (in3.size(1) == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    double ai;
    double ar;
    double bi;
    double br;
    double im;
    double re;
    int ar_tmp;
    ar_tmp = i * stride_0_1;
    ar = in2[ar_tmp].re;
    ai = in2[ar_tmp].im;
    ar_tmp = i * stride_1_1;
    br = in3[ar_tmp].re;
    bi = in3[ar_tmp].im;
    if (bi == 0.0) {
      if (ai == 0.0) {
        re = ar / br;
        im = 0.0;
      } else if (ar == 0.0) {
        re = 0.0;
        im = ai / br;
      } else {
        re = ar / br;
        im = ai / br;
      }
    } else if (br == 0.0) {
      if (ar == 0.0) {
        re = ai / bi;
        im = 0.0;
      } else if (ai == 0.0) {
        re = 0.0;
        im = -(ar / bi);
      } else {
        re = ai / bi;
        im = -(ar / bi);
      }
    } else {
      double brm;
      brm = std::abs(br);
      im = std::abs(bi);
      if (brm > im) {
        double s;
        s = bi / br;
        im = br + s * bi;
        re = (ar + s * ai) / im;
        im = (ai - s * ar) / im;
      } else if (im == brm) {
        double s;
        if (br > 0.0) {
          s = 0.5;
        } else {
          s = -0.5;
        }
        if (bi > 0.0) {
          im = 0.5;
        } else {
          im = -0.5;
        }
        re = (ar * s + ai * im) / brm;
        im = (ai * s - ar * im) / brm;
      } else {
        double s;
        s = br / bi;
        im = bi + s * br;
        re = (s * ar + ai) / im;
        im = (s * ai - ar) / im;
      }
    }
    in1[i].re = re;
    in1[i].im = im;
  }
}

void rdivide(coder::array<creal_T, 2U> &in1,
             const coder::array<creal_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double ai;
      double ar;
      double bi;
      double br;
      int ar_tmp;
      ar_tmp = i1 * stride_0_0;
      ar = in1[ar_tmp + in1.size(0) * aux_0_1].re;
      ai = in1[ar_tmp + in1.size(0) * aux_0_1].im;
      ar_tmp = i1 * stride_1_0;
      br = in2[ar_tmp + in2.size(0) * aux_1_1].re;
      bi = in2[ar_tmp + in2.size(0) * aux_1_1].im;
      if (bi == 0.0) {
        if (ai == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = ar / br;
          b_in1[i1 + b_in1.size(0) * i].im = 0.0;
        } else if (ar == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = 0.0;
          b_in1[i1 + b_in1.size(0) * i].im = ai / br;
        } else {
          b_in1[i1 + b_in1.size(0) * i].re = ar / br;
          b_in1[i1 + b_in1.size(0) * i].im = ai / br;
        }
      } else if (br == 0.0) {
        if (ar == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = ai / bi;
          b_in1[i1 + b_in1.size(0) * i].im = 0.0;
        } else if (ai == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = 0.0;
          b_in1[i1 + b_in1.size(0) * i].im = -(ar / bi);
        } else {
          b_in1[i1 + b_in1.size(0) * i].re = ai / bi;
          b_in1[i1 + b_in1.size(0) * i].im = -(ar / bi);
        }
      } else {
        double bim;
        double brm;
        brm = std::abs(br);
        bim = std::abs(bi);
        if (brm > bim) {
          double s;
          s = bi / br;
          bim = br + s * bi;
          b_in1[i1 + b_in1.size(0) * i].re = (ar + s * ai) / bim;
          b_in1[i1 + b_in1.size(0) * i].im = (ai - s * ar) / bim;
        } else if (bim == brm) {
          double s;
          if (br > 0.0) {
            s = 0.5;
          } else {
            s = -0.5;
          }
          if (bi > 0.0) {
            bim = 0.5;
          } else {
            bim = -0.5;
          }
          b_in1[i1 + b_in1.size(0) * i].re = (ar * s + ai * bim) / brm;
          b_in1[i1 + b_in1.size(0) * i].im = (ai * s - ar * bim) / brm;
        } else {
          double s;
          s = br / bi;
          bim = bi + s * br;
          b_in1[i1 + b_in1.size(0) * i].re = (s * ar + ai) / bim;
          b_in1[i1 + b_in1.size(0) * i].im = (s * ai - ar) / bim;
        }
      }
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

// End of code generation (div.cpp)
