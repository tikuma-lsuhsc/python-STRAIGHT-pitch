//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sum.h
//
// Code generation for function 'sum'
//

#ifndef SUM_H
#define SUM_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void sum(const ::coder::array<double, 2U> &x, ::coder::array<double, 2U> &y);

creal_T sum(const ::coder::array<creal_T, 1U> &x);

} // namespace legacy_STRAIGHT

#endif
// End of code generation (sum.h)
