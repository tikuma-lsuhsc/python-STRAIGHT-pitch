//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// conv.cpp
//
// Code generation for function 'conv'
//

// Include files
#include "conv.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <emmintrin.h>

// Function Definitions
namespace legacy_STRAIGHT {
void conv(const ::coder::array<double, 2U> &A,
          const ::coder::array<double, 2U> &B, ::coder::array<double, 2U> &C)
{
  int i;
  int nA;
  int nApnB;
  int nB;
  nA = A.size(1) - 1;
  nB = B.size(1) - 1;
  nApnB = A.size(1) + B.size(1);
  if ((A.size(1) != 0) && (B.size(1) != 0)) {
    nApnB--;
  }
  C.set_size(1, nApnB);
  for (i = 0; i < nApnB; i++) {
    C[i] = 0.0;
  }
  if ((A.size(1) > 0) && (B.size(1) > 0)) {
    if (B.size(1) > A.size(1)) {
      int scalarLB;
      int vectorUB;
      scalarLB = ((nB + 1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (int k{0}; k <= nA; k++) {
        for (int b_k{0}; b_k <= vectorUB; b_k += 2) {
          __m128d r;
          i = k + b_k;
          r = _mm_loadu_pd(&C[i]);
          _mm_storeu_pd(&C[i],
                        _mm_add_pd(r, _mm_mul_pd(_mm_set1_pd(A[k]),
                                                 _mm_loadu_pd(&B[b_k]))));
        }
        for (int b_k{scalarLB}; b_k <= nB; b_k++) {
          nApnB = k + b_k;
          C[nApnB] = C[nApnB] + A[k] * B[b_k];
        }
      }
    } else {
      int scalarLB;
      int vectorUB;
      scalarLB = ((nA + 1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (int k{0}; k <= nB; k++) {
        for (int b_k{0}; b_k <= vectorUB; b_k += 2) {
          __m128d r;
          i = k + b_k;
          r = _mm_loadu_pd(&C[i]);
          _mm_storeu_pd(&C[i],
                        _mm_add_pd(r, _mm_mul_pd(_mm_set1_pd(B[k]),
                                                 _mm_loadu_pd(&A[b_k]))));
        }
        for (int b_k{scalarLB}; b_k <= nA; b_k++) {
          nApnB = k + b_k;
          C[nApnB] = C[nApnB] + B[k] * A[b_k];
        }
      }
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (conv.cpp)
