//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource_types.h
//
// Code generation for function 'exstraightsource'
//

#ifndef EXSTRAIGHTSOURCE_TYPES_H
#define EXSTRAIGHTSOURCE_TYPES_H

// Include files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

// Type Definitions
struct struct0_T {
  double F0searchLowerBound;
  double F0searchUpperBound;
  double F0defaultWindowLength;
  double F0frameUpdateInterval;
  double NofChannelsInOctave;
  double IFWindowStretch;
  double DisplayPlots;
  double IFsmoothingLengthRelToFc;
  double IFminimumSmoothingLength;
  double IFexponentForNonlinearSum;
  double IFnumberOfHarmonicForInitialEstimate;
  double refineFftLength;
  double refineTimeStretchingFactor;
  double refineNumberofHarmonicComponent;
  double periodicityFrameUpdateInterval;
  char note;
};

#endif
// End of code generation (exstraightsource_types.h)
