//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// aperiodicpartERB2.cpp
//
// Code generation for function 'aperiodicpartERB2'
//

// Include files
#include "aperiodicpartERB2.h"
#include "blockedSummation.h"
#include "cat.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "diff.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "fft.h"
#include "fftfilt.h"
#include "hanning.h"
#include "ifft.h"
#include "interp1.h"
#include "log2.h"
#include "minOrMax.h"
#include "mrdivide_helper.h"
#include "randn.h"
#include "rt_nonfinite.h"
#include "sum.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>
#include <emmintrin.h>

// Function Declarations
static void binary_expand_op_77(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 1U> &in3);

static void binary_expand_op_78(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3,
                                const coder::array<double, 2U> &in4);

static void binary_expand_op_79(coder::array<double, 1U> &in1,
                                const coder::array<double, 1U> &in2,
                                double in3);

// Function Definitions
static void binary_expand_op_77(coder::array<creal_T, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 1U> &in3)
{
  coder::array<double, 2U> b_in2;
  int b_loop_ub;
  int in3_idx_0;
  int loop_ub;
  int stride_0_0;
  in3_idx_0 = in3.size(0);
  if (in3_idx_0 == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3_idx_0;
  }
  b_loop_ub = in2.size(1);
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  in3_idx_0 = (in3_idx_0 != 1);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          in2[i1 * stride_0_0 + in2.size(0) * i] * in3[i1 * in3_idx_0];
    }
  }
  legacy_STRAIGHT::ifft(b_in2, in1);
}

static void binary_expand_op_78(coder::array<double, 2U> &in1,
                                const coder::array<double, 2U> &in2,
                                const coder::array<double, 2U> &in3,
                                const coder::array<double, 2U> &in4)
{
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  int stride_2_1;
  loop_ub = in2.size(0);
  in1.set_size(loop_ub, in1.size(1));
  if (in4.size(1) == 1) {
    if (in3.size(1) == 1) {
      b_loop_ub = in2.size(1);
    } else {
      b_loop_ub = in3.size(1);
    }
  } else {
    b_loop_ub = in4.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  stride_2_1 = (in4.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    int scalarLB;
    int vectorUB;
    scalarLB = (loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i1{0}; i1 <= vectorUB; i1 += 2) {
      __m128d r;
      r = _mm_loadu_pd(&in2[i1 + in2.size(0) * aux_0_1]);
      _mm_storeu_pd(
          &in1[i1 + in1.size(0) * i],
          _mm_div_pd(
              _mm_add_pd(
                  _mm_add_pd(
                      _mm_mul_pd(r, _mm_set1_pd(2.0)),
                      _mm_set1_pd(in2[static_cast<int>(in3[aux_1_1]) - 1])),
                  _mm_set1_pd(in2[static_cast<int>(in4[aux_2_1]) - 1])),
              _mm_set1_pd(4.0)));
    }
    for (int i1{scalarLB}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = ((in2[i1 + in2.size(0) * aux_0_1] * 2.0 +
                                    in2[static_cast<int>(in3[aux_1_1]) - 1]) +
                                   in2[static_cast<int>(in4[aux_2_1]) - 1]) /
                                  4.0;
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op_79(coder::array<double, 1U> &in1,
                                const coder::array<double, 1U> &in2, double in3)
{
  coder::array<double, 1U> b_in1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in2.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in1[i] = in1[i * stride_0_0] + in2[i * stride_1_0] * in3 / 100000.0;
  }
  in1.set_size(loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

void aperiodicpartERB2(const coder::array<double, 1U> &x, double fs,
                       coder::array<double, 2U> &f0, double shiftm,
                       double intshiftm, double mm,
                       coder::array<double, 2U> &apv,
                       coder::array<double, 2U> &dpv,
                       coder::array<double, 2U> &apve,
                       coder::array<double, 2U> &dpve)
{
  static creal_T c_tmp_data[3076];
  __m128d r1;
  __m128d r2;
  coder::array<creal_T, 2U> r3;
  coder::array<creal_T, 2U> wcc;
  coder::array<creal_T, 2U> ww;
  coder::array<creal_T, 1U> b_wcc;
  coder::array<double, 2U> b_f0;
  coder::array<double, 2U> b_sw;
  coder::array<double, 2U> bb;
  coder::array<double, 2U> c_x;
  coder::array<double, 2U> f0ii;
  coder::array<double, 2U> ffb;
  coder::array<double, 2U> fff;
  coder::array<double, 2U> fxa;
  coder::array<double, 2U> phc;
  coder::array<double, 2U> phri;
  coder::array<double, 2U> sw;
  coder::array<double, 2U> ti;
  coder::array<double, 2U> tidx;
  coder::array<double, 2U> w;
  coder::array<double, 2U> xi;
  coder::array<double, 2U> y;
  coder::array<double, 1U> b_x;
  coder::array<double, 1U> fxfi;
  coder::array<double, 1U> phr;
  coder::array<double, 1U> we;
  coder::array<double, 1U> xii;
  coder::array<int, 2U> r;
  creal_T ex;
  double dpefs_data[3076];
  double ape[1025];
  double dpe[1025];
  double evv[1025];
  double hvv[1025];
  double dlits[2];
  double plits[2];
  double avf0;
  double b;
  double b_phr;
  double b_tmp;
  double brm;
  double c_y;
  double fftl;
  double lh;
  int dpefs_size[2];
  int b_i;
  int b_loop_ub;
  int c_loop_ub;
  int d_loop_ub;
  int e_loop_ub;
  int f_loop_ub;
  int g_loop_ub;
  int h_loop_ub;
  int i;
  int i1;
  int i10;
  int i11;
  int i12;
  int i13;
  int i14;
  int i2;
  int i3;
  int i4;
  int i5;
  int i6;
  int i7;
  int i8;
  int i9;
  int i_loop_ub;
  int j_loop_ub;
  int k_loop_ub;
  int l_loop_ub;
  int loop_ub;
  int loop_ub_tmp;
  int m_loop_ub;
  int n_loop_ub;
  int nx;
  int nx_tmp;
  int partialTrueCount;
  int scalarLB;
  int scalarLB_tmp;
  int trueCount;
  int vectorUB;
  int vectorUB_tmp;
  signed char b_tmp_data[2];
  signed char tmp_data[2];
  boolean_T guard1;
  // 	Relative aperiodic energy estimation with ERB smoothing
  // 		[apv,dpv,apve,dpve]=aperiodicpartERB2(x,fs,f0,shiftm,intshiftm,mm,imgi)
  // 		x	: input speech
  // 		fs	: sampling frequency (Hz)
  // 		f0	: fundamental frequency (Hz)
  // 		shiftm	: frame shift (ms) for input F0 data
  // 		intshiftm 	: frame shift (ms) for internal processing
  // 		mm	: length of frequency axis (usually 2^N+1)
  // 		imgi	: display indicator, 1: display on (default) 0: off
  // 	19/August/1999
  // 	21/August/1999
  // 	30/May/2001
  // 	10/April/2002 completely rewrote
  //    07/Dec./2002 waitbar was added
  //    13/Jan./2005 bug fix
  //    08/April/2005 safe guard
  // 	10/Aug./2005 modified by Takahashi on wait bar
  // 	10/Sept./2005 modified by Kawahara on wait bar
  //    16/Sept./2005 minor bug fix
  //  10/Sept./2005
  // if imgi==1; hpg=waitbar(0,'ERB-based multiband periodicity calculation');
  // end;
  nx = f0.size(1) - 1;
  trueCount = 0;
  for (i = 0; i <= nx; i++) {
    if (std::isnan(f0[i])) {
      trueCount++;
    }
  }
  plits[0] = 1.0;
  plits[1] = trueCount;
  for (i = 0; i <= nx; i++) {
    if (std::isnan(f0[i])) {
      f0[i] = 0.0;
    }
  }
  //  safe guard
  //  safe guard 16/Sept./2005
  fftl = rt_powd_snf(2.0,
                     std::ceil(legacy_STRAIGHT::b_log2(6.7 * fs / 40.0) + 1.0));
  //  FFT size selection to be scalable
  trueCount = 0;
  for (i = 0; i <= nx; i++) {
    if (f0[i] > 0.0) {
      trueCount++;
    }
  }
  r.set_size(1, trueCount);
  partialTrueCount = 0;
  for (i = 0; i <= nx; i++) {
    if (f0[i] > 0.0) {
      r[partialTrueCount] = i;
      partialTrueCount++;
    }
  }
  if (r.size(1) != 0) {
    loop_ub = r.size(1);
    b_f0.set_size(1, r.size(1));
    for (b_i = 0; b_i < loop_ub; b_i++) {
      b_f0[b_i] = f0[r[b_i]];
    }
    avf0 = legacy_STRAIGHT::combineVectorElements(b_f0) /
           static_cast<double>(r.size(1));
  } else {
    avf0 = 180.0;
  }
  //  08/April/2005
  // f0bk=f0;
  for (i = 0; i <= nx; i++) {
    brm = f0[i];
    if (brm == 0.0) {
      brm += avf0;
      f0[i] = brm;
    }
  }
  for (i = 0; i <= nx; i++) {
    brm = f0[i];
    if (brm < 40.0) {
      brm = brm * 0.0 + 40.0;
      f0[i] = brm;
    }
  }
  //  safe guard 16/Sept./2005
  b = shiftm / 1000.0;
  if (x.size(0) - 1 < 0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, x.size(0));
    loop_ub = x.size(0) - 1;
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      y[b_i] = b_i;
    }
  }
  loop_ub = f0.size(1);
  phr.set_size(f0.size(1));
  scalarLB = (f0.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&f0[b_i]);
    _mm_storeu_pd(
        &phr[b_i],
        _mm_div_pd(_mm_mul_pd(_mm_mul_pd(_mm_set1_pd(6.2831853071795862), r1),
                              _mm_set1_pd(shiftm)),
                   _mm_set1_pd(1000.0)));
  }
  for (b_i = scalarLB; b_i < loop_ub; b_i++) {
    phr[b_i] = 6.2831853071795862 * f0[b_i] * shiftm / 1000.0;
  }
  if ((phr.size(0) != 1) && (phr.size(0) != 0) && (phr.size(0) != 1)) {
    b_i = phr.size(0);
    for (scalarLB = 0; scalarLB <= b_i - 2; scalarLB++) {
      phr[scalarLB + 1] = phr[scalarLB] + phr[scalarLB + 1];
    }
  }
  if (phr.size(0) - 1 < 0) {
    w.set_size(1, 0);
  } else {
    w.set_size(1, phr.size(0));
    b_loop_ub = phr.size(0) - 1;
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      w[b_i] = b_i;
    }
  }
  if (x.size(0) - 1 < 0) {
    phc.set_size(1, 0);
  } else {
    phc.set_size(1, x.size(0));
    b_loop_ub = x.size(0) - 1;
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      phc[b_i] = b_i;
    }
  }
  avf0 = static_cast<double>(x.size(0)) - 1.0;
  b_phr = static_cast<double>(phr.size(0)) - 1.0;
  b_loop_ub = phc.size(1);
  b_f0.set_size(1, phc.size(1));
  scalarLB = (phc.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&phc[b_i]);
    _mm_storeu_pd(&b_f0[b_i], _mm_mul_pd(_mm_div_pd(r1, _mm_set1_pd(avf0)),
                                         _mm_set1_pd(b_phr)));
  }
  for (b_i = scalarLB; b_i < b_loop_ub; b_i++) {
    b_f0[b_i] = phc[b_i] / avf0 * b_phr;
  }
  legacy_STRAIGHT::interp1(w, phr, b_f0, phri);
  // if imgi==1; waitbar(0.05); end; % 08/Dec./2002%10/Aug./2005
  b_phr = 251.32741228718345 / fs;
  guard1 = false;
  if (std::isnan(phr[0]) || std::isnan(b_phr)) {
    guard1 = true;
  } else {
    brm = phr[phr.size(0) - 1];
    if (std::isnan(brm)) {
      guard1 = true;
    } else if ((b_phr == 0.0) || ((phr[0] < brm) && (b_phr < 0.0)) ||
               ((brm < phr[0]) && (b_phr > 0.0))) {
      phc.set_size(1, 0);
    } else if ((std::isinf(phr[0]) || std::isinf(brm)) &&
               (std::isinf(b_phr) || (phr[0] == brm))) {
      phc.set_size(1, 1);
      phc[0] = rtNaN;
    } else if (std::isinf(b_phr)) {
      phc.set_size(1, 1);
      phc[0] = phr[0];
    } else if ((std::floor(phr[0]) == phr[0]) && (std::floor(b_phr) == b_phr)) {
      b_loop_ub = static_cast<int>((brm - phr[0]) / b_phr);
      phc.set_size(1, b_loop_ub + 1);
      for (b_i = 0; b_i <= b_loop_ub; b_i++) {
        phc[b_i] = phr[0] + b_phr * static_cast<double>(b_i);
      }
    } else {
      legacy_STRAIGHT::eml_float_colon(phr[0], b_phr, brm, phc);
    }
  }
  if (guard1) {
    phc.set_size(1, 1);
    phc[0] = rtNaN;
  }
  legacy_STRAIGHT::interp1(phri, x, phc, xi);
  ti.set_size(1, f0.size(1) + 3);
  loop_ub_tmp = f0.size(1) + 2;
  for (b_i = 0; b_i <= loop_ub_tmp; b_i++) {
    ti[b_i] = static_cast<double>(b_i) * b;
  }
  phr.set_size(f0.size(1) + 3);
  for (b_i = 0; b_i < loop_ub; b_i++) {
    phr[b_i] = f0[b_i];
  }
  avf0 = f0[f0.size(1) - 1];
  phr[f0.size(1)] = avf0;
  phr[f0.size(1) + 1] = avf0;
  phr[f0.size(1) + 2] = avf0;
  loop_ub = y.size(1);
  b_f0.set_size(1, y.size(1));
  scalarLB = (y.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&y[b_i]);
    _mm_storeu_pd(&b_f0[b_i], _mm_div_pd(r1, _mm_set1_pd(fs)));
  }
  for (b_i = scalarLB; b_i < loop_ub; b_i++) {
    b_f0[b_i] = y[b_i] / fs;
  }
  legacy_STRAIGHT::interp1(ti, phr, b_f0, y);
  legacy_STRAIGHT::interp1(phri, y, phc, f0ii);
  if (x.size(0) - 1 < 0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, x.size(0));
    loop_ub = x.size(0) - 1;
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      y[b_i] = b_i;
    }
  }
  loop_ub = y.size(1);
  b_f0.set_size(1, y.size(1));
  scalarLB = (y.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&y[b_i]);
    _mm_storeu_pd(&b_f0[b_i], _mm_div_pd(r1, _mm_set1_pd(fs)));
  }
  for (b_i = scalarLB; b_i < loop_ub; b_i++) {
    b_f0[b_i] = y[b_i] / fs;
  }
  legacy_STRAIGHT::interp1(phri, b_f0, phc, ti);
  // if imgi==1; waitbar(0.1); end; % 08/Dec./2002 %10/Aug./2005
  if (ti.size(1) - 1 < 0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, ti.size(1));
    loop_ub = ti.size(1) - 1;
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      y[b_i] = b_i;
    }
  }
  b_phr = intshiftm / 1000.0;
  guard1 = false;
  if (std::isnan(b_phr)) {
    guard1 = true;
  } else {
    brm = ti[ti.size(1) - 1];
    if (std::isnan(brm)) {
      guard1 = true;
    } else if ((b_phr == 0.0) || ((brm > 0.0) && (b_phr < 0.0)) ||
               ((brm < 0.0) && (b_phr > 0.0))) {
      w.set_size(1, 0);
    } else if (std::isinf(brm) && std::isinf(b_phr)) {
      w.set_size(1, 1);
      w[0] = rtNaN;
    } else if (std::isinf(b_phr)) {
      w.set_size(1, 1);
      w[0] = 0.0;
    } else if (std::floor(b_phr) == b_phr) {
      loop_ub = static_cast<int>(brm / b_phr);
      w.set_size(1, loop_ub + 1);
      for (b_i = 0; b_i <= loop_ub; b_i++) {
        w[b_i] = b_phr * static_cast<double>(b_i);
      }
    } else {
      legacy_STRAIGHT::b_eml_float_colon(b_phr, brm, w);
    }
  }
  if (guard1) {
    w.set_size(1, 1);
    w[0] = rtNaN;
  }
  legacy_STRAIGHT::interp1(ti, y, w, tidx);
  tidx.set_size(1, tidx.size(1));
  loop_ub = tidx.size(1) - 1;
  scalarLB = (tidx.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&tidx[b_i]);
    _mm_storeu_pd(&tidx[b_i], _mm_add_pd(r1, _mm_set1_pd(1.0)));
  }
  for (b_i = scalarLB; b_i <= loop_ub; b_i++) {
    tidx[b_i] = tidx[b_i] + 1.0;
  }
  if (std::isnan(mm - 1.0)) {
    fxa.set_size(1, 1);
    fxa[0] = rtNaN;
  } else if (mm - 1.0 < 0.0) {
    fxa.set_size(fxa.size(0), 0);
  } else {
    fxa.set_size(1, static_cast<int>(mm - 1.0) + 1);
    loop_ub = static_cast<int>(mm - 1.0);
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      fxa[b_i] = b_i;
    }
  }
  fxa.set_size(1, fxa.size(1));
  loop_ub = fxa.size(1) - 1;
  scalarLB = (fxa.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&fxa[b_i]);
    _mm_storeu_pd(&fxa[b_i],
                  _mm_div_pd(_mm_mul_pd(_mm_div_pd(r1, _mm_set1_pd(mm - 1.0)),
                                        _mm_set1_pd(fs)),
                             _mm_set1_pd(2.0)));
  }
  for (b_i = scalarLB; b_i <= loop_ub; b_i++) {
    fxa[b_i] = fxa[b_i] / (mm - 1.0) * fs / 2.0;
  }
  b_tmp = fftl / 2.0;
  if (std::isnan(b_tmp)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else {
    y.set_size(1, static_cast<int>(b_tmp) + 1);
    loop_ub = static_cast<int>(b_tmp);
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      y[b_i] = b_i;
    }
  }
  loop_ub = y.size(1);
  fxfi.set_size(y.size(1));
  scalarLB = (y.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&y[b_i]);
    _mm_storeu_pd(&fxfi[b_i], _mm_mul_pd(_mm_div_pd(r1, _mm_set1_pd(fftl)),
                                         _mm_set1_pd(fs)));
  }
  for (b_i = scalarLB; b_i < loop_ub; b_i++) {
    fxfi[b_i] = y[b_i] / fftl * fs;
  }
  loop_ub = (static_cast<int>(fftl) + xi.size(1)) + static_cast<int>(fftl);
  xii.set_size(loop_ub);
  loop_ub_tmp = static_cast<int>(fftl);
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    xii[b_i] = 0.0;
  }
  b_loop_ub = xi.size(1);
  for (b_i = 0; b_i < b_loop_ub; b_i++) {
    xii[b_i + static_cast<int>(fftl)] = xi[b_i];
  }
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    xii[(b_i + static_cast<int>(fftl)) + xi.size(1)] = 0.0;
  }
  phr.set_size(loop_ub);
  for (scalarLB = 0; scalarLB < loop_ub; scalarLB++) {
    phr[scalarLB] = std::abs(xii[scalarLB]);
  }
  b = legacy_STRAIGHT::coder::internal::maximum(phr);
  legacy_STRAIGHT::randn(static_cast<double>(xii.size(0)), phr);
  if (xii.size(0) == phr.size(0)) {
    scalarLB = (xii.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (b_i = 0; b_i <= vectorUB; b_i += 2) {
      r1 = _mm_loadu_pd(&phr[b_i]);
      r2 = _mm_loadu_pd(&xii[b_i]);
      _mm_storeu_pd(&xii[b_i],
                    _mm_add_pd(r2, _mm_div_pd(_mm_mul_pd(r1, _mm_set1_pd(b)),
                                              _mm_set1_pd(100000.0))));
    }
    for (b_i = scalarLB; b_i < loop_ub; b_i++) {
      xii[b_i] = xii[b_i] + phr[b_i] * b / 100000.0;
    }
  } else {
    binary_expand_op_79(xii, phr, b);
  }
  //  safeguard
  // ----- window design for 40 Hz ------
  if (fftl < 1.0) {
    bb.set_size(bb.size(0), 0);
  } else {
    bb.set_size(1, static_cast<int>(fftl - 1.0) + 1);
    loop_ub = static_cast<int>(fftl - 1.0);
    for (b_i = 0; b_i <= loop_ub; b_i++) {
      bb[b_i] = static_cast<double>(b_i) + 1.0;
    }
  }
  bb.set_size(1, bb.size(1));
  loop_ub = bb.size(1) - 1;
  scalarLB = (bb.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&bb[b_i]);
    _mm_storeu_pd(&bb[b_i], _mm_sub_pd(r1, _mm_set1_pd(b_tmp)));
  }
  for (b_i = scalarLB; b_i <= loop_ub; b_i++) {
    bb[b_i] = bb[b_i] - b_tmp;
  }
  loop_ub = bb.size(1);
  phc.set_size(1, bb.size(1));
  scalarLB_tmp = (bb.size(1) / 2) << 1;
  vectorUB_tmp = scalarLB_tmp - 2;
  for (b_i = 0; b_i <= vectorUB_tmp; b_i += 2) {
    r1 = _mm_loadu_pd(&bb[b_i]);
    _mm_storeu_pd(&phc[b_i], _mm_mul_pd(_mm_div_pd(r1, _mm_set1_pd(fs)),
                                        _mm_set1_pd(40.0)));
  }
  for (b_i = scalarLB_tmp; b_i < loop_ub; b_i++) {
    phc[b_i] = bb[b_i] / fs * 40.0;
  }
  b_loop_ub = phc.size(1);
  w.set_size(1, phc.size(1));
  for (b_i = 0; b_i < b_loop_ub; b_i++) {
    avf0 = phc[b_i];
    w[b_i] = -3.1415926535897931 * rt_powd_snf(avf0, 2.0);
  }
  for (scalarLB = 0; scalarLB < b_loop_ub; scalarLB++) {
    w[scalarLB] = std::exp(w[scalarLB]);
  }
  //  40/0.2 to 40/2 worked reasonably. But, WATCH fftl !!
  phc.set_size(1, phc.size(1));
  partialTrueCount = phc.size(1) - 1;
  scalarLB = (phc.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&phc[b_i]);
    _mm_storeu_pd(&phc[b_i], _mm_div_pd(r1, _mm_set1_pd(2.0)));
  }
  for (b_i = scalarLB; b_i <= partialTrueCount; b_i++) {
    phc[b_i] = phc[b_i] / 2.0;
  }
  nx_tmp = phc.size(1);
  y.set_size(1, phc.size(1));
  for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
    y[scalarLB] = std::abs(phc[scalarLB]);
  }
  phc.set_size(1, nx_tmp);
  for (b_i = 0; b_i < nx_tmp; b_i++) {
    avf0 = 1.0 - y[b_i];
    phc[b_i] = std::fmax(0.0, avf0);
  }
  nx = phc.size(1) - 1;
  trueCount = 0;
  for (i = 0; i <= nx; i++) {
    if (phc[i] > 0.0) {
      trueCount++;
    }
  }
  partialTrueCount = 0;
  for (i = 0; i <= nx; i++) {
    if (phc[i] > 0.0) {
      phc[partialTrueCount] = phc[i];
      partialTrueCount++;
    }
  }
  phc.set_size(1, trueCount);
  ti.set_size(1, (static_cast<int>(fftl) + w.size(1)) + static_cast<int>(fftl));
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    ti[b_i] = 0.0;
  }
  for (b_i = 0; b_i < b_loop_ub; b_i++) {
    ti[b_i + static_cast<int>(fftl)] = w[b_i];
  }
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    ti[(b_i + static_cast<int>(fftl)) + w.size(1)] = 0.0;
  }
  legacy_STRAIGHT::fftfilt(phc, ti, wcc);
  legacy_STRAIGHT::coder::internal::maximum(wcc, ww);
  legacy_STRAIGHT::coder::internal::mrdiv(wcc, ww, b_wcc);
  nx = legacy_STRAIGHT::coder::internal::maximum(b_wcc, ex);
  ex = b_wcc[0];
  loop_ub_tmp = b_wcc.size(0);
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    b_wcc[b_i].re = b_wcc[b_i].re - ex.re;
    b_wcc[b_i].im = b_wcc[b_i].im - ex.im;
  }
  ex = legacy_STRAIGHT::sum(b_wcc);
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    double ai;
    lh = b_wcc[b_i].re;
    ai = b_wcc[b_i].im;
    if (ex.im == 0.0) {
      if (ai == 0.0) {
        b = lh / ex.re;
        avf0 = 0.0;
      } else if (lh == 0.0) {
        b = 0.0;
        avf0 = ai / ex.re;
      } else {
        b = lh / ex.re;
        avf0 = ai / ex.re;
      }
    } else if (ex.re == 0.0) {
      if (lh == 0.0) {
        b = ai / ex.im;
        avf0 = 0.0;
      } else if (ai == 0.0) {
        b = 0.0;
        avf0 = -(lh / ex.im);
      } else {
        b = ai / ex.im;
        avf0 = -(lh / ex.im);
      }
    } else {
      brm = std::abs(ex.re);
      avf0 = std::abs(ex.im);
      if (brm > avf0) {
        avf0 = ex.im / ex.re;
        b_phr = ex.re + avf0 * ex.im;
        b = (lh + avf0 * ai) / b_phr;
        avf0 = (ai - avf0 * lh) / b_phr;
      } else if (avf0 == brm) {
        if (ex.re > 0.0) {
          avf0 = 0.5;
        } else {
          avf0 = -0.5;
        }
        if (ex.im > 0.0) {
          b_phr = 0.5;
        } else {
          b_phr = -0.5;
        }
        b = (lh * avf0 + ai * b_phr) / brm;
        avf0 = (ai * avf0 - lh * b_phr) / brm;
      } else {
        avf0 = ex.re / ex.im;
        b_phr = ex.im + avf0 * ex.re;
        b = (avf0 * lh + ai) / b_phr;
        avf0 = (avf0 * ai - lh) / b_phr;
      }
    }
    b_wcc[b_i].re = b;
    b_wcc[b_i].im = avf0;
  }
  y.set_size(1, bb.size(1));
  for (b_i = 0; b_i <= vectorUB_tmp; b_i += 2) {
    r1 = _mm_loadu_pd(&bb[b_i]);
    _mm_storeu_pd(&y[b_i],
                  _mm_add_pd(r1, _mm_set1_pd(static_cast<double>(nx))));
  }
  for (b_i = scalarLB_tmp; b_i < loop_ub; b_i++) {
    y[b_i] = bb[b_i] + static_cast<double>(nx);
  }
  nx_tmp = y.size(1);
  for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
    y[scalarLB] = std::round(y[scalarLB]);
  }
  ww.set_size(1, y.size(1));
  for (b_i = 0; b_i < nx_tmp; b_i++) {
    scalarLB_tmp = static_cast<int>(y[b_i]) - 1;
    ww[b_i].re = b_wcc[scalarLB_tmp].re;
    ww[b_i].im = -b_wcc[scalarLB_tmp].im;
  }
  // ----- spectrum smoother design
  if (fftl < 2.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(fftl - 2.0) + 1);
    b_loop_ub = static_cast<int>(fftl - 2.0);
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      y[b_i] = static_cast<double>(b_i) + 2.0;
    }
  }
  fff.set_size(1, y.size(1) + 1);
  loop_ub_tmp = y.size(1);
  for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
    fff[b_i] = y[b_i];
  }
  fff[y.size(1)] = 1.0;
  if (fftl - 1.0 < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>((fftl - 1.0) - 1.0) + 1);
    b_loop_ub = static_cast<int>((fftl - 1.0) - 1.0);
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      y[b_i] = static_cast<double>(b_i) + 1.0;
    }
  }
  ffb.set_size(1, y.size(1) + 1);
  ffb[0] = fftl;
  b_loop_ub = y.size(1);
  for (b_i = 0; b_i < b_loop_ub; b_i++) {
    ffb[b_i + 1] = y[b_i];
  }
  // ----- lifter design
  if (fftl - 1.0 < 0.0) {
    y.set_size(y.size(0), 0);
  } else {
    y.set_size(1, static_cast<int>(fftl - 1.0) + 1);
    b_loop_ub = static_cast<int>(fftl - 1.0);
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      y[b_i] = b_i;
    }
  }
  y.set_size(1, y.size(1));
  b_loop_ub = y.size(1) - 1;
  scalarLB = (y.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&y[b_i]);
    _mm_storeu_pd(&y[b_i],
                  _mm_mul_pd(_mm_sub_pd(_mm_div_pd(r1, _mm_set1_pd(fs)),
                                        _mm_set1_pd(0.034999999999999996)),
                             _mm_set1_pd(1000.0)));
  }
  for (b_i = scalarLB; b_i <= b_loop_ub; b_i++) {
    y[b_i] = (y[b_i] / fs - 0.034999999999999996) * 1000.0;
  }
  nx = y.size(1);
  for (scalarLB = 0; scalarLB < nx; scalarLB++) {
    y[scalarLB] = std::exp(y[scalarLB]);
  }
  phr.set_size(y.size(1));
  scalarLB = (y.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&y[b_i]);
    r2 = _mm_set1_pd(1.0);
    _mm_storeu_pd(&phr[b_i], _mm_div_pd(r2, _mm_add_pd(r1, r2)));
  }
  for (b_i = scalarLB; b_i < nx; b_i++) {
    phr[b_i] = 1.0 / (y[b_i] + 1.0);
  }
  if (fftl / 2.0 > fftl) {
    b_i = 1;
    scalarLB_tmp = 1;
  } else {
    b_i = static_cast<int>(fftl);
    scalarLB_tmp = -1;
  }
  b_loop_ub = static_cast<int>(fftl / 2.0 + 2.0) - 2;
  b_f0.set_size(1, b_loop_ub + 1);
  for (nx = 0; nx <= b_loop_ub; nx++) {
    b_f0[nx] = phr[nx + 1];
  }
  b_loop_ub = b_f0.size(1);
  for (nx = 0; nx < b_loop_ub; nx++) {
    phr[(b_i + scalarLB_tmp * nx) - 1] = b_f0[nx];
  }
  // ------ preparation for EREB smoothing
  //  by Matrin Cooke, adopted from MAD library
  b = 21.4 * std::log10(0.00437 * (fs / 2.0) + 1.0);
  for (b_i = 0; b_i < 1025; b_i++) {
    evv[b_i] = 0.0009765625 * static_cast<double>(b_i) * b;
  }
  //  ERB axis for smoothing
  //  effective smoothing width in ERB
  lh = std::round(2.0 / evv[1]);
  //  number of samples for 2*eew on evv axis
  legacy_STRAIGHT::hanning(lh, b_x);
  avf0 = legacy_STRAIGHT::blockedSummation(b_x, b_x.size(0));
  legacy_STRAIGHT::hanning(lh, we);
  b_loop_ub = we.size(0);
  scalarLB = (we.size(0) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    r1 = _mm_loadu_pd(&we[b_i]);
    _mm_storeu_pd(&we[b_i], _mm_div_pd(r1, _mm_set1_pd(avf0)));
  }
  for (b_i = scalarLB; b_i < b_loop_ub; b_i++) {
    we[b_i] = we[b_i] / avf0;
  }
  //  Hanning window is used for smoothing
  //  index for extraction
  for (scalarLB = 0; scalarLB < 1025; scalarLB++) {
    hvv[scalarLB] = 228.8 * (rt_powd_snf(10.0, 0.0467 * evv[scalarLB]) - 1.0);
  }
  //  frequency axis represented in Hz
  hvv[0] = 0.0;
  hvv[1024] = fs / 2.0;
  //  safeguard
  b = legacy_STRAIGHT::coder::internal::maximum(evv);
  if (std::isnan(b)) {
    phc.set_size(1, 1);
    phc[0] = rtNaN;
  } else if (b < 0.0) {
    phc.set_size(1, 0);
  } else {
    legacy_STRAIGHT::b_eml_float_colon(b, phc);
  }
  b = fftl / 2.0 - 1.0;
  if (b < 1.0) {
    phri.set_size(1, 0);
  } else {
    phri.set_size(1, static_cast<int>(b - 1.0) + 1);
    b_loop_ub = static_cast<int>(b - 1.0);
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      phri[b_i] = static_cast<double>(b_i) + 1.0;
    }
  }
  if (b_tmp < 1.0) {
    ti.set_size(1, 0);
  } else {
    ti.set_size(1, static_cast<int>(b_tmp - 1.0) + 1);
    b_loop_ub = static_cast<int>(b_tmp - 1.0);
    for (b_i = 0; b_i <= b_loop_ub; b_i++) {
      ti[b_i] = static_cast<double>(b_i) + 1.0;
    }
  }
  loop_ub_tmp = static_cast<int>(mm);
  b_i = tidx.size(1);
  apv.set_size(loop_ub_tmp, tidx.size(1));
  nx = static_cast<int>(mm) * tidx.size(1);
  dpv.set_size(loop_ub_tmp, tidx.size(1));
  for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
    apv[scalarLB_tmp] = 0.0;
    dpv[scalarLB_tmp] = 0.0;
  }
  b_loop_ub = phc.size(1);
  apve.set_size(phc.size(1), tidx.size(1));
  nx = phc.size(1) * tidx.size(1);
  dpve.set_size(phc.size(1), tidx.size(1));
  for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
    apve[scalarLB_tmp] = 0.0;
    dpve[scalarLB_tmp] = 0.0;
  }
  if (tidx.size(1) - 1 >= 0) {
    c_loop_ub = bb.size(1);
    d_loop_ub = nx_tmp;
    e_loop_ub = ti.size(1);
    f_loop_ub = ti.size(1);
    g_loop_ub = ti.size(1);
    h_loop_ub = ti.size(1);
    i_loop_ub = ti.size(1);
    j_loop_ub = ti.size(1);
    if (lh < 2.0) {
      i3 = 0;
      i4 = 1;
      i2 = -1;
    } else {
      i3 = static_cast<int>(lh) - 1;
      i4 = -1;
      i2 = 1;
    }
    if (1025.0 - lh > 1024.0) {
      i9 = 0;
      i10 = 1;
      i11 = -1;
    } else {
      i9 = 1023;
      i10 = -1;
      i11 = static_cast<int>(1025.0 - lh) - 1;
    }
    if (lh < 2.0) {
      i7 = 0;
      i8 = 1;
      i6 = -1;
    } else {
      i7 = static_cast<int>(lh) - 1;
      i8 = -1;
      i6 = 1;
    }
    if (1025.0 - lh > 1024.0) {
      i12 = 0;
      i13 = 1;
      i14 = -1;
    } else {
      i12 = 1023;
      i13 = -1;
      i14 = static_cast<int>(1025.0 - lh) - 1;
    }
    k_loop_ub = div_s32(i2 - i3, i4);
    l_loop_ub = div_s32(i11 - i9, i10);
    m_loop_ub = div_s32(i6 - i7, i8);
    n_loop_ub = div_s32(i14 - i12, i13);
    c_y = std::round(lh / 2.0);
  }
  if (b_i - 1 >= 0) {
    i1 = div_s32(i2 - i3, i4);
    i5 = div_s32(i6 - i7, i8);
  }
  for (vectorUB_tmp = 0; vectorUB_tmp < b_i; vectorUB_tmp++) {
    double apefs_data[3076];
    double sw_data[4];
    double b_y[2];
    int tmp_size[2];
    b_phr = std::round(tidx[vectorUB_tmp]);
    avf0 = b_phr + fftl;
    y.set_size(1, loop_ub);
    for (scalarLB_tmp = 0; scalarLB_tmp < c_loop_ub; scalarLB_tmp++) {
      y[scalarLB_tmp] = xii[static_cast<int>(avf0 + bb[scalarLB_tmp]) - 1];
    }
    wcc.set_size(loop_ub, nx_tmp);
    for (scalarLB_tmp = 0; scalarLB_tmp < d_loop_ub; scalarLB_tmp++) {
      for (nx = 0; nx < loop_ub; nx++) {
        wcc[nx + wcc.size(0) * scalarLB_tmp].re = y[nx] * ww[scalarLB_tmp].re;
        wcc[nx + wcc.size(0) * scalarLB_tmp].im = y[nx] * ww[scalarLB_tmp].im;
      }
    }
    legacy_STRAIGHT::fft(wcc, r3);
    nx = r3.size(0) * r3.size(1);
    sw.set_size(r3.size(0), r3.size(1));
    for (scalarLB = 0; scalarLB < nx; scalarLB++) {
      sw[scalarLB] = rt_hypotd_snf(r3[scalarLB].re, r3[scalarLB].im);
    }
    if (sw.size(1) == 1) {
      i2 = ffb.size(1);
    } else {
      i2 = sw.size(1);
    }
    if ((sw.size(1) == ffb.size(1)) && (i2 == fff.size(1))) {
      partialTrueCount = sw.size(0);
      i = sw.size(1);
      c_x.set_size(sw.size(0), sw.size(1));
      for (scalarLB_tmp = 0; scalarLB_tmp < i; scalarLB_tmp++) {
        scalarLB = (sw.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          r1 = _mm_loadu_pd(&sw[nx + sw.size(0) * scalarLB_tmp]);
          _mm_storeu_pd(
              &c_x[nx + c_x.size(0) * scalarLB_tmp],
              _mm_div_pd(
                  _mm_add_pd(
                      _mm_add_pd(
                          _mm_mul_pd(r1, _mm_set1_pd(2.0)),
                          _mm_set1_pd(
                              sw[static_cast<int>(ffb[scalarLB_tmp]) - 1])),
                      _mm_set1_pd(sw[static_cast<int>(fff[scalarLB_tmp]) - 1])),
                  _mm_set1_pd(4.0)));
        }
        for (nx = scalarLB; nx < partialTrueCount; nx++) {
          c_x[nx + c_x.size(0) * scalarLB_tmp] =
              ((sw[nx + sw.size(0) * scalarLB_tmp] * 2.0 +
                sw[static_cast<int>(ffb[scalarLB_tmp]) - 1]) +
               sw[static_cast<int>(fff[scalarLB_tmp]) - 1]) /
              4.0;
        }
      }
    } else {
      binary_expand_op_78(c_x, sw, ffb, fff);
    }
    nx = c_x.size(0) * c_x.size(1);
    for (scalarLB = 0; scalarLB < nx; scalarLB++) {
      c_x[scalarLB] = std::log(c_x[scalarLB]);
    }
    legacy_STRAIGHT::fft(c_x, wcc);
    partialTrueCount = wcc.size(0);
    i = wcc.size(1);
    sw.set_size(wcc.size(0), wcc.size(1));
    nx = wcc.size(0) * wcc.size(1);
    for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
      sw[scalarLB_tmp] = wcc[scalarLB_tmp].re;
    }
    if (sw.size(0) == phr.size(0)) {
      b_sw.set_size(wcc.size(0), wcc.size(1));
      for (scalarLB_tmp = 0; scalarLB_tmp < i; scalarLB_tmp++) {
        scalarLB = (sw.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          r1 = _mm_loadu_pd(&sw[nx + sw.size(0) * scalarLB_tmp]);
          r2 = _mm_loadu_pd(&phr[nx]);
          _mm_storeu_pd(&b_sw[nx + b_sw.size(0) * scalarLB_tmp],
                        _mm_mul_pd(r1, r2));
        }
        for (nx = scalarLB; nx < partialTrueCount; nx++) {
          b_sw[nx + b_sw.size(0) * scalarLB_tmp] =
              sw[nx + sw.size(0) * scalarLB_tmp] * phr[nx];
        }
      }
      partialTrueCount = b_sw.size(0);
      i = b_sw.size(1);
      sw.set_size(b_sw.size(0), b_sw.size(1));
      for (scalarLB_tmp = 0; scalarLB_tmp < i; scalarLB_tmp++) {
        for (nx = 0; nx < partialTrueCount; nx++) {
          sw[nx + sw.size(0) * scalarLB_tmp] =
              b_sw[nx + b_sw.size(0) * scalarLB_tmp];
        }
      }
      legacy_STRAIGHT::ifft(sw, wcc);
    } else {
      binary_expand_op_77(wcc, sw, phr);
    }
    sw.set_size(wcc.size(0), wcc.size(1));
    nx = wcc.size(0) * wcc.size(1);
    for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
      sw[scalarLB_tmp] = wcc[scalarLB_tmp].re / 2.3025850929940459;
    }
    scalarLB = (nx / 2) << 1;
    vectorUB = scalarLB - 2;
    for (scalarLB_tmp = 0; scalarLB_tmp <= vectorUB; scalarLB_tmp += 2) {
      r1 = _mm_loadu_pd(&sw[scalarLB_tmp]);
      _mm_storeu_pd(&sw[scalarLB_tmp], _mm_mul_pd(r1, _mm_set1_pd(20.0)));
    }
    for (scalarLB_tmp = scalarLB; scalarLB_tmp < nx; scalarLB_tmp++) {
      sw[scalarLB_tmp] = sw[scalarLB_tmp] * 20.0;
    }
    // smoothed dB spectrum
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < e_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] =
          sw[static_cast<int>(static_cast<unsigned int>(ti[scalarLB_tmp]))];
    }
    legacy_STRAIGHT::diff(b_f0, y);
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < f_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] = sw[static_cast<int>(ti[scalarLB_tmp]) - 1];
    }
    legacy_STRAIGHT::diff(b_f0, w);
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < g_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] = sw[static_cast<int>(ti[scalarLB_tmp]) - 1];
    }
    legacy_STRAIGHT::diff(b_f0, xi);
    if (w.size(1) == 1) {
      scalarLB_tmp = y.size(1);
    } else {
      scalarLB_tmp = w.size(1);
    }
    if (scalarLB_tmp == 1) {
      i2 = phri.size(1);
    } else {
      i2 = scalarLB_tmp;
    }
    if ((w.size(1) == y.size(1)) && (scalarLB_tmp == phri.size(1)) &&
        (i2 == xi.size(1))) {
      partialTrueCount = w.size(1);
      b_f0.set_size(1, w.size(1));
      for (scalarLB_tmp = 0; scalarLB_tmp < partialTrueCount; scalarLB_tmp++) {
        b_f0[scalarLB_tmp] =
            static_cast<double>(w[scalarLB_tmp] * y[scalarLB_tmp] < 0.0) *
            sw[static_cast<int>(phri[scalarLB_tmp]) - 1] *
            static_cast<double>(xi[scalarLB_tmp] > 0.0);
      }
      plits[0] = 0.0;
      plits[1] = b_f0[0];
    } else {
      binary_expand_op_76(plits, w, y, sw, phri, xi);
    }
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < h_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] =
          sw[static_cast<int>(static_cast<unsigned int>(ti[scalarLB_tmp]))];
    }
    legacy_STRAIGHT::diff(b_f0, y);
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < i_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] = sw[static_cast<int>(ti[scalarLB_tmp]) - 1];
    }
    legacy_STRAIGHT::diff(b_f0, w);
    b_f0.set_size(1, ti.size(1));
    for (scalarLB_tmp = 0; scalarLB_tmp < j_loop_ub; scalarLB_tmp++) {
      b_f0[scalarLB_tmp] = sw[static_cast<int>(ti[scalarLB_tmp]) - 1];
    }
    legacy_STRAIGHT::diff(b_f0, xi);
    if (w.size(1) == 1) {
      scalarLB_tmp = y.size(1);
    } else {
      scalarLB_tmp = w.size(1);
    }
    if (scalarLB_tmp == 1) {
      i2 = phri.size(1);
    } else {
      i2 = scalarLB_tmp;
    }
    if ((w.size(1) == y.size(1)) && (scalarLB_tmp == phri.size(1)) &&
        (i2 == xi.size(1))) {
      partialTrueCount = w.size(1);
      b_f0.set_size(1, w.size(1));
      for (scalarLB_tmp = 0; scalarLB_tmp < partialTrueCount; scalarLB_tmp++) {
        b_f0[scalarLB_tmp] =
            static_cast<double>(w[scalarLB_tmp] * y[scalarLB_tmp] < 0.0) *
            sw[static_cast<int>(phri[scalarLB_tmp]) - 1] *
            static_cast<double>(xi[scalarLB_tmp] < 0.0);
      }
      dlits[0] = 0.0;
      dlits[1] = b_f0[0];
    } else {
      binary_expand_op_75(dlits, w, y, sw, phri, xi);
    }
    trueCount = 0;
    brm = std::abs(plits[0]);
    b_y[0] = brm;
    if (brm > 0.0) {
      trueCount = 1;
    }
    brm = std::abs(plits[1]);
    b_y[1] = brm;
    if (brm > 0.0) {
      trueCount++;
    }
    partialTrueCount = 0;
    i = 0;
    nx = 0;
    for (scalarLB = 0; scalarLB < 2; scalarLB++) {
      if (b_y[scalarLB] > 0.0) {
        tmp_data[partialTrueCount] = static_cast<signed char>(scalarLB);
        partialTrueCount++;
      }
      brm = std::abs(dlits[scalarLB]);
      b_y[scalarLB] = brm;
      if (brm > 0.0) {
        i++;
        b_tmp_data[nx] = static_cast<signed char>(scalarLB);
        nx++;
      }
    }
    b_tmp = f0ii[static_cast<int>(b_phr) - 1];
    //  dip level (dB)
    //  peak level (dB)
    //  dip level (power)
    //  peak level (power)
    //  by Matrin Cooke, adopted from MAD library
    nx = trueCount + 2;
    b_x.set_size(trueCount + 2);
    avf0 = 0.00437 * (0.0 * b_tmp / 40.0) + 1.0;
    b_x[0] = avf0;
    for (scalarLB_tmp = 0; scalarLB_tmp < trueCount; scalarLB_tmp++) {
      b_x[scalarLB_tmp + 1] =
          0.00437 *
              (fxfi[static_cast<int>(tmp_data[scalarLB_tmp])] * b_tmp / 40.0) +
          1.0;
    }
    b_phr = 0.00437 * (fs / 2.0 * b_tmp / 40.0) + 1.0;
    b_x[trueCount + 1] = b_phr;
    for (scalarLB = 0; scalarLB < nx; scalarLB++) {
      b_x[scalarLB] = std::log10(b_x[scalarLB]);
    }
    sw_data[0] = sw[static_cast<int>(tmp_data[0])] / 10.0;
    for (scalarLB_tmp = 0; scalarLB_tmp < trueCount; scalarLB_tmp++) {
      sw_data[scalarLB_tmp + 1] =
          sw[static_cast<int>(tmp_data[scalarLB_tmp])] / 10.0;
    }
    sw_data[trueCount + 1] =
        sw[static_cast<int>(tmp_data[trueCount - 1])] / 10.0;
    scalarLB = (b_x.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (scalarLB_tmp = 0; scalarLB_tmp <= vectorUB; scalarLB_tmp += 2) {
      r1 = _mm_loadu_pd(&b_x[scalarLB_tmp]);
      _mm_storeu_pd(&b_x[scalarLB_tmp], _mm_mul_pd(_mm_set1_pd(21.4), r1));
    }
    for (scalarLB_tmp = scalarLB; scalarLB_tmp < nx; scalarLB_tmp++) {
      b_x[scalarLB_tmp] = 21.4 * b_x[scalarLB_tmp];
    }
    for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
      sw_data[scalarLB_tmp] = rt_powd_snf(10.0, sw_data[scalarLB_tmp]);
    }
    legacy_STRAIGHT::interp1((const double *)b_x.data(),
                             (*(int(*)[1])b_x.size())[0], sw_data,
                             trueCount + 2, evv, ape);
    //  Upper power envelope on ERB
    //  by Matrin Cooke, adopted from MAD library
    nx = i + 2;
    b_x.set_size(i + 2);
    b_x[0] = avf0;
    for (scalarLB_tmp = 0; scalarLB_tmp < i; scalarLB_tmp++) {
      b_x[scalarLB_tmp + 1] =
          0.00437 * (fxfi[static_cast<int>(b_tmp_data[scalarLB_tmp])] * b_tmp /
                     40.0) +
          1.0;
    }
    b_x[i + 1] = b_phr;
    for (scalarLB = 0; scalarLB < nx; scalarLB++) {
      b_x[scalarLB] = std::log10(b_x[scalarLB]);
    }
    sw_data[0] = sw[static_cast<int>(b_tmp_data[0])] / 10.0;
    for (scalarLB_tmp = 0; scalarLB_tmp < i; scalarLB_tmp++) {
      sw_data[scalarLB_tmp + 1] =
          sw[static_cast<int>(b_tmp_data[scalarLB_tmp])] / 10.0;
    }
    sw_data[i + 1] = sw[static_cast<int>(b_tmp_data[i - 1])] / 10.0;
    scalarLB = (b_x.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (scalarLB_tmp = 0; scalarLB_tmp <= vectorUB; scalarLB_tmp += 2) {
      r1 = _mm_loadu_pd(&b_x[scalarLB_tmp]);
      _mm_storeu_pd(&b_x[scalarLB_tmp], _mm_mul_pd(_mm_set1_pd(21.4), r1));
    }
    for (scalarLB_tmp = scalarLB; scalarLB_tmp < nx; scalarLB_tmp++) {
      b_x[scalarLB_tmp] = 21.4 * b_x[scalarLB_tmp];
    }
    for (scalarLB_tmp = 0; scalarLB_tmp < nx; scalarLB_tmp++) {
      sw_data[scalarLB_tmp] = rt_powd_snf(10.0, sw_data[scalarLB_tmp]);
    }
    legacy_STRAIGHT::interp1((const double *)b_x.data(),
                             (*(int(*)[1])b_x.size())[0], sw_data, i + 2, evv,
                             dpe);
    //  Lower power envelope on ERB
    //  ape with mirrored ends
    //  dpe with mirrored ends
    dpefs_size[0] = 1;
    dpefs_size[1] = (i1 + div_s32(i11 - i9, i10)) + 1027;
    for (scalarLB_tmp = 0; scalarLB_tmp <= k_loop_ub; scalarLB_tmp++) {
      dpefs_data[scalarLB_tmp] = ape[i3 + i4 * scalarLB_tmp];
    }
    std::copy(&ape[0], &ape[1025], &dpefs_data[i1 + 1]);
    for (scalarLB_tmp = 0; scalarLB_tmp <= l_loop_ub; scalarLB_tmp++) {
      dpefs_data[(scalarLB_tmp + i1) + 1026] = ape[i9 + i10 * scalarLB_tmp];
    }
    legacy_STRAIGHT::fftfilt(we, dpefs_data, dpefs_size, c_tmp_data, tmp_size);
    partialTrueCount = tmp_size[1];
    for (scalarLB_tmp = 0; scalarLB_tmp < partialTrueCount; scalarLB_tmp++) {
      apefs_data[scalarLB_tmp] = c_tmp_data[scalarLB_tmp].re;
    }
    //  smoothed ape
    dpefs_size[0] = 1;
    dpefs_size[1] = (i5 + div_s32(i14 - i12, i13)) + 1027;
    for (scalarLB_tmp = 0; scalarLB_tmp <= m_loop_ub; scalarLB_tmp++) {
      dpefs_data[scalarLB_tmp] = dpe[i7 + i8 * scalarLB_tmp];
    }
    std::copy(&dpe[0], &dpe[1025], &dpefs_data[i5 + 1]);
    for (scalarLB_tmp = 0; scalarLB_tmp <= n_loop_ub; scalarLB_tmp++) {
      dpefs_data[(scalarLB_tmp + i5) + 1026] = dpe[i12 + i13 * scalarLB_tmp];
    }
    legacy_STRAIGHT::fftfilt(we, dpefs_data, dpefs_size, c_tmp_data, tmp_size);
    partialTrueCount = tmp_size[1];
    for (scalarLB_tmp = 0; scalarLB_tmp < partialTrueCount; scalarLB_tmp++) {
      dpefs_data[scalarLB_tmp] = c_tmp_data[scalarLB_tmp].re;
    }
    //  smoothed dpe
    for (scalarLB_tmp = 0; scalarLB_tmp < 1025; scalarLB_tmp++) {
      brm = ((lh + (static_cast<double>(scalarLB_tmp) + 1.0)) - 1.0) + c_y;
      dpe[scalarLB_tmp] = apefs_data[static_cast<int>(brm) - 1];
      ape[scalarLB_tmp] = dpefs_data[static_cast<int>(brm) - 1];
    }
    //  smoothed ape on linear axis
    //  smoothed dpe on linear axis
    legacy_STRAIGHT::interp1(hvv, ape, fxa, y);
    for (scalarLB_tmp = 0; scalarLB_tmp < loop_ub_tmp; scalarLB_tmp++) {
      dpv[scalarLB_tmp + dpv.size(0) * vectorUB_tmp] = y[scalarLB_tmp];
    }
    legacy_STRAIGHT::interp1(hvv, dpe, fxa, y);
    for (scalarLB_tmp = 0; scalarLB_tmp < loop_ub_tmp; scalarLB_tmp++) {
      apv[scalarLB_tmp + apv.size(0) * vectorUB_tmp] = y[scalarLB_tmp];
    }
    legacy_STRAIGHT::interp1(evv, ape, phc, y);
    for (scalarLB_tmp = 0; scalarLB_tmp < b_loop_ub; scalarLB_tmp++) {
      dpve[scalarLB_tmp + dpve.size(0) * vectorUB_tmp] = y[scalarLB_tmp];
    }
    legacy_STRAIGHT::interp1(evv, dpe, phc, y);
    for (scalarLB_tmp = 0; scalarLB_tmp < b_loop_ub; scalarLB_tmp++) {
      apve[scalarLB_tmp + apve.size(0) * vectorUB_tmp] = y[scalarLB_tmp];
    }
    //   if imgi==1 && rem(ii,2)==0 %10/Aug./2005
    //      waitbar(0.1+0.9*ii/length(tidx)); %,hpg);
  }
}

// End of code generation (aperiodicpartERB2.cpp)
