//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// grpdelay.cpp
//
// Code generation for function 'grpdelay'
//

// Include files
#include "grpdelay.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
void binary_expand_op_18(double in1[8], const creal_T in2_data[],
                         const coder::array<double, 2U> &in3,
                         const int in4_size[2])
{
  int stride_0_1;
  stride_0_1 = (in3.size(1) != 1);
  for (int i{0}; i < 8; i++) {
    in1[i] = in2_data[static_cast<int>(in3[i * stride_0_1]) - 1].re -
             (static_cast<double>(in4_size[1]) - 1.0);
  }
}

void binary_expand_op_51(double in1_data[], int in1_size[2],
                         const double in2_data[], const int in2_size[2],
                         const coder::array<double, 2U> &in3)
{
  int in2_idx_0;
  int loop_ub;
  int stride_1_1;
  in2_idx_0 = in2_size[1];
  in1_size[0] = 1;
  if (in3.size(1) == 1) {
    loop_ub = in2_idx_0;
  } else {
    loop_ub = in3.size(1);
  }
  in1_size[1] = loop_ub;
  in2_idx_0 = (in2_idx_0 != 1);
  stride_1_1 = (in3.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    in1_data[i] = in2_data[i * in2_idx_0] * in3[i * stride_1_1];
  }
}

// End of code generation (grpdelay.cpp)
