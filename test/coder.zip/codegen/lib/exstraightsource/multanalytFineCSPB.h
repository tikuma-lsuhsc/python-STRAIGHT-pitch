//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// multanalytFineCSPB.h
//
// Code generation for function 'multanalytFineCSPB'
//

#ifndef MULTANALYTFINECSPB_H
#define MULTANALYTFINECSPB_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void b_multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs,
                          double f0floor, double nvc, double nvo, double mu,
                          coder::array<creal_T, 2U> &pm);

void c_multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs,
                          double f0floor, double nvc, double nvo, double mu,
                          coder::array<creal_T, 2U> &pm);

void multanalytFineCSPB(coder::array<creal_T, 2U> &x, double fs, double f0floor,
                        double nvc, double nvo, double mu,
                        coder::array<creal_T, 2U> &pm);

#endif
// End of code generation (multanalytFineCSPB.h)
