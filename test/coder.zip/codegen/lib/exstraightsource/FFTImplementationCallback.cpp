//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// FFTImplementationCallback.cpp
//
// Code generation for function 'FFTImplementationCallback'
//

// Include files
#include "FFTImplementationCallback.h"
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
namespace fft {
void FFTImplementationCallback::b_doHalfLengthBluestein(
    const ::coder::array<double, 2U> &x, int xoffInit,
    ::coder::array<creal_T, 1U> &y, int nrowsx, int nRows, int nfft,
    const ::coder::array<creal_T, 1U> &wwc,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &costabinv,
    const ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> reconVar1;
  ::coder::array<creal_T, 1U> reconVar2;
  ::coder::array<creal_T, 1U> ytmp;
  ::coder::array<double, 2U> a__1;
  ::coder::array<double, 2U> costable;
  ::coder::array<double, 2U> hcostabinv;
  ::coder::array<double, 2U> hsintab;
  ::coder::array<double, 2U> hsintabinv;
  ::coder::array<double, 2U> sintable;
  ::coder::array<int, 2U> wrapIndex;
  double a_im;
  double a_re;
  double ar;
  double b_im;
  double b_re;
  int hnRows;
  int k1;
  int minHnrowsNxBy2;
  int u0;
  boolean_T nxeven;
  hnRows = nRows / 2;
  ytmp.set_size(hnRows);
  if (hnRows > nrowsx) {
    ytmp.set_size(hnRows);
    for (k1 = 0; k1 < hnRows; k1++) {
      ytmp[k1].re = 0.0;
      ytmp[k1].im = 0.0;
    }
  }
  if ((x.size(0) & 1) == 0) {
    nxeven = true;
    u0 = x.size(0);
  } else if (x.size(0) >= nRows) {
    nxeven = true;
    u0 = nRows;
  } else {
    nxeven = false;
    u0 = x.size(0) - 1;
  }
  FFTImplementationCallback::b_generate_twiddle_tables(nRows << 1, costable,
                                                       sintable, a__1);
  FFTImplementationCallback::get_half_twiddle_tables(costab, sintab, costabinv,
                                                     sintabinv, a__1, hsintab,
                                                     hcostabinv, hsintabinv);
  reconVar1.set_size(hnRows);
  reconVar2.set_size(hnRows);
  wrapIndex.set_size(1, hnRows);
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    k1 = minHnrowsNxBy2 << 1;
    a_re = sintable[k1];
    a_im = costable[k1];
    reconVar1[minHnrowsNxBy2].re = 1.0 - a_re;
    reconVar1[minHnrowsNxBy2].im = -a_im;
    reconVar2[minHnrowsNxBy2].re = a_re + 1.0;
    reconVar2[minHnrowsNxBy2].im = a_im;
    if (minHnrowsNxBy2 + 1 != 1) {
      wrapIndex[minHnrowsNxBy2] = (hnRows - minHnrowsNxBy2) + 1;
    } else {
      wrapIndex[0] = 1;
    }
  }
  if (u0 > nRows) {
    u0 = nRows;
  }
  minHnrowsNxBy2 = u0 / 2 - 1;
  for (k1 = 0; k1 <= minHnrowsNxBy2; k1++) {
    u0 = (hnRows + k1) - 1;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    u0 = xoffInit + (k1 << 1);
    b_re = x[u0];
    b_im = x[u0 + 1];
    ytmp[k1].re = a_re * b_re + a_im * b_im;
    ytmp[k1].im = a_re * b_im - a_im * b_re;
  }
  if (!nxeven) {
    u0 = hnRows + minHnrowsNxBy2;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    if (minHnrowsNxBy2 < 0) {
      u0 = xoffInit;
    } else {
      u0 = xoffInit + ((minHnrowsNxBy2 + 1) << 1);
    }
    b_re = x[u0];
    ytmp[minHnrowsNxBy2 + 1].re = a_re * b_re + a_im * 0.0;
    ytmp[minHnrowsNxBy2 + 1].im = a_re * 0.0 - a_im * b_re;
    if (minHnrowsNxBy2 + 3 <= hnRows) {
      k1 = minHnrowsNxBy2 + 3;
      for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
        ytmp[minHnrowsNxBy2 - 1].re = 0.0;
        ytmp[minHnrowsNxBy2 - 1].im = 0.0;
      }
    }
  } else if (minHnrowsNxBy2 + 2 <= hnRows) {
    k1 = minHnrowsNxBy2 + 2;
    for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
      ytmp[minHnrowsNxBy2 - 1].re = 0.0;
      ytmp[minHnrowsNxBy2 - 1].im = 0.0;
    }
  }
  u0 = nfft / 2;
  FFTImplementationCallback::r2br_r2dit_trig_impl(ytmp, u0, a__1, hsintab, fv);
  FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, u0, a__1, hsintab, b_fv);
  minHnrowsNxBy2 = fv.size(0);
  b_fv.set_size(fv.size(0));
  for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
    a_re = fv[k1].re;
    a_im = b_fv[k1].im;
    b_re = fv[k1].im;
    b_im = b_fv[k1].re;
    b_fv[k1].re = a_re * b_im - b_re * a_im;
    b_fv[k1].im = a_re * a_im + b_re * b_im;
  }
  FFTImplementationCallback::r2br_r2dit_trig_impl(b_fv, u0, hcostabinv,
                                                  hsintabinv, fv);
  if (fv.size(0) > 1) {
    a_re = 1.0 / static_cast<double>(fv.size(0));
    minHnrowsNxBy2 = fv.size(0);
    for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
      fv[k1].re = a_re * fv[k1].re;
      fv[k1].im = a_re * fv[k1].im;
    }
  }
  k1 = wwc.size(0);
  for (minHnrowsNxBy2 = hnRows; minHnrowsNxBy2 <= k1; minHnrowsNxBy2++) {
    a_re = wwc[minHnrowsNxBy2 - 1].re;
    a_im = fv[minHnrowsNxBy2 - 1].im;
    b_re = wwc[minHnrowsNxBy2 - 1].im;
    b_im = fv[minHnrowsNxBy2 - 1].re;
    ar = a_re * b_im + b_re * a_im;
    a_re = a_re * a_im - b_re * b_im;
    if (a_re == 0.0) {
      u0 = minHnrowsNxBy2 - hnRows;
      ytmp[u0].re = ar / static_cast<double>(hnRows);
      ytmp[u0].im = 0.0;
    } else if (ar == 0.0) {
      u0 = minHnrowsNxBy2 - hnRows;
      ytmp[u0].re = 0.0;
      ytmp[u0].im = a_re / static_cast<double>(hnRows);
    } else {
      u0 = minHnrowsNxBy2 - hnRows;
      ytmp[u0].re = ar / static_cast<double>(hnRows);
      ytmp[u0].im = a_re / static_cast<double>(hnRows);
    }
  }
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    double b_ytmp_re_tmp;
    double ytmp_im_tmp;
    double ytmp_re_tmp;
    k1 = wrapIndex[minHnrowsNxBy2];
    a_re = ytmp[minHnrowsNxBy2].re;
    a_im = reconVar1[minHnrowsNxBy2].im;
    b_re = ytmp[minHnrowsNxBy2].im;
    b_im = reconVar1[minHnrowsNxBy2].re;
    ar = ytmp[k1 - 1].re;
    ytmp_im_tmp = -ytmp[k1 - 1].im;
    ytmp_re_tmp = reconVar2[minHnrowsNxBy2].im;
    b_ytmp_re_tmp = reconVar2[minHnrowsNxBy2].re;
    y[minHnrowsNxBy2].re =
        0.5 * ((a_re * b_im - b_re * a_im) +
               (ar * b_ytmp_re_tmp - ytmp_im_tmp * ytmp_re_tmp));
    y[minHnrowsNxBy2].im =
        0.5 * ((a_re * a_im + b_re * b_im) +
               (ar * ytmp_re_tmp + ytmp_im_tmp * b_ytmp_re_tmp));
    k1 = hnRows + minHnrowsNxBy2;
    y[k1].re = 0.5 * ((a_re * b_ytmp_re_tmp - b_re * ytmp_re_tmp) +
                      (ar * b_im - ytmp_im_tmp * a_im));
    y[k1].im = 0.5 * ((a_re * ytmp_re_tmp + b_re * b_ytmp_re_tmp) +
                      (ar * a_im + ytmp_im_tmp * b_im));
  }
  minHnrowsNxBy2 = y.size(0);
  for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
    ar = y[k1].re;
    a_re = y[k1].im;
    if (a_re == 0.0) {
      a_im = ar / 2.0;
      a_re = 0.0;
    } else if (ar == 0.0) {
      a_im = 0.0;
      a_re /= 2.0;
    } else {
      a_im = ar / 2.0;
      a_re /= 2.0;
    }
    y[k1].re = a_im;
    y[k1].im = a_re;
  }
}

void FFTImplementationCallback::b_generate_twiddle_tables(
    int nRows, ::coder::array<double, 2U> &costab,
    ::coder::array<double, 2U> &sintab, ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<double, 2U> costab1q;
  double e;
  int i;
  int n;
  int nd2;
  e = 6.2831853071795862 / static_cast<double>(nRows);
  n = nRows / 2 / 2;
  costab1q.set_size(1, n + 1);
  costab1q[0] = 1.0;
  nd2 = static_cast<int>(static_cast<unsigned int>(n) >> 1) - 1;
  for (int k{0}; k <= nd2; k++) {
    costab1q[k + 1] = std::cos(e * (static_cast<double>(k) + 1.0));
  }
  i = nd2 + 2;
  nd2 = n - 1;
  for (int k{i}; k <= nd2; k++) {
    costab1q[k] = std::sin(e * static_cast<double>(n - k));
  }
  costab1q[n] = 0.0;
  n = costab1q.size(1) - 1;
  nd2 = (costab1q.size(1) - 1) << 1;
  costab.set_size(1, nd2 + 1);
  sintab.set_size(1, nd2 + 1);
  costab[0] = 1.0;
  sintab[0] = 0.0;
  sintabinv.set_size(1, nd2 + 1);
  for (int k{0}; k < n; k++) {
    sintabinv[k + 1] = costab1q[(n - k) - 1];
  }
  i = costab1q.size(1);
  for (int k{i}; k <= nd2; k++) {
    sintabinv[k] = costab1q[k - n];
  }
  for (int k{0}; k < n; k++) {
    costab[k + 1] = costab1q[k + 1];
    sintab[k + 1] = -costab1q[(n - k) - 1];
  }
  for (int k{i}; k <= nd2; k++) {
    costab[k] = -costab1q[nd2 - k];
    sintab[k] = -costab1q[k - n];
  }
}

void FFTImplementationCallback::doHalfLengthBluestein(
    const ::coder::array<double, 1U> &x, ::coder::array<creal_T, 1U> &y,
    int nrowsx, int nRows, int nfft, const ::coder::array<creal_T, 1U> &wwc,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &costabinv,
    const ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> reconVar1;
  ::coder::array<creal_T, 1U> reconVar2;
  ::coder::array<creal_T, 1U> ytmp;
  ::coder::array<double, 2U> a__1;
  ::coder::array<double, 2U> costable;
  ::coder::array<double, 2U> hcostabinv;
  ::coder::array<double, 2U> hsintab;
  ::coder::array<double, 2U> hsintabinv;
  ::coder::array<double, 2U> sintable;
  ::coder::array<int, 2U> wrapIndex;
  double a_im;
  double a_re;
  double b_im;
  double b_re;
  int hnRows;
  int k1;
  int minHnrowsNxBy2;
  int u0;
  boolean_T nxeven;
  hnRows = nRows / 2;
  ytmp.set_size(hnRows);
  if (hnRows > nrowsx) {
    ytmp.set_size(hnRows);
    for (k1 = 0; k1 < hnRows; k1++) {
      ytmp[k1].re = 0.0;
      ytmp[k1].im = 0.0;
    }
  }
  if ((x.size(0) & 1) == 0) {
    nxeven = true;
    u0 = x.size(0);
  } else if (x.size(0) >= nRows) {
    nxeven = true;
    u0 = nRows;
  } else {
    nxeven = false;
    u0 = x.size(0) - 1;
  }
  FFTImplementationCallback::b_generate_twiddle_tables(nRows << 1, costable,
                                                       sintable, a__1);
  FFTImplementationCallback::get_half_twiddle_tables(costab, sintab, costabinv,
                                                     sintabinv, a__1, hsintab,
                                                     hcostabinv, hsintabinv);
  reconVar1.set_size(hnRows);
  reconVar2.set_size(hnRows);
  wrapIndex.set_size(1, hnRows);
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    k1 = minHnrowsNxBy2 << 1;
    a_re = sintable[k1];
    a_im = costable[k1];
    reconVar1[minHnrowsNxBy2].re = a_re + 1.0;
    reconVar1[minHnrowsNxBy2].im = -a_im;
    reconVar2[minHnrowsNxBy2].re = 1.0 - a_re;
    reconVar2[minHnrowsNxBy2].im = a_im;
    if (minHnrowsNxBy2 + 1 != 1) {
      wrapIndex[minHnrowsNxBy2] = (hnRows - minHnrowsNxBy2) + 1;
    } else {
      wrapIndex[0] = 1;
    }
  }
  if (u0 > nRows) {
    u0 = nRows;
  }
  minHnrowsNxBy2 = u0 / 2 - 1;
  for (k1 = 0; k1 <= minHnrowsNxBy2; k1++) {
    u0 = (hnRows + k1) - 1;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    u0 = k1 << 1;
    b_re = x[u0];
    b_im = x[u0 + 1];
    ytmp[k1].re = a_re * b_re + a_im * b_im;
    ytmp[k1].im = a_re * b_im - a_im * b_re;
  }
  if (!nxeven) {
    u0 = hnRows + minHnrowsNxBy2;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    if (minHnrowsNxBy2 < 0) {
      u0 = 0;
    } else {
      u0 = (minHnrowsNxBy2 + 1) << 1;
    }
    b_re = x[u0];
    ytmp[minHnrowsNxBy2 + 1].re = a_re * b_re + a_im * 0.0;
    ytmp[minHnrowsNxBy2 + 1].im = a_re * 0.0 - a_im * b_re;
    if (minHnrowsNxBy2 + 3 <= hnRows) {
      k1 = minHnrowsNxBy2 + 3;
      for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
        ytmp[minHnrowsNxBy2 - 1].re = 0.0;
        ytmp[minHnrowsNxBy2 - 1].im = 0.0;
      }
    }
  } else if (minHnrowsNxBy2 + 2 <= hnRows) {
    k1 = minHnrowsNxBy2 + 2;
    for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
      ytmp[minHnrowsNxBy2 - 1].re = 0.0;
      ytmp[minHnrowsNxBy2 - 1].im = 0.0;
    }
  }
  u0 = nfft / 2;
  FFTImplementationCallback::r2br_r2dit_trig_impl(ytmp, u0, a__1, hsintab, fv);
  FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, u0, a__1, hsintab, b_fv);
  minHnrowsNxBy2 = fv.size(0);
  b_fv.set_size(fv.size(0));
  for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
    a_re = fv[k1].re;
    a_im = b_fv[k1].im;
    b_re = fv[k1].im;
    b_im = b_fv[k1].re;
    b_fv[k1].re = a_re * b_im - b_re * a_im;
    b_fv[k1].im = a_re * a_im + b_re * b_im;
  }
  FFTImplementationCallback::r2br_r2dit_trig_impl(b_fv, u0, hcostabinv,
                                                  hsintabinv, fv);
  if (fv.size(0) > 1) {
    a_re = 1.0 / static_cast<double>(fv.size(0));
    minHnrowsNxBy2 = fv.size(0);
    for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
      fv[k1].re = a_re * fv[k1].re;
      fv[k1].im = a_re * fv[k1].im;
    }
  }
  k1 = wwc.size(0);
  for (minHnrowsNxBy2 = hnRows; minHnrowsNxBy2 <= k1; minHnrowsNxBy2++) {
    a_re = wwc[minHnrowsNxBy2 - 1].re;
    a_im = fv[minHnrowsNxBy2 - 1].im;
    b_re = wwc[minHnrowsNxBy2 - 1].im;
    b_im = fv[minHnrowsNxBy2 - 1].re;
    u0 = minHnrowsNxBy2 - hnRows;
    ytmp[u0].re = a_re * b_im + b_re * a_im;
    ytmp[u0].im = a_re * a_im - b_re * b_im;
  }
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    double b_ytmp_re_tmp;
    double c_ytmp_re_tmp;
    double ytmp_im_tmp;
    double ytmp_re_tmp;
    k1 = wrapIndex[minHnrowsNxBy2];
    a_re = ytmp[minHnrowsNxBy2].re;
    a_im = reconVar1[minHnrowsNxBy2].im;
    b_re = ytmp[minHnrowsNxBy2].im;
    b_im = reconVar1[minHnrowsNxBy2].re;
    ytmp_re_tmp = ytmp[k1 - 1].re;
    ytmp_im_tmp = -ytmp[k1 - 1].im;
    b_ytmp_re_tmp = reconVar2[minHnrowsNxBy2].im;
    c_ytmp_re_tmp = reconVar2[minHnrowsNxBy2].re;
    y[minHnrowsNxBy2].re =
        0.5 * ((a_re * b_im - b_re * a_im) +
               (ytmp_re_tmp * c_ytmp_re_tmp - ytmp_im_tmp * b_ytmp_re_tmp));
    y[minHnrowsNxBy2].im =
        0.5 * ((a_re * a_im + b_re * b_im) +
               (ytmp_re_tmp * b_ytmp_re_tmp + ytmp_im_tmp * c_ytmp_re_tmp));
    k1 = hnRows + minHnrowsNxBy2;
    y[k1].re = 0.5 * ((a_re * c_ytmp_re_tmp - b_re * b_ytmp_re_tmp) +
                      (ytmp_re_tmp * b_im - ytmp_im_tmp * a_im));
    y[k1].im = 0.5 * ((a_re * b_ytmp_re_tmp + b_re * c_ytmp_re_tmp) +
                      (ytmp_re_tmp * a_im + ytmp_im_tmp * b_im));
  }
}

void FFTImplementationCallback::doHalfLengthBluestein(
    const ::coder::array<double, 2U> &x, int xoffInit,
    ::coder::array<creal_T, 1U> &y, int nrowsx, int nRows, int nfft,
    const ::coder::array<creal_T, 1U> &wwc,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &costabinv,
    const ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> reconVar1;
  ::coder::array<creal_T, 1U> reconVar2;
  ::coder::array<creal_T, 1U> ytmp;
  ::coder::array<double, 2U> a__1;
  ::coder::array<double, 2U> costable;
  ::coder::array<double, 2U> hcostabinv;
  ::coder::array<double, 2U> hsintab;
  ::coder::array<double, 2U> hsintabinv;
  ::coder::array<double, 2U> sintable;
  ::coder::array<int, 2U> wrapIndex;
  double a_im;
  double a_re;
  double b_im;
  double b_re;
  int hnRows;
  int k1;
  int minHnrowsNxBy2;
  int u0;
  boolean_T nxeven;
  hnRows = nRows / 2;
  ytmp.set_size(hnRows);
  if (hnRows > nrowsx) {
    ytmp.set_size(hnRows);
    for (k1 = 0; k1 < hnRows; k1++) {
      ytmp[k1].re = 0.0;
      ytmp[k1].im = 0.0;
    }
  }
  if ((x.size(0) & 1) == 0) {
    nxeven = true;
    u0 = x.size(0);
  } else if (x.size(0) >= nRows) {
    nxeven = true;
    u0 = nRows;
  } else {
    nxeven = false;
    u0 = x.size(0) - 1;
  }
  FFTImplementationCallback::b_generate_twiddle_tables(nRows << 1, costable,
                                                       sintable, a__1);
  FFTImplementationCallback::get_half_twiddle_tables(costab, sintab, costabinv,
                                                     sintabinv, a__1, hsintab,
                                                     hcostabinv, hsintabinv);
  reconVar1.set_size(hnRows);
  reconVar2.set_size(hnRows);
  wrapIndex.set_size(1, hnRows);
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    k1 = minHnrowsNxBy2 << 1;
    a_re = sintable[k1];
    a_im = costable[k1];
    reconVar1[minHnrowsNxBy2].re = a_re + 1.0;
    reconVar1[minHnrowsNxBy2].im = -a_im;
    reconVar2[minHnrowsNxBy2].re = 1.0 - a_re;
    reconVar2[minHnrowsNxBy2].im = a_im;
    if (minHnrowsNxBy2 + 1 != 1) {
      wrapIndex[minHnrowsNxBy2] = (hnRows - minHnrowsNxBy2) + 1;
    } else {
      wrapIndex[0] = 1;
    }
  }
  if (u0 > nRows) {
    u0 = nRows;
  }
  minHnrowsNxBy2 = u0 / 2 - 1;
  for (k1 = 0; k1 <= minHnrowsNxBy2; k1++) {
    u0 = (hnRows + k1) - 1;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    u0 = xoffInit + (k1 << 1);
    b_re = x[u0];
    b_im = x[u0 + 1];
    ytmp[k1].re = a_re * b_re + a_im * b_im;
    ytmp[k1].im = a_re * b_im - a_im * b_re;
  }
  if (!nxeven) {
    u0 = hnRows + minHnrowsNxBy2;
    a_re = wwc[u0].re;
    a_im = wwc[u0].im;
    if (minHnrowsNxBy2 < 0) {
      u0 = xoffInit;
    } else {
      u0 = xoffInit + ((minHnrowsNxBy2 + 1) << 1);
    }
    b_re = x[u0];
    ytmp[minHnrowsNxBy2 + 1].re = a_re * b_re + a_im * 0.0;
    ytmp[minHnrowsNxBy2 + 1].im = a_re * 0.0 - a_im * b_re;
    if (minHnrowsNxBy2 + 3 <= hnRows) {
      k1 = minHnrowsNxBy2 + 3;
      for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
        ytmp[minHnrowsNxBy2 - 1].re = 0.0;
        ytmp[minHnrowsNxBy2 - 1].im = 0.0;
      }
    }
  } else if (minHnrowsNxBy2 + 2 <= hnRows) {
    k1 = minHnrowsNxBy2 + 2;
    for (minHnrowsNxBy2 = k1; minHnrowsNxBy2 <= hnRows; minHnrowsNxBy2++) {
      ytmp[minHnrowsNxBy2 - 1].re = 0.0;
      ytmp[minHnrowsNxBy2 - 1].im = 0.0;
    }
  }
  u0 = nfft / 2;
  FFTImplementationCallback::r2br_r2dit_trig_impl(ytmp, u0, a__1, hsintab, fv);
  FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, u0, a__1, hsintab, b_fv);
  minHnrowsNxBy2 = fv.size(0);
  b_fv.set_size(fv.size(0));
  for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
    a_re = fv[k1].re;
    a_im = b_fv[k1].im;
    b_re = fv[k1].im;
    b_im = b_fv[k1].re;
    b_fv[k1].re = a_re * b_im - b_re * a_im;
    b_fv[k1].im = a_re * a_im + b_re * b_im;
  }
  FFTImplementationCallback::r2br_r2dit_trig_impl(b_fv, u0, hcostabinv,
                                                  hsintabinv, fv);
  if (fv.size(0) > 1) {
    a_re = 1.0 / static_cast<double>(fv.size(0));
    minHnrowsNxBy2 = fv.size(0);
    for (k1 = 0; k1 < minHnrowsNxBy2; k1++) {
      fv[k1].re = a_re * fv[k1].re;
      fv[k1].im = a_re * fv[k1].im;
    }
  }
  k1 = wwc.size(0);
  for (minHnrowsNxBy2 = hnRows; minHnrowsNxBy2 <= k1; minHnrowsNxBy2++) {
    a_re = wwc[minHnrowsNxBy2 - 1].re;
    a_im = fv[minHnrowsNxBy2 - 1].im;
    b_re = wwc[minHnrowsNxBy2 - 1].im;
    b_im = fv[minHnrowsNxBy2 - 1].re;
    u0 = minHnrowsNxBy2 - hnRows;
    ytmp[u0].re = a_re * b_im + b_re * a_im;
    ytmp[u0].im = a_re * a_im - b_re * b_im;
  }
  for (minHnrowsNxBy2 = 0; minHnrowsNxBy2 < hnRows; minHnrowsNxBy2++) {
    double b_ytmp_re_tmp;
    double c_ytmp_re_tmp;
    double ytmp_im_tmp;
    double ytmp_re_tmp;
    k1 = wrapIndex[minHnrowsNxBy2];
    a_re = ytmp[minHnrowsNxBy2].re;
    a_im = reconVar1[minHnrowsNxBy2].im;
    b_re = ytmp[minHnrowsNxBy2].im;
    b_im = reconVar1[minHnrowsNxBy2].re;
    ytmp_re_tmp = ytmp[k1 - 1].re;
    ytmp_im_tmp = -ytmp[k1 - 1].im;
    b_ytmp_re_tmp = reconVar2[minHnrowsNxBy2].im;
    c_ytmp_re_tmp = reconVar2[minHnrowsNxBy2].re;
    y[minHnrowsNxBy2].re =
        0.5 * ((a_re * b_im - b_re * a_im) +
               (ytmp_re_tmp * c_ytmp_re_tmp - ytmp_im_tmp * b_ytmp_re_tmp));
    y[minHnrowsNxBy2].im =
        0.5 * ((a_re * a_im + b_re * b_im) +
               (ytmp_re_tmp * b_ytmp_re_tmp + ytmp_im_tmp * c_ytmp_re_tmp));
    k1 = hnRows + minHnrowsNxBy2;
    y[k1].re = 0.5 * ((a_re * c_ytmp_re_tmp - b_re * b_ytmp_re_tmp) +
                      (ytmp_re_tmp * b_im - ytmp_im_tmp * a_im));
    y[k1].im = 0.5 * ((a_re * b_ytmp_re_tmp + b_re * c_ytmp_re_tmp) +
                      (ytmp_re_tmp * a_im + ytmp_im_tmp * b_im));
  }
}

void FFTImplementationCallback::doHalfLengthRadix2(
    const ::coder::array<double, 2U> &x, int xoffInit,
    ::coder::array<creal_T, 1U> &y, int unsigned_nRows,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab)
{
  ::coder::array<creal_T, 1U> reconVar1;
  ::coder::array<creal_T, 1U> reconVar2;
  ::coder::array<double, 2U> hcostab;
  ::coder::array<double, 2U> hsintab;
  ::coder::array<int, 2U> wrapIndex;
  ::coder::array<int, 1U> bitrevIndex;
  double im;
  double re;
  double temp_im;
  double temp_re;
  double twid_im;
  double twid_re;
  int hszCostab;
  int i;
  int iDelta;
  int iDelta2;
  int iheight;
  int ihi;
  int j;
  int k;
  int nRowsD2;
  int nRows_tmp;
  boolean_T nxeven;
  nRows_tmp = unsigned_nRows / 2;
  ihi = nRows_tmp - 2;
  nRowsD2 = nRows_tmp / 2;
  k = nRowsD2 / 2;
  hszCostab = static_cast<int>(static_cast<unsigned int>(costab.size(1)) >> 1);
  hcostab.set_size(1, hszCostab);
  hsintab.set_size(1, hszCostab);
  for (i = 0; i < hszCostab; i++) {
    j = ((i + 1) << 1) - 2;
    hcostab[i] = costab[j];
    hsintab[i] = sintab[j];
  }
  reconVar1.set_size(nRows_tmp);
  reconVar2.set_size(nRows_tmp);
  wrapIndex.set_size(1, nRows_tmp);
  for (i = 0; i < nRows_tmp; i++) {
    re = sintab[i];
    im = costab[i];
    reconVar1[i].re = re + 1.0;
    reconVar1[i].im = -im;
    reconVar2[i].re = 1.0 - re;
    reconVar2[i].im = im;
    if (i + 1 != 1) {
      wrapIndex[i] = (nRows_tmp - i) + 1;
    } else {
      wrapIndex[0] = 1;
    }
  }
  hszCostab = y.size(0);
  if (hszCostab > nRows_tmp) {
    hszCostab = nRows_tmp;
  }
  FFTImplementationCallback::get_bitrevIndex(hszCostab - 1, nRows_tmp,
                                             bitrevIndex);
  if ((x.size(0) & 1) == 0) {
    nxeven = true;
    hszCostab = x.size(0);
  } else if (x.size(0) >= unsigned_nRows) {
    nxeven = true;
    hszCostab = unsigned_nRows;
  } else {
    nxeven = false;
    hszCostab = x.size(0) - 1;
  }
  if (hszCostab > unsigned_nRows) {
    hszCostab = unsigned_nRows;
  }
  hszCostab /= 2;
  for (i = 0; i < hszCostab; i++) {
    j = xoffInit + (i << 1);
    y[bitrevIndex[i] - 1].re = x[j];
    y[bitrevIndex[i] - 1].im = x[j + 1];
  }
  if (!nxeven) {
    if (hszCostab - 1 < 0) {
      j = xoffInit;
    } else {
      j = xoffInit + (hszCostab << 1);
    }
    y[bitrevIndex[hszCostab] - 1].re = x[j];
    y[bitrevIndex[hszCostab] - 1].im = 0.0;
  }
  if (nRows_tmp > 1) {
    for (i = 0; i <= ihi; i += 2) {
      re = y[i + 1].re;
      im = y[i + 1].im;
      temp_re = re;
      temp_im = im;
      twid_re = y[i].re;
      twid_im = y[i].im;
      re = twid_re - re;
      im = twid_im - im;
      y[i + 1].re = re;
      y[i + 1].im = im;
      twid_re += temp_re;
      twid_im += temp_im;
      y[i].re = twid_re;
      y[i].im = twid_im;
    }
  }
  iDelta = 2;
  iDelta2 = 4;
  iheight = ((k - 1) << 2) + 1;
  while (k > 0) {
    for (i = 0; i < iheight; i += iDelta2) {
      hszCostab = i + iDelta;
      temp_re = y[hszCostab].re;
      temp_im = y[hszCostab].im;
      y[hszCostab].re = y[i].re - temp_re;
      y[hszCostab].im = y[i].im - temp_im;
      y[i].re = y[i].re + temp_re;
      y[i].im = y[i].im + temp_im;
    }
    hszCostab = 1;
    for (j = k; j < nRowsD2; j += k) {
      twid_re = hcostab[j];
      twid_im = hsintab[j];
      i = hszCostab;
      ihi = hszCostab + iheight;
      while (i < ihi) {
        int temp_re_tmp_tmp;
        temp_re_tmp_tmp = i + iDelta;
        re = y[temp_re_tmp_tmp].im;
        im = y[temp_re_tmp_tmp].re;
        temp_re = twid_re * im - twid_im * re;
        temp_im = twid_re * re + twid_im * im;
        y[temp_re_tmp_tmp].re = y[i].re - temp_re;
        y[temp_re_tmp_tmp].im = y[i].im - temp_im;
        y[i].re = y[i].re + temp_re;
        y[i].im = y[i].im + temp_im;
        i += iDelta2;
      }
      hszCostab++;
    }
    k /= 2;
    iDelta = iDelta2;
    iDelta2 += iDelta2;
    iheight -= iDelta;
  }
  FFTImplementationCallback::getback_radix2_fft(y, reconVar1, reconVar2,
                                                wrapIndex, nRows_tmp);
}

void FFTImplementationCallback::get_bitrevIndex(
    int nRowsM1, int nfftLen, ::coder::array<int, 1U> &bitrevIndex)
{
  int iy;
  int ju;
  ju = 0;
  iy = 1;
  bitrevIndex.set_size(nfftLen);
  for (int b_j1{0}; b_j1 < nfftLen; b_j1++) {
    bitrevIndex[b_j1] = 0;
  }
  for (int b_j1{0}; b_j1 < nRowsM1; b_j1++) {
    boolean_T tst;
    bitrevIndex[b_j1] = iy;
    iy = nfftLen;
    tst = true;
    while (tst) {
      iy >>= 1;
      ju ^= iy;
      tst = ((ju & iy) == 0);
    }
    iy = ju + 1;
  }
  bitrevIndex[nRowsM1] = iy;
}

void FFTImplementationCallback::get_half_twiddle_tables(
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &costabinv,
    const ::coder::array<double, 2U> &sintabinv,
    ::coder::array<double, 2U> &hcostab, ::coder::array<double, 2U> &hsintab,
    ::coder::array<double, 2U> &hcostabinv,
    ::coder::array<double, 2U> &hsintabinv)
{
  int hszCostab;
  hszCostab = static_cast<int>(static_cast<unsigned int>(costab.size(1)) >> 1);
  hcostab.set_size(1, hszCostab);
  hsintab.set_size(1, hszCostab);
  hcostabinv.set_size(1, hszCostab);
  hsintabinv.set_size(1, hszCostab);
  for (int i{0}; i < hszCostab; i++) {
    int hcostab_tmp;
    hcostab_tmp = ((i + 1) << 1) - 2;
    hcostab[i] = costab[hcostab_tmp];
    hsintab[i] = sintab[hcostab_tmp];
    hcostabinv[i] = costabinv[hcostab_tmp];
    hsintabinv[i] = sintabinv[hcostab_tmp];
  }
}

void FFTImplementationCallback::getback_radix2_fft(
    ::coder::array<creal_T, 1U> &y,
    const ::coder::array<creal_T, 1U> &reconVar1,
    const ::coder::array<creal_T, 1U> &reconVar2,
    const ::coder::array<int, 2U> &wrapIndex, int hnRows)
{
  double b_temp1_re_tmp;
  double b_temp2_re_tmp;
  double b_y_re_tmp;
  double c_y_re_tmp;
  double d_y_re_tmp;
  double temp1_im_tmp;
  double temp1_re_tmp;
  double temp1_re_tmp_tmp;
  double y_im_tmp;
  double y_re_tmp;
  int b_i;
  int iterVar;
  iterVar = hnRows / 2;
  temp1_re_tmp_tmp = y[0].re;
  temp1_im_tmp = y[0].im;
  y_re_tmp = temp1_re_tmp_tmp * reconVar1[0].re;
  y_im_tmp = temp1_re_tmp_tmp * reconVar1[0].im;
  b_y_re_tmp = temp1_re_tmp_tmp * reconVar2[0].re;
  temp1_re_tmp_tmp *= reconVar2[0].im;
  y[0].re = 0.5 * ((y_re_tmp - temp1_im_tmp * reconVar1[0].im) +
                   (b_y_re_tmp - -temp1_im_tmp * reconVar2[0].im));
  y[0].im = 0.5 * ((y_im_tmp + temp1_im_tmp * reconVar1[0].re) +
                   (temp1_re_tmp_tmp + -temp1_im_tmp * reconVar2[0].re));
  y[hnRows].re = 0.5 * ((b_y_re_tmp - temp1_im_tmp * reconVar2[0].im) +
                        (y_re_tmp - -temp1_im_tmp * reconVar1[0].im));
  y[hnRows].im = 0.5 * ((temp1_re_tmp_tmp + temp1_im_tmp * reconVar2[0].re) +
                        (y_im_tmp + -temp1_im_tmp * reconVar1[0].re));
  for (int i{2}; i <= iterVar; i++) {
    double temp2_im_tmp;
    double temp2_re_tmp;
    int i1;
    temp1_re_tmp = y[i - 1].re;
    temp1_im_tmp = y[i - 1].im;
    b_i = wrapIndex[i - 1];
    temp2_re_tmp = y[b_i - 1].re;
    temp2_im_tmp = y[b_i - 1].im;
    y_re_tmp = reconVar1[i - 1].im;
    b_y_re_tmp = reconVar1[i - 1].re;
    c_y_re_tmp = reconVar2[i - 1].im;
    d_y_re_tmp = reconVar2[i - 1].re;
    y[i - 1].re =
        0.5 * ((temp1_re_tmp * b_y_re_tmp - temp1_im_tmp * y_re_tmp) +
               (temp2_re_tmp * d_y_re_tmp - -temp2_im_tmp * c_y_re_tmp));
    y[i - 1].im =
        0.5 * ((temp1_re_tmp * y_re_tmp + temp1_im_tmp * b_y_re_tmp) +
               (temp2_re_tmp * c_y_re_tmp + -temp2_im_tmp * d_y_re_tmp));
    i1 = (hnRows + i) - 1;
    y[i1].re = 0.5 * ((temp1_re_tmp * d_y_re_tmp - temp1_im_tmp * c_y_re_tmp) +
                      (temp2_re_tmp * b_y_re_tmp - -temp2_im_tmp * y_re_tmp));
    y[i1].im = 0.5 * ((temp1_re_tmp * c_y_re_tmp + temp1_im_tmp * d_y_re_tmp) +
                      (temp2_re_tmp * y_re_tmp + -temp2_im_tmp * b_y_re_tmp));
    temp1_re_tmp_tmp = reconVar1[b_i - 1].im;
    b_temp2_re_tmp = reconVar1[b_i - 1].re;
    b_temp1_re_tmp = reconVar2[b_i - 1].im;
    y_im_tmp = reconVar2[b_i - 1].re;
    y[b_i - 1].re =
        0.5 *
        ((temp2_re_tmp * b_temp2_re_tmp - temp2_im_tmp * temp1_re_tmp_tmp) +
         (temp1_re_tmp * y_im_tmp - -temp1_im_tmp * b_temp1_re_tmp));
    y[b_i - 1].im =
        0.5 *
        ((temp2_re_tmp * temp1_re_tmp_tmp + temp2_im_tmp * b_temp2_re_tmp) +
         (temp1_re_tmp * b_temp1_re_tmp + -temp1_im_tmp * y_im_tmp));
    b_i = (b_i + hnRows) - 1;
    y[b_i].re =
        0.5 *
        ((temp2_re_tmp * y_im_tmp - temp2_im_tmp * b_temp1_re_tmp) +
         (temp1_re_tmp * b_temp2_re_tmp - -temp1_im_tmp * temp1_re_tmp_tmp));
    y[b_i].im =
        0.5 *
        ((temp2_re_tmp * b_temp1_re_tmp + temp2_im_tmp * y_im_tmp) +
         (temp1_re_tmp * temp1_re_tmp_tmp + -temp1_im_tmp * b_temp2_re_tmp));
  }
  if (iterVar != 0) {
    temp1_re_tmp = y[iterVar].re;
    temp1_im_tmp = y[iterVar].im;
    y_re_tmp = reconVar1[iterVar].im;
    b_y_re_tmp = reconVar1[iterVar].re;
    c_y_re_tmp = temp1_re_tmp * b_y_re_tmp;
    y_im_tmp = temp1_re_tmp * y_re_tmp;
    d_y_re_tmp = reconVar2[iterVar].im;
    b_temp2_re_tmp = reconVar2[iterVar].re;
    b_temp1_re_tmp = temp1_re_tmp * b_temp2_re_tmp;
    temp1_re_tmp_tmp = temp1_re_tmp * d_y_re_tmp;
    y[iterVar].re = 0.5 * ((c_y_re_tmp - temp1_im_tmp * y_re_tmp) +
                           (b_temp1_re_tmp - -temp1_im_tmp * d_y_re_tmp));
    y[iterVar].im = 0.5 * ((y_im_tmp + temp1_im_tmp * b_y_re_tmp) +
                           (temp1_re_tmp_tmp + -temp1_im_tmp * b_temp2_re_tmp));
    b_i = hnRows + iterVar;
    y[b_i].re = 0.5 * ((b_temp1_re_tmp - temp1_im_tmp * d_y_re_tmp) +
                       (c_y_re_tmp - -temp1_im_tmp * y_re_tmp));
    y[b_i].im = 0.5 * ((temp1_re_tmp_tmp + temp1_im_tmp * b_temp2_re_tmp) +
                       (y_im_tmp + -temp1_im_tmp * b_y_re_tmp));
  }
}

void FFTImplementationCallback::r2br_r2dit_trig_impl(
    const ::coder::array<double, 2U> &x, int xoffInit, int unsigned_nRows,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 1U> &y)
{
  y.set_size(unsigned_nRows);
  if (unsigned_nRows > x.size(0)) {
    y.set_size(unsigned_nRows);
    for (int i{0}; i < unsigned_nRows; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  if (unsigned_nRows != 1) {
    FFTImplementationCallback::doHalfLengthRadix2(
        x, xoffInit, y, unsigned_nRows, costab, sintab);
  } else {
    y[0].re = x[xoffInit];
    y[0].im = 0.0;
  }
}

void FFTImplementationCallback::r2br_r2dit_trig_impl(
    const ::coder::array<creal_T, 2U> &x, int xoffInit, int unsigned_nRows,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 1U> &y)
{
  double temp_im;
  double temp_re;
  double temp_re_tmp;
  double twid_re;
  int i;
  int iDelta;
  int iDelta2;
  int iheight;
  int ihi;
  int iy;
  int j;
  int ju;
  int k;
  int nRowsD2;
  y.set_size(unsigned_nRows);
  if (unsigned_nRows > x.size(0)) {
    y.set_size(unsigned_nRows);
    for (iy = 0; iy < unsigned_nRows; iy++) {
      y[iy].re = 0.0;
      y[iy].im = 0.0;
    }
  }
  j = x.size(0);
  if (j > unsigned_nRows) {
    j = unsigned_nRows;
  }
  ihi = unsigned_nRows - 2;
  nRowsD2 = unsigned_nRows / 2;
  k = nRowsD2 / 2;
  iy = 0;
  ju = 0;
  for (i = 0; i <= j - 2; i++) {
    boolean_T tst;
    y[iy] = x[xoffInit + i];
    iy = unsigned_nRows;
    tst = true;
    while (tst) {
      iy >>= 1;
      ju ^= iy;
      tst = ((ju & iy) == 0);
    }
    iy = ju;
  }
  if (j - 2 < 0) {
    j = xoffInit;
  } else {
    j = (xoffInit + j) - 1;
  }
  y[iy] = x[j];
  if (unsigned_nRows > 1) {
    for (i = 0; i <= ihi; i += 2) {
      temp_re_tmp = y[i + 1].re;
      temp_im = y[i + 1].im;
      temp_re = y[i].re;
      twid_re = y[i].im;
      y[i + 1].re = temp_re - temp_re_tmp;
      y[i + 1].im = twid_re - temp_im;
      y[i].re = temp_re + temp_re_tmp;
      y[i].im = twid_re + temp_im;
    }
  }
  iDelta = 2;
  iDelta2 = 4;
  iheight = ((k - 1) << 2) + 1;
  while (k > 0) {
    for (i = 0; i < iheight; i += iDelta2) {
      iy = i + iDelta;
      temp_re = y[iy].re;
      temp_im = y[iy].im;
      y[iy].re = y[i].re - temp_re;
      y[iy].im = y[i].im - temp_im;
      y[i].re = y[i].re + temp_re;
      y[i].im = y[i].im + temp_im;
    }
    iy = 1;
    for (j = k; j < nRowsD2; j += k) {
      double twid_im;
      twid_re = costab[j];
      twid_im = sintab[j];
      i = iy;
      ihi = iy + iheight;
      while (i < ihi) {
        ju = i + iDelta;
        temp_re_tmp = y[ju].im;
        temp_im = y[ju].re;
        temp_re = twid_re * temp_im - twid_im * temp_re_tmp;
        temp_im = twid_re * temp_re_tmp + twid_im * temp_im;
        y[ju].re = y[i].re - temp_re;
        y[ju].im = y[i].im - temp_im;
        y[i].re = y[i].re + temp_re;
        y[i].im = y[i].im + temp_im;
        i += iDelta2;
      }
      iy++;
    }
    k /= 2;
    iDelta = iDelta2;
    iDelta2 += iDelta2;
    iheight -= iDelta;
  }
}

void FFTImplementationCallback::b_dobluesteinfft(
    const ::coder::array<creal_T, 2U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> r;
  ::coder::array<creal_T, 1U> wwc;
  double a_im;
  double a_re;
  double b_re_tmp;
  double re_tmp;
  int b_k;
  int b_y;
  int i;
  int i1;
  int minNrowsNx;
  int nInt2;
  int nInt2m1;
  int rt;
  int u0;
  int xoff;
  nInt2m1 = (nfft + nfft) - 1;
  wwc.set_size(nInt2m1);
  rt = 0;
  wwc[nfft - 1].re = 1.0;
  wwc[nfft - 1].im = 0.0;
  nInt2 = nfft << 1;
  for (int k{0}; k <= nfft - 2; k++) {
    double nt_im;
    b_y = ((k + 1) << 1) - 1;
    if (nInt2 - rt <= b_y) {
      rt += b_y - nInt2;
    } else {
      rt += b_y;
    }
    nt_im = -3.1415926535897931 * static_cast<double>(rt) /
            static_cast<double>(nfft);
    i = (nfft - k) - 2;
    wwc[i].re = std::cos(nt_im);
    wwc[i].im = -std::sin(nt_im);
  }
  i = nInt2m1 - 1;
  for (int k{i}; k >= nfft; k--) {
    wwc[k] = wwc[(nInt2m1 - k) - 1];
  }
  nInt2m1 = x.size(0);
  y.set_size(nfft, x.size(1));
  if (nfft > x.size(0)) {
    y.set_size(nfft, x.size(1));
    b_y = nfft * x.size(1);
    for (i = 0; i < b_y; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  b_y = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        fv, b_fv, r, xoff, i1, minNrowsNx, b_k, u0, a_re, a_im, re_tmp,        \
            b_re_tmp)

  for (int chan = 0; chan <= b_y; chan++) {
    xoff = chan * nInt2m1;
    r.set_size(nfft);
    if (nfft > x.size(0)) {
      r.set_size(nfft);
      for (i1 = 0; i1 < nfft; i1++) {
        r[i1].re = 0.0;
        r[i1].im = 0.0;
      }
    }
    minNrowsNx = x.size(0);
    if (nfft <= minNrowsNx) {
      minNrowsNx = nfft;
    }
    for (b_k = 0; b_k < minNrowsNx; b_k++) {
      u0 = (nfft + b_k) - 1;
      a_re = wwc[u0].re;
      a_im = wwc[u0].im;
      i1 = xoff + b_k;
      r[b_k].re = a_re * x[i1].re + a_im * x[i1].im;
      r[b_k].im = a_re * x[i1].im - a_im * x[i1].re;
    }
    i1 = minNrowsNx + 1;
    for (b_k = i1; b_k <= nfft; b_k++) {
      r[b_k - 1].re = 0.0;
      r[b_k - 1].im = 0.0;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(r, n2blue, costab, sintab,
                                                    b_fv);
    FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab, sintab,
                                                    fv);
    fv.set_size(b_fv.size(0));
    u0 = b_fv.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      a_re = b_fv[i1].re;
      a_im = fv[i1].im;
      re_tmp = b_fv[i1].im;
      b_re_tmp = fv[i1].re;
      fv[i1].re = a_re * b_re_tmp - re_tmp * a_im;
      fv[i1].im = a_re * a_im + re_tmp * b_re_tmp;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(fv, n2blue, costab,
                                                    sintabinv, b_fv);
    if (b_fv.size(0) > 1) {
      a_re = 1.0 / static_cast<double>(b_fv.size(0));
      u0 = b_fv.size(0);
      for (i1 = 0; i1 < u0; i1++) {
        b_fv[i1].re = a_re * b_fv[i1].re;
        b_fv[i1].im = a_re * b_fv[i1].im;
      }
    }
    i1 = wwc.size(0);
    for (b_k = nfft; b_k <= i1; b_k++) {
      a_re = wwc[b_k - 1].re;
      a_im = b_fv[b_k - 1].im;
      re_tmp = wwc[b_k - 1].im;
      b_re_tmp = b_fv[b_k - 1].re;
      u0 = b_k - nfft;
      r[u0].re = a_re * b_re_tmp + re_tmp * a_im;
      r[u0].im = a_re * a_im - re_tmp * b_re_tmp;
    }
    u0 = y.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::b_dobluesteinfft(
    const ::coder::array<double, 2U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> r;
  ::coder::array<creal_T, 1U> wwc;
  double ar;
  double b_re_tmp;
  double c_re_tmp;
  double d_re_tmp;
  double re_tmp;
  int b_k;
  int b_y;
  int i;
  int i1;
  int minNrowsNx;
  int nInt2m1;
  int u0;
  int xoff;
  if ((nfft != 1) && ((nfft & 1) == 0)) {
    int nInt2;
    int nRows;
    int rt;
    nRows = nfft / 2;
    nInt2m1 = (nRows + nRows) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nRows - 1].re = 1.0;
    wwc[nRows - 1].im = 0.0;
    nInt2 = nRows << 1;
    for (int k{0}; k <= nRows - 2; k++) {
      double nt_im;
      b_y = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= b_y) {
        rt += b_y - nInt2;
      } else {
        rt += b_y;
      }
      nt_im = 3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nRows);
      i = (nRows - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nRows; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  } else {
    int nInt2;
    int rt;
    nInt2m1 = (nfft + nfft) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nfft - 1].re = 1.0;
    wwc[nfft - 1].im = 0.0;
    nInt2 = nfft << 1;
    for (int k{0}; k <= nfft - 2; k++) {
      double nt_im;
      b_y = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= b_y) {
        rt += b_y - nInt2;
      } else {
        rt += b_y;
      }
      nt_im = 3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nfft);
      i = (nfft - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nfft; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  }
  nInt2m1 = x.size(0);
  y.set_size(nfft, x.size(1));
  if (nfft > x.size(0)) {
    y.set_size(nfft, x.size(1));
    b_y = nfft * x.size(1);
    for (i = 0; i < b_y; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  b_y = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        fv, b_fv, r, xoff, i1, minNrowsNx, u0, b_k, re_tmp, b_re_tmp,          \
            c_re_tmp, d_re_tmp, ar)

  for (int chan = 0; chan <= b_y; chan++) {
    xoff = chan * nInt2m1;
    r.set_size(nfft);
    if (nfft > x.size(0)) {
      r.set_size(nfft);
      for (i1 = 0; i1 < nfft; i1++) {
        r[i1].re = 0.0;
        r[i1].im = 0.0;
      }
    }
    if ((n2blue != 1) && ((nfft & 1) == 0)) {
      FFTImplementationCallback::b_doHalfLengthBluestein(
          x, xoff, r, x.size(0), nfft, n2blue, wwc, costab, sintab, costab,
          sintabinv);
    } else {
      minNrowsNx = x.size(0);
      if (nfft <= minNrowsNx) {
        minNrowsNx = nfft;
      }
      for (b_k = 0; b_k < minNrowsNx; b_k++) {
        u0 = (nfft + b_k) - 1;
        i1 = xoff + b_k;
        r[b_k].re = wwc[u0].re * x[i1];
        r[b_k].im = wwc[u0].im * -x[i1];
      }
      i1 = minNrowsNx + 1;
      for (b_k = i1; b_k <= nfft; b_k++) {
        r[b_k - 1].re = 0.0;
        r[b_k - 1].im = 0.0;
      }
      FFTImplementationCallback::r2br_r2dit_trig_impl(r, n2blue, costab, sintab,
                                                      b_fv);
      FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab,
                                                      sintab, fv);
      fv.set_size(b_fv.size(0));
      u0 = b_fv.size(0);
      for (i1 = 0; i1 < u0; i1++) {
        re_tmp = b_fv[i1].re;
        b_re_tmp = fv[i1].im;
        c_re_tmp = b_fv[i1].im;
        d_re_tmp = fv[i1].re;
        fv[i1].re = re_tmp * d_re_tmp - c_re_tmp * b_re_tmp;
        fv[i1].im = re_tmp * b_re_tmp + c_re_tmp * d_re_tmp;
      }
      FFTImplementationCallback::r2br_r2dit_trig_impl(fv, n2blue, costab,
                                                      sintabinv, b_fv);
      if (b_fv.size(0) > 1) {
        re_tmp = 1.0 / static_cast<double>(b_fv.size(0));
        u0 = b_fv.size(0);
        for (i1 = 0; i1 < u0; i1++) {
          b_fv[i1].re = re_tmp * b_fv[i1].re;
          b_fv[i1].im = re_tmp * b_fv[i1].im;
        }
      }
      i1 = wwc.size(0);
      for (b_k = nfft; b_k <= i1; b_k++) {
        re_tmp = wwc[b_k - 1].re;
        b_re_tmp = b_fv[b_k - 1].im;
        c_re_tmp = wwc[b_k - 1].im;
        d_re_tmp = b_fv[b_k - 1].re;
        ar = re_tmp * d_re_tmp + c_re_tmp * b_re_tmp;
        re_tmp = re_tmp * b_re_tmp - c_re_tmp * d_re_tmp;
        if (re_tmp == 0.0) {
          u0 = b_k - nfft;
          r[u0].re = ar / static_cast<double>(nfft);
          r[u0].im = 0.0;
        } else if (ar == 0.0) {
          u0 = b_k - nfft;
          r[u0].re = 0.0;
          r[u0].im = re_tmp / static_cast<double>(nfft);
        } else {
          u0 = b_k - nfft;
          r[u0].re = ar / static_cast<double>(nfft);
          r[u0].im = re_tmp / static_cast<double>(nfft);
        }
      }
    }
    u0 = y.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::b_r2br_r2dit_trig(
    const ::coder::array<double, 2U> &x, int n1_unsigned,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> r;
  int i1;
  int loop_ub;
  int nrows;
  int xoff;
  nrows = x.size(0);
  y.set_size(n1_unsigned, x.size(1));
  if (n1_unsigned > x.size(0)) {
    y.set_size(n1_unsigned, x.size(1));
    loop_ub = n1_unsigned * x.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  loop_ub = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(r, xoff, i1)

  for (int chan = 0; chan <= loop_ub; chan++) {
    xoff = chan * nrows;
    FFTImplementationCallback::r2br_r2dit_trig_impl(x, xoff, n1_unsigned,
                                                    costab, sintab, r);
    xoff = y.size(0);
    for (i1 = 0; i1 < xoff; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
  if (y.size(0) > 1) {
    double b;
    b = 1.0 / static_cast<double>(y.size(0));
    loop_ub = y.size(0) * y.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = b * y[i].re;
      y[i].im = b * y[i].im;
    }
  }
}

void FFTImplementationCallback::b_r2br_r2dit_trig(
    const ::coder::array<creal_T, 2U> &x, int n1_unsigned,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> r;
  int i1;
  int loop_ub;
  int nrows;
  int xoff;
  nrows = x.size(0);
  y.set_size(n1_unsigned, x.size(1));
  if (n1_unsigned > x.size(0)) {
    y.set_size(n1_unsigned, x.size(1));
    loop_ub = n1_unsigned * x.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  loop_ub = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(r, xoff, i1)

  for (int chan = 0; chan <= loop_ub; chan++) {
    xoff = chan * nrows;
    FFTImplementationCallback::r2br_r2dit_trig_impl(x, xoff, n1_unsigned,
                                                    costab, sintab, r);
    xoff = y.size(0);
    for (i1 = 0; i1 < xoff; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::c_generate_twiddle_tables(
    int nRows, boolean_T useRadix2, ::coder::array<double, 2U> &costab,
    ::coder::array<double, 2U> &sintab, ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<double, 2U> costab1q;
  double e;
  int i;
  int n;
  int nd2;
  e = 6.2831853071795862 / static_cast<double>(nRows);
  n = nRows / 2 / 2;
  costab1q.set_size(1, n + 1);
  costab1q[0] = 1.0;
  nd2 = static_cast<int>(static_cast<unsigned int>(n) >> 1) - 1;
  for (int k{0}; k <= nd2; k++) {
    costab1q[k + 1] = std::cos(e * (static_cast<double>(k) + 1.0));
  }
  i = nd2 + 2;
  nd2 = n - 1;
  for (int k{i}; k <= nd2; k++) {
    costab1q[k] = std::sin(e * static_cast<double>(n - k));
  }
  costab1q[n] = 0.0;
  if (!useRadix2) {
    n = costab1q.size(1) - 1;
    nd2 = (costab1q.size(1) - 1) << 1;
    costab.set_size(1, nd2 + 1);
    sintab.set_size(1, nd2 + 1);
    costab[0] = 1.0;
    sintab[0] = 0.0;
    sintabinv.set_size(1, nd2 + 1);
    for (int k{0}; k < n; k++) {
      sintabinv[k + 1] = costab1q[(n - k) - 1];
    }
    i = costab1q.size(1);
    for (int k{i}; k <= nd2; k++) {
      sintabinv[k] = costab1q[k - n];
    }
    for (int k{0}; k < n; k++) {
      costab[k + 1] = costab1q[k + 1];
      sintab[k + 1] = -costab1q[(n - k) - 1];
    }
    for (int k{i}; k <= nd2; k++) {
      costab[k] = -costab1q[nd2 - k];
      sintab[k] = -costab1q[k - n];
    }
  } else {
    n = costab1q.size(1) - 1;
    nd2 = (costab1q.size(1) - 1) << 1;
    costab.set_size(1, nd2 + 1);
    sintab.set_size(1, nd2 + 1);
    costab[0] = 1.0;
    sintab[0] = 0.0;
    for (int k{0}; k < n; k++) {
      costab[k + 1] = costab1q[k + 1];
      sintab[k + 1] = costab1q[(n - k) - 1];
    }
    i = costab1q.size(1);
    for (int k{i}; k <= nd2; k++) {
      costab[k] = -costab1q[nd2 - k];
      sintab[k] = costab1q[k - n];
    }
    sintabinv.set_size(1, 0);
  }
}

void FFTImplementationCallback::doHalfLengthRadix2(
    const ::coder::array<double, 1U> &x, ::coder::array<creal_T, 1U> &y,
    int unsigned_nRows, const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab)
{
  ::coder::array<creal_T, 1U> reconVar1;
  ::coder::array<creal_T, 1U> reconVar2;
  ::coder::array<double, 2U> hcostab;
  ::coder::array<double, 2U> hsintab;
  ::coder::array<int, 2U> wrapIndex;
  ::coder::array<int, 1U> bitrevIndex;
  double im;
  double re;
  double temp_im;
  double temp_re;
  double twid_im;
  double twid_re;
  int hszCostab;
  int i;
  int iDelta;
  int iDelta2;
  int iheight;
  int ihi;
  int j;
  int k;
  int nRowsD2;
  int nRows_tmp;
  boolean_T nxeven;
  nRows_tmp = unsigned_nRows / 2;
  ihi = nRows_tmp - 2;
  nRowsD2 = nRows_tmp / 2;
  k = nRowsD2 / 2;
  hszCostab = static_cast<int>(static_cast<unsigned int>(costab.size(1)) >> 1);
  hcostab.set_size(1, hszCostab);
  hsintab.set_size(1, hszCostab);
  for (i = 0; i < hszCostab; i++) {
    j = ((i + 1) << 1) - 2;
    hcostab[i] = costab[j];
    hsintab[i] = sintab[j];
  }
  reconVar1.set_size(nRows_tmp);
  reconVar2.set_size(nRows_tmp);
  wrapIndex.set_size(1, nRows_tmp);
  for (i = 0; i < nRows_tmp; i++) {
    re = sintab[i];
    im = costab[i];
    reconVar1[i].re = re + 1.0;
    reconVar1[i].im = -im;
    reconVar2[i].re = 1.0 - re;
    reconVar2[i].im = im;
    if (i + 1 != 1) {
      wrapIndex[i] = (nRows_tmp - i) + 1;
    } else {
      wrapIndex[0] = 1;
    }
  }
  hszCostab = y.size(0);
  if (hszCostab > nRows_tmp) {
    hszCostab = nRows_tmp;
  }
  FFTImplementationCallback::get_bitrevIndex(hszCostab - 1, nRows_tmp,
                                             bitrevIndex);
  if ((x.size(0) & 1) == 0) {
    nxeven = true;
    hszCostab = x.size(0);
  } else if (x.size(0) >= unsigned_nRows) {
    nxeven = true;
    hszCostab = unsigned_nRows;
  } else {
    nxeven = false;
    hszCostab = x.size(0) - 1;
  }
  if (hszCostab > unsigned_nRows) {
    hszCostab = unsigned_nRows;
  }
  hszCostab /= 2;
  for (i = 0; i < hszCostab; i++) {
    j = i << 1;
    y[bitrevIndex[i] - 1].re = x[j];
    y[bitrevIndex[i] - 1].im = x[j + 1];
  }
  if (!nxeven) {
    if (hszCostab - 1 < 0) {
      j = 0;
    } else {
      j = hszCostab << 1;
    }
    y[bitrevIndex[hszCostab] - 1].re = x[j];
    y[bitrevIndex[hszCostab] - 1].im = 0.0;
  }
  if (nRows_tmp > 1) {
    for (i = 0; i <= ihi; i += 2) {
      re = y[i + 1].re;
      im = y[i + 1].im;
      temp_re = re;
      temp_im = im;
      twid_re = y[i].re;
      twid_im = y[i].im;
      re = twid_re - re;
      im = twid_im - im;
      y[i + 1].re = re;
      y[i + 1].im = im;
      twid_re += temp_re;
      twid_im += temp_im;
      y[i].re = twid_re;
      y[i].im = twid_im;
    }
  }
  iDelta = 2;
  iDelta2 = 4;
  iheight = ((k - 1) << 2) + 1;
  while (k > 0) {
    for (i = 0; i < iheight; i += iDelta2) {
      hszCostab = i + iDelta;
      temp_re = y[hszCostab].re;
      temp_im = y[hszCostab].im;
      y[hszCostab].re = y[i].re - temp_re;
      y[hszCostab].im = y[i].im - temp_im;
      y[i].re = y[i].re + temp_re;
      y[i].im = y[i].im + temp_im;
    }
    hszCostab = 1;
    for (j = k; j < nRowsD2; j += k) {
      twid_re = hcostab[j];
      twid_im = hsintab[j];
      i = hszCostab;
      ihi = hszCostab + iheight;
      while (i < ihi) {
        int temp_re_tmp_tmp;
        temp_re_tmp_tmp = i + iDelta;
        re = y[temp_re_tmp_tmp].im;
        im = y[temp_re_tmp_tmp].re;
        temp_re = twid_re * im - twid_im * re;
        temp_im = twid_re * re + twid_im * im;
        y[temp_re_tmp_tmp].re = y[i].re - temp_re;
        y[temp_re_tmp_tmp].im = y[i].im - temp_im;
        y[i].re = y[i].re + temp_re;
        y[i].im = y[i].im + temp_im;
        i += iDelta2;
      }
      hszCostab++;
    }
    k /= 2;
    iDelta = iDelta2;
    iDelta2 += iDelta2;
    iheight -= iDelta;
  }
  FFTImplementationCallback::getback_radix2_fft(y, reconVar1, reconVar2,
                                                wrapIndex, nRows_tmp);
}

void FFTImplementationCallback::dobluesteinfft(
    const ::coder::array<double, 2U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> r;
  ::coder::array<creal_T, 1U> wwc;
  double b_re_tmp;
  double c_re_tmp;
  double d_re_tmp;
  double re_tmp;
  int b_k;
  int b_y;
  int i;
  int i1;
  int minNrowsNx;
  int nInt2m1;
  int u0;
  int xoff;
  if ((nfft != 1) && ((nfft & 1) == 0)) {
    int nInt2;
    int nRows;
    int rt;
    nRows = nfft / 2;
    nInt2m1 = (nRows + nRows) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nRows - 1].re = 1.0;
    wwc[nRows - 1].im = 0.0;
    nInt2 = nRows << 1;
    for (int k{0}; k <= nRows - 2; k++) {
      double nt_im;
      b_y = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= b_y) {
        rt += b_y - nInt2;
      } else {
        rt += b_y;
      }
      nt_im = -3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nRows);
      i = (nRows - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nRows; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  } else {
    int nInt2;
    int rt;
    nInt2m1 = (nfft + nfft) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nfft - 1].re = 1.0;
    wwc[nfft - 1].im = 0.0;
    nInt2 = nfft << 1;
    for (int k{0}; k <= nfft - 2; k++) {
      double nt_im;
      b_y = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= b_y) {
        rt += b_y - nInt2;
      } else {
        rt += b_y;
      }
      nt_im = -3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nfft);
      i = (nfft - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nfft; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  }
  nInt2m1 = x.size(0);
  y.set_size(nfft, x.size(1));
  if (nfft > x.size(0)) {
    y.set_size(nfft, x.size(1));
    b_y = nfft * x.size(1);
    for (i = 0; i < b_y; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  b_y = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        fv, b_fv, r, xoff, i1, minNrowsNx, u0, b_k, re_tmp, b_re_tmp,          \
            c_re_tmp, d_re_tmp)

  for (int chan = 0; chan <= b_y; chan++) {
    xoff = chan * nInt2m1;
    r.set_size(nfft);
    if (nfft > x.size(0)) {
      r.set_size(nfft);
      for (i1 = 0; i1 < nfft; i1++) {
        r[i1].re = 0.0;
        r[i1].im = 0.0;
      }
    }
    if ((n2blue != 1) && ((nfft & 1) == 0)) {
      FFTImplementationCallback::doHalfLengthBluestein(
          x, xoff, r, x.size(0), nfft, n2blue, wwc, costab, sintab, costab,
          sintabinv);
    } else {
      minNrowsNx = x.size(0);
      if (nfft <= minNrowsNx) {
        minNrowsNx = nfft;
      }
      for (b_k = 0; b_k < minNrowsNx; b_k++) {
        u0 = (nfft + b_k) - 1;
        i1 = xoff + b_k;
        r[b_k].re = wwc[u0].re * x[i1];
        r[b_k].im = wwc[u0].im * -x[i1];
      }
      i1 = minNrowsNx + 1;
      for (b_k = i1; b_k <= nfft; b_k++) {
        r[b_k - 1].re = 0.0;
        r[b_k - 1].im = 0.0;
      }
      FFTImplementationCallback::r2br_r2dit_trig_impl(r, n2blue, costab, sintab,
                                                      b_fv);
      FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab,
                                                      sintab, fv);
      fv.set_size(b_fv.size(0));
      u0 = b_fv.size(0);
      for (i1 = 0; i1 < u0; i1++) {
        re_tmp = b_fv[i1].re;
        b_re_tmp = fv[i1].im;
        c_re_tmp = b_fv[i1].im;
        d_re_tmp = fv[i1].re;
        fv[i1].re = re_tmp * d_re_tmp - c_re_tmp * b_re_tmp;
        fv[i1].im = re_tmp * b_re_tmp + c_re_tmp * d_re_tmp;
      }
      FFTImplementationCallback::r2br_r2dit_trig_impl(fv, n2blue, costab,
                                                      sintabinv, b_fv);
      if (b_fv.size(0) > 1) {
        re_tmp = 1.0 / static_cast<double>(b_fv.size(0));
        u0 = b_fv.size(0);
        for (i1 = 0; i1 < u0; i1++) {
          b_fv[i1].re = re_tmp * b_fv[i1].re;
          b_fv[i1].im = re_tmp * b_fv[i1].im;
        }
      }
      i1 = wwc.size(0);
      for (b_k = nfft; b_k <= i1; b_k++) {
        re_tmp = wwc[b_k - 1].re;
        b_re_tmp = b_fv[b_k - 1].im;
        c_re_tmp = wwc[b_k - 1].im;
        d_re_tmp = b_fv[b_k - 1].re;
        u0 = b_k - nfft;
        r[u0].re = re_tmp * d_re_tmp + c_re_tmp * b_re_tmp;
        r[u0].im = re_tmp * b_re_tmp - c_re_tmp * d_re_tmp;
      }
    }
    u0 = y.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::dobluesteinfft(
    const ::coder::array<double, 1U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 1U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> wwc;
  double nt_im;
  int i;
  int minNrowsNx;
  int nInt2m1;
  if ((nfft != 1) && ((nfft & 1) == 0)) {
    int nInt2;
    int nRows;
    int rt;
    nRows = nfft / 2;
    nInt2m1 = (nRows + nRows) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nRows - 1].re = 1.0;
    wwc[nRows - 1].im = 0.0;
    nInt2 = nRows << 1;
    for (int k{0}; k <= nRows - 2; k++) {
      minNrowsNx = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= minNrowsNx) {
        rt += minNrowsNx - nInt2;
      } else {
        rt += minNrowsNx;
      }
      nt_im = -3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nRows);
      i = (nRows - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nRows; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  } else {
    int nInt2;
    int rt;
    nInt2m1 = (nfft + nfft) - 1;
    wwc.set_size(nInt2m1);
    rt = 0;
    wwc[nfft - 1].re = 1.0;
    wwc[nfft - 1].im = 0.0;
    nInt2 = nfft << 1;
    for (int k{0}; k <= nfft - 2; k++) {
      minNrowsNx = ((k + 1) << 1) - 1;
      if (nInt2 - rt <= minNrowsNx) {
        rt += minNrowsNx - nInt2;
      } else {
        rt += minNrowsNx;
      }
      nt_im = -3.1415926535897931 * static_cast<double>(rt) /
              static_cast<double>(nfft);
      i = (nfft - k) - 2;
      wwc[i].re = std::cos(nt_im);
      wwc[i].im = -std::sin(nt_im);
    }
    i = nInt2m1 - 1;
    for (int k{i}; k >= nfft; k--) {
      wwc[k] = wwc[(nInt2m1 - k) - 1];
    }
  }
  y.set_size(nfft);
  if (nfft > x.size(0)) {
    y.set_size(nfft);
    for (i = 0; i < nfft; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  if ((n2blue != 1) && ((nfft & 1) == 0)) {
    FFTImplementationCallback::doHalfLengthBluestein(
        x, y, x.size(0), nfft, n2blue, wwc, costab, sintab, costab, sintabinv);
  } else {
    double b_re_tmp;
    double c_re_tmp;
    double re_tmp;
    minNrowsNx = x.size(0);
    if (nfft <= minNrowsNx) {
      minNrowsNx = nfft;
    }
    for (int k{0}; k < minNrowsNx; k++) {
      nInt2m1 = (nfft + k) - 1;
      y[k].re = wwc[nInt2m1].re * x[k];
      y[k].im = wwc[nInt2m1].im * -x[k];
    }
    i = minNrowsNx + 1;
    for (int k{i}; k <= nfft; k++) {
      y[k - 1].re = 0.0;
      y[k - 1].im = 0.0;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(y, n2blue, costab, sintab,
                                                    fv);
    FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab, sintab,
                                                    b_fv);
    minNrowsNx = fv.size(0);
    b_fv.set_size(fv.size(0));
    for (i = 0; i < minNrowsNx; i++) {
      nt_im = fv[i].re;
      re_tmp = b_fv[i].im;
      b_re_tmp = fv[i].im;
      c_re_tmp = b_fv[i].re;
      b_fv[i].re = nt_im * c_re_tmp - b_re_tmp * re_tmp;
      b_fv[i].im = nt_im * re_tmp + b_re_tmp * c_re_tmp;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(b_fv, n2blue, costab,
                                                    sintabinv, fv);
    if (fv.size(0) > 1) {
      nt_im = 1.0 / static_cast<double>(fv.size(0));
      minNrowsNx = fv.size(0);
      for (i = 0; i < minNrowsNx; i++) {
        fv[i].re = nt_im * fv[i].re;
        fv[i].im = nt_im * fv[i].im;
      }
    }
    i = wwc.size(0);
    for (int k{nfft}; k <= i; k++) {
      nt_im = wwc[k - 1].re;
      re_tmp = fv[k - 1].im;
      b_re_tmp = wwc[k - 1].im;
      c_re_tmp = fv[k - 1].re;
      minNrowsNx = k - nfft;
      y[minNrowsNx].re = nt_im * c_re_tmp + b_re_tmp * re_tmp;
      y[minNrowsNx].im = nt_im * re_tmp - b_re_tmp * c_re_tmp;
    }
  }
}

void FFTImplementationCallback::dobluesteinfft(
    const ::coder::array<creal_T, 2U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> r;
  ::coder::array<creal_T, 1U> wwc;
  double a_im;
  double a_re;
  double ar;
  double b_re_tmp;
  double re_tmp;
  int b_k;
  int b_y;
  int i;
  int i1;
  int minNrowsNx;
  int nInt2;
  int nInt2m1;
  int rt;
  int u0;
  int xoff;
  nInt2m1 = (nfft + nfft) - 1;
  wwc.set_size(nInt2m1);
  rt = 0;
  wwc[nfft - 1].re = 1.0;
  wwc[nfft - 1].im = 0.0;
  nInt2 = nfft << 1;
  for (int k{0}; k <= nfft - 2; k++) {
    double nt_im;
    b_y = ((k + 1) << 1) - 1;
    if (nInt2 - rt <= b_y) {
      rt += b_y - nInt2;
    } else {
      rt += b_y;
    }
    nt_im = 3.1415926535897931 * static_cast<double>(rt) /
            static_cast<double>(nfft);
    i = (nfft - k) - 2;
    wwc[i].re = std::cos(nt_im);
    wwc[i].im = -std::sin(nt_im);
  }
  i = nInt2m1 - 1;
  for (int k{i}; k >= nfft; k--) {
    wwc[k] = wwc[(nInt2m1 - k) - 1];
  }
  nInt2m1 = x.size(0);
  y.set_size(nfft, x.size(1));
  if (nfft > x.size(0)) {
    y.set_size(nfft, x.size(1));
    b_y = nfft * x.size(1);
    for (i = 0; i < b_y; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  b_y = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        fv, b_fv, r, xoff, i1, minNrowsNx, b_k, u0, a_re, a_im, re_tmp,        \
            b_re_tmp, ar)

  for (int chan = 0; chan <= b_y; chan++) {
    xoff = chan * nInt2m1;
    r.set_size(nfft);
    if (nfft > x.size(0)) {
      r.set_size(nfft);
      for (i1 = 0; i1 < nfft; i1++) {
        r[i1].re = 0.0;
        r[i1].im = 0.0;
      }
    }
    minNrowsNx = x.size(0);
    if (nfft <= minNrowsNx) {
      minNrowsNx = nfft;
    }
    for (b_k = 0; b_k < minNrowsNx; b_k++) {
      u0 = (nfft + b_k) - 1;
      a_re = wwc[u0].re;
      a_im = wwc[u0].im;
      i1 = xoff + b_k;
      r[b_k].re = a_re * x[i1].re + a_im * x[i1].im;
      r[b_k].im = a_re * x[i1].im - a_im * x[i1].re;
    }
    i1 = minNrowsNx + 1;
    for (b_k = i1; b_k <= nfft; b_k++) {
      r[b_k - 1].re = 0.0;
      r[b_k - 1].im = 0.0;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(r, n2blue, costab, sintab,
                                                    b_fv);
    FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab, sintab,
                                                    fv);
    fv.set_size(b_fv.size(0));
    u0 = b_fv.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      a_re = b_fv[i1].re;
      a_im = fv[i1].im;
      re_tmp = b_fv[i1].im;
      b_re_tmp = fv[i1].re;
      fv[i1].re = a_re * b_re_tmp - re_tmp * a_im;
      fv[i1].im = a_re * a_im + re_tmp * b_re_tmp;
    }
    FFTImplementationCallback::r2br_r2dit_trig_impl(fv, n2blue, costab,
                                                    sintabinv, b_fv);
    if (b_fv.size(0) > 1) {
      a_re = 1.0 / static_cast<double>(b_fv.size(0));
      u0 = b_fv.size(0);
      for (i1 = 0; i1 < u0; i1++) {
        b_fv[i1].re = a_re * b_fv[i1].re;
        b_fv[i1].im = a_re * b_fv[i1].im;
      }
    }
    i1 = wwc.size(0);
    for (b_k = nfft; b_k <= i1; b_k++) {
      a_re = wwc[b_k - 1].re;
      a_im = b_fv[b_k - 1].im;
      re_tmp = wwc[b_k - 1].im;
      b_re_tmp = b_fv[b_k - 1].re;
      ar = a_re * b_re_tmp + re_tmp * a_im;
      a_re = a_re * a_im - re_tmp * b_re_tmp;
      if (a_re == 0.0) {
        u0 = b_k - nfft;
        r[u0].re = ar / static_cast<double>(nfft);
        r[u0].im = 0.0;
      } else if (ar == 0.0) {
        u0 = b_k - nfft;
        r[u0].re = 0.0;
        r[u0].im = a_re / static_cast<double>(nfft);
      } else {
        u0 = b_k - nfft;
        r[u0].re = ar / static_cast<double>(nfft);
        r[u0].im = a_re / static_cast<double>(nfft);
      }
    }
    u0 = y.size(0);
    for (i1 = 0; i1 < u0; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::dobluesteinfft(
    const ::coder::array<creal_T, 1U> &x, int n2blue, int nfft,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab,
    const ::coder::array<double, 2U> &sintabinv, ::coder::array<creal_T, 1U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> wwc;
  double b_re_tmp;
  double nt_im;
  double nt_re;
  double re_tmp;
  int i;
  int minNrowsNx;
  int nInt2;
  int nInt2m1_tmp;
  int rt;
  nInt2m1_tmp = (nfft + nfft) - 1;
  wwc.set_size(nInt2m1_tmp);
  rt = 0;
  wwc[nfft - 1].re = 1.0;
  wwc[nfft - 1].im = 0.0;
  nInt2 = nfft << 1;
  for (int k{0}; k <= nfft - 2; k++) {
    minNrowsNx = ((k + 1) << 1) - 1;
    if (nInt2 - rt <= minNrowsNx) {
      rt += minNrowsNx - nInt2;
    } else {
      rt += minNrowsNx;
    }
    nt_im = -3.1415926535897931 * static_cast<double>(rt) /
            static_cast<double>(nfft);
    i = (nfft - k) - 2;
    wwc[i].re = std::cos(nt_im);
    wwc[i].im = -std::sin(nt_im);
  }
  i = nInt2m1_tmp - 1;
  for (int k{i}; k >= nfft; k--) {
    wwc[k] = wwc[(nInt2m1_tmp - k) - 1];
  }
  y.set_size(nfft);
  if (nfft > x.size(0)) {
    y.set_size(nfft);
    for (i = 0; i < nfft; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  minNrowsNx = x.size(0);
  if (nfft <= minNrowsNx) {
    minNrowsNx = nfft;
  }
  for (int k{0}; k < minNrowsNx; k++) {
    rt = (nfft + k) - 1;
    nt_re = wwc[rt].re;
    nt_im = wwc[rt].im;
    re_tmp = x[k].im;
    b_re_tmp = x[k].re;
    y[k].re = nt_re * b_re_tmp + nt_im * re_tmp;
    y[k].im = nt_re * re_tmp - nt_im * b_re_tmp;
  }
  i = minNrowsNx + 1;
  for (int k{i}; k <= nfft; k++) {
    y[k - 1].re = 0.0;
    y[k - 1].im = 0.0;
  }
  FFTImplementationCallback::r2br_r2dit_trig_impl(y, n2blue, costab, sintab,
                                                  fv);
  FFTImplementationCallback::r2br_r2dit_trig_impl(wwc, n2blue, costab, sintab,
                                                  b_fv);
  minNrowsNx = fv.size(0);
  b_fv.set_size(fv.size(0));
  for (i = 0; i < minNrowsNx; i++) {
    nt_re = fv[i].re;
    nt_im = b_fv[i].im;
    re_tmp = fv[i].im;
    b_re_tmp = b_fv[i].re;
    b_fv[i].re = nt_re * b_re_tmp - re_tmp * nt_im;
    b_fv[i].im = nt_re * nt_im + re_tmp * b_re_tmp;
  }
  FFTImplementationCallback::r2br_r2dit_trig_impl(b_fv, n2blue, costab,
                                                  sintabinv, fv);
  if (fv.size(0) > 1) {
    nt_re = 1.0 / static_cast<double>(fv.size(0));
    minNrowsNx = fv.size(0);
    for (i = 0; i < minNrowsNx; i++) {
      fv[i].re = nt_re * fv[i].re;
      fv[i].im = nt_re * fv[i].im;
    }
  }
  for (int k{nfft}; k <= nInt2m1_tmp; k++) {
    re_tmp = wwc[k - 1].re;
    b_re_tmp = fv[k - 1].im;
    nt_re = wwc[k - 1].im;
    nt_im = fv[k - 1].re;
    i = k - nfft;
    y[i].re = re_tmp * nt_im + nt_re * b_re_tmp;
    y[i].im = re_tmp * b_re_tmp - nt_re * nt_im;
  }
}

void FFTImplementationCallback::generate_twiddle_tables(
    int nRows, boolean_T useRadix2, ::coder::array<double, 2U> &costab,
    ::coder::array<double, 2U> &sintab, ::coder::array<double, 2U> &sintabinv)
{
  ::coder::array<double, 2U> costab1q;
  double e;
  int i;
  int n;
  int nd2;
  e = 6.2831853071795862 / static_cast<double>(nRows);
  n = nRows / 2 / 2;
  costab1q.set_size(1, n + 1);
  costab1q[0] = 1.0;
  nd2 = static_cast<int>(static_cast<unsigned int>(n) >> 1) - 1;
  for (int k{0}; k <= nd2; k++) {
    costab1q[k + 1] = std::cos(e * (static_cast<double>(k) + 1.0));
  }
  i = nd2 + 2;
  nd2 = n - 1;
  for (int k{i}; k <= nd2; k++) {
    costab1q[k] = std::sin(e * static_cast<double>(n - k));
  }
  costab1q[n] = 0.0;
  if (!useRadix2) {
    n = costab1q.size(1) - 1;
    nd2 = (costab1q.size(1) - 1) << 1;
    costab.set_size(1, nd2 + 1);
    sintab.set_size(1, nd2 + 1);
    costab[0] = 1.0;
    sintab[0] = 0.0;
    sintabinv.set_size(1, nd2 + 1);
    for (int k{0}; k < n; k++) {
      sintabinv[k + 1] = costab1q[(n - k) - 1];
    }
    i = costab1q.size(1);
    for (int k{i}; k <= nd2; k++) {
      sintabinv[k] = costab1q[k - n];
    }
    for (int k{0}; k < n; k++) {
      costab[k + 1] = costab1q[k + 1];
      sintab[k + 1] = -costab1q[(n - k) - 1];
    }
    for (int k{i}; k <= nd2; k++) {
      costab[k] = -costab1q[nd2 - k];
      sintab[k] = -costab1q[k - n];
    }
  } else {
    n = costab1q.size(1) - 1;
    nd2 = (costab1q.size(1) - 1) << 1;
    costab.set_size(1, nd2 + 1);
    sintab.set_size(1, nd2 + 1);
    costab[0] = 1.0;
    sintab[0] = 0.0;
    for (int k{0}; k < n; k++) {
      costab[k + 1] = costab1q[k + 1];
      sintab[k + 1] = -costab1q[(n - k) - 1];
    }
    i = costab1q.size(1);
    for (int k{i}; k <= nd2; k++) {
      costab[k] = -costab1q[nd2 - k];
      sintab[k] = -costab1q[k - n];
    }
    sintabinv.set_size(1, 0);
  }
}

int FFTImplementationCallback::get_algo_sizes(int nfft, boolean_T useRadix2,
                                              int &nRows)
{
  int n2blue;
  n2blue = 1;
  if (useRadix2) {
    nRows = nfft;
  } else {
    if (nfft > 0) {
      int n;
      int pmax;
      n = (nfft + nfft) - 1;
      pmax = 31;
      if (n <= 1) {
        pmax = 0;
      } else {
        int pmin;
        boolean_T exitg1;
        pmin = 0;
        exitg1 = false;
        while ((!exitg1) && (pmax - pmin > 1)) {
          int k;
          int pow2p;
          k = (pmin + pmax) >> 1;
          pow2p = 1 << k;
          if (pow2p == n) {
            pmax = k;
            exitg1 = true;
          } else if (pow2p > n) {
            pmax = k;
          } else {
            pmin = k;
          }
        }
      }
      n2blue = 1 << pmax;
    }
    nRows = n2blue;
  }
  return n2blue;
}

void FFTImplementationCallback::r2br_r2dit_trig(
    const ::coder::array<creal_T, 2U> &x, int n1_unsigned,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> r;
  int i1;
  int loop_ub;
  int nrows;
  int xoff;
  nrows = x.size(0);
  y.set_size(n1_unsigned, x.size(1));
  if (n1_unsigned > x.size(0)) {
    y.set_size(n1_unsigned, x.size(1));
    loop_ub = n1_unsigned * x.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  loop_ub = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(r, xoff, i1)

  for (int chan = 0; chan <= loop_ub; chan++) {
    xoff = chan * nrows;
    FFTImplementationCallback::r2br_r2dit_trig_impl(x, xoff, n1_unsigned,
                                                    costab, sintab, r);
    xoff = y.size(0);
    for (i1 = 0; i1 < xoff; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
  if (y.size(0) > 1) {
    double b;
    b = 1.0 / static_cast<double>(y.size(0));
    loop_ub = y.size(0) * y.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = b * y[i].re;
      y[i].im = b * y[i].im;
    }
  }
}

void FFTImplementationCallback::r2br_r2dit_trig(
    const ::coder::array<double, 1U> &x, int n1_unsigned,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 1U> &y)
{
  y.set_size(n1_unsigned);
  if (n1_unsigned > x.size(0)) {
    y.set_size(n1_unsigned);
    for (int i{0}; i < n1_unsigned; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  if (n1_unsigned != 1) {
    FFTImplementationCallback::doHalfLengthRadix2(x, y, n1_unsigned, costab,
                                                  sintab);
  } else {
    y[0].re = x[0];
    y[0].im = 0.0;
  }
}

void FFTImplementationCallback::r2br_r2dit_trig(
    const ::coder::array<double, 2U> &x, int n1_unsigned,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 1U> r;
  int i1;
  int loop_ub;
  int nrows;
  int xoff;
  nrows = x.size(0);
  y.set_size(n1_unsigned, x.size(1));
  if (n1_unsigned > x.size(0)) {
    y.set_size(n1_unsigned, x.size(1));
    loop_ub = n1_unsigned * x.size(1);
    for (int i{0}; i < loop_ub; i++) {
      y[i].re = 0.0;
      y[i].im = 0.0;
    }
  }
  loop_ub = x.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(r, xoff, i1)

  for (int chan = 0; chan <= loop_ub; chan++) {
    xoff = chan * nrows;
    FFTImplementationCallback::r2br_r2dit_trig_impl(x, xoff, n1_unsigned,
                                                    costab, sintab, r);
    xoff = y.size(0);
    for (i1 = 0; i1 < xoff; i1++) {
      y[i1 + y.size(0) * chan] = r[i1];
    }
  }
}

void FFTImplementationCallback::r2br_r2dit_trig_impl(
    const ::coder::array<creal_T, 1U> &x, int unsigned_nRows,
    const ::coder::array<double, 2U> &costab,
    const ::coder::array<double, 2U> &sintab, ::coder::array<creal_T, 1U> &y)
{
  double temp_im;
  double temp_re;
  double temp_re_tmp;
  double twid_re;
  int i;
  int iDelta;
  int iDelta2;
  int iheight;
  int ihi;
  int iy;
  int j;
  int ju;
  int k;
  int nRowsD2;
  y.set_size(unsigned_nRows);
  if (unsigned_nRows > x.size(0)) {
    y.set_size(unsigned_nRows);
    for (iy = 0; iy < unsigned_nRows; iy++) {
      y[iy].re = 0.0;
      y[iy].im = 0.0;
    }
  }
  j = x.size(0);
  if (j > unsigned_nRows) {
    j = unsigned_nRows;
  }
  ihi = unsigned_nRows - 2;
  nRowsD2 = unsigned_nRows / 2;
  k = nRowsD2 / 2;
  iy = 0;
  ju = 0;
  for (i = 0; i <= j - 2; i++) {
    boolean_T tst;
    y[iy] = x[i];
    iy = unsigned_nRows;
    tst = true;
    while (tst) {
      iy >>= 1;
      ju ^= iy;
      tst = ((ju & iy) == 0);
    }
    iy = ju;
  }
  if (j - 2 < 0) {
    j = 0;
  } else {
    j--;
  }
  y[iy] = x[j];
  if (unsigned_nRows > 1) {
    for (i = 0; i <= ihi; i += 2) {
      temp_re_tmp = y[i + 1].re;
      temp_im = y[i + 1].im;
      temp_re = y[i].re;
      twid_re = y[i].im;
      y[i + 1].re = temp_re - temp_re_tmp;
      y[i + 1].im = twid_re - temp_im;
      y[i].re = temp_re + temp_re_tmp;
      y[i].im = twid_re + temp_im;
    }
  }
  iDelta = 2;
  iDelta2 = 4;
  iheight = ((k - 1) << 2) + 1;
  while (k > 0) {
    for (i = 0; i < iheight; i += iDelta2) {
      iy = i + iDelta;
      temp_re = y[iy].re;
      temp_im = y[iy].im;
      y[iy].re = y[i].re - temp_re;
      y[iy].im = y[i].im - temp_im;
      y[i].re = y[i].re + temp_re;
      y[i].im = y[i].im + temp_im;
    }
    iy = 1;
    for (j = k; j < nRowsD2; j += k) {
      double twid_im;
      twid_re = costab[j];
      twid_im = sintab[j];
      i = iy;
      ihi = iy + iheight;
      while (i < ihi) {
        ju = i + iDelta;
        temp_re_tmp = y[ju].im;
        temp_im = y[ju].re;
        temp_re = twid_re * temp_im - twid_im * temp_re_tmp;
        temp_im = twid_re * temp_re_tmp + twid_im * temp_im;
        y[ju].re = y[i].re - temp_re;
        y[ju].im = y[i].im - temp_im;
        y[i].re = y[i].re + temp_re;
        y[i].im = y[i].im + temp_im;
        i += iDelta2;
      }
      iy++;
    }
    k /= 2;
    iDelta = iDelta2;
    iDelta2 += iDelta2;
    iheight -= iDelta;
  }
}

} // namespace fft
} // namespace internal
} // namespace coder
} // namespace legacy_STRAIGHT

// End of code generation (FFTImplementationCallback.cpp)
