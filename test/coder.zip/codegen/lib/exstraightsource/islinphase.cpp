//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// islinphase.cpp
//
// Code generation for function 'islinphase'
//

// Include files
#include "islinphase.h"
#include "exstraightsource_rtwutil.h"
#include "find.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>

// Variable Definitions
static const char cv[128]{
    '\x00', '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\a',   '\b',
    '\t',   '\n',   '\v',   '\f',   '\r',   '\x0e', '\x0f', '\x10', '\x11',
    '\x12', '\x13', '\x14', '\x15', '\x16', '\x17', '\x18', '\x19', '\x1a',
    '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', ' ',    '!',    '\"',   '#',
    '$',    '%',    '&',    '\'',   '(',    ')',    '*',    '+',    ',',
    '-',    '.',    '/',    '0',    '1',    '2',    '3',    '4',    '5',
    '6',    '7',    '8',    '9',    ':',    ';',    '<',    '=',    '>',
    '?',    '@',    'a',    'b',    'c',    'd',    'e',    'f',    'g',
    'h',    'i',    'j',    'k',    'l',    'm',    'n',    'o',    'p',
    'q',    'r',    's',    't',    'u',    'v',    'w',    'x',    'y',
    'z',    '[',    '\\',   ']',    '^',    '_',    '`',    'a',    'b',
    'c',    'd',    'e',    'f',    'g',    'h',    'i',    'j',    'k',
    'l',    'm',    'n',    'o',    'p',    'q',    'r',    's',    't',
    'u',    'v',    'w',    'x',    'y',    'z',    '{',    '|',    '}',
    '~',    '\x7f'};

// Function Declarations
static void binary_expand_op_21(creal_T in1_data[], int in1_size[2],
                                const creal_T in2_data[], const int in2_size[2],
                                int in3, int in4, int in5);

static void binary_expand_op_22(creal_T in1_data[], int in1_size[2],
                                const creal_T in2_data[], const int in2_size[2],
                                int in3, int in4, int in5);

static void binary_expand_op_24(coder::array<double, 2U> &in1,
                                const double in2_data[], const int in2_size[2],
                                int in3, int in4, int in5);

static void binary_expand_op_25(coder::array<double, 2U> &in1,
                                const double in2_data[], const int in2_size[2],
                                int in3, int in4, int in5);

// Function Definitions
static void binary_expand_op_21(creal_T in1_data[], int in1_size[2],
                                const creal_T in2_data[], const int in2_size[2],
                                int in3, int in4, int in5)
{
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1_size[0] = 1;
  i = div_s32(in5 - in3, in4) + 1;
  if (i == 1) {
    loop_ub = in2_size[1];
  } else {
    loop_ub = i;
  }
  in1_size[1] = loop_ub;
  stride_0_1 = (in2_size[1] != 1);
  stride_1_1 = (i != 1);
  for (i = 0; i < loop_ub; i++) {
    int i1;
    int i2;
    i1 = i * stride_0_1;
    i2 = in3 + in4 * (i * stride_1_1);
    in1_data[i].re = in2_data[i1].re + in2_data[i2].re;
    in1_data[i].im = in2_data[i1].im - in2_data[i2].im;
  }
}

static void binary_expand_op_22(creal_T in1_data[], int in1_size[2],
                                const creal_T in2_data[], const int in2_size[2],
                                int in3, int in4, int in5)
{
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1_size[0] = 1;
  i = div_s32(in5 - in3, in4) + 1;
  if (i == 1) {
    loop_ub = in2_size[1];
  } else {
    loop_ub = i;
  }
  in1_size[1] = loop_ub;
  stride_0_1 = (in2_size[1] != 1);
  stride_1_1 = (i != 1);
  for (i = 0; i < loop_ub; i++) {
    int i1;
    int i2;
    i1 = i * stride_0_1;
    i2 = in3 + in4 * (i * stride_1_1);
    in1_data[i].re = in2_data[i1].re - in2_data[i2].re;
    in1_data[i].im = in2_data[i1].im - (-in2_data[i2].im);
  }
}

static void binary_expand_op_24(coder::array<double, 2U> &in1,
                                const double in2_data[], const int in2_size[2],
                                int in3, int in4, int in5)
{
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1.set_size(1, in1.size(1));
  i = div_s32(in5 - in3, in4) + 1;
  if (i == 1) {
    loop_ub = in2_size[1];
  } else {
    loop_ub = i;
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2_size[1] != 1);
  stride_1_1 = (i != 1);
  for (i = 0; i < loop_ub; i++) {
    in1[i] = in2_data[i * stride_0_1] + in2_data[in3 + in4 * (i * stride_1_1)];
  }
}

static void binary_expand_op_25(coder::array<double, 2U> &in1,
                                const double in2_data[], const int in2_size[2],
                                int in3, int in4, int in5)
{
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1.set_size(1, in1.size(1));
  i = div_s32(in5 - in3, in4) + 1;
  if (i == 1) {
    loop_ub = in2_size[1];
  } else {
    loop_ub = i;
  }
  in1.set_size(in1.size(0), loop_ub);
  stride_0_1 = (in2_size[1] != 1);
  stride_1_1 = (i != 1);
  for (i = 0; i < loop_ub; i++) {
    in1[i] = in2_data[i * stride_0_1] - in2_data[in3 + in4 * (i * stride_1_1)];
  }
}

namespace legacy_STRAIGHT {
namespace b_signal {
namespace internal {
boolean_T determineiflinphase(const creal_T b_data[], const int b_size[2])
{
  static const char cv2[13]{'a', 'n', 't', 'i', 'h', 'e', 'r',
                            'm', 'i', 't', 'i', 'a', 'n'};
  static const char b_cv[9]{'h', 'e', 'r', 'm', 'i', 't', 'i', 'a', 'n'};
  static const char cv1[4]{'n', 'o', 'n', 'e'};
  ::coder::array<double, 2U> b_y_data;
  ::coder::array<double, 2U> c_y_data;
  ::coder::array<double, 2U> d_y_data;
  creal_T x_data[32];
  creal_T bIn_data[31];
  double y_data[32];
  int bIn_size[2];
  int x_size[2];
  boolean_T islinphaseflag;
  if (b_size[1] == 1) {
    islinphaseflag = true;
  } else {
    int i;
    int idx;
    int ii;
    int ii_data;
    int startidx_data;
    char symstr_data[13];
    boolean_T b_bool;
    startidx_data = b_size[1];
    for (ii_data = 0; ii_data < startidx_data; ii_data++) {
      y_data[ii_data] = rt_hypotd_snf(b_data[ii_data].re, b_data[ii_data].im);
    }
    b_y_data.set(&y_data[0], 1, b_size[1]);
    if (coder::internal::maximum(b_y_data) == 0.0) {
      bIn_size[0] = 1;
      bIn_size[1] = 1;
      bIn_data[0].re = 0.0;
      bIn_data[0].im = 0.0;
    } else {
      int ii_size[2];
      signed char stopidx_data;
      boolean_T exitg1;
      bIn_size[0] = 1;
      bIn_size[1] = b_size[1];
      if (startidx_data - 1 >= 0) {
        std::copy(&b_data[0], &b_data[startidx_data], &bIn_data[0]);
      }
      eml_find(bIn_data, bIn_size, (int *)&ii_data, ii_size);
      if (ii_size[1] - 1 >= 0) {
        startidx_data = ii_data;
      }
      ii = b_size[1];
      idx = 0;
      ii_size[1] = 1;
      exitg1 = false;
      while ((!exitg1) && (ii > 0)) {
        if ((b_data[ii - 1].re != 0.0) || (b_data[ii - 1].im != 0.0)) {
          idx = 1;
          ii_data = ii;
          exitg1 = true;
        } else {
          ii--;
        }
      }
      if (idx == 0) {
        ii_size[1] = 0;
      }
      if (ii_size[1] - 1 >= 0) {
        stopidx_data = static_cast<signed char>(ii_data);
      }
      if (startidx_data > stopidx_data) {
        i = 0;
        ii = 0;
      } else {
        i = startidx_data - 1;
        ii = stopidx_data;
      }
      bIn_size[0] = 1;
      startidx_data = ii - i;
      bIn_size[1] = startidx_data;
      for (ii = 0; ii < startidx_data; ii++) {
        bIn_data[ii] = b_data[i + ii];
      }
    }
    if (bIn_size[1] < 1) {
      i = 0;
      ii = 1;
      idx = -1;
    } else {
      i = bIn_size[1] - 1;
      ii = -1;
      idx = 0;
    }
    if (bIn_size[1] == div_s32(idx - i, ii) + 1) {
      x_size[0] = 1;
      startidx_data = bIn_size[1];
      x_size[1] = bIn_size[1];
      for (idx = 0; idx < startidx_data; idx++) {
        ii_data = i + ii * idx;
        x_data[idx].re = bIn_data[idx].re - bIn_data[ii_data].re;
        x_data[idx].im = bIn_data[idx].im - (-bIn_data[ii_data].im);
      }
    } else {
      binary_expand_op_22(x_data, x_size, bIn_data, bIn_size, i, ii, idx);
    }
    i = x_size[1];
    for (ii_data = 0; ii_data < i; ii_data++) {
      y_data[ii_data] = rt_hypotd_snf(x_data[ii_data].re, x_data[ii_data].im);
    }
    c_y_data.set(&y_data[0], 1, x_size[1]);
    if (coder::internal::maximum(c_y_data) <= 0.0) {
      ii_data = 9;
      for (i = 0; i < 9; i++) {
        symstr_data[i] = b_cv[i];
      }
    } else {
      if (bIn_size[1] < 1) {
        i = 0;
        ii = 1;
        idx = -1;
      } else {
        i = bIn_size[1] - 1;
        ii = -1;
        idx = 0;
      }
      if (bIn_size[1] == div_s32(idx - i, ii) + 1) {
        startidx_data = bIn_size[1];
        x_size[1] = bIn_size[1];
        for (idx = 0; idx < startidx_data; idx++) {
          ii_data = i + ii * idx;
          x_data[idx].re = bIn_data[idx].re + bIn_data[ii_data].re;
          x_data[idx].im = bIn_data[idx].im - bIn_data[ii_data].im;
        }
      } else {
        binary_expand_op_21(x_data, x_size, bIn_data, bIn_size, i, ii, idx);
      }
      i = x_size[1];
      for (ii_data = 0; ii_data < i; ii_data++) {
        y_data[ii_data] = rt_hypotd_snf(x_data[ii_data].re, x_data[ii_data].im);
      }
      d_y_data.set(&y_data[0], 1, x_size[1]);
      if (coder::internal::maximum(d_y_data) <= 0.0) {
        ii_data = 13;
        for (i = 0; i < 13; i++) {
          symstr_data[i] = cv2[i];
        }
      } else {
        ii_data = 4;
        symstr_data[0] = 'n';
        symstr_data[1] = 'o';
        symstr_data[2] = 'n';
        symstr_data[3] = 'e';
      }
    }
    b_bool = false;
    if (ii_data == 4) {
      ii_data = 0;
      int exitg2;
      do {
        exitg2 = 0;
        if (ii_data < 4) {
          if (cv[static_cast<int>(symstr_data[ii_data])] !=
              cv[static_cast<int>(cv1[ii_data])]) {
            exitg2 = 1;
          } else {
            ii_data++;
          }
        } else {
          b_bool = true;
          exitg2 = 1;
        }
      } while (exitg2 == 0);
    }
    islinphaseflag = !b_bool;
  }
  return islinphaseflag;
}

boolean_T determineiflinphase(const double b_data[], const int b_size[2])
{
  static const char cv2[13]{'a', 'n', 't', 'i', 's', 'y', 'm',
                            'm', 'e', 't', 'r', 'i', 'c'};
  static const char b_cv[9]{'s', 'y', 'm', 'm', 'e', 't', 'r', 'i', 'c'};
  static const char cv1[4]{'n', 'o', 'n', 'e'};
  ::coder::array<double, 2U> varargin_1;
  ::coder::array<double, 2U> x;
  double bIn_data[31];
  int bIn_size[2];
  boolean_T islinphaseflag;
  if (b_size[1] == 1) {
    islinphaseflag = true;
  } else {
    int idx;
    int ii;
    int ii_data;
    int startidx_data;
    char symstr_data[13];
    boolean_T b_bool;
    ii_data = b_size[1];
    varargin_1.set_size(1, b_size[1]);
    for (startidx_data = 0; startidx_data < ii_data; startidx_data++) {
      varargin_1[startidx_data] = std::abs(b_data[startidx_data]);
    }
    if (coder::internal::maximum(varargin_1) == 0.0) {
      bIn_size[0] = 1;
      bIn_size[1] = 1;
      bIn_data[0] = 0.0;
    } else {
      int ii_size[2];
      signed char stopidx_data;
      boolean_T exitg1;
      bIn_size[0] = 1;
      bIn_size[1] = b_size[1];
      if (ii_data - 1 >= 0) {
        std::copy(&b_data[0], &b_data[ii_data], &bIn_data[0]);
      }
      eml_find(bIn_data, bIn_size, (int *)&ii_data, ii_size);
      if (ii_size[1] - 1 >= 0) {
        startidx_data = ii_data;
      }
      ii = b_size[1];
      idx = 0;
      ii_size[1] = 1;
      exitg1 = false;
      while ((!exitg1) && (ii > 0)) {
        if (b_data[ii - 1] != 0.0) {
          idx = 1;
          ii_data = ii;
          exitg1 = true;
        } else {
          ii--;
        }
      }
      if (idx == 0) {
        ii_size[1] = 0;
      }
      if (ii_size[1] - 1 >= 0) {
        stopidx_data = static_cast<signed char>(ii_data);
      }
      if (startidx_data > stopidx_data) {
        idx = 0;
        startidx_data = 0;
      } else {
        idx = startidx_data - 1;
        startidx_data = stopidx_data;
      }
      bIn_size[0] = 1;
      ii_data = startidx_data - idx;
      bIn_size[1] = ii_data;
      for (startidx_data = 0; startidx_data < ii_data; startidx_data++) {
        bIn_data[startidx_data] = b_data[idx + startidx_data];
      }
    }
    if (bIn_size[1] < 1) {
      idx = 0;
      startidx_data = 1;
      ii = -1;
    } else {
      idx = bIn_size[1] - 1;
      startidx_data = -1;
      ii = 0;
    }
    if (bIn_size[1] == div_s32(ii - idx, startidx_data) + 1) {
      ii_data = bIn_size[1];
      x.set_size(1, bIn_size[1]);
      for (ii = 0; ii < ii_data; ii++) {
        x[ii] = bIn_data[ii] - bIn_data[idx + startidx_data * ii];
      }
    } else {
      binary_expand_op_25(x, bIn_data, bIn_size, idx, startidx_data, ii);
    }
    ii_data = x.size(1);
    varargin_1.set_size(1,
                        static_cast<int>(static_cast<signed char>(x.size(1))));
    for (startidx_data = 0; startidx_data < ii_data; startidx_data++) {
      varargin_1[startidx_data] = std::abs(x[startidx_data]);
    }
    if (coder::internal::maximum(varargin_1) <= 0.0) {
      ii_data = 9;
      for (idx = 0; idx < 9; idx++) {
        symstr_data[idx] = b_cv[idx];
      }
    } else {
      if (bIn_size[1] < 1) {
        idx = 0;
        startidx_data = 1;
        ii = -1;
      } else {
        idx = bIn_size[1] - 1;
        startidx_data = -1;
        ii = 0;
      }
      if (bIn_size[1] == div_s32(ii - idx, startidx_data) + 1) {
        ii_data = bIn_size[1];
        x.set_size(1, bIn_size[1]);
        for (ii = 0; ii < ii_data; ii++) {
          x[ii] = bIn_data[ii] + bIn_data[idx + startidx_data * ii];
        }
      } else {
        binary_expand_op_24(x, bIn_data, bIn_size, idx, startidx_data, ii);
      }
      ii_data = x.size(1);
      varargin_1.set_size(
          1, static_cast<int>(static_cast<signed char>(x.size(1))));
      for (startidx_data = 0; startidx_data < ii_data; startidx_data++) {
        varargin_1[startidx_data] = std::abs(x[startidx_data]);
      }
      if (coder::internal::maximum(varargin_1) <= 0.0) {
        ii_data = 13;
        for (idx = 0; idx < 13; idx++) {
          symstr_data[idx] = cv2[idx];
        }
      } else {
        ii_data = 4;
        symstr_data[0] = 'n';
        symstr_data[1] = 'o';
        symstr_data[2] = 'n';
        symstr_data[3] = 'e';
      }
    }
    b_bool = false;
    if (ii_data == 4) {
      ii_data = 0;
      int exitg2;
      do {
        exitg2 = 0;
        if (ii_data < 4) {
          if (cv[static_cast<int>(symstr_data[ii_data])] !=
              cv[static_cast<int>(cv1[ii_data])]) {
            exitg2 = 1;
          } else {
            ii_data++;
          }
        } else {
          b_bool = true;
          exitg2 = 1;
        }
      } while (exitg2 == 0);
    }
    islinphaseflag = !b_bool;
  }
  return islinphaseflag;
}

} // namespace internal
} // namespace b_signal
} // namespace legacy_STRAIGHT

// End of code generation (islinphase.cpp)
