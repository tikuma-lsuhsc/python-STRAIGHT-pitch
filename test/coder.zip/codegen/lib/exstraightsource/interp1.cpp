//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// interp1.cpp
//
// Code generation for function 'interp1'
//

// Include files
#include "interp1.h"
#include "bsearch.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"
#include <algorithm>
#include <cmath>

// Function Declarations
namespace legacy_STRAIGHT {
static void interp1Linear(const ::coder::array<double, 1U> &y,
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const ::coder::array<double, 2U> &varargin_1);

static void interp1Linear(const ::coder::array<double, 2U> &y,
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const ::coder::array<double, 2U> &varargin_1);

static void interp1Linear(const double y_data[], const double xi[1025],
                          const double varargin_1_data[], int varargin_1_size,
                          double yi[1025]);

static void interp1Linear(const double y[1025],
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const double varargin_1[1025]);

} // namespace legacy_STRAIGHT

// Function Definitions
namespace legacy_STRAIGHT {
static void interp1Linear(const ::coder::array<double, 1U> &y,
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const ::coder::array<double, 2U> &varargin_1)
{
  double d;
  double maxx;
  double minx;
  double r;
  int n;
  int ub_loop;
  minx = varargin_1[0];
  maxx = varargin_1[varargin_1.size(1) - 1];
  ub_loop = xi.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(d, n, r)

  for (int k = 0; k <= ub_loop; k++) {
    d = xi[k];
    if (std::isnan(d)) {
      yi[k] = rtNaN;
    } else if ((!(d > maxx)) && (!(d < minx))) {
      n = coder::internal::b_bsearch(varargin_1, d) - 1;
      r = (d - varargin_1[n]) / (varargin_1[n + 1] - varargin_1[n]);
      if (r == 0.0) {
        yi[k] = y[n];
      } else if (r == 1.0) {
        yi[k] = y[n + 1];
      } else {
        d = y[n + 1];
        if (y[n] == d) {
          yi[k] = y[n];
        } else {
          yi[k] = (1.0 - r) * y[n] + r * d;
        }
      }
    }
  }
}

static void interp1Linear(const ::coder::array<double, 2U> &y,
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const ::coder::array<double, 2U> &varargin_1)
{
  double d;
  double maxx;
  double minx;
  double r;
  int n;
  int ub_loop;
  minx = varargin_1[0];
  maxx = varargin_1[varargin_1.size(1) - 1];
  ub_loop = xi.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(d, n, r)

  for (int k = 0; k <= ub_loop; k++) {
    d = xi[k];
    if (std::isnan(d)) {
      yi[k] = rtNaN;
    } else if ((!(d > maxx)) && (!(d < minx))) {
      n = coder::internal::b_bsearch(varargin_1, d) - 1;
      r = (d - varargin_1[n]) / (varargin_1[n + 1] - varargin_1[n]);
      if (r == 0.0) {
        yi[k] = y[n];
      } else if (r == 1.0) {
        yi[k] = y[n + 1];
      } else {
        d = y[n + 1];
        if (y[n] == d) {
          yi[k] = y[n];
        } else {
          yi[k] = (1.0 - r) * y[n] + r * d;
        }
      }
    }
  }
}

static void interp1Linear(const double y_data[], const double xi[1025],
                          const double varargin_1_data[], int varargin_1_size,
                          double yi[1025])
{
  ::coder::array<double, 1U> b_varargin_1_data;
  double maxx;
  double minx;
  double r;
  int n;
  for (int i{0}; i < 1025; i++) {
    yi[i] = rtNaN;
  }
  minx = varargin_1_data[0];
  maxx = varargin_1_data[varargin_1_size - 1];
#pragma omp parallel for num_threads(omp_get_max_threads()) private(r, n)      \
    firstprivate(b_varargin_1_data)

  for (int k = 0; k < 1025; k++) {
    r = xi[k];
    if (std::isnan(r)) {
      yi[k] = rtNaN;
    } else if ((!(r > maxx)) && (!(r < minx))) {
      b_varargin_1_data.set((double *)&varargin_1_data[0], varargin_1_size);
      n = coder::internal::b_bsearch(b_varargin_1_data, r) - 1;
      r = (r - varargin_1_data[n]) /
          (varargin_1_data[n + 1] - varargin_1_data[n]);
      if (r == 0.0) {
        yi[k] = y_data[n];
      } else if (r == 1.0) {
        yi[k] = y_data[n + 1];
      } else if (y_data[n] == y_data[n + 1]) {
        yi[k] = y_data[n];
      } else {
        yi[k] = (1.0 - r) * y_data[n] + r * y_data[n + 1];
      }
    }
  }
}

static void interp1Linear(const double y[1025],
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const double varargin_1[1025])
{
  double maxx;
  double minx;
  double r;
  double r_tmp;
  int high_i;
  int low_i;
  int low_ip1;
  int mid_i;
  int ub_loop;
  minx = varargin_1[0];
  maxx = varargin_1[1024];
  ub_loop = xi.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        r_tmp, low_i, low_ip1, high_i, mid_i, r)

  for (int k = 0; k <= ub_loop; k++) {
    r_tmp = xi[k];
    if (std::isnan(r_tmp)) {
      yi[k] = rtNaN;
    } else if ((!(r_tmp > maxx)) && (!(r_tmp < minx))) {
      low_i = 1;
      low_ip1 = 2;
      high_i = 1025;
      while (high_i > low_ip1) {
        mid_i = (low_i + high_i) >> 1;
        if (xi[k] >= varargin_1[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }
      r_tmp = varargin_1[low_i - 1];
      r = (xi[k] - r_tmp) / (varargin_1[low_i] - r_tmp);
      if (r == 0.0) {
        yi[k] = y[low_i - 1];
      } else if (r == 1.0) {
        yi[k] = y[low_i];
      } else {
        r_tmp = y[low_i - 1];
        if (r_tmp == y[low_i]) {
          yi[k] = r_tmp;
        } else {
          yi[k] = (1.0 - r) * r_tmp + r * y[low_i];
        }
      }
    }
  }
}

void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<creal_T, 2U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<creal_T, 2U> &Vq)
{
  ::coder::array<creal_T, 2U> y;
  ::coder::array<double, 2U> x;
  int i;
  int i1;
  int i2;
  int nd2;
  int nx_tmp;
  int nycols_tmp;
  boolean_T b;
  i = varargin_2.size(0);
  y.set_size(varargin_2.size(0), varargin_2.size(1));
  nd2 = varargin_2.size(0) * varargin_2.size(1);
  for (i1 = 0; i1 < nd2; i1++) {
    y[i1] = varargin_2[i1];
  }
  nd2 = varargin_1.size(1);
  x.set_size(1, varargin_1.size(1));
  for (i1 = 0; i1 < nd2; i1++) {
    x[i1] = varargin_1[i1];
  }
  nycols_tmp = varargin_2.size(1) - 1;
  nx_tmp = varargin_1.size(1) - 1;
  i1 = varargin_3.size(1);
  Vq.set_size(varargin_3.size(1), varargin_2.size(1));
  nd2 = varargin_3.size(1) * varargin_2.size(1);
  for (i2 = 0; i2 < nd2; i2++) {
    Vq[i2].re = rtNaN;
    Vq[i2].im = rtNaN;
  }
  b = (varargin_3.size(1) == 0);
  if (!b) {
    int k;
    k = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (k <= nx_tmp) {
        if (std::isnan(varargin_1[k])) {
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        double tmp_im;
        double xtmp;
        int n;
        if (varargin_1[1] < varargin_1[0]) {
          int offset;
          i2 = (nx_tmp + 1) >> 1;
          for (offset = 0; offset < i2; offset++) {
            xtmp = x[offset];
            nd2 = nx_tmp - offset;
            x[offset] = x[nd2];
            x[nd2] = xtmp;
          }
          if ((varargin_2.size(0) != 0) && (varargin_2.size(1) != 0) &&
              (varargin_2.size(0) > 1)) {
            n = varargin_2.size(0) - 1;
            nd2 = varargin_2.size(0) >> 1;
            for (int j{0}; j <= nycols_tmp; j++) {
              offset = j * varargin_2.size(0);
              for (k = 0; k < nd2; k++) {
                int tmp_re_tmp;
                tmp_re_tmp = offset + k;
                xtmp = y[tmp_re_tmp].re;
                tmp_im = y[tmp_re_tmp].im;
                i2 = (offset + n) - k;
                y[tmp_re_tmp] = y[i2];
                y[i2].re = xtmp;
                y[i2].im = tmp_im;
              }
            }
          }
        }
        for (k = 0; k < i1; k++) {
          xtmp = varargin_3[k];
          if (std::isnan(xtmp)) {
            for (int j{0}; j <= nycols_tmp; j++) {
              i2 = k + j * i1;
              Vq[i2].re = rtNaN;
              Vq[i2].im = rtNaN;
            }
          } else if ((!(xtmp > x[nx_tmp])) && (!(xtmp < x[0]))) {
            double r;
            n = coder::internal::b_bsearch(x, xtmp);
            tmp_im = x[n - 1];
            r = (xtmp - tmp_im) / (x[n] - tmp_im);
            if (r == 0.0) {
              for (int j{0}; j <= nycols_tmp; j++) {
                Vq[k + j * i1] = y[(n + j * i) - 1];
              }
            } else if (r == 1.0) {
              for (int j{0}; j <= nycols_tmp; j++) {
                Vq[k + j * i1] = y[n + j * i];
              }
            } else {
              for (int j{0}; j <= nycols_tmp; j++) {
                double y2_im;
                double y2_re;
                nd2 = n + j * i;
                xtmp = y[nd2 - 1].re;
                tmp_im = y[nd2 - 1].im;
                y2_re = y[nd2].re;
                y2_im = y[nd2].im;
                if ((xtmp == y2_re) && (tmp_im == y2_im)) {
                  i2 = k + j * i1;
                  Vq[i2].re = xtmp;
                  Vq[i2].im = tmp_im;
                } else {
                  i2 = k + j * i1;
                  Vq[i2].re = (1.0 - r) * xtmp + r * y2_re;
                  Vq[i2].im = (1.0 - r) * tmp_im + r * y2_im;
                }
              }
            }
          }
        }
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<double, 1U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq)
{
  ::coder::array<double, 2U> x;
  ::coder::array<double, 1U> y;
  int k;
  int n;
  int nx;
  boolean_T b;
  n = varargin_2.size(0);
  y.set_size(varargin_2.size(0));
  for (k = 0; k < n; k++) {
    y[k] = varargin_2[k];
  }
  n = varargin_1.size(1);
  x.set_size(1, varargin_1.size(1));
  for (k = 0; k < n; k++) {
    x[k] = varargin_1[k];
  }
  nx = varargin_1.size(1) - 1;
  Vq.set_size(1, varargin_3.size(1));
  n = varargin_3.size(1);
  for (k = 0; k < n; k++) {
    Vq[k] = rtNaN;
  }
  b = (varargin_3.size(1) == 0);
  if (!b) {
    k = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (k <= nx) {
        if (std::isnan(varargin_1[k])) {
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        if (varargin_1[1] < varargin_1[0]) {
          double xtmp;
          int b_j1;
          k = (nx + 1) >> 1;
          for (b_j1 = 0; b_j1 < k; b_j1++) {
            xtmp = x[b_j1];
            n = nx - b_j1;
            x[b_j1] = x[n];
            x[n] = xtmp;
          }
          if (varargin_2.size(0) > 1) {
            n = varargin_2.size(0) - 1;
            nx = varargin_2.size(0) >> 1;
            for (k = 0; k < nx; k++) {
              xtmp = y[k];
              b_j1 = n - k;
              y[k] = y[b_j1];
              y[b_j1] = xtmp;
            }
          }
        }
        interp1Linear(y, varargin_3, Vq, x);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

void interp1(const ::coder::array<double, 2U> &varargin_1,
             const ::coder::array<double, 2U> &varargin_2,
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq)
{
  ::coder::array<double, 2U> x;
  ::coder::array<double, 2U> y;
  int i;
  int nd2;
  int nx;
  boolean_T b;
  nd2 = varargin_2.size(1);
  y.set_size(1, varargin_2.size(1));
  for (i = 0; i < nd2; i++) {
    y[i] = varargin_2[i];
  }
  nd2 = varargin_1.size(1);
  x.set_size(1, varargin_1.size(1));
  for (i = 0; i < nd2; i++) {
    x[i] = varargin_1[i];
  }
  nx = varargin_1.size(1) - 1;
  Vq.set_size(1, varargin_3.size(1));
  nd2 = varargin_3.size(1);
  for (i = 0; i < nd2; i++) {
    Vq[i] = rtNaN;
  }
  b = (varargin_3.size(1) == 0);
  if (!b) {
    nd2 = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (nd2 <= nx) {
        if (std::isnan(varargin_1[nd2])) {
          exitg1 = 1;
        } else {
          nd2++;
        }
      } else {
        if (varargin_1[1] < varargin_1[0]) {
          double xtmp;
          i = (nx + 1) >> 1;
          for (int b_j1{0}; b_j1 < i; b_j1++) {
            xtmp = x[b_j1];
            nd2 = nx - b_j1;
            x[b_j1] = x[nd2];
            x[nd2] = xtmp;
          }
          nd2 = varargin_2.size(1) >> 1;
          for (int b_j1{0}; b_j1 < nd2; b_j1++) {
            nx = (varargin_2.size(1) - b_j1) - 1;
            xtmp = y[b_j1];
            y[b_j1] = y[nx];
            y[nx] = xtmp;
          }
        }
        interp1Linear(y, varargin_3, Vq, x);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

void interp1(const double varargin_1_data[], int varargin_1_size,
             const double varargin_2_data[], int varargin_2_size,
             const double varargin_3[1025], double Vq[1025])
{
  ::coder::array<double, 1U> x;
  double x_data[4];
  int k;
  int nd2;
  x.set_size(varargin_2_size);
  for (nd2 = 0; nd2 < varargin_2_size; nd2++) {
    x[nd2] = varargin_2_data[nd2];
  }
  if (varargin_1_size - 1 >= 0) {
    std::copy(&varargin_1_data[0], &varargin_1_data[varargin_1_size],
              &x_data[0]);
  }
  k = 0;
  int exitg1;
  do {
    exitg1 = 0;
    if (k <= varargin_1_size - 1) {
      if (std::isnan(varargin_1_data[k])) {
        exitg1 = 1;
      } else {
        k++;
      }
    } else {
      if (varargin_1_data[1] < varargin_1_data[0]) {
        double xtmp;
        int x_tmp;
        nd2 = varargin_1_size >> 1;
        for (k = 0; k < nd2; k++) {
          xtmp = x_data[k];
          x_tmp = (varargin_1_size - k) - 1;
          x_data[k] = x_data[x_tmp];
          x_data[x_tmp] = xtmp;
        }
        x.set_size(varargin_2_size);
        for (nd2 = 0; nd2 < varargin_2_size; nd2++) {
          x[nd2] = varargin_2_data[nd2];
        }
        if (varargin_2_size > 1) {
          nd2 = varargin_2_size >> 1;
          for (k = 0; k < nd2; k++) {
            xtmp = x[k];
            x_tmp = (varargin_2_size - k) - 1;
            x[k] = x[x_tmp];
            x[x_tmp] = xtmp;
          }
        }
      }
      interp1Linear((const double *)x.data(), varargin_3, x_data,
                    varargin_1_size, Vq);
      exitg1 = 1;
    }
  } while (exitg1 == 0);
}

void interp1(const double varargin_1[1025], const double varargin_2[1025],
             const ::coder::array<double, 2U> &varargin_3,
             ::coder::array<double, 2U> &Vq)
{
  double x[1025];
  double y[1025];
  int loop_ub;
  boolean_T b;
  std::copy(&varargin_2[0], &varargin_2[1025], &y[0]);
  std::copy(&varargin_1[0], &varargin_1[1025], &x[0]);
  Vq.set_size(1, varargin_3.size(1));
  loop_ub = varargin_3.size(1);
  for (int i{0}; i < loop_ub; i++) {
    Vq[i] = rtNaN;
  }
  b = (varargin_3.size(1) == 0);
  if (!b) {
    loop_ub = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (loop_ub < 1025) {
        if (std::isnan(varargin_1[loop_ub])) {
          exitg1 = 1;
        } else {
          loop_ub++;
        }
      } else {
        if (varargin_1[1] < varargin_1[0]) {
          for (loop_ub = 0; loop_ub < 512; loop_ub++) {
            double xtmp;
            xtmp = x[loop_ub];
            x[loop_ub] = x[1024 - loop_ub];
            x[1024 - loop_ub] = xtmp;
            xtmp = y[loop_ub];
            y[loop_ub] = y[1024 - loop_ub];
            y[1024 - loop_ub] = xtmp;
          }
        }
        interp1Linear(y, varargin_3, Vq, x);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (interp1.cpp)
