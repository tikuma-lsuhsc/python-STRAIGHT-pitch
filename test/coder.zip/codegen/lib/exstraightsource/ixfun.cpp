//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ixfun.cpp
//
// Code generation for function 'ixfun'
//

// Include files
#include "ixfun.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
void expand_min(const ::coder::array<double, 1U> &a,
                const ::coder::array<double, 1U> &b,
                ::coder::array<double, 1U> &c)
{
  int csz_idx_0;
  int u1;
  csz_idx_0 = a.size(0);
  u1 = b.size(0);
  if (csz_idx_0 <= u1) {
    u1 = csz_idx_0;
  }
  if (b.size(0) == 1) {
    csz_idx_0 = a.size(0);
  } else {
    csz_idx_0 = u1;
  }
  c.set_size(csz_idx_0);
  if (csz_idx_0 != 0) {
    boolean_T b_b;
    b_b = (b.size(0) != 1);
    csz_idx_0--;
    for (u1 = 0; u1 <= csz_idx_0; u1++) {
      c[u1] = std::fmin(a[u1], b[b_b * u1]);
    }
  }
}

} // namespace internal
} // namespace coder
} // namespace legacy_STRAIGHT

// End of code generation (ixfun.cpp)
