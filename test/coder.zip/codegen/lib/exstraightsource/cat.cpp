//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cat.cpp
//
// Code generation for function 'cat'
//

// Include files
#include "cat.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
void binary_expand_op_75(double in1[2], const coder::array<double, 2U> &in2,
                         const coder::array<double, 2U> &in3,
                         const coder::array<double, 2U> &in4,
                         const coder::array<double, 2U> &in5,
                         const coder::array<double, 2U> &in6)
{
  coder::array<double, 2U> b_in2;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  int stride_2_1;
  int stride_3_1;
  if (in6.size(1) == 1) {
    if (in5.size(1) == 1) {
      if (in3.size(1) == 1) {
        loop_ub = in2.size(1);
      } else {
        loop_ub = in3.size(1);
      }
    } else {
      loop_ub = in5.size(1);
    }
  } else {
    loop_ub = in6.size(1);
  }
  b_in2.set_size(1, loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  stride_2_1 = (in5.size(1) != 1);
  stride_3_1 = (in6.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in2[i] =
        static_cast<double>(in2[i * stride_0_1] * in3[i * stride_1_1] < 0.0) *
        in4[static_cast<int>(in5[i * stride_2_1]) - 1] *
        static_cast<double>(in6[i * stride_3_1] < 0.0);
  }
  in1[0] = 0.0;
  in1[1] = b_in2[0];
}

void binary_expand_op_76(double in1[2], const coder::array<double, 2U> &in2,
                         const coder::array<double, 2U> &in3,
                         const coder::array<double, 2U> &in4,
                         const coder::array<double, 2U> &in5,
                         const coder::array<double, 2U> &in6)
{
  coder::array<double, 2U> b_in2;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  int stride_2_1;
  int stride_3_1;
  if (in6.size(1) == 1) {
    if (in5.size(1) == 1) {
      if (in3.size(1) == 1) {
        loop_ub = in2.size(1);
      } else {
        loop_ub = in3.size(1);
      }
    } else {
      loop_ub = in5.size(1);
    }
  } else {
    loop_ub = in6.size(1);
  }
  b_in2.set_size(1, loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  stride_2_1 = (in5.size(1) != 1);
  stride_3_1 = (in6.size(1) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in2[i] =
        static_cast<double>(in2[i * stride_0_1] * in3[i * stride_1_1] < 0.0) *
        in4[static_cast<int>(in5[i * stride_2_1]) - 1] *
        static_cast<double>(in6[i * stride_3_1] > 0.0);
  }
  in1[0] = 0.0;
  in1[1] = b_in2[0];
}

// End of code generation (cat.cpp)
