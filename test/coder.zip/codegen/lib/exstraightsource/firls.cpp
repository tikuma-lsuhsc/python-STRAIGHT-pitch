//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// firls.cpp
//
// Code generation for function 'firls'
//

// Include files
#include "firls.h"
#include "blockedSummation.h"
#include "diff.h"
#include "exstraightsource_rtwutil.h"
#include "minOrMax.h"
#include "mldivide.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "coder_array.h"
#include "omp.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstring>
#include <emmintrin.h>

// Function Declarations
static void binary_expand_op_12(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3, double in4,
                                const coder::array<double, 1U> &in5);

static void binary_expand_op_13(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5);

static void binary_expand_op_83(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3, double in4,
                                const coder::array<double, 1U> &in5,
                                double in6);

static void binary_expand_op_84(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5,
                                double in6);

static double rt_remd_snf(double u0, double u1);

// Function Definitions
static void binary_expand_op_12(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3, double in4,
                                const coder::array<double, 1U> &in5)
{
  coder::array<double, 1U> b_in1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    int in1_tmp;
    in1_tmp = i * stride_1_0;
    b_in1[i] = in1[i * stride_0_0] + (in2 * in3[in1_tmp] - in4 * in5[in1_tmp]);
  }
  in1.set_size(loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

static void binary_expand_op_13(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5)
{
  coder::array<double, 1U> b_in1;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  if (in5.size(0) == 1) {
    i = in3.size(0);
  } else {
    i = in5.size(0);
  }
  if (i == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = i;
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_2_0 = (in5.size(0) != 1);
  for (i = 0; i < loop_ub; i++) {
    double b_in1_tmp;
    int in1_tmp;
    in1_tmp = i * stride_1_0;
    b_in1_tmp = in5[i * stride_2_0];
    b_in1[i] = in1[i * stride_0_0] +
               in2 * (in3[in1_tmp] - in4[in1_tmp]) / (b_in1_tmp * b_in1_tmp);
  }
  in1.set_size(loop_ub);
  for (i = 0; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

static void binary_expand_op_83(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3, double in4,
                                const coder::array<double, 1U> &in5, double in6)
{
  coder::array<double, 1U> b_in1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    int in1_tmp;
    in1_tmp = i * stride_1_0;
    b_in1[i] =
        in1[i * stride_0_0] + (in2 * in3[in1_tmp] - in4 * in5[in1_tmp]) * in6;
  }
  in1.set_size(loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

static void binary_expand_op_84(coder::array<double, 1U> &in1, double in2,
                                const coder::array<double, 1U> &in3,
                                const coder::array<double, 1U> &in4,
                                const coder::array<double, 1U> &in5, double in6)
{
  coder::array<double, 1U> b_in1;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  if (in5.size(0) == 1) {
    i = in3.size(0);
  } else {
    i = in5.size(0);
  }
  if (i == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = i;
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_2_0 = (in5.size(0) != 1);
  for (i = 0; i < loop_ub; i++) {
    double b_in1_tmp;
    int in1_tmp;
    in1_tmp = i * stride_1_0;
    b_in1_tmp = in5[i * stride_2_0];
    b_in1[i] = in1[i * stride_0_0] + in2 * (in3[in1_tmp] - in4[in1_tmp]) /
                                         (b_in1_tmp * b_in1_tmp) * in6;
  }
  in1.set_size(loop_ub);
  for (i = 0; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

static double rt_remd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1) || std::isinf(u0)) {
    y = rtNaN;
  } else if (std::isinf(u1)) {
    y = u0;
  } else if ((u1 != 0.0) && (u1 != std::trunc(u1))) {
    double q;
    q = std::abs(u0 / u1);
    if (!(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q)) {
      y = 0.0 * u0;
    } else {
      y = std::fmod(u0, u1);
    }
  } else {
    y = std::fmod(u0, u1);
  }
  return y;
}

namespace legacy_STRAIGHT {
void b_eFirls(double N, const double freq[6], ::coder::array<double, 2U> &h,
              ::coder::array<double, 1U> &a)
{
  static const signed char A[6]{0, 0, 1, 1, 0, 0};
  ::coder::array<double, 2U> G;
  ::coder::array<double, 2U> b_m;
  ::coder::array<double, 2U> sinc2A;
  ::coder::array<double, 2U> sinc3A;
  ::coder::array<double, 2U> sinc4A;
  ::coder::array<double, 1U> k;
  ::coder::array<double, 1U> y;
  ::coder::array<double, 1U> y_tmp;
  double max_freq[6];
  double min_freq[6];
  double i2Map;
  double k1;
  double k2;
  double k3;
  double k4;
  int i;
  unsigned int i1Map;
  int nn;
  for (i = 0; i < 6; i++) {
    max_freq[i] = freq[i];
    min_freq[i] = freq[i];
  }
  if ((!(max_freq[0] > 1.0)) && (!(min_freq[0] < 0.0))) {
    __m128d r;
    __m128d r1;
    double dF[5];
    double L;
    double b0;
    double tmp2;
    double tmpStorageLen;
    double work;
    int b_i;
    int i1Start;
    int loop_ub;
    int m;
    int md2;
    int nG;
    int nx;
    int s;
    boolean_T Nodd;
    boolean_T exitg1;
    boolean_T fullband;
    N++;
    r = _mm_set1_pd(2.0);
    _mm_storeu_pd(&max_freq[0], _mm_div_pd(_mm_loadu_pd(&freq[0]), r));
    _mm_storeu_pd(&max_freq[2], _mm_div_pd(_mm_loadu_pd(&freq[2]), r));
    _mm_storeu_pd(&max_freq[4], _mm_div_pd(_mm_loadu_pd(&freq[4]), r));
    work = 0.0;
    for (m = 0; m < 5; m++) {
      tmp2 = work;
      work = max_freq[m + 1];
      dF[m] = work - tmp2;
    }
    fullband = true;
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 2)) {
      if (dF[(i << 1) + 1] != 0.0) {
        fullband = false;
        exitg1 = true;
      } else {
        i++;
      }
    }
    L = (N - 1.0) / 2.0;
    Nodd = (rt_remd_snf(N, 2.0) == 1.0);
    b0 = 0.0;
    if (!Nodd) {
      if (L < 0.0) {
        b_m.set_size(b_m.size(0), 0);
      } else {
        b_m.set_size(1, static_cast<int>(L) + 1);
        loop_ub = static_cast<int>(L);
        for (b_i = 0; b_i <= loop_ub; b_i++) {
          b_m[b_i] = b_i;
        }
      }
      b_m.set_size(1, b_m.size(1));
      loop_ub = b_m.size(1) - 1;
      md2 = (b_m.size(1) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r1 = _mm_loadu_pd(&b_m[b_i]);
        _mm_storeu_pd(&b_m[b_i], _mm_add_pd(r1, _mm_set1_pd(0.5)));
      }
      for (b_i = md2; b_i <= loop_ub; b_i++) {
        b_m[b_i] = b_m[b_i] + 0.5;
      }
    } else if (L < 0.0) {
      b_m.set_size(1, 0);
    } else {
      b_m.set_size(1, static_cast<int>(L) + 1);
      loop_ub = static_cast<int>(L);
      for (b_i = 0; b_i <= loop_ub; b_i++) {
        b_m[b_i] = b_i;
      }
    }
    loop_ub = b_m.size(1);
    k.set_size(b_m.size(1));
    for (b_i = 0; b_i < loop_ub; b_i++) {
      k[b_i] = b_m[b_i];
    }
    fullband = !fullband;
    nG = b_m.size(1);
    if (fullband) {
      G.set_size(b_m.size(1), b_m.size(1));
      nx = k.size(0) * k.size(0);
      for (b_i = 0; b_i < nx; b_i++) {
        G[b_i] = 0.0;
      }
      tmpStorageLen = 2.0 * static_cast<double>(k.size(0)) - 1.0;
    } else {
      G.set_size(0, 0);
      tmpStorageLen = 0.0;
    }
    b_m.set_size(1, static_cast<int>(tmpStorageLen));
    sinc2A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc3A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc4A.set_size(1, static_cast<int>(tmpStorageLen));
    if (Nodd) {
      i1Start = -1;
      if (k.size(0) < 2) {
        b_i = 0;
        loop_ub = 0;
      } else {
        b_i = 1;
      }
      m = loop_ub - b_i;
      for (s = 0; s < m; s++) {
        k[s] = k[b_i + s];
      }
      k.set_size(m);
    } else {
      i1Start = 0;
    }
    loop_ub = k.size(0);
    a.set_size(k.size(0));
    for (b_i = 0; b_i < loop_ub; b_i++) {
      a[b_i] = 0.0;
    }
    for (int b_s{0}; b_s < 3; b_s++) {
      __m128d r2;
      __m128d r3;
      double b1;
      double b1_tmp;
      double b_a;
      double d;
      double m_s_tmp_tmp;
      signed char i1;
      s = b_s << 1;
      m_s_tmp_tmp = max_freq[s + 1];
      d = max_freq[s];
      work = m_s_tmp_tmp - d;
      i1 = A[s];
      tmp2 = static_cast<double>(A[s + 1] - i1) / work;
      b1_tmp = tmp2 * d;
      b1 = static_cast<double>(i1) - b1_tmp;
      if (Nodd) {
        b0 += b1 * work + tmp2 / 2.0 * (m_s_tmp_tmp * m_s_tmp_tmp - d * d);
      }
      m = k.size(0);
      y_tmp.set_size(k.size(0));
      md2 = (k.size(0) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r1 = _mm_loadu_pd(&k[b_i]);
        _mm_storeu_pd(&y_tmp[b_i],
                      _mm_mul_pd(_mm_set1_pd(6.2831853071795862), r1));
      }
      for (b_i = md2; b_i < m; b_i++) {
        y_tmp[b_i] = 6.2831853071795862 * k[b_i];
      }
      loop_ub = y_tmp.size(0);
      y.set_size(y_tmp.size(0));
      md2 = (y_tmp.size(0) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r1 = _mm_loadu_pd(&y_tmp[b_i]);
        _mm_storeu_pd(&y[b_i], _mm_mul_pd(r1, _mm_set1_pd(m_s_tmp_tmp)));
      }
      for (b_i = md2; b_i < loop_ub; b_i++) {
        y[b_i] = y_tmp[b_i] * m_s_tmp_tmp;
      }
      nx = y.size(0);
      for (md2 = 0; md2 < nx; md2++) {
        y[md2] = std::cos(y[md2]);
        y_tmp[md2] = y_tmp[md2] * max_freq[s];
      }
      for (md2 = 0; md2 < loop_ub; md2++) {
        y_tmp[md2] = std::cos(y_tmp[md2]);
      }
      b_a = tmp2 / 39.478417604357432;
      loop_ub = a.size(0);
      if (y.size(0) == 1) {
        b_i = k.size(0);
      } else {
        b_i = y.size(0);
      }
      if ((y.size(0) == k.size(0)) && (a.size(0) == b_i)) {
        md2 = (a.size(0) / 2) << 1;
        i = md2 - 2;
        for (b_i = 0; b_i <= i; b_i += 2) {
          __m128d r4;
          r1 = _mm_loadu_pd(&y[b_i]);
          r2 = _mm_loadu_pd(&y_tmp[b_i]);
          r3 = _mm_loadu_pd(&k[b_i]);
          r4 = _mm_loadu_pd(&a[b_i]);
          _mm_storeu_pd(
              &a[b_i], _mm_add_pd(r4, _mm_div_pd(_mm_mul_pd(_mm_set1_pd(b_a),
                                                            _mm_sub_pd(r1, r2)),
                                                 _mm_mul_pd(r3, r3))));
        }
        for (b_i = md2; b_i < loop_ub; b_i++) {
          a[b_i] = a[b_i] + b_a * (y[b_i] - y_tmp[b_i]) / (k[b_i] * k[b_i]);
        }
      } else {
        binary_expand_op_13(a, b_a, y, y_tmp, k);
      }
      m = k.size(0);
      y_tmp.set_size(k.size(0));
      md2 = (k.size(0) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r1 = _mm_loadu_pd(&k[b_i]);
        _mm_storeu_pd(&y_tmp[b_i], _mm_mul_pd(r, r1));
      }
      for (b_i = md2; b_i < m; b_i++) {
        y_tmp[b_i] = 2.0 * k[b_i];
      }
      loop_ub = y_tmp.size(0);
      y.set_size(y_tmp.size(0));
      md2 = (y_tmp.size(0) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r1 = _mm_loadu_pd(&y_tmp[b_i]);
        _mm_storeu_pd(&y[b_i], _mm_mul_pd(r1, _mm_set1_pd(m_s_tmp_tmp)));
      }
      for (b_i = md2; b_i < loop_ub; b_i++) {
        y[b_i] = y_tmp[b_i] * m_s_tmp_tmp;
      }
      b_a = m_s_tmp_tmp * (tmp2 * m_s_tmp_tmp + b1);
      b_i = y.size(0);
      for (md2 = 0; md2 < b_i; md2++) {
        if (std::abs(y[md2]) < 1.0020841800044864E-292) {
          y[md2] = 1.0;
        } else {
          d = 3.1415926535897931 * y[md2];
          d = std::sin(d) / d;
          y[md2] = d;
        }
        y_tmp[md2] = y_tmp[md2] * max_freq[s];
      }
      work = max_freq[s] * (b1_tmp + b1);
      for (md2 = 0; md2 < loop_ub; md2++) {
        if (std::abs(y_tmp[md2]) < 1.0020841800044864E-292) {
          y_tmp[md2] = 1.0;
        } else {
          d = 3.1415926535897931 * y_tmp[md2];
          d = std::sin(d) / d;
          y_tmp[md2] = d;
        }
      }
      loop_ub = a.size(0);
      if (a.size(0) == y.size(0)) {
        md2 = (a.size(0) / 2) << 1;
        i = md2 - 2;
        for (b_i = 0; b_i <= i; b_i += 2) {
          r1 = _mm_loadu_pd(&y[b_i]);
          r2 = _mm_loadu_pd(&y_tmp[b_i]);
          r3 = _mm_loadu_pd(&a[b_i]);
          _mm_storeu_pd(
              &a[b_i],
              _mm_add_pd(r3, _mm_sub_pd(_mm_mul_pd(_mm_set1_pd(b_a), r1),
                                        _mm_mul_pd(_mm_set1_pd(work), r2))));
        }
        for (b_i = md2; b_i < loop_ub; b_i++) {
          a[b_i] = a[b_i] + (b_a * y[b_i] - work * y_tmp[b_i]);
        }
      } else {
        binary_expand_op_12(a, b_a, y, work, y_tmp);
      }
      if (fullband) {
        work = 2.0 * m_s_tmp_tmp;
        tmp2 = 2.0 * max_freq[s];
        md2 = static_cast<int>(tmpStorageLen) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        k4, k3, k2, k1, i2Map, i1Map)

        for (int ii = 0; ii <= md2; ii++) {
          i1Map = static_cast<unsigned int>((static_cast<double>(ii) + 1.0) +
                                            static_cast<double>(i1Start));
          i2Map = (static_cast<double>(ii) + 1.0) - static_cast<double>(nG);
          k1 = work * static_cast<double>(i1Map);
          k2 = tmp2 * static_cast<double>(i1Map);
          k3 = work * i2Map;
          k4 = tmp2 * i2Map;
          if (std::abs(k1) < 1.0020841800044864E-292) {
            b_m[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k1;
            b_m[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k2) < 1.0020841800044864E-292) {
            sinc2A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k2;
            sinc2A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k3) < 1.0020841800044864E-292) {
            sinc3A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k3;
            sinc3A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k4) < 1.0020841800044864E-292) {
            sinc4A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k4;
            sinc4A[ii] = std::sin(i2Map) / i2Map;
          }
        }
        md2 = nG - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        i2Map, i1Map, nn)

        for (int ii = 0; ii <= md2; ii++) {
          for (nn = 0; nn < nG; nn++) {
            i1Map = (static_cast<unsigned int>(nn) +
                     static_cast<unsigned int>(ii)) +
                    1U;
            i2Map = static_cast<double>(nn - ii) + static_cast<double>(nG);
            G[nn + G.size(0) * ii] =
                G[nn + G.size(0) * ii] +
                0.25 * (work * (b_m[static_cast<int>(i1Map) - 1] +
                                sinc3A[static_cast<int>(i2Map) - 1]) -
                        tmp2 * (sinc2A[static_cast<int>(i1Map) - 1] +
                                sinc4A[static_cast<int>(i2Map) - 1]));
          }
        }
      }
    }
    if (Nodd) {
      loop_ub = a.size(0) + 1;
      k.set_size(a.size(0) + 1);
      k[0] = b0;
      nx = a.size(0);
      for (b_i = 0; b_i < nx; b_i++) {
        k[b_i + 1] = a[b_i];
      }
      a.set_size(loop_ub);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        a[b_i] = k[b_i];
      }
    }
    if (fullband) {
      mldivide(G, a);
    } else {
      loop_ub = a.size(0);
      md2 = (a.size(0) / 2) << 1;
      i = md2 - 2;
      for (b_i = 0; b_i <= i; b_i += 2) {
        r = _mm_loadu_pd(&a[b_i]);
        _mm_storeu_pd(&a[b_i], _mm_mul_pd(_mm_set1_pd(4.0), r));
      }
      for (b_i = md2; b_i < loop_ub; b_i++) {
        a[b_i] = 4.0 * a[b_i];
      }
      if (Nodd) {
        a[0] = a[0] / 2.0;
      }
    }
    if (Nodd) {
      if (L + 1.0 < 2.0) {
        b_i = 0;
        s = 1;
        i = -1;
        md2 = 0;
        nx = 0;
      } else {
        b_i = static_cast<int>(L + 1.0) - 1;
        s = -1;
        i = 1;
        md2 = 1;
        nx = static_cast<int>(L + 1.0);
      }
      loop_ub = div_s32(i - b_i, s);
      h.set_size(1, ((loop_ub + nx) - md2) + 2);
      for (i = 0; i <= loop_ub; i++) {
        h[i] = a[b_i + s * i] / 2.0;
      }
      h[loop_ub + 1] = a[0];
      nx -= md2;
      for (b_i = 0; b_i < nx; b_i++) {
        h[(b_i + loop_ub) + 2] = a[md2 + b_i] / 2.0;
      }
    } else {
      loop_ub = a.size(0);
      y_tmp.set_size(a.size(0));
      for (b_i = 0; b_i < loop_ub; b_i++) {
        y_tmp[b_i] = a[b_i];
      }
      m = a.size(0) - 1;
      md2 = a.size(0) >> 1;
      for (i = 0; i < md2; i++) {
        work = y_tmp[i];
        nx = m - i;
        y_tmp[i] = y_tmp[nx];
        y_tmp[nx] = work;
      }
      h.set_size(1, y_tmp.size(0) + a.size(0));
      nx = (y_tmp.size(0) / 2) << 1;
      md2 = nx - 2;
      for (b_i = 0; b_i <= md2; b_i += 2) {
        r = _mm_loadu_pd(&y_tmp[b_i]);
        _mm_storeu_pd(&h[b_i], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (b_i = nx; b_i < loop_ub; b_i++) {
        h[b_i] = 0.5 * y_tmp[b_i];
      }
      for (b_i = 0; b_i <= md2; b_i += 2) {
        r = _mm_loadu_pd(&a[b_i]);
        _mm_storeu_pd(&h[b_i + y_tmp.size(0)], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (b_i = nx; b_i < loop_ub; b_i++) {
        h[b_i + y_tmp.size(0)] = 0.5 * a[b_i];
      }
    }
    a.set_size(1);
    a[0] = 1.0;
  }
}

void eFirls(double N, const double freq[4], ::coder::array<double, 2U> &h,
            ::coder::array<double, 1U> &a)
{
  static const signed char A[4]{1, 1, 0, 0};
  ::coder::array<double, 2U> G;
  ::coder::array<double, 2U> m;
  ::coder::array<double, 2U> sinc2A;
  ::coder::array<double, 2U> sinc3A;
  ::coder::array<double, 2U> sinc4A;
  ::coder::array<double, 1U> k;
  ::coder::array<double, 1U> y;
  ::coder::array<double, 1U> y_tmp;
  double max_freq[4];
  double i2Map;
  double k1;
  double k2;
  double k3;
  double k4;
  unsigned int i1Map;
  int nn;
  if ((!(freq[0] > 1.0)) && (!(freq[0] < 0.0))) {
    __m128d r;
    __m128d r1;
    double L;
    double b0;
    double f1;
    double tmpStorageLen;
    int i;
    int i1Start;
    int loop_ub;
    int md2;
    int nG;
    int nx;
    int s;
    int vectorUB;
    boolean_T Nodd;
    boolean_T need_matrix;
    N++;
    r = _mm_set1_pd(2.0);
    _mm_storeu_pd(&max_freq[0], _mm_div_pd(_mm_loadu_pd(&freq[0]), r));
    _mm_storeu_pd(&max_freq[2], _mm_div_pd(_mm_loadu_pd(&freq[2]), r));
    L = (N - 1.0) / 2.0;
    Nodd = (rt_remd_snf(N, 2.0) == 1.0);
    b0 = 0.0;
    if (!Nodd) {
      if (L < 0.0) {
        m.set_size(m.size(0), 0);
      } else {
        m.set_size(1, static_cast<int>(L) + 1);
        loop_ub = static_cast<int>(L);
        for (i = 0; i <= loop_ub; i++) {
          m[i] = i;
        }
      }
      m.set_size(1, m.size(1));
      loop_ub = m.size(1) - 1;
      md2 = (m.size(1) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&m[i]);
        _mm_storeu_pd(&m[i], _mm_add_pd(r1, _mm_set1_pd(0.5)));
      }
      for (i = md2; i <= loop_ub; i++) {
        m[i] = m[i] + 0.5;
      }
    } else if (L < 0.0) {
      m.set_size(1, 0);
    } else {
      m.set_size(1, static_cast<int>(L) + 1);
      loop_ub = static_cast<int>(L);
      for (i = 0; i <= loop_ub; i++) {
        m[i] = i;
      }
    }
    loop_ub = m.size(1);
    k.set_size(m.size(1));
    for (i = 0; i < loop_ub; i++) {
      k[i] = m[i];
    }
    need_matrix = (max_freq[2] - max_freq[1] != 0.0);
    nG = m.size(1);
    if (need_matrix) {
      G.set_size(m.size(1), m.size(1));
      md2 = k.size(0) * k.size(0);
      for (i = 0; i < md2; i++) {
        G[i] = 0.0;
      }
      tmpStorageLen = 2.0 * static_cast<double>(k.size(0)) - 1.0;
    } else {
      G.set_size(0, 0);
      tmpStorageLen = 0.0;
    }
    m.set_size(1, static_cast<int>(tmpStorageLen));
    sinc2A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc3A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc4A.set_size(1, static_cast<int>(tmpStorageLen));
    if (Nodd) {
      i1Start = -1;
      if (k.size(0) < 2) {
        i = 0;
        loop_ub = 0;
      } else {
        i = 1;
      }
      nx = loop_ub - i;
      for (s = 0; s < nx; s++) {
        k[s] = k[i + s];
      }
      k.set_size(nx);
    } else {
      i1Start = 0;
    }
    loop_ub = k.size(0);
    a.set_size(k.size(0));
    for (i = 0; i < loop_ub; i++) {
      a[i] = 0.0;
    }
    for (int b_s{0}; b_s < 2; b_s++) {
      __m128d r2;
      __m128d r3;
      double b1;
      double b1_tmp;
      double b_a;
      double d;
      double m_s;
      double m_s_tmp_tmp;
      signed char i1;
      s = b_s << 1;
      m_s_tmp_tmp = max_freq[s + 1];
      d = max_freq[s];
      f1 = m_s_tmp_tmp - d;
      i1 = A[s];
      m_s = static_cast<double>(A[s + 1] - i1) / f1;
      b1_tmp = m_s * d;
      b1 = static_cast<double>(i1) - b1_tmp;
      if (Nodd) {
        b0 += b1 * f1 + m_s / 2.0 * (m_s_tmp_tmp * m_s_tmp_tmp - d * d);
      }
      nx = k.size(0);
      y_tmp.set_size(k.size(0));
      md2 = (k.size(0) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&k[i]);
        _mm_storeu_pd(&y_tmp[i],
                      _mm_mul_pd(_mm_set1_pd(6.2831853071795862), r1));
      }
      for (i = md2; i < nx; i++) {
        y_tmp[i] = 6.2831853071795862 * k[i];
      }
      loop_ub = y_tmp.size(0);
      y.set_size(y_tmp.size(0));
      md2 = (y_tmp.size(0) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&y_tmp[i]);
        _mm_storeu_pd(&y[i], _mm_mul_pd(r1, _mm_set1_pd(m_s_tmp_tmp)));
      }
      for (i = md2; i < loop_ub; i++) {
        y[i] = y_tmp[i] * m_s_tmp_tmp;
      }
      nx = y.size(0);
      for (md2 = 0; md2 < nx; md2++) {
        y[md2] = std::cos(y[md2]);
        y_tmp[md2] = y_tmp[md2] * max_freq[s];
      }
      for (md2 = 0; md2 < loop_ub; md2++) {
        y_tmp[md2] = std::cos(y_tmp[md2]);
      }
      b_a = m_s / 39.478417604357432;
      loop_ub = a.size(0);
      if (y.size(0) == 1) {
        i = k.size(0);
      } else {
        i = y.size(0);
      }
      if ((y.size(0) == k.size(0)) && (a.size(0) == i)) {
        md2 = (a.size(0) / 2) << 1;
        vectorUB = md2 - 2;
        for (i = 0; i <= vectorUB; i += 2) {
          __m128d r4;
          r1 = _mm_loadu_pd(&y[i]);
          r2 = _mm_loadu_pd(&y_tmp[i]);
          r3 = _mm_loadu_pd(&k[i]);
          r4 = _mm_loadu_pd(&a[i]);
          _mm_storeu_pd(
              &a[i], _mm_add_pd(r4, _mm_div_pd(_mm_mul_pd(_mm_set1_pd(b_a),
                                                          _mm_sub_pd(r1, r2)),
                                               _mm_mul_pd(r3, r3))));
        }
        for (i = md2; i < loop_ub; i++) {
          a[i] = a[i] + b_a * (y[i] - y_tmp[i]) / (k[i] * k[i]);
        }
      } else {
        binary_expand_op_13(a, b_a, y, y_tmp, k);
      }
      nx = k.size(0);
      y_tmp.set_size(k.size(0));
      md2 = (k.size(0) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&k[i]);
        _mm_storeu_pd(&y_tmp[i], _mm_mul_pd(r, r1));
      }
      for (i = md2; i < nx; i++) {
        y_tmp[i] = 2.0 * k[i];
      }
      loop_ub = y_tmp.size(0);
      y.set_size(y_tmp.size(0));
      md2 = (y_tmp.size(0) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r1 = _mm_loadu_pd(&y_tmp[i]);
        _mm_storeu_pd(&y[i], _mm_mul_pd(r1, _mm_set1_pd(m_s_tmp_tmp)));
      }
      for (i = md2; i < loop_ub; i++) {
        y[i] = y_tmp[i] * m_s_tmp_tmp;
      }
      b_a = m_s_tmp_tmp * (m_s * m_s_tmp_tmp + b1);
      i = y.size(0);
      for (md2 = 0; md2 < i; md2++) {
        if (std::abs(y[md2]) < 1.0020841800044864E-292) {
          y[md2] = 1.0;
        } else {
          d = 3.1415926535897931 * y[md2];
          d = std::sin(d) / d;
          y[md2] = d;
        }
        y_tmp[md2] = y_tmp[md2] * max_freq[s];
      }
      f1 = max_freq[s] * (b1_tmp + b1);
      for (md2 = 0; md2 < loop_ub; md2++) {
        if (std::abs(y_tmp[md2]) < 1.0020841800044864E-292) {
          y_tmp[md2] = 1.0;
        } else {
          d = 3.1415926535897931 * y_tmp[md2];
          d = std::sin(d) / d;
          y_tmp[md2] = d;
        }
      }
      loop_ub = a.size(0);
      if (a.size(0) == y.size(0)) {
        md2 = (a.size(0) / 2) << 1;
        vectorUB = md2 - 2;
        for (i = 0; i <= vectorUB; i += 2) {
          r1 = _mm_loadu_pd(&y[i]);
          r2 = _mm_loadu_pd(&y_tmp[i]);
          r3 = _mm_loadu_pd(&a[i]);
          _mm_storeu_pd(
              &a[i],
              _mm_add_pd(r3, _mm_sub_pd(_mm_mul_pd(_mm_set1_pd(b_a), r1),
                                        _mm_mul_pd(_mm_set1_pd(f1), r2))));
        }
        for (i = md2; i < loop_ub; i++) {
          a[i] = a[i] + (b_a * y[i] - f1 * y_tmp[i]);
        }
      } else {
        binary_expand_op_12(a, b_a, y, f1, y_tmp);
      }
      if (need_matrix) {
        f1 = 2.0 * m_s_tmp_tmp;
        m_s = 2.0 * max_freq[s];
        md2 = static_cast<int>(tmpStorageLen) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        k4, k3, k2, k1, i2Map, i1Map)

        for (int ii = 0; ii <= md2; ii++) {
          i1Map = static_cast<unsigned int>((static_cast<double>(ii) + 1.0) +
                                            static_cast<double>(i1Start));
          i2Map = (static_cast<double>(ii) + 1.0) - static_cast<double>(nG);
          k1 = f1 * static_cast<double>(i1Map);
          k2 = m_s * static_cast<double>(i1Map);
          k3 = f1 * i2Map;
          k4 = m_s * i2Map;
          if (std::abs(k1) < 1.0020841800044864E-292) {
            m[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k1;
            m[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k2) < 1.0020841800044864E-292) {
            sinc2A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k2;
            sinc2A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k3) < 1.0020841800044864E-292) {
            sinc3A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k3;
            sinc3A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k4) < 1.0020841800044864E-292) {
            sinc4A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k4;
            sinc4A[ii] = std::sin(i2Map) / i2Map;
          }
        }
        md2 = nG - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        i2Map, i1Map, nn)

        for (int ii = 0; ii <= md2; ii++) {
          for (nn = 0; nn < nG; nn++) {
            i1Map = (static_cast<unsigned int>(nn) +
                     static_cast<unsigned int>(ii)) +
                    1U;
            i2Map = static_cast<double>(nn - ii) + static_cast<double>(nG);
            G[nn + G.size(0) * ii] =
                G[nn + G.size(0) * ii] +
                0.25 * (f1 * (m[static_cast<int>(i1Map) - 1] +
                              sinc3A[static_cast<int>(i2Map) - 1]) -
                        m_s * (sinc2A[static_cast<int>(i1Map) - 1] +
                               sinc4A[static_cast<int>(i2Map) - 1]));
          }
        }
      }
    }
    if (Nodd) {
      loop_ub = a.size(0) + 1;
      k.set_size(a.size(0) + 1);
      k[0] = b0;
      md2 = a.size(0);
      for (i = 0; i < md2; i++) {
        k[i + 1] = a[i];
      }
      a.set_size(loop_ub);
      for (i = 0; i < loop_ub; i++) {
        a[i] = k[i];
      }
    }
    if (need_matrix) {
      mldivide(G, a);
    } else {
      loop_ub = a.size(0);
      md2 = (a.size(0) / 2) << 1;
      vectorUB = md2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&a[i]);
        _mm_storeu_pd(&a[i], _mm_mul_pd(_mm_set1_pd(4.0), r));
      }
      for (i = md2; i < loop_ub; i++) {
        a[i] = 4.0 * a[i];
      }
      if (Nodd) {
        a[0] = a[0] / 2.0;
      }
    }
    if (Nodd) {
      if (L + 1.0 < 2.0) {
        i = 0;
        s = 1;
        md2 = -1;
        vectorUB = 0;
        nx = 0;
      } else {
        i = static_cast<int>(L + 1.0) - 1;
        s = -1;
        md2 = 1;
        vectorUB = 1;
        nx = static_cast<int>(L + 1.0);
      }
      loop_ub = div_s32(md2 - i, s);
      h.set_size(1, ((loop_ub + nx) - vectorUB) + 2);
      for (md2 = 0; md2 <= loop_ub; md2++) {
        h[md2] = a[i + s * md2] / 2.0;
      }
      h[loop_ub + 1] = a[0];
      md2 = nx - vectorUB;
      for (i = 0; i < md2; i++) {
        h[(i + loop_ub) + 2] = a[vectorUB + i] / 2.0;
      }
    } else {
      loop_ub = a.size(0);
      y_tmp.set_size(a.size(0));
      for (i = 0; i < loop_ub; i++) {
        y_tmp[i] = a[i];
      }
      nx = a.size(0) - 1;
      md2 = a.size(0) >> 1;
      for (s = 0; s < md2; s++) {
        f1 = y_tmp[s];
        vectorUB = nx - s;
        y_tmp[s] = y_tmp[vectorUB];
        y_tmp[vectorUB] = f1;
      }
      h.set_size(1, y_tmp.size(0) + a.size(0));
      md2 = (y_tmp.size(0) / 2) << 1;
      nx = md2 - 2;
      for (i = 0; i <= nx; i += 2) {
        r = _mm_loadu_pd(&y_tmp[i]);
        _mm_storeu_pd(&h[i], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (i = md2; i < loop_ub; i++) {
        h[i] = 0.5 * y_tmp[i];
      }
      for (i = 0; i <= nx; i += 2) {
        r = _mm_loadu_pd(&a[i]);
        _mm_storeu_pd(&h[i + y_tmp.size(0)], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (i = md2; i < loop_ub; i++) {
        h[i + y_tmp.size(0)] = 0.5 * a[i];
      }
    }
    a.set_size(1);
    a[0] = 1.0;
  }
}

int eFirls(const double freq[4], double h_data[], int h_size[2],
           double a_data[])
{
  static const signed char A[4]{1, 1, 0, 0};
  __m128d r3;
  __m128d r4;
  __m128d r5;
  __m128d r6;
  __m128d r7;
  ::coder::array<double, 2U> b_G_data;
  ::coder::array<double, 1U> b_y;
  ::coder::array<double, 1U> y;
  double G_data[256];
  double sinc1A_data[31];
  double sinc2A_data[31];
  double sinc3A_data[31];
  double sinc4A_data[31];
  double b0_data[16];
  double b_data[16];
  double max_freq[4];
  double k1;
  double k2;
  double k3;
  double k4;
  int a_size;
  int i2;
  int i3;
  int i4;
  int nn;
  signed char G_size[2];
  if ((!(freq[0] > 1.0)) && (!(freq[0] < 0.0))) {
    __m128d r;
    double b0;
    int k;
    int tmpStorageLen;
    signed char k_data[16];
    boolean_T need_matrix;
    r = _mm_set1_pd(2.0);
    _mm_storeu_pd(&max_freq[0], _mm_div_pd(_mm_loadu_pd(&freq[0]), r));
    _mm_storeu_pd(&max_freq[2], _mm_div_pd(_mm_loadu_pd(&freq[2]), r));
    need_matrix = (max_freq[2] - max_freq[1] != 0.0);
    if (need_matrix) {
      G_size[0] = 16;
      G_size[1] = 16;
      std::memset(&G_data[0], 0, 256U * sizeof(double));
      tmpStorageLen = 30;
    } else {
      G_size[0] = 0;
      G_size[1] = 0;
      tmpStorageLen = -1;
    }
    b0 = 0.0;
    for (int i{0}; i < 15; i++) {
      k_data[i] = static_cast<signed char>(i + 1);
      b_data[i] = 0.0;
    }
    for (int s{0}; s < 2; s++) {
      double a;
      double b1;
      double b1_tmp;
      double f1;
      double f2;
      double m_s;
      double m_s_tmp_tmp;
      int b_s;
      signed char i1;
      b_s = s << 1;
      m_s_tmp_tmp = max_freq[b_s + 1];
      f2 = max_freq[b_s];
      f1 = m_s_tmp_tmp - f2;
      i1 = A[b_s];
      m_s = static_cast<double>(A[b_s + 1] - i1) / f1;
      b1_tmp = m_s * f2;
      b1 = static_cast<double>(i1) - b1_tmp;
      b0 += b1 * f1 + m_s / 2.0 * (m_s_tmp_tmp * m_s_tmp_tmp - f2 * f2);
      b_y.set_size(15);
      for (int i{0}; i < 15; i++) {
        b_y[i] = 6.2831853071795862 * static_cast<double>(k_data[i]);
      }
      y.set_size(15);
      for (int i{0}; i <= 12; i += 2) {
        r = _mm_loadu_pd(&b_y[i]);
        _mm_storeu_pd(&y[i], _mm_mul_pd(r, _mm_set1_pd(m_s_tmp_tmp)));
      }
      y[14] = b_y[14] * m_s_tmp_tmp;
      for (k = 0; k < 15; k++) {
        y[k] = std::cos(y[k]);
      }
      for (int i{0}; i <= 12; i += 2) {
        r = _mm_loadu_pd(&b_y[i]);
        _mm_storeu_pd(&b_y[i], _mm_mul_pd(r, _mm_set1_pd(f2)));
      }
      b_y[14] = b_y[14] * f2;
      for (k = 0; k < 15; k++) {
        b_y[k] = std::cos(b_y[k]);
      }
      a = m_s / 39.478417604357432;
      for (int i{0}; i < 15; i++) {
        i1 = k_data[i];
        b_data[i] += a * (y[i] - b_y[i]) / static_cast<double>(i1 * i1);
      }
      y.set_size(15);
      for (int i{0}; i < 15; i++) {
        y[i] = 2.0 * static_cast<double>(k_data[i]) * m_s_tmp_tmp;
      }
      a = m_s_tmp_tmp * (m_s * m_s_tmp_tmp + b1);
      for (k = 0; k < 15; k++) {
        if (std::abs(y[k]) < 1.0020841800044864E-292) {
          y[k] = 1.0;
        } else {
          m_s = 3.1415926535897931 * y[k];
          m_s = std::sin(m_s) / m_s;
          y[k] = m_s;
        }
      }
      b_y.set_size(15);
      for (int i{0}; i < 15; i++) {
        b_y[i] = 2.0 * static_cast<double>(k_data[i]) * max_freq[b_s];
      }
      m_s = max_freq[b_s];
      f2 = m_s * (b1_tmp + b1);
      for (k = 0; k < 15; k++) {
        if (std::abs(b_y[k]) < 1.0020841800044864E-292) {
          b_y[k] = 1.0;
        } else {
          f1 = 3.1415926535897931 * b_y[k];
          f1 = std::sin(f1) / f1;
          b_y[k] = f1;
        }
      }
      for (int i{0}; i <= 12; i += 2) {
        __m128d r1;
        __m128d r2;
        r = _mm_loadu_pd(&y[i]);
        r1 = _mm_loadu_pd(&b_y[i]);
        r2 = _mm_loadu_pd(&b_data[i]);
        _mm_storeu_pd(
            &b_data[i],
            _mm_add_pd(r2, _mm_sub_pd(_mm_mul_pd(_mm_set1_pd(a), r),
                                      _mm_mul_pd(_mm_set1_pd(f2), r1))));
      }
      b_data[14] += a * y[14] - f2 * b_y[14];
      if (need_matrix) {
        f1 = 2.0 * m_s_tmp_tmp;
        f2 = 2.0 * m_s;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        k4, k3, k2, k1)

        for (int ii = 0; ii <= tmpStorageLen; ii++) {
          k1 = f1 * ((static_cast<double>(ii) + 1.0) - 1.0);
          k2 = f2 * ((static_cast<double>(ii) + 1.0) - 1.0);
          k3 = f1 * ((static_cast<double>(ii) + 1.0) - 16.0);
          k4 = f2 * ((static_cast<double>(ii) + 1.0) - 16.0);
          if (std::abs(k1) < 1.0020841800044864E-292) {
            sinc1A_data[ii] = 1.0;
          } else {
            k1 *= 3.1415926535897931;
            sinc1A_data[ii] = std::sin(k1) / k1;
          }
          if (std::abs(k2) < 1.0020841800044864E-292) {
            sinc2A_data[ii] = 1.0;
          } else {
            k1 = 3.1415926535897931 * k2;
            sinc2A_data[ii] = std::sin(k1) / k1;
          }
          if (std::abs(k3) < 1.0020841800044864E-292) {
            sinc3A_data[ii] = 1.0;
          } else {
            k1 = 3.1415926535897931 * k3;
            sinc3A_data[ii] = std::sin(k1) / k1;
          }
          if (std::abs(k4) < 1.0020841800044864E-292) {
            sinc4A_data[ii] = 1.0;
          } else {
            k1 = 3.1415926535897931 * k4;
            sinc4A_data[ii] = std::sin(k1) / k1;
          }
        }
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        i2, nn, i3, i4, r3, r4, r5, r6, r7)

        for (int ii = 0; ii < 16; ii++) {
          i2 = G_size[0];
          for (nn = 0; nn <= 14; nn += 2) {
            i3 = (nn + ii) + 1;
            i4 = (nn - ii) + 16;
            r3 = _mm_loadu_pd(&sinc1A_data[i3 - 1]);
            r4 = _mm_loadu_pd(&sinc3A_data[i4 - 1]);
            r5 = _mm_loadu_pd(&sinc2A_data[i3 - 1]);
            r6 = _mm_loadu_pd(&sinc4A_data[i4 - 1]);
            i3 = nn + i2 * ii;
            r7 = _mm_loadu_pd(&G_data[i3]);
            _mm_storeu_pd(
                &G_data[i3],
                _mm_add_pd(
                    r7,
                    _mm_mul_pd(
                        _mm_set1_pd(0.25),
                        _mm_sub_pd(
                            _mm_mul_pd(_mm_set1_pd(f1), _mm_add_pd(r3, r4)),
                            _mm_mul_pd(_mm_set1_pd(f2), _mm_add_pd(r5, r6))))));
          }
        }
      }
    }
    b0_data[0] = b0;
    std::copy(&b_data[0], &b_data[15], &b0_data[1]);
    std::copy(&b0_data[0], &b0_data[16], &b_data[0]);
    if (need_matrix) {
      y.set_size(16);
      for (int i{0}; i < 16; i++) {
        y[i] = b_data[i];
      }
      b_G_data.set(&G_data[0], static_cast<int>(G_size[0]),
                   static_cast<int>(G_size[1]));
      mldivide(b_G_data, y);
      k = y.size(0);
      for (int i{0}; i < k; i++) {
        a_data[i] = y[i];
      }
    } else {
      for (int i{0}; i <= 14; i += 2) {
        r = _mm_loadu_pd(&b_data[i]);
        _mm_storeu_pd(&a_data[i], _mm_mul_pd(_mm_set1_pd(4.0), r));
      }
      a_data[0] = 4.0 * b_data[0] / 2.0;
    }
    h_size[0] = 1;
    h_size[1] = 31;
    h_data[15] = a_data[0];
    for (int i{0}; i < 15; i++) {
      h_data[i] = a_data[15 - i] / 2.0;
      h_data[i + 16] = a_data[i + 1] / 2.0;
    }
    a_size = 1;
    a_data[0] = 1.0;
  }
  return a_size;
}

void eFirls(double N, const ::coder::array<double, 2U> &freq,
            const ::coder::array<double, 2U> &amp,
            ::coder::array<double, 2U> &h, ::coder::array<double, 1U> &a)
{
  ::coder::array<creal_T, 1U> x;
  ::coder::array<double, 2U> G;
  ::coder::array<double, 2U> m;
  ::coder::array<double, 2U> sinc2A;
  ::coder::array<double, 2U> sinc3A;
  ::coder::array<double, 2U> sinc4A;
  ::coder::array<double, 1U> A;
  ::coder::array<double, 1U> F;
  ::coder::array<double, 1U> b;
  ::coder::array<double, 1U> dF;
  ::coder::array<double, 1U> k;
  ::coder::array<double, 1U> wt;
  double i2Map;
  double k1;
  double k2;
  double k3;
  double k4;
  unsigned int i1Map;
  int nn;
  if ((!(coder::internal::maximum(freq) > 1.0)) &&
      (!(coder::internal::minimum(freq) < 0.0))) {
    __m128d r;
    double L;
    double b0;
    double b_a;
    double f2;
    double tmpStorageLen;
    int i;
    int i1Start;
    int loop_ub;
    int md2;
    int nG;
    int nx;
    int scalarLB;
    int vectorUB;
    boolean_T Nodd;
    boolean_T exitg1;
    boolean_T fullband;
    if ((!(N != std::round(N))) && (amp[amp.size(1) - 1] != 0.0) &&
        (freq[freq.size(1) - 1] == 1.0)) {
      if (std::isinf(N)) {
        f2 = rtNaN;
      } else if (N == 0.0) {
        f2 = 0.0;
      } else {
        f2 = std::fmod(N, 2.0);
        if (f2 == 0.0) {
          f2 = 0.0;
        }
      }
      if (f2 == 1.0) {
        N++;
      }
    }
    N++;
    loop_ub = freq.size(1);
    F.set_size(freq.size(1));
    scalarLB = (freq.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      _mm_storeu_pd(&F[i],
                    _mm_div_pd(_mm_loadu_pd(&freq[i]), _mm_set1_pd(2.0)));
    }
    for (i = scalarLB; i < loop_ub; i++) {
      F[i] = freq[i] / 2.0;
    }
    loop_ub = amp.size(1);
    A.set_size(amp.size(1));
    for (i = 0; i < loop_ub; i++) {
      A[i] = amp[i];
    }
    loop_ub =
        static_cast<int>(std::floor(static_cast<double>(freq.size(1)) / 2.0));
    x.set_size(
        static_cast<int>(std::floor(static_cast<double>(freq.size(1)) / 2.0)));
    for (i = 0; i < loop_ub; i++) {
      x[i].re = 1.0;
      x[i].im = 0.0;
    }
    b_sqrt(x);
    nx = x.size(0);
    wt.set_size(x.size(0));
    for (md2 = 0; md2 < nx; md2++) {
      wt[md2] = rt_hypotd_snf(x[md2].re, x[md2].im);
    }
    diff(F, dF);
    fullband = true;
    i = static_cast<int>((static_cast<double>(freq.size(1)) - 1.0) / 2.0);
    vectorUB = 0;
    exitg1 = false;
    while ((!exitg1) && (vectorUB <= i - 1)) {
      if (dF[(vectorUB << 1) + 1] != 0.0) {
        fullband = false;
        exitg1 = true;
      } else {
        vectorUB++;
      }
    }
    f2 = wt[0];
    dF.set_size(x.size(0));
    scalarLB = (wt.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&wt[i]);
      _mm_storeu_pd(&dF[i], _mm_sub_pd(r, _mm_set1_pd(f2)));
    }
    for (i = scalarLB; i < nx; i++) {
      dF[i] = wt[i] - f2;
    }
    L = (N - 1.0) / 2.0;
    Nodd = (rt_remd_snf(N, 2.0) == 1.0);
    b0 = 0.0;
    if (!Nodd) {
      if (std::isnan(L)) {
        m.set_size(1, 1);
        m[0] = rtNaN;
      } else if (L < 0.0) {
        m.set_size(m.size(0), 0);
      } else {
        m.set_size(1, static_cast<int>(L) + 1);
        loop_ub = static_cast<int>(L);
        for (i = 0; i <= loop_ub; i++) {
          m[i] = i;
        }
      }
      m.set_size(1, m.size(1));
      loop_ub = m.size(1) - 1;
      scalarLB = (m.size(1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&m[i]);
        _mm_storeu_pd(&m[i], _mm_add_pd(r, _mm_set1_pd(0.5)));
      }
      for (i = scalarLB; i <= loop_ub; i++) {
        m[i] = m[i] + 0.5;
      }
    } else if (std::isnan(L)) {
      m.set_size(1, 1);
      m[0] = rtNaN;
    } else if (L < 0.0) {
      m.set_size(1, 0);
    } else {
      m.set_size(1, static_cast<int>(L) + 1);
      loop_ub = static_cast<int>(L);
      for (i = 0; i <= loop_ub; i++) {
        m[i] = i;
      }
    }
    loop_ub = m.size(1);
    k.set_size(m.size(1));
    for (i = 0; i < loop_ub; i++) {
      k[i] = m[i];
    }
    if ((!fullband) || (!(blockedSummation(dF, dF.size(0)) == 0.0))) {
      fullband = true;
    } else {
      fullband = false;
    }
    nG = m.size(1);
    if (fullband) {
      G.set_size(m.size(1), m.size(1));
      nx = k.size(0) * k.size(0);
      for (i = 0; i < nx; i++) {
        G[i] = 0.0;
      }
      tmpStorageLen = 2.0 * static_cast<double>(k.size(0)) - 1.0;
    } else {
      G.set_size(0, 0);
      tmpStorageLen = 0.0;
    }
    m.set_size(1, static_cast<int>(tmpStorageLen));
    sinc2A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc3A.set_size(1, static_cast<int>(tmpStorageLen));
    sinc4A.set_size(1, static_cast<int>(tmpStorageLen));
    if (Nodd) {
      i1Start = -1;
      if (k.size(0) < 2) {
        i = 0;
        loop_ub = 0;
      } else {
        i = 1;
      }
      md2 = loop_ub - i;
      for (nx = 0; nx < md2; nx++) {
        k[nx] = k[i + nx];
      }
      k.set_size(md2);
    } else {
      i1Start = 0;
    }
    loop_ub = k.size(0);
    a.set_size(k.size(0));
    for (i = 0; i < loop_ub; i++) {
      a[i] = 0.0;
    }
    i = static_cast<int>((static_cast<double>(F.size(0)) + 1.0) / 2.0);
    for (int s{0}; s < i; s++) {
      __m128d r1;
      __m128d r2;
      double b1;
      double b1_tmp;
      double b_tmp;
      double m_s;
      double m_s_tmp;
      double wtSq;
      int b_s;
      b_s = (s << 1) + 1;
      f2 = A[b_s - 1];
      m_s_tmp = F[b_s - 1];
      wtSq = F[b_s] - m_s_tmp;
      m_s = (A[b_s] - f2) / wtSq;
      b1_tmp = m_s * m_s_tmp;
      b1 = f2 - b1_tmp;
      if (Nodd) {
        b_a = wt[static_cast<int>((static_cast<double>(b_s) + 1.0) / 2.0) - 1];
        b0 += (b1 * wtSq + m_s / 2.0 * (F[b_s] * F[b_s] - m_s_tmp * m_s_tmp)) *
              (b_a * b_a);
      }
      md2 = k.size(0);
      dF.set_size(k.size(0));
      scalarLB = (k.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        r = _mm_loadu_pd(&k[nx]);
        _mm_storeu_pd(&dF[nx], _mm_mul_pd(_mm_set1_pd(6.2831853071795862), r));
      }
      for (nx = scalarLB; nx < md2; nx++) {
        dF[nx] = 6.2831853071795862 * k[nx];
      }
      f2 = F[b_s];
      loop_ub = dF.size(0);
      b.set_size(dF.size(0));
      scalarLB = (dF.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        r = _mm_loadu_pd(&dF[nx]);
        _mm_storeu_pd(&b[nx], _mm_mul_pd(r, _mm_set1_pd(f2)));
      }
      for (nx = scalarLB; nx < loop_ub; nx++) {
        b[nx] = dF[nx] * f2;
      }
      nx = b.size(0);
      for (md2 = 0; md2 < nx; md2++) {
        b[md2] = std::cos(b[md2]);
        dF[md2] = dF[md2] * m_s_tmp;
      }
      for (md2 = 0; md2 < loop_ub; md2++) {
        dF[md2] = std::cos(dF[md2]);
      }
      b_a = m_s / 39.478417604357432;
      f2 = wt[static_cast<int>((static_cast<double>(b_s) + 1.0) / 2.0) - 1];
      b_tmp = f2 * f2;
      loop_ub = a.size(0);
      if (b.size(0) == 1) {
        scalarLB = k.size(0);
      } else {
        scalarLB = b.size(0);
      }
      if ((b.size(0) == k.size(0)) && (a.size(0) == scalarLB)) {
        scalarLB = (a.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          __m128d r3;
          r = _mm_loadu_pd(&b[nx]);
          r1 = _mm_loadu_pd(&dF[nx]);
          r2 = _mm_loadu_pd(&k[nx]);
          r3 = _mm_loadu_pd(&a[nx]);
          _mm_storeu_pd(
              &a[nx],
              _mm_add_pd(r3,
                         _mm_mul_pd(_mm_div_pd(_mm_mul_pd(_mm_set1_pd(b_a),
                                                          _mm_sub_pd(r, r1)),
                                               _mm_mul_pd(r2, r2)),
                                    _mm_set1_pd(b_tmp))));
        }
        for (nx = scalarLB; nx < loop_ub; nx++) {
          a[nx] = a[nx] + b_a * (b[nx] - dF[nx]) / (k[nx] * k[nx]) * b_tmp;
        }
      } else {
        binary_expand_op_84(a, b_a, b, dF, k, b_tmp);
      }
      md2 = k.size(0);
      dF.set_size(k.size(0));
      scalarLB = (k.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        r = _mm_loadu_pd(&k[nx]);
        _mm_storeu_pd(&dF[nx], _mm_mul_pd(_mm_set1_pd(2.0), r));
      }
      for (nx = scalarLB; nx < md2; nx++) {
        dF[nx] = 2.0 * k[nx];
      }
      f2 = F[b_s];
      b_a = F[b_s] * (m_s * F[b_s] + b1);
      loop_ub = dF.size(0);
      b.set_size(dF.size(0));
      scalarLB = (dF.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        r = _mm_loadu_pd(&dF[nx]);
        _mm_storeu_pd(&b[nx], _mm_mul_pd(r, _mm_set1_pd(f2)));
      }
      for (nx = scalarLB; nx < loop_ub; nx++) {
        b[nx] = dF[nx] * f2;
      }
      nx = b.size(0);
      f2 = m_s_tmp * (b1_tmp + b1);
      for (md2 = 0; md2 < nx; md2++) {
        if (std::abs(b[md2]) < 1.0020841800044864E-292) {
          b[md2] = 1.0;
        } else {
          wtSq = 3.1415926535897931 * b[md2];
          wtSq = std::sin(wtSq) / wtSq;
          b[md2] = wtSq;
        }
        dF[md2] = dF[md2] * m_s_tmp;
      }
      for (md2 = 0; md2 < loop_ub; md2++) {
        if (std::abs(dF[md2]) < 1.0020841800044864E-292) {
          dF[md2] = 1.0;
        } else {
          wtSq = 3.1415926535897931 * dF[md2];
          wtSq = std::sin(wtSq) / wtSq;
          dF[md2] = wtSq;
        }
      }
      loop_ub = a.size(0);
      if (a.size(0) == b.size(0)) {
        scalarLB = (a.size(0) / 2) << 1;
        vectorUB = scalarLB - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          r = _mm_loadu_pd(&b[nx]);
          r1 = _mm_loadu_pd(&dF[nx]);
          r2 = _mm_loadu_pd(&a[nx]);
          _mm_storeu_pd(
              &a[nx],
              _mm_add_pd(r2,
                         _mm_mul_pd(_mm_sub_pd(_mm_mul_pd(_mm_set1_pd(b_a), r),
                                               _mm_mul_pd(_mm_set1_pd(f2), r1)),
                                    _mm_set1_pd(b_tmp))));
        }
        for (nx = scalarLB; nx < loop_ub; nx++) {
          a[nx] = a[nx] + (b_a * b[nx] - f2 * dF[nx]) * b_tmp;
        }
      } else {
        binary_expand_op_83(a, b_a, b, f2, dF, b_tmp);
      }
      if (fullband) {
        wtSq = 0.25 * b_tmp;
        b1 = 2.0 * F[b_s];
        f2 = 2.0 * m_s_tmp;
        md2 = static_cast<int>(tmpStorageLen) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        k4, k3, k2, k1, i2Map, i1Map)

        for (int ii = 0; ii <= md2; ii++) {
          i1Map = static_cast<unsigned int>((static_cast<double>(ii) + 1.0) +
                                            static_cast<double>(i1Start));
          i2Map = (static_cast<double>(ii) + 1.0) - static_cast<double>(nG);
          k1 = b1 * static_cast<double>(i1Map);
          k2 = f2 * static_cast<double>(i1Map);
          k3 = b1 * i2Map;
          k4 = f2 * i2Map;
          if (std::abs(k1) < 1.0020841800044864E-292) {
            m[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k1;
            m[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k2) < 1.0020841800044864E-292) {
            sinc2A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k2;
            sinc2A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k3) < 1.0020841800044864E-292) {
            sinc3A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k3;
            sinc3A[ii] = std::sin(i2Map) / i2Map;
          }
          if (std::abs(k4) < 1.0020841800044864E-292) {
            sinc4A[ii] = 1.0;
          } else {
            i2Map = 3.1415926535897931 * k4;
            sinc4A[ii] = std::sin(i2Map) / i2Map;
          }
        }
        md2 = nG - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
        i2Map, i1Map, nn)

        for (int ii = 0; ii <= md2; ii++) {
          for (nn = 0; nn < nG; nn++) {
            i1Map = (static_cast<unsigned int>(nn) +
                     static_cast<unsigned int>(ii)) +
                    1U;
            i2Map = static_cast<double>(nn - ii) + static_cast<double>(nG);
            G[nn + G.size(0) * ii] =
                G[nn + G.size(0) * ii] +
                wtSq * (b1 * (m[static_cast<int>(i1Map) - 1] +
                              sinc3A[static_cast<int>(i2Map) - 1]) -
                        f2 * (sinc2A[static_cast<int>(i1Map) - 1] +
                              sinc4A[static_cast<int>(i2Map) - 1]));
          }
        }
      }
    }
    if (Nodd) {
      loop_ub = a.size(0) + 1;
      F.set_size(a.size(0) + 1);
      F[0] = b0;
      nx = a.size(0);
      for (i = 0; i < nx; i++) {
        F[i + 1] = a[i];
      }
      a.set_size(loop_ub);
      for (i = 0; i < loop_ub; i++) {
        a[i] = F[i];
      }
    }
    if (fullband) {
      mldivide(G, a);
    } else {
      b_a = wt[0] * wt[0] * 4.0;
      loop_ub = a.size(0);
      scalarLB = (a.size(0) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&a[i]);
        _mm_storeu_pd(&a[i], _mm_mul_pd(_mm_set1_pd(b_a), r));
      }
      for (i = scalarLB; i < loop_ub; i++) {
        a[i] = b_a * a[i];
      }
      if (Nodd) {
        a[0] = a[0] / 2.0;
      }
    }
    if (Nodd) {
      md2 = static_cast<int>(L + 1.0) - 2;
      h.set_size(1,
                 (static_cast<int>(L + 1.0) + static_cast<int>(L + 1.0)) - 1);
      for (i = 0; i <= md2; i++) {
        h[i] = a[(static_cast<int>(L + 1.0) - i) - 1] / 2.0;
      }
      h[static_cast<int>(L + 1.0) - 1] = a[0];
      scalarLB = ((static_cast<int>(L + 1.0) - 1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&a[i + 1]);
        _mm_storeu_pd(&h[i + static_cast<int>(L + 1.0)],
                      _mm_div_pd(r, _mm_set1_pd(2.0)));
      }
      for (i = scalarLB; i <= md2; i++) {
        h[i + static_cast<int>(L + 1.0)] = a[i + 1] / 2.0;
      }
    } else {
      loop_ub = a.size(0);
      dF.set_size(a.size(0));
      for (i = 0; i < loop_ub; i++) {
        dF[i] = a[i];
      }
      nx = a.size(0) - 1;
      md2 = a.size(0) >> 1;
      for (vectorUB = 0; vectorUB < md2; vectorUB++) {
        f2 = dF[vectorUB];
        scalarLB = nx - vectorUB;
        dF[vectorUB] = dF[scalarLB];
        dF[scalarLB] = f2;
      }
      h.set_size(1, dF.size(0) + a.size(0));
      nx = (dF.size(0) / 2) << 1;
      md2 = nx - 2;
      for (i = 0; i <= md2; i += 2) {
        r = _mm_loadu_pd(&dF[i]);
        _mm_storeu_pd(&h[i], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (i = nx; i < loop_ub; i++) {
        h[i] = 0.5 * dF[i];
      }
      for (i = 0; i <= md2; i += 2) {
        r = _mm_loadu_pd(&a[i]);
        _mm_storeu_pd(&h[i + dF.size(0)], _mm_mul_pd(_mm_set1_pd(0.5), r));
      }
      for (i = nx; i < loop_ub; i++) {
        h[i + dF.size(0)] = 0.5 * a[i];
      }
    }
    a.set_size(1);
    a[0] = 1.0;
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (firls.cpp)
