//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource.cpp
//
// Code generation for function 'exstraightsource'
//

// Include files
#include "exstraightsource.h"
#include "aperiodiccomp.h"
#include "aperiodicpartERB2.h"
#include "blockedSummation.h"
#include "boundmes2.h"
#include "bsearch.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "correctdpv.h"
#include "decimate.h"
#include "div.h"
#include "exp.h"
#include "exstraightsource_data.h"
#include "exstraightsource_initialize.h"
#include "exstraightsource_rtwutil.h"
#include "exstraightsource_types.h"
#include "f0track5.h"
#include "fftfilt.h"
#include "fir1.h"
#include "firls.h"
#include "fixpF0VexMltpBG4.h"
#include "hamming.h"
#include "hanning.h"
#include "interp.h"
#include "ixfun.h"
#include "minOrMax.h"
#include "refineF06.h"
#include "relop.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Declarations
static void zplotcpower(const coder::array<double, 1U> &x, double fs,
                        double shiftm, coder::array<creal_T, 2U> &pw,
                        coder::array<creal_T, 2U> &pwh);

// Function Definitions
static void zplotcpower(const coder::array<double, 1U> &x, double fs,
                        double shiftm, coder::array<creal_T, 2U> &pw,
                        coder::array<creal_T, 2U> &pwh)
{
  __m128d r;
  __m128d r1;
  coder::array<creal_T, 2U> b_ttx;
  coder::array<creal_T, 2U> ttx;
  coder::array<creal_T, 2U> tx;
  coder::array<double, 2U> hh;
  coder::array<double, 2U> pw_tmp_tmp;
  coder::array<double, 2U> wind;
  coder::array<double, 1U> a;
  coder::array<double, 1U> w;
  creal_T mpw;
  creal_T varargout_1;
  double freq[6];
  double d_tmp;
  double f0;
  double ff_idx_1;
  double fl;
  double flp;
  double im;
  double re;
  double w_tmp;
  int b_loop_ub;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  boolean_T b;
  // %%---- internal functions
  //  01/August/1999
  fl = std::round(8.0 * fs / 1000.0);
  w_tmp = 2.0 * fl + 1.0;
  legacy_STRAIGHT::hanning(w_tmp, w);
  ff_idx_1 = legacy_STRAIGHT::blockedSummation(w, w.size(0));
  loop_ub = w.size(0);
  scalarLB = (w.size(0) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&w[i]);
    _mm_storeu_pd(&w[i], _mm_div_pd(r, _mm_set1_pd(ff_idx_1)));
  }
  for (int i{scalarLB}; i < loop_ub; i++) {
    w[i] = w[i] / ff_idx_1;
  }
  flp = std::round(40.0 * fs / 1000.0);
  ff_idx_1 = flp * 2.0;
  f0 = 70.0 / (fs / 2.0);
  legacy_STRAIGHT::hamming(ff_idx_1 + 1.0, a);
  loop_ub = a.size(0);
  wind.set_size(1, a.size(0));
  for (int i{0}; i < loop_ub; i++) {
    wind[i] = a[i];
  }
  double ff[4];
  ff[0] = 0.0;
  ff[1] = f0;
  ff[2] = f0;
  ff[3] = 1.0;
  legacy_STRAIGHT::eFirls((ff_idx_1 + 1.0) - 1.0, ff, hh, a);
  if (hh.size(1) == wind.size(1)) {
    loop_ub = hh.size(1) - 1;
    hh.set_size(1, hh.size(1));
    scalarLB = (hh.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i{0}; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&hh[i]);
      r1 = _mm_loadu_pd(&wind[i]);
      _mm_storeu_pd(&hh[i], _mm_mul_pd(r, r1));
    }
    for (int i{scalarLB}; i <= loop_ub; i++) {
      hh[i] = hh[i] * wind[i];
    }
  } else {
    times(hh, wind);
  }
  ff_idx_1 = legacy_STRAIGHT::combineVectorElements(hh);
  hh.set_size(1, hh.size(1));
  loop_ub = hh.size(1) - 1;
  scalarLB = (hh.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&hh[i]);
    _mm_storeu_pd(&hh[i], _mm_div_pd(r, _mm_set1_pd(ff_idx_1)));
  }
  for (int i{scalarLB}; i <= loop_ub; i++) {
    hh[i] = hh[i] / ff_idx_1;
  }
  hh[static_cast<int>(flp + 1.0) - 1] =
      hh[static_cast<int>(flp + 1.0) - 1] - 1.0;
  hh.set_size(1, hh.size(1));
  loop_ub = hh.size(1) - 1;
  scalarLB = (hh.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&hh[i]);
    _mm_storeu_pd(&hh[i], _mm_mul_pd(r, _mm_set1_pd(-1.0)));
  }
  for (int i{scalarLB}; i <= loop_ub; i++) {
    hh[i] = -hh[i];
  }
  vectorUB = 2 * hh.size(1);
  wind.set_size(1, x.size(0) + vectorUB);
  scalarLB = x.size(0);
  for (int i{0}; i < scalarLB; i++) {
    wind[i] = x[i];
  }
  for (int i{0}; i < vectorUB; i++) {
    wind[i + x.size(0)] = 0.0;
  }
  legacy_STRAIGHT::fftfilt(hh, wind, ttx);
  if (x.size(0) < 1) {
    pw_tmp_tmp.set_size(1, 0);
  } else {
    pw_tmp_tmp.set_size(1, x.size(0));
    loop_ub = x.size(0) - 1;
    for (int i{0}; i <= loop_ub; i++) {
      pw_tmp_tmp[i] = static_cast<double>(i) + 1.0;
    }
  }
  loop_ub = pw_tmp_tmp.size(1);
  vectorUB = 2 * w.size(0);
  b_loop_ub = pw_tmp_tmp.size(1) + vectorUB;
  tx.set_size(1, b_loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    scalarLB = static_cast<int>(pw_tmp_tmp[i] + flp) - 1;
    tx[i].re = ttx[scalarLB].re;
    tx[i].im = -ttx[scalarLB].im;
  }
  for (int i{0}; i < vectorUB; i++) {
    tx[i + pw_tmp_tmp.size(1)].re = 0.0;
    tx[i + pw_tmp_tmp.size(1)].im = 0.0;
  }
  b_ttx.set_size(1, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    mpw = tx[i];
    varargout_1.re = mpw.re * mpw.re - mpw.im * mpw.im;
    ff_idx_1 = mpw.re * mpw.im;
    varargout_1.im = ff_idx_1 + ff_idx_1;
    b_ttx[i] = varargout_1;
  }
  legacy_STRAIGHT::fftfilt(w, b_ttx, pw);
  pw_tmp_tmp.set_size(1, pw_tmp_tmp.size(1));
  loop_ub = pw_tmp_tmp.size(1) - 1;
  scalarLB = (pw_tmp_tmp.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&pw_tmp_tmp[i]);
    _mm_storeu_pd(&pw_tmp_tmp[i], _mm_add_pd(r, _mm_set1_pd(fl)));
  }
  for (int i{scalarLB}; i <= loop_ub; i++) {
    pw_tmp_tmp[i] = pw_tmp_tmp[i] + fl;
  }
  loop_ub = pw_tmp_tmp.size(1);
  b_ttx.set_size(1, pw_tmp_tmp.size(1));
  for (int i{0}; i < loop_ub; i++) {
    b_ttx[i] = pw[static_cast<int>(pw_tmp_tmp[i]) - 1];
  }
  pw.set_size(1, pw_tmp_tmp.size(1));
  for (int i{0}; i < loop_ub; i++) {
    pw[i] = b_ttx[i];
  }
  mpw = pw[0];
  for (vectorUB = 2; vectorUB <= loop_ub; vectorUB++) {
    varargout_1 = pw[vectorUB - 1];
    if (legacy_STRAIGHT::coder::internal::relop(mpw, varargout_1)) {
      mpw = varargout_1;
    }
  }
  d_tmp = shiftm * fs / 1000.0;
  b = std::isnan(d_tmp);
  if (b) {
    wind.set_size(1, 1);
    wind[0] = rtNaN;
  } else if ((d_tmp == 0.0) || ((x.size(0) > 1) && (d_tmp < 0.0)) ||
             ((x.size(0) < 1) && (d_tmp > 0.0))) {
    wind.set_size(1, 0);
  } else if (std::isinf(d_tmp)) {
    wind.set_size(1, 1);
    wind[0] = 1.0;
  } else if (std::floor(d_tmp) == d_tmp) {
    b_loop_ub =
        static_cast<int>((static_cast<double>(x.size(0)) - 1.0) / d_tmp);
    wind.set_size(1, b_loop_ub + 1);
    for (int i{0}; i <= b_loop_ub; i++) {
      wind[i] = d_tmp * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(d_tmp, static_cast<double>(x.size(0)),
                                     wind);
  }
  scalarLB = wind.size(1);
  for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
    wind[vectorUB] = std::round(wind[vectorUB]);
  }
  b_ttx.set_size(1, wind.size(1));
  for (int i{0}; i < scalarLB; i++) {
    b_ttx[i] = pw[static_cast<int>(wind[i]) - 1];
  }
  pw.set_size(1, wind.size(1));
  for (int i{0}; i < scalarLB; i++) {
    pw[i] = b_ttx[i];
  }
  if (mpw.im == 0.0) {
    re = mpw.re / 1.0E+7;
    im = 0.0;
  } else if (mpw.re == 0.0) {
    re = 0.0;
    im = mpw.im / 1.0E+7;
  } else {
    re = mpw.re / 1.0E+7;
    im = mpw.im / 1.0E+7;
  }
  scalarLB = pw.size(1) - 1;
  for (vectorUB = 0; vectorUB <= scalarLB; vectorUB++) {
    if (pw[vectorUB].re < re) {
      pw[vectorUB].re = pw[vectorUB].re + re;
      pw[vectorUB].im = pw[vectorUB].im + im;
    }
  }
  //  safeguard 15/Jan./2003
  ff_idx_1 = 3000.0 / (fs / 2.0);
  freq[0] = 0.0;
  freq[1] = 0.0001;
  freq[2] = 0.0001;
  freq[3] = ff_idx_1;
  freq[4] = ff_idx_1;
  freq[5] = 1.0;
  legacy_STRAIGHT::hamming(w_tmp + 1.0, a);
  b_loop_ub = a.size(0);
  wind.set_size(1, a.size(0));
  for (int i{0}; i < b_loop_ub; i++) {
    wind[i] = a[i];
  }
  legacy_STRAIGHT::b_eFirls((w_tmp + 1.0) - 1.0, freq, hh, a);
  if (hh.size(1) == wind.size(1)) {
    b_loop_ub = hh.size(1) - 1;
    hh.set_size(1, hh.size(1));
    scalarLB = (hh.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i{0}; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&hh[i]);
      r1 = _mm_loadu_pd(&wind[i]);
      _mm_storeu_pd(&hh[i], _mm_mul_pd(r, r1));
    }
    for (int i{scalarLB}; i <= b_loop_ub; i++) {
      hh[i] = hh[i] * wind[i];
    }
  } else {
    times(hh, wind);
  }
  if (ff_idx_1 == 1.0) {
    f0 = 1.0;
  } else {
    f0 = (ff_idx_1 + 0.0001) / 2.0;
  }
  flp = f0 / 2.0;
  b_ttx.set_size(1, static_cast<int>((w_tmp + 1.0) - 1.0) + 1);
  b_loop_ub = static_cast<int>((w_tmp + 1.0) - 1.0);
  for (int i{0}; i <= b_loop_ub; i++) {
    b_ttx[i].re = flp * -0.0;
    b_ttx[i].im = flp * (static_cast<double>(i) * -6.2831853071795862);
  }
  legacy_STRAIGHT::b_exp(b_ttx);
  flp = 0.0;
  ff_idx_1 = 0.0;
  b_loop_ub = b_ttx.size(1);
  for (int i{0}; i < b_loop_ub; i++) {
    double ttx_re_tmp;
    f0 = hh[i];
    w_tmp = b_ttx[i].re;
    ttx_re_tmp = b_ttx[i].im;
    flp += w_tmp * f0 - ttx_re_tmp * 0.0;
    ff_idx_1 += w_tmp * 0.0 + ttx_re_tmp * f0;
  }
  ff_idx_1 = rt_hypotd_snf(flp, ff_idx_1);
  hh.set_size(1, hh.size(1));
  b_loop_ub = hh.size(1) - 1;
  scalarLB = (hh.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int i{0}; i <= vectorUB; i += 2) {
    r = _mm_loadu_pd(&hh[i]);
    _mm_storeu_pd(&hh[i], _mm_div_pd(r, _mm_set1_pd(ff_idx_1)));
  }
  for (int i{scalarLB}; i <= b_loop_ub; i++) {
    hh[i] = hh[i] / ff_idx_1;
  }
  hh[static_cast<int>(fl + 1.0) - 1] = hh[static_cast<int>(fl + 1.0) - 1] - 1.0;
  legacy_STRAIGHT::fftfilt(hh, tx, ttx);
  vectorUB = 10 * w.size(0);
  b_loop_ub = pw_tmp_tmp.size(1) + vectorUB;
  tx.set_size(1, b_loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    scalarLB = static_cast<int>(pw_tmp_tmp[i]) - 1;
    tx[i].re = ttx[scalarLB].re;
    tx[i].im = -ttx[scalarLB].im;
  }
  for (int i{0}; i < vectorUB; i++) {
    tx[i + pw_tmp_tmp.size(1)].re = 0.0;
    tx[i + pw_tmp_tmp.size(1)].im = 0.0;
  }
  b_ttx.set_size(1, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    mpw = tx[i];
    varargout_1.re = mpw.re * mpw.re - mpw.im * mpw.im;
    ff_idx_1 = mpw.re * mpw.im;
    varargout_1.im = ff_idx_1 + ff_idx_1;
    b_ttx[i] = varargout_1;
  }
  legacy_STRAIGHT::fftfilt(w, b_ttx, pwh);
  b_ttx.set_size(1, pw_tmp_tmp.size(1));
  for (int i{0}; i < loop_ub; i++) {
    b_ttx[i] = pwh[static_cast<int>(pw_tmp_tmp[i]) - 1];
  }
  pwh.set_size(1, pw_tmp_tmp.size(1));
  for (int i{0}; i < loop_ub; i++) {
    pwh[i] = b_ttx[i];
  }
  if (b) {
    wind.set_size(1, 1);
    wind[0] = rtNaN;
  } else if ((d_tmp == 0.0) || ((x.size(0) > 1) && (d_tmp < 0.0)) ||
             ((x.size(0) < 1) && (d_tmp > 0.0))) {
    wind.set_size(1, 0);
  } else if (std::isinf(d_tmp)) {
    wind.set_size(1, 1);
    wind[0] = 1.0;
  } else if (std::floor(d_tmp) == d_tmp) {
    loop_ub = static_cast<int>((static_cast<double>(x.size(0)) - 1.0) / d_tmp);
    wind.set_size(1, loop_ub + 1);
    for (int i{0}; i <= loop_ub; i++) {
      wind[i] = d_tmp * static_cast<double>(i) + 1.0;
    }
  } else {
    legacy_STRAIGHT::eml_float_colon(d_tmp, static_cast<double>(x.size(0)),
                                     wind);
  }
  scalarLB = wind.size(1);
  for (vectorUB = 0; vectorUB < scalarLB; vectorUB++) {
    wind[vectorUB] = std::round(wind[vectorUB]);
  }
  b_ttx.set_size(1, wind.size(1));
  for (int i{0}; i < scalarLB; i++) {
    b_ttx[i] = pwh[static_cast<int>(wind[i]) - 1];
  }
  pwh.set_size(1, wind.size(1));
  for (int i{0}; i < scalarLB; i++) {
    pwh[i] = b_ttx[i];
  }
  scalarLB = pwh.size(1) - 1;
  for (vectorUB = 0; vectorUB <= scalarLB; vectorUB++) {
    if (pwh[vectorUB].re < re) {
      pwh[vectorUB].re = pwh[vectorUB].re + re;
      pwh[vectorUB].im = pwh[vectorUB].im + im;
    }
  }
  //  safeguard 15/Jan./2003
}

void exstraightsource(coder::array<double, 1U> &x, double fs,
                      const struct0_T *optionalParams,
                      coder::array<double, 2U> &f0raw,
                      coder::array<double, 2U> &ap, struct0_T *analysisParams)
{
  __m128d b_r;
  __m128d r1;
  coder::array<creal_T, 2U> pwh;
  coder::array<creal_T, 2U> pwt;
  coder::array<double, 2U> aav;
  coder::array<double, 2U> apv;
  coder::array<double, 2U> b_bv;
  coder::array<double, 2U> b_f0raw;
  coder::array<double, 2U> bdr;
  coder::array<double, 2U> bv;
  coder::array<double, 2U> dfv;
  coder::array<double, 2U> dpv;
  coder::array<double, 2U> ecrt;
  coder::array<double, 2U> f0v;
  coder::array<double, 2U> lyv;
  coder::array<double, 2U> tirms;
  coder::array<double, 2U> varargin_2;
  coder::array<double, 2U> vrv;
  coder::array<double, 1U> b_dpv;
  coder::array<double, 1U> b_x;
  coder::array<double, 1U> z;
  double d;
  double fftl;
  double framel;
  double r;
  int b_loop_ub;
  int end_tmp;
  int i;
  int k;
  int loop_ub;
  int nd2;
  int nx;
  int nx_tmp;
  int nyrows;
  int offset;
  int vectorUB;
  if (!isInitialized_exstraightsource) {
    exstraightsource_initialize();
  }
  //    Source information extraction for STRAIGHT
  //    [f0raw,ap,analysisParams]=exstraightsource(x,fs,optionalParams)
  //    Input parameters
  //    x   : input signal. if it is multi channel, only the first channel is
  //    used fs  : sampling frequency (Hz) optionalParams : Optional parameters
  //    for analysis Output parameters f0raw   : fundamental frequency (Hz) ap
  //    : amount of aperiodic component in the time frequency represntation
  //        : represented in dB
  //    analysisParams : Analysis parameters actually used
  //
  //    Usage:
  //    Case 1: The simplest method
  //    [f0raw,ap]=exstraightsource(x,fs);
  //    Case 2: You can get to know what parameters were used.
  //    [f0raw,ap,analysisParams]=exstraightsource(x,fs);
  //    CAse 3: You can have full control of STRAIGHT synthesis.
  //        Please use case 2 to find desired parameters to modify.
  //    [f0raw,ap,analysisParams]=exstraightsource(x,fs,optionalParams);
  //    Notes on programing style
  //    This routine is based on the current (2005.1.31) implementation of
  //    STRAIGHT that consist of many legacy fragments. They were intentionally
  //    kept for maintaining historic record. Revised functions written in a
  //    reasonable stylistic practice will be made available soon.
  //    Designed and coded by Hideki Kawahara
  //    15/January/2005
  //    01/February/2005 extended for user control
  // 	30/April/2005 modification for Matlab v7.0 compatibility
  // ---Check for number of input parameters
  // %%--------
  *analysisParams = *optionalParams;
  //    Initialize default parameters
  //  f0floor
  //  f0ceil
  //  default frame length for pitch extraction (ms)
  //  shiftm % F0 calculation interval (ms)
  fftl = 1024.0;
  //  default FFT length
  framel = optionalParams->F0defaultWindowLength * fs / 1000.0;
  if (framel > 1024.0) {
    fftl = rt_powd_snf(2.0, std::ceil(std::log(framel) / 0.69314718055994529));
  }
  if (x.size(0) <= 1) {
    framel = x[0];
    x.set_size(1);
    x[0] = framel;
  }
  //  nvo=24; % Number of channels in one octave
  //  mu=1.2; % window stretch from isometric window
  //  imgi=1; % image display indicator (1: display image)
  //   smp=1; % smoothing length relative to fc (ratio)
  //   minm=5; % minimum smoothing length (ms)
  //  pc=0.5; % exponent to represent nonlinear summation
  //  nc=1; % number of harmonic component to use (1,2,3)
  // =' '; % Any text to be printed on the source information plot
  //  number of channels
  //  paramaters for F0 refinement
  // fftlf0r=1024; % FFT length for F0 refinement
  // tstretch=1.1; % time window stretching factor
  // nhmx=3; % number of harmonic components for F0 refinement
  //  frame update interval for periodicity index (ms)
  // ---- F0 extraction based on a fixed-point method in the frequency domain
  fixpF0VexMltpBG4(
      x, fs, optionalParams->F0searchLowerBound,
      std::ceil(std::log(optionalParams->F0searchUpperBound /
                         optionalParams->F0searchLowerBound) /
                0.69314718055994529 * optionalParams->NofChannelsInOctave),
      optionalParams->NofChannelsInOctave, optionalParams->IFWindowStretch,
      optionalParams->F0frameUpdateInterval,
      optionalParams->IFsmoothingLengthRelToFc,
      optionalParams->IFminimumSmoothingLength,
      optionalParams->IFexponentForNonlinearSum,
      optionalParams->IFnumberOfHarmonicForInitialEstimate, f0v, vrv, dfv, bdr,
      aav);
  // if imageOn
  //     title([fname '  ' datestr(now,0)]);
  //     drawnow;
  // end;
  // ---- post processing for V/UV decision and F0 tracking
  zplotcpower(x, fs, optionalParams->F0frameUpdateInterval, pwt, pwh);
  f0track5(f0v, vrv, dfv, pwt, pwh, aav, optionalParams->F0frameUpdateInterval,
           b_f0raw, tirms, bdr, ecrt);
  //  11/Sept./2005
  // ---- F0 refinement
  //  start position of F0 refinement (samples)
  //  last position of F0 refinement (samples)
  framel = std::floor(fs / (optionalParams->F0searchUpperBound * 3.0 * 2.0));
  //  fix by H.K. at 28/Jan./2003
  legacy_STRAIGHT::decimate(x, framel, z);
  refineF06(z, fs / framel, b_f0raw, optionalParams->refineFftLength,
            optionalParams->refineTimeStretchingFactor,
            optionalParams->refineNumberofHarmonicComponent,
            optionalParams->F0frameUpdateInterval,
            static_cast<double>(b_f0raw.size(1)), f0raw, ecrt);
  //  31/Aug./2004% 11/Sept.2005
  // ----------- 31/July/1999
  end_tmp = f0raw.size(1) - 1;
  for (nd2 = 0; nd2 <= end_tmp; nd2++) {
    if (f0raw[nd2] == 0.0) {
      ecrt[nd2] = rtNaN;
    }
  }
  // -------------------------------------------------------------------------------------
  for (nd2 = 0; nd2 <= end_tmp; nd2++) {
    d = f0raw[nd2];
    if (d <= 0.0) {
      d *= 0.0;
      f0raw[nd2] = d;
    }
  }
  //  safeguard 31/August/2004
  for (nd2 = 0; nd2 <= end_tmp; nd2++) {
    d = f0raw[nd2];
    if (d > optionalParams->F0searchUpperBound) {
      d = d * 0.0 + optionalParams->F0searchUpperBound;
      f0raw[nd2] = d;
    }
  }
  //  safeguard 31/August/2004
  // ----- aperiodicity estimation
  r = fftl / 2.0 + 1.0;
  b_f0raw.set_size(1, f0raw.size(1));
  loop_ub = f0raw.size(0) * f0raw.size(1) - 1;
  for (i = 0; i <= loop_ub; i++) {
    b_f0raw[i] = f0raw[i];
  }
  aperiodicpartERB2(x, fs, b_f0raw, optionalParams->F0frameUpdateInterval,
                    optionalParams->periodicityFrameUpdateInterval, r, apv, dpv,
                    varargin_2, lyv);
  //  10/April/2002$11/Sept./2005
  nx_tmp = apv.size(0) * apv.size(1);
  for (k = 0; k < nx_tmp; k++) {
    apv[k] = std::log10(apv[k]);
  }
  nd2 = (nx_tmp / 2) << 1;
  vectorUB = nd2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    b_r = _mm_loadu_pd(&apv[i]);
    _mm_storeu_pd(&apv[i], _mm_mul_pd(_mm_set1_pd(10.0), b_r));
  }
  for (i = nd2; i < nx_tmp; i++) {
    apv[i] = 10.0 * apv[i];
  }
  //  for compatibility
  nx_tmp = dpv.size(0) * dpv.size(1);
  for (k = 0; k < nx_tmp; k++) {
    dpv[k] = std::log10(dpv[k]);
  }
  nd2 = (nx_tmp / 2) << 1;
  vectorUB = nd2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    b_r = _mm_loadu_pd(&dpv[i]);
    _mm_storeu_pd(&dpv[i], _mm_mul_pd(_mm_set1_pd(10.0), b_r));
  }
  for (i = nd2; i < nx_tmp; i++) {
    dpv[i] = 10.0 * dpv[i];
  }
  //  for compatibility
  // - ---------
  //    Notes on aperiodicity estimation: The previous implementation of
  //    aperiodicity estimation was sensitive to low frequency noise. It is a
  //    bad news, because environmental noise usually has its power in the low
  //    frequency region. The following corrction uses the C/N information
  //    which is the byproduct of fixed point based F0 estimation.
  //    by H.K. 04/Feb./2003
  // - ---------
  loop_ub = f0raw.size(1);
  b_f0raw.set_size(1, f0raw.size(1));
  for (i = 0; i < loop_ub; i++) {
    b_f0raw[i] = f0raw[i];
  }
  //    dpv=correctdpv(apv,dpv,shiftap,ecrt,shiftm,fs)
  //    Apperiodicity correction based on C/N estimation
  //    dpv     : lower spectral envelope
  //    apv     : upper spectral envelope
  //    shiftap : frame shift for apv and dpv (ms)
  //    f0raw   : fundamental frequency (Hz)
  //    ecrt    : C/N (absolute value)
  //    shiftm  : frame shift for F0 and spectrum (ms)
  //    fs      : sampling frequency (Hz)
  //    Designed and coded by Hideki Kawahara
  //    04/Feb./2003
  // 	30/April/2005 modification for Matlab v7.0 compatibility
  if (apv.size(0) - 1 < 0) {
    tirms.set_size(tirms.size(0), 0);
  } else {
    tirms.set_size(1, apv.size(0));
    loop_ub = apv.size(0) - 1;
    for (i = 0; i <= loop_ub; i++) {
      tirms[i] = i;
    }
  }
  tirms.set_size(1, tirms.size(1));
  framel = static_cast<double>(apv.size(0)) - 1.0;
  loop_ub = tirms.size(1) - 1;
  nd2 = (tirms.size(1) / 2) << 1;
  vectorUB = nd2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    b_r = _mm_loadu_pd(&tirms[i]);
    _mm_storeu_pd(&tirms[i],
                  _mm_mul_pd(_mm_div_pd(_mm_div_pd(b_r, _mm_set1_pd(framel)),
                                        _mm_set1_pd(2.0)),
                             _mm_set1_pd(fs)));
  }
  for (i = nd2; i <= loop_ub; i++) {
    tirms[i] = tirms[i] / framel / 2.0 * fs;
  }
  for (nd2 = 0; nd2 <= end_tmp; nd2++) {
    if (f0raw[nd2] == 0.0) {
      b_f0raw[nd2] = 40.0;
    }
  }
  //  safe guard
  i = apv.size(1);
  for (offset = 0; offset < i; offset++) {
    framel =
        std::fmin(static_cast<double>(f0raw.size(1)),
                  std::round(((static_cast<double>(offset) + 1.0) - 1.0) *
                             optionalParams->periodicityFrameUpdateInterval /
                             optionalParams->F0frameUpdateInterval) +
                      1.0);
    d = ecrt[static_cast<int>(framel) - 1];
    if (!std::isnan(d)) {
      nyrows = tirms.size(1);
      bdr.set_size(1, tirms.size(1));
      framel = b_f0raw[static_cast<int>(framel) - 1];
      fftl = 2.5 * framel;
      nd2 = (tirms.size(1) / 2) << 1;
      vectorUB = nd2 - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        b_r = _mm_loadu_pd(&tirms[nx]);
        _mm_storeu_pd(
            &bdr[nx],
            _mm_mul_pd(_mm_div_pd(_mm_mul_pd(_mm_sub_pd(b_r, _mm_set1_pd(fftl)),
                                             _mm_set1_pd(-1.0)),
                                  _mm_set1_pd(framel)),
                       _mm_set1_pd(4.0)));
      }
      for (nx = nd2; nx < nyrows; nx++) {
        bdr[nx] = -(tirms[nx] - fftl) / framel * 4.0;
      }
      nx = bdr.size(1);
      for (k = 0; k < nx; k++) {
        bdr[k] = std::exp(bdr[k]);
      }
      bdr.set_size(1, bdr.size(1));
      d = 1.0 / d;
      loop_ub = bdr.size(1) - 1;
      nd2 = (bdr.size(1) / 2) << 1;
      vectorUB = nd2 - 2;
      for (nx = 0; nx <= vectorUB; nx += 2) {
        b_r = _mm_loadu_pd(&bdr[nx]);
        r1 = _mm_set1_pd(1.0);
        _mm_storeu_pd(&bdr[nx],
                      _mm_div_pd(_mm_add_pd(_mm_div_pd(r1, _mm_add_pd(b_r, r1)),
                                            _mm_set1_pd(d)),
                                 _mm_set1_pd(d + 1.0)));
      }
      for (nx = nd2; nx <= loop_ub; nx++) {
        bdr[nx] = (1.0 / (bdr[nx] + 1.0) + d) / (d + 1.0);
      }
      loop_ub = bdr.size(1);
      b_x.set_size(bdr.size(1));
      for (k = 0; k < loop_ub; k++) {
        b_x[k] = std::log10(bdr[k]);
      }
      nyrows = apv.size(0);
      if (apv.size(0) == b_x.size(0)) {
        b_x.set_size(apv.size(0));
        nd2 = (apv.size(0) / 2) << 1;
        vectorUB = nd2 - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          b_r = _mm_loadu_pd(&b_x[nx]);
          r1 = _mm_loadu_pd(&apv[nx + apv.size(0) * offset]);
          _mm_storeu_pd(&b_x[nx],
                        _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(20.0), b_r)));
        }
        for (nx = nd2; nx < nyrows; nx++) {
          b_x[nx] = apv[nx + apv.size(0) * offset] + 20.0 * b_x[nx];
        }
      } else {
        binary_expand_op(b_x, apv, offset);
      }
      nyrows = dpv.size(0);
      if (dpv.size(0) == b_x.size(0)) {
        z.set_size(dpv.size(0));
        for (nx = 0; nx < nyrows; nx++) {
          framel = dpv[nx + dpv.size(0) * offset];
          fftl = b_x[nx];
          z[nx] = std::fmin(framel, fftl);
        }
      } else {
        b_dpv.set_size(dpv.size(0));
        for (nx = 0; nx < nyrows; nx++) {
          b_dpv[nx] = dpv[nx + dpv.size(0) * offset];
        }
        legacy_STRAIGHT::coder::internal::expand_min(b_dpv, b_x, z);
      }
      for (nx = 0; nx < nyrows; nx++) {
        dpv[nx + dpv.size(0) * offset] = z[nx];
      }
    }
  }
  //  Aperiodicity correction 04/Feb./2003 by H.K.
  if (optionalParams->DisplayPlots != 0.0) {
    // 	boundary calculation for MBE model
    // 		bv=boundmes2(apv,dpv,fs,shiftm,intshiftm,mm);
    // 		apv		: peak envelope
    // 		dpv		: dip envelope
    // 		fs		: sampling frequency (Hz)
    // 		shiftm	: frame shift of F0 data
    // 		intshiftm	: frame shift for envelope data
    // 		mm		: number of elements in frequency axis
    // 	01/Sept./1999
    // 	by Hideki Kawahara
    bdr.set_size(1, static_cast<int>((r - 1.0) - 1.0) + 1);
    nyrows = static_cast<int>((r - 1.0) - 1.0);
    for (i = 0; i <= nyrows; i++) {
      bdr[i] = static_cast<double>(i) + 1.0;
    }
    bdr.set_size(1, bdr.size(1));
    nd2 = bdr.size(1) - 1;
    vectorUB = (bdr.size(1) / 2) << 1;
    offset = vectorUB - 2;
    for (i = 0; i <= offset; i += 2) {
      b_r = _mm_loadu_pd(&bdr[i]);
      _mm_storeu_pd(&bdr[i],
                    _mm_mul_pd(_mm_div_pd(_mm_div_pd(b_r, _mm_set1_pd(r - 1.0)),
                                          _mm_set1_pd(2.0)),
                               _mm_set1_pd(fs)));
    }
    for (i = vectorUB; i <= nd2; i++) {
      bdr[i] = bdr[i] / (r - 1.0) / 2.0 * fs;
    }
    nx = bdr.size(1);
    for (k = 0; k < nx; k++) {
      bdr[k] = std::log10(bdr[k]);
    }
    tirms.set_size(1, static_cast<int>((r - 1.0) - 1.0) + 1);
    for (i = 0; i <= nyrows; i++) {
      tirms[i] = static_cast<double>(i) + 1.0;
    }
    tirms.set_size(1, tirms.size(1));
    for (i = 0; i <= offset; i += 2) {
      b_r = _mm_loadu_pd(&tirms[i]);
      _mm_storeu_pd(&tirms[i],
                    _mm_mul_pd(_mm_div_pd(_mm_div_pd(b_r, _mm_set1_pd(r - 1.0)),
                                          _mm_set1_pd(2.0)),
                               _mm_set1_pd(fs)));
    }
    for (i = vectorUB; i <= nd2; i++) {
      tirms[i] = tirms[i] / (r - 1.0) / 2.0 * fs;
    }
    varargin_2.set_size(apv.size(0), apv.size(1));
    loop_ub = apv.size(0) * apv.size(1);
    for (i = 0; i < loop_ub; i++) {
      fftl = apv[i] / 20.0;
      varargin_2[i] = rt_powd_snf(10.0, fftl);
    }
    if (dpv.size(1) == apv.size(1)) {
      lyv.set_size(dpv.size(0), dpv.size(1));
      loop_ub = dpv.size(0) * dpv.size(1);
      nd2 = (loop_ub / 2) << 1;
      vectorUB = nd2 - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        b_r = _mm_loadu_pd(&dpv[i]);
        r1 = _mm_loadu_pd(&apv[i]);
        _mm_storeu_pd(&lyv[i],
                      _mm_div_pd(_mm_sub_pd(b_r, r1), _mm_set1_pd(20.0)));
      }
      for (i = nd2; i < loop_ub; i++) {
        lyv[i] = (dpv[i] - apv[i]) / 20.0;
      }
    } else {
      binary_expand_op_4(lyv, dpv, apv);
    }
    i = apv.size(1);
    bv.set_size(1, apv.size(1));
    for (offset = 0; offset < i; offset++) {
      if (static_cast<int>(r) - 1 == tirms.size(1)) {
        z.set_size(static_cast<int>(r) - 1);
        loop_ub = static_cast<int>(r);
        nd2 = ((static_cast<int>(r) - 1) / 2) << 1;
        vectorUB = nd2 - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          b_r =
              _mm_loadu_pd(&varargin_2[(nx + varargin_2.size(0) * offset) + 1]);
          r1 = _mm_loadu_pd(&tirms[nx]);
          _mm_storeu_pd(&z[nx], _mm_div_pd(b_r, r1));
        }
        for (nx = nd2; nx <= loop_ub - 2; nx++) {
          z[nx] =
              varargin_2[(nx + varargin_2.size(0) * offset) + 1] / tirms[nx];
        }
      } else {
        binary_expand_op_2(z, varargin_2, r, offset, tirms);
      }
      if ((static_cast<int>(r) - 1 == bdr.size(1)) &&
          (static_cast<int>(r) - 1 == tirms.size(1))) {
        b_f0raw.set_size(1, static_cast<int>(r) - 1);
        loop_ub = static_cast<int>(r);
        nd2 = ((static_cast<int>(r) - 1) / 2) << 1;
        vectorUB = nd2 - 2;
        for (nx = 0; nx <= vectorUB; nx += 2) {
          __m128d r2;
          __m128d r3;
          b_r = _mm_loadu_pd(&lyv[(nx + lyv.size(0) * offset) + 1]);
          r1 = _mm_loadu_pd(&bdr[nx]);
          r2 =
              _mm_loadu_pd(&varargin_2[(nx + varargin_2.size(0) * offset) + 1]);
          r3 = _mm_loadu_pd(&tirms[nx]);
          _mm_storeu_pd(&b_f0raw[nx],
                        _mm_div_pd(_mm_mul_pd(_mm_sub_pd(b_r, r1), r2), r3));
        }
        for (nx = nd2; nx <= loop_ub - 2; nx++) {
          b_f0raw[nx] = (lyv[(nx + lyv.size(0) * offset) + 1] - bdr[nx]) *
                        varargin_2[(nx + varargin_2.size(0) * offset) + 1] /
                        tirms[nx];
        }
        bv[offset] = legacy_STRAIGHT::combineVectorElements(b_f0raw) /
                     legacy_STRAIGHT::blockedSummation(z, z.size(0));
      } else {
        binary_expand_op_1(bv, offset, lyv, r, bdr, varargin_2, tirms, z);
      }
    }
    // 	Assuming shiftm >= 1 ms
    if ((!(std::round(optionalParams->F0frameUpdateInterval) !=
           optionalParams->F0frameUpdateInterval)) &&
        (!(std::round(optionalParams->periodicityFrameUpdateInterval) !=
           optionalParams->periodicityFrameUpdateInterval)) &&
        (!(optionalParams->F0frameUpdateInterval ==
           optionalParams->periodicityFrameUpdateInterval)) &&
        (optionalParams->periodicityFrameUpdateInterval > 1.0)) {
      legacy_STRAIGHT::interp(
          bv, optionalParams->periodicityFrameUpdateInterval, b_bv);
    }
  }
  // 	ap=aperiodiccomp(apv,dpv,ashift,f0,nshift,fftl,imgi);
  // 	Calculate aperiodicity index
  // 	Input parameters
  // 		apv, dpv : Upper and lower envelope
  // 		ashift		: shift step for aperiodicity index calculation
  // (ms) 		f0			: fundamental frequency (Hz)
  // 		nshift		: shift step for f0 information (ms)
  // 		fftl		: FFT size
  // 		imgi		: display indicator, 1: display on (default) 0:
  // off
  //    modified to add the waitbar on 08/Dec./2002
  // 	modified by Takahashi 10/Aug./2005
  // 	modified by Kawahara 10/Sept./2005
  // [nn,mm]=size(nsgram);
  // nn=fftl/2+1;
  if (apv.size(1) - 1 < 0) {
    bdr.set_size(1, 0);
  } else {
    bdr.set_size(1, apv.size(1));
    loop_ub = apv.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      bdr[i] = i;
    }
  }
  loop_ub = bdr.size(1);
  b_x.set_size(bdr.size(1));
  nd2 = (bdr.size(1) / 2) << 1;
  vectorUB = nd2 - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    b_r = _mm_loadu_pd(&bdr[i]);
    _mm_storeu_pd(
        &b_x[i],
        _mm_mul_pd(
            b_r, _mm_set1_pd(optionalParams->periodicityFrameUpdateInterval)));
  }
  for (i = nd2; i < loop_ub; i++) {
    b_x[i] = bdr[i] * optionalParams->periodicityFrameUpdateInterval;
  }
  if (f0raw.size(1) - 1 < 0) {
    bdr.set_size(1, 0);
  } else {
    bdr.set_size(1, f0raw.size(1));
    for (i = 0; i <= end_tmp; i++) {
      bdr[i] = i;
    }
  }
  framel = legacy_STRAIGHT::coder::internal::maximum(b_x);
  // if imgi==1; hpg=waitbar(0.1,'Interpolating periodicity information'); end;
  // if imgi==1; drawnow; end;
  // ap=interp1q(x,(dpv-apv)',xi)';%,'*linear')';
  if (dpv.size(1) == apv.size(1)) {
    loop_ub = dpv.size(1);
    b_loop_ub = dpv.size(0);
    varargin_2.set_size(dpv.size(1), dpv.size(0));
    for (i = 0; i < b_loop_ub; i++) {
      for (nx = 0; nx < loop_ub; nx++) {
        varargin_2[nx + varargin_2.size(0) * i] =
            dpv[i + dpv.size(0) * nx] - apv[i + apv.size(0) * nx];
      }
    }
  } else {
    binary_expand_op_3(varargin_2, dpv, apv);
  }
  loop_ub = bdr.size(1);
  z.set_size(bdr.size(1));
  for (i = 0; i < loop_ub; i++) {
    fftl = bdr[i] * optionalParams->F0frameUpdateInterval;
    z[i] = std::fmin(framel, fftl);
  }
  nyrows = varargin_2.size(0);
  end_tmp = varargin_2.size(1) - 1;
  nx_tmp = b_x.size(0) - 1;
  b_loop_ub = varargin_2.size(1);
  lyv.set_size(bdr.size(1), varargin_2.size(1));
  nd2 = z.size(0) * varargin_2.size(1);
  for (i = 0; i < nd2; i++) {
    lyv[i] = 0.0;
  }
  if (z.size(0) != 0) {
    k = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (k <= nx_tmp) {
        if (std::isnan(b_x[k])) {
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        double maxx;
        double minx;
        if (b_x[1] < b_x[0]) {
          i = (nx_tmp + 1) >> 1;
          for (offset = 0; offset < i; offset++) {
            framel = b_x[offset];
            nd2 = nx_tmp - offset;
            b_x[offset] = b_x[nd2];
            b_x[nd2] = framel;
          }
          if ((varargin_2.size(0) != 0) && (varargin_2.size(1) != 0) &&
              (varargin_2.size(0) > 1)) {
            nx = varargin_2.size(0) - 1;
            nd2 = varargin_2.size(0) >> 1;
            for (int j{0}; j <= end_tmp; j++) {
              offset = j * varargin_2.size(0);
              for (k = 0; k < nd2; k++) {
                vectorUB = offset + k;
                framel = varargin_2[vectorUB];
                i = (offset + nx) - k;
                varargin_2[vectorUB] = varargin_2[i];
                varargin_2[i] = framel;
              }
            }
          }
        }
        minx = b_x[0];
        maxx = b_x[nx_tmp];
        for (k = 0; k < loop_ub; k++) {
          if (std::isnan(z[k])) {
            for (int j{0}; j <= end_tmp; j++) {
              lyv[k + j * loop_ub] = rtNaN;
            }
          } else if (z[k] > maxx) {
            if (nyrows > 1) {
              r = (z[k] - maxx) / (maxx - b_x[b_x.size(0) - 2]);
              for (int j{0}; j <= end_tmp; j++) {
                i = nyrows + j * nyrows;
                d = varargin_2[i - 1];
                lyv[k + j * loop_ub] = d + r * (d - varargin_2[i - 2]);
              }
            }
          } else if (z[k] < minx) {
            r = (z[k] - minx) / (b_x[1] - minx);
            for (int j{0}; j <= end_tmp; j++) {
              i = j * nyrows;
              d = varargin_2[i];
              lyv[k + j * loop_ub] = d + r * (varargin_2[i + 1] - d);
            }
          } else {
            nx = legacy_STRAIGHT::coder::internal::b_bsearch(b_x, z[k]);
            framel = b_x[nx - 1];
            r = (z[k] - framel) / (b_x[nx] - framel);
            if (r == 0.0) {
              for (int j{0}; j <= end_tmp; j++) {
                lyv[k + j * loop_ub] = varargin_2[(nx + j * nyrows) - 1];
              }
            } else if (r == 1.0) {
              for (int j{0}; j <= end_tmp; j++) {
                lyv[k + j * loop_ub] = varargin_2[nx + j * nyrows];
              }
            } else {
              for (int j{0}; j <= end_tmp; j++) {
                nd2 = nx + j * nyrows;
                framel = varargin_2[nd2 - 1];
                fftl = varargin_2[nd2];
                if (framel == fftl) {
                  lyv[k + j * loop_ub] = framel;
                } else {
                  lyv[k + j * loop_ub] = (1.0 - r) * framel + r * fftl;
                }
              }
            }
          }
        }
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  ap.set_size(varargin_2.size(1), bdr.size(1));
  for (i = 0; i < loop_ub; i++) {
    for (nx = 0; nx < b_loop_ub; nx++) {
      ap[nx + ap.size(0) * i] = lyv[i + lyv.size(0) * nx];
    }
  }
  // if imgi==1; close(hpg); end;
  //  11/Sept./2005
}

// End of code generation (exstraightsource.cpp)
