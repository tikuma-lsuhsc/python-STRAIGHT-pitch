//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource.h
//
// Code generation for function 'exstraightsource'
//

#ifndef EXSTRAIGHTSOURCE_H
#define EXSTRAIGHTSOURCE_H

// Include files
#include "exstraightsource_types.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void exstraightsource(coder::array<double, 1U> &x, double fs,
                             const struct0_T *optionalParams,
                             coder::array<double, 2U> &f0raw,
                             coder::array<double, 2U> &ap,
                             struct0_T *analysisParams);

#endif
// End of code generation (exstraightsource.h)
