//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// f0track5.h
//
// Code generation for function 'f0track5'
//

#ifndef F0TRACK5_H
#define F0TRACK5_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void f0track5(const coder::array<double, 2U> &f0v,
              const coder::array<double, 2U> &vrv,
              const coder::array<double, 2U> &dfv,
              const coder::array<creal_T, 2U> &pwt,
              const coder::array<creal_T, 2U> &pwh,
              const coder::array<double, 2U> &aav, double shiftm,
              coder::array<double, 2U> &f0, coder::array<double, 2U> &irms,
              coder::array<double, 2U> &df, coder::array<double, 2U> &amp);

#endif
// End of code generation (f0track5.h)
