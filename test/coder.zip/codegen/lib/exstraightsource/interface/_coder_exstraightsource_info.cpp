//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_exstraightsource_info.cpp
//
// Code generation for function 'exstraightsource'
//

// Include files
#include "_coder_exstraightsource_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[11]{
      "789ced5a4d73db44185698c234654a0d072e0cc3a53798c8766da71eb8c4b6fcd144496a"
      "3b2e71a76d64691dcbd26ae5d52ab633fc0466e006478ecc70618663"
      "2f0c27a627e017f01fb833d896d61f4a351655bac6467bc8eaf563edf3f87dad27bbebe5"
      "b62ae216c771ef704efbf953a7bfedc631b77f835b6c5e7ccbeddff6",
      "c4b4bdc9dd58b88fe25fb9bd8c0c0206c4090c0982e99d0a82aa2119a43e3401878185f4"
      "0ba04c90b6aa83ba0a416d3e381c47b038074d833134bece7780acd5"
      "6cc8e18e3553a8cf07d37c7cebf3796f04ccc7ae4f3e621efcb1f084ef2008f8a16418aa"
      "acf13a3897e4e1b35abdba572995ebbc85651e0c2c8225f5bc432c64",
      "6319ecc0a94e33a44e6fecd549fbb63a308bf10618883a3173a514e53f0bc9ff962fbf83"
      "28c86ee9e03f5a176f52e6ea72e6a3e34e409dde7ef6fe9b93fe9bdf"
      "9eb7c73d2b3ee1cb5fb759f2d1b62abe81cf7841bf67effbf0c53c78f6e09e92cf0c3376"
      "5d54f3fd41e6347d58d50a331dc74b7896e9e07c6256e3afcbf31ab6",
      "deef2dd1497168eb4432247d488aaa01f2b5e39cf3faaafcf4bb907c595fbe453c507dae"
      "26675421a7b1f20191b1af12f44382251f6d9beeabe7f946eec130db"
      "531fe1c381d6d4f6b46eb5958f7c95f5fcf42ca4ce9b9e78a6d341daf111b3aca557e59f"
      "5f87e4e37df916f160ffdfdc64309c879efcced62f2f7ab7522cf968",
      "db74bf1ccabdc3aeac7caef60da16042d8e8f56b7bb9c82fd76d3dbfbd4427c531688fa6"
      "58c578c68dd7d53fe3be7c8b78a0ba4c93b203593defcd3fd8fae7df"
      "7f3ef888251f6d9bee9fe9547baf2b344a39e1a49fd088880f48767f83fcf3479ffb83e6"
      "71df67fc98077f5c39109edc8512d1a5164688dce509427a0b0d7800",
      "755e575bbc83f126d2876ddbe05583006c2676e0568d60d538af2311900e522a8505fd61"
      "7de69325fa292e2305e09d89a8d142d6b91849950870af1d759660d8"
      "705edfd92beaf3363f7db44df7fb5f918f8eff74091fc547f53c7c793dad8e8481c24f12"
      "e6fefdd8ed68fadc2b277ffc95fc8d370758f98af962bb35eeff2fbe",
      "c99a8f954f8b95e37403a8bbcdac98acca083f84890a2e6f8e4f7fef737fd03c967cc68f"
      "79f0103eed5e3deb23ac45feec89237f7ef9e789fc79b57c913f5fcf"
      "f8ebb20f11b6deef2ed14971c90458458a2a9b1226423597745f5fd7f305f77df916f140"
      "f5b9921c76fb122f18ef4b94ffb2eeb0e4a36dd3fdb42b17ce2f05f1",
      "4832ecf223a0896a733fa945bf83317f5ec3eeebfa9daf8b79f0f2651d09b8551d4dc826"
      "f1bafa68d213739ef7513c505de692420f14b07aee7f7aced6473fc0"
      "fa872cf968db741fb5cb7269b7d918960bf14c275b94cd8cbd77149dd3623e2f0deba3b7"
      "96e8a4f868e981814c14f3c289d7d54713be7c8b78a0bacc92c2fc5c",
      "56e4a3af978f958f0ab0776442d43f52c8e9c35eb7943ac9175242e4a3ebe6a341cf19b4"
      "906d281058ab5ed787dd5f8efbf22de281ea324d0abbf57ce49faf97"
      "8f957f56e389034860b7552fe4ef1d93d2ee69a65a2946feb96efe79db137b75527cbaa5"
      "202338e65cd77968ca976f11ff77fb2ce3a4ec04fa9deeba9efbcf7e",
      "61eba35fe42bd1792deefa7d54d3e49cb0df2e5f96cd81650dc4f4fde4657303d6f3ff00"
      "b95e4892",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 15320U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[9]{"Version",
                                 "ResolvedFunctions",
                                 "Checksum",
                                 "EntryPoints",
                                 "CoverageInfo",
                                 "IsPolymorphic",
                                 "PropertyList",
                                 "UUID",
                                 "ClassEntryPointIsHandle"};
  const char_T *epFieldName[8]{
      "Name",     "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "FullPath", "TimeStamp",      "Constructor",     "Visible"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 8, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("exstraightsource"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath",
                emlrtMxCreateString(
                    "/home/yannick/legacy_STRAIGHT/src/exstraightsource.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739477.98263888888));
  emlrtSetField(xEntryPoints, 0, "Constructor",
                emlrtMxCreateLogicalScalar(false));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 9, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("24.1.0.2537033 (R2024a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("gB6aGjRqWDiLcI6hQUcEMG"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_exstraightsource_info.cpp)
