//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_exstraightsource_api.cpp
//
// Code generation for function 'exstraightsource'
//

// Include files
#include "_coder_exstraightsource_api.h"
#include "_coder_exstraightsource_mex.h"
#include "coder_array_mex.h"

// Variable Definitions
emlrtCTX emlrtRootTLSGlobal{nullptr};

emlrtContext emlrtContextGlobal{
    true,                                                 // bFirstTime
    false,                                                // bInitialized
    131643U,                                              // fVersionInfo
    nullptr,                                              // fErrorFunction
    "exstraightsource",                                   // fFunctionName
    nullptr,                                              // fRTCallStack
    false,                                                // bDebugMode
    {2045744189U, 2170104910U, 2743257031U, 4284093946U}, // fSigWrd
    nullptr                                               // fSigMem
};

// Function Declarations
static char_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId);

static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               coder::array<real_T, 1U> &ret);

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

static char_T d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

static void emlrtExitTimeCleanupDtorFcn(const void *r);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, struct0_T &y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId, struct0_T &y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier,
                             coder::array<real_T, 1U> &y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             coder::array<real_T, 1U> &y);

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                               const char_T *identifier);

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                               const emlrtMsgIdentifier *parentId);

static const mxArray *emlrt_marshallOut(const coder::array<real_T, 2U> &u);

static const mxArray *emlrt_marshallOut(const emlrtStack &sp,
                                        const struct0_T &u);

// Function Definitions
static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               coder::array<real_T, 1U> &ret)
{
  static const int32_T dims{-1};
  int32_T i;
  boolean_T b{true};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 1U,
                            (const void *)&dims, &b, &i);
  ret.prealloc(i);
  ret.set_size(i);
  ret.set(static_cast<real_T *>(emlrtMxGetData(src)), ret.size(0));
  emlrtDestroyArray(&src);
}

static char_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId)
{
  char_T y;
  y = d_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims{0};
  real_T ret;
  emlrtCheckBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 0U,
                          (const void *)&dims);
  ret = *static_cast<real_T *>(emlrtMxGetData(src));
  emlrtDestroyArray(&src);
  return ret;
}

static char_T d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims{0};
  char_T ret;
  emlrtCheckBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "char", false, 0U,
                          (const void *)&dims);
  emlrtImportCharR2015b((emlrtCTX)&sp, src, &ret);
  emlrtDestroyArray(&src);
  return ret;
}

static void emlrtExitTimeCleanupDtorFcn(const void *r)
{
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, struct0_T &y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId, y);
  emlrtDestroyArray(&b_nullptr);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId, struct0_T &y)
{
  static const int32_T dims{0};
  static const char_T *fieldNames[16]{"F0searchLowerBound",
                                      "F0searchUpperBound",
                                      "F0defaultWindowLength",
                                      "F0frameUpdateInterval",
                                      "NofChannelsInOctave",
                                      "IFWindowStretch",
                                      "DisplayPlots",
                                      "IFsmoothingLengthRelToFc",
                                      "IFminimumSmoothingLength",
                                      "IFexponentForNonlinearSum",
                                      "IFnumberOfHarmonicForInitialEstimate",
                                      "refineFftLength",
                                      "refineTimeStretchingFactor",
                                      "refineNumberofHarmonicComponent",
                                      "periodicityFrameUpdateInterval",
                                      "note"};
  emlrtMsgIdentifier thisId;
  thisId.fParent = parentId;
  thisId.bParentIsCell = false;
  emlrtCheckStructR2012b((emlrtConstCTX)&sp, parentId, u, 16,
                         (const char_T **)&fieldNames[0], 0U,
                         (const void *)&dims);
  thisId.fIdentifier = "F0searchLowerBound";
  y.F0searchLowerBound =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0,
                                                      0, "F0searchLowerBound")),
                       &thisId);
  thisId.fIdentifier = "F0searchUpperBound";
  y.F0searchUpperBound =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0,
                                                      1, "F0searchUpperBound")),
                       &thisId);
  thisId.fIdentifier = "F0defaultWindowLength";
  y.F0defaultWindowLength = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 2,
                                     "F0defaultWindowLength")),
      &thisId);
  thisId.fIdentifier = "F0frameUpdateInterval";
  y.F0frameUpdateInterval = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 3,
                                     "F0frameUpdateInterval")),
      &thisId);
  thisId.fIdentifier = "NofChannelsInOctave";
  y.NofChannelsInOctave =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b(
                           (emlrtConstCTX)&sp, u, 0, 4, "NofChannelsInOctave")),
                       &thisId);
  thisId.fIdentifier = "IFWindowStretch";
  y.IFWindowStretch =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0,
                                                      5, "IFWindowStretch")),
                       &thisId);
  thisId.fIdentifier = "DisplayPlots";
  y.DisplayPlots =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0,
                                                      6, "DisplayPlots")),
                       &thisId);
  thisId.fIdentifier = "IFsmoothingLengthRelToFc";
  y.IFsmoothingLengthRelToFc = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 7,
                                     "IFsmoothingLengthRelToFc")),
      &thisId);
  thisId.fIdentifier = "IFminimumSmoothingLength";
  y.IFminimumSmoothingLength = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 8,
                                     "IFminimumSmoothingLength")),
      &thisId);
  thisId.fIdentifier = "IFexponentForNonlinearSum";
  y.IFexponentForNonlinearSum = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 9,
                                     "IFexponentForNonlinearSum")),
      &thisId);
  thisId.fIdentifier = "IFnumberOfHarmonicForInitialEstimate";
  y.IFnumberOfHarmonicForInitialEstimate = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 10,
                                     "IFnumberOfHarmonicForInitialEstimate")),
      &thisId);
  thisId.fIdentifier = "refineFftLength";
  y.refineFftLength =
      emlrt_marshallIn(sp,
                       emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0,
                                                      11, "refineFftLength")),
                       &thisId);
  thisId.fIdentifier = "refineTimeStretchingFactor";
  y.refineTimeStretchingFactor = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 12,
                                     "refineTimeStretchingFactor")),
      &thisId);
  thisId.fIdentifier = "refineNumberofHarmonicComponent";
  y.refineNumberofHarmonicComponent = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 13,
                                     "refineNumberofHarmonicComponent")),
      &thisId);
  thisId.fIdentifier = "periodicityFrameUpdateInterval";
  y.periodicityFrameUpdateInterval = emlrt_marshallIn(
      sp,
      emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 14,
                                     "periodicityFrameUpdateInterval")),
      &thisId);
  thisId.fIdentifier = "note";
  y.note = b_emlrt_marshallIn(
      sp, emlrtAlias(emlrtGetFieldR2017b((emlrtConstCTX)&sp, u, 0, 15, "note")),
      &thisId);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier,
                             coder::array<real_T, 1U> &y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId, y);
  emlrtDestroyArray(&b_nullptr);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             coder::array<real_T, 1U> &y)
{
  b_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                               const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                               const emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = c_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static const mxArray *emlrt_marshallOut(const coder::array<real_T, 2U> &u)
{
  static const int32_T iv[2]{0, 0};
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, &(((coder::array<real_T, 2U> *)&u)->data())[0]);
  emlrtSetDimensions((mxArray *)m, ((coder::array<real_T, 2U> *)&u)->size(), 2);
  emlrtAssign(&y, m);
  return y;
}

static const mxArray *emlrt_marshallOut(const emlrtStack &sp,
                                        const struct0_T &u)
{
  static const char_T *sv[16]{"F0searchLowerBound",
                              "F0searchUpperBound",
                              "F0defaultWindowLength",
                              "F0frameUpdateInterval",
                              "NofChannelsInOctave",
                              "IFWindowStretch",
                              "DisplayPlots",
                              "IFsmoothingLengthRelToFc",
                              "IFminimumSmoothingLength",
                              "IFexponentForNonlinearSum",
                              "IFnumberOfHarmonicForInitialEstimate",
                              "refineFftLength",
                              "refineTimeStretchingFactor",
                              "refineNumberofHarmonicComponent",
                              "periodicityFrameUpdateInterval",
                              "note"};
  const mxArray *b_y;
  const mxArray *c_y;
  const mxArray *d_y;
  const mxArray *e_y;
  const mxArray *f_y;
  const mxArray *g_y;
  const mxArray *h_y;
  const mxArray *i_y;
  const mxArray *j_y;
  const mxArray *k_y;
  const mxArray *l_y;
  const mxArray *m;
  const mxArray *m_y;
  const mxArray *n_y;
  const mxArray *o_y;
  const mxArray *p_y;
  const mxArray *q_y;
  const mxArray *y;
  y = nullptr;
  emlrtAssign(&y, emlrtCreateStructMatrix(1, 1, 16, (const char_T **)&sv[0]));
  b_y = nullptr;
  m = emlrtCreateDoubleScalar(u.F0searchLowerBound);
  emlrtAssign(&b_y, m);
  emlrtSetFieldR2017b(y, 0, "F0searchLowerBound", b_y, 0);
  c_y = nullptr;
  m = emlrtCreateDoubleScalar(u.F0searchUpperBound);
  emlrtAssign(&c_y, m);
  emlrtSetFieldR2017b(y, 0, "F0searchUpperBound", c_y, 1);
  d_y = nullptr;
  m = emlrtCreateDoubleScalar(u.F0defaultWindowLength);
  emlrtAssign(&d_y, m);
  emlrtSetFieldR2017b(y, 0, "F0defaultWindowLength", d_y, 2);
  e_y = nullptr;
  m = emlrtCreateDoubleScalar(u.F0frameUpdateInterval);
  emlrtAssign(&e_y, m);
  emlrtSetFieldR2017b(y, 0, "F0frameUpdateInterval", e_y, 3);
  f_y = nullptr;
  m = emlrtCreateDoubleScalar(u.NofChannelsInOctave);
  emlrtAssign(&f_y, m);
  emlrtSetFieldR2017b(y, 0, "NofChannelsInOctave", f_y, 4);
  g_y = nullptr;
  m = emlrtCreateDoubleScalar(u.IFWindowStretch);
  emlrtAssign(&g_y, m);
  emlrtSetFieldR2017b(y, 0, "IFWindowStretch", g_y, 5);
  h_y = nullptr;
  m = emlrtCreateDoubleScalar(u.DisplayPlots);
  emlrtAssign(&h_y, m);
  emlrtSetFieldR2017b(y, 0, "DisplayPlots", h_y, 6);
  i_y = nullptr;
  m = emlrtCreateDoubleScalar(u.IFsmoothingLengthRelToFc);
  emlrtAssign(&i_y, m);
  emlrtSetFieldR2017b(y, 0, "IFsmoothingLengthRelToFc", i_y, 7);
  j_y = nullptr;
  m = emlrtCreateDoubleScalar(u.IFminimumSmoothingLength);
  emlrtAssign(&j_y, m);
  emlrtSetFieldR2017b(y, 0, "IFminimumSmoothingLength", j_y, 8);
  k_y = nullptr;
  m = emlrtCreateDoubleScalar(u.IFexponentForNonlinearSum);
  emlrtAssign(&k_y, m);
  emlrtSetFieldR2017b(y, 0, "IFexponentForNonlinearSum", k_y, 9);
  l_y = nullptr;
  m = emlrtCreateDoubleScalar(u.IFnumberOfHarmonicForInitialEstimate);
  emlrtAssign(&l_y, m);
  emlrtSetFieldR2017b(y, 0, "IFnumberOfHarmonicForInitialEstimate", l_y, 10);
  m_y = nullptr;
  m = emlrtCreateDoubleScalar(u.refineFftLength);
  emlrtAssign(&m_y, m);
  emlrtSetFieldR2017b(y, 0, "refineFftLength", m_y, 11);
  n_y = nullptr;
  m = emlrtCreateDoubleScalar(u.refineTimeStretchingFactor);
  emlrtAssign(&n_y, m);
  emlrtSetFieldR2017b(y, 0, "refineTimeStretchingFactor", n_y, 12);
  o_y = nullptr;
  m = emlrtCreateDoubleScalar(u.refineNumberofHarmonicComponent);
  emlrtAssign(&o_y, m);
  emlrtSetFieldR2017b(y, 0, "refineNumberofHarmonicComponent", o_y, 13);
  p_y = nullptr;
  m = emlrtCreateDoubleScalar(u.periodicityFrameUpdateInterval);
  emlrtAssign(&p_y, m);
  emlrtSetFieldR2017b(y, 0, "periodicityFrameUpdateInterval", p_y, 14);
  q_y = nullptr;
  m = emlrtCreateString1R2022a((emlrtCTX)&sp, u.note);
  emlrtAssign(&q_y, m);
  emlrtSetFieldR2017b(y, 0, "note", q_y, 15);
  return y;
}

void exstraightsource_api(const mxArray *const prhs[3], int32_T nlhs,
                          const mxArray *plhs[3])
{
  coder::array<real_T, 2U> ap;
  coder::array<real_T, 2U> f0raw;
  coder::array<real_T, 1U> x;
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  const mxArray *prhs_copy_idx_0;
  struct0_T analysisParams;
  struct0_T optionalParams;
  real_T fs;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  prhs_copy_idx_0 = emlrtProtectR2012b(prhs[0], 0, false, -1);
  // Marshall function inputs
  x.no_free();
  emlrt_marshallIn(st, emlrtAlias(prhs_copy_idx_0), "x", x);
  fs = emlrt_marshallIn(st, emlrtAliasP(prhs[1]), "fs");
  emlrt_marshallIn(st, emlrtAliasP(prhs[2]), "optionalParams", optionalParams);
  // Invoke the target function
  exstraightsource(x, fs, &optionalParams, f0raw, ap, &analysisParams);
  // Marshall function outputs
  f0raw.no_free();
  plhs[0] = emlrt_marshallOut(f0raw);
  if (nlhs > 1) {
    ap.no_free();
    plhs[1] = emlrt_marshallOut(ap);
  }
  if (nlhs > 2) {
    plhs[2] = emlrt_marshallOut(st, analysisParams);
  }
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void exstraightsource_atexit()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                    (void *)&emlrtExitTimeCleanupDtorFcn,
                                    nullptr, nullptr, nullptr);
  emlrtEnterRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  exstraightsource_xil_terminate();
  exstraightsource_xil_shutdown();
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

void exstraightsource_initialize()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, nullptr);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

void exstraightsource_terminate()
{
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

// End of code generation (_coder_exstraightsource_api.cpp)
