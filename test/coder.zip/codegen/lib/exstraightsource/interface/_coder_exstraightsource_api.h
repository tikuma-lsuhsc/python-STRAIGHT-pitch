//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_exstraightsource_api.h
//
// Code generation for function 'exstraightsource'
//

#ifndef _CODER_EXSTRAIGHTSOURCE_API_H
#define _CODER_EXSTRAIGHTSOURCE_API_H

// Include files
#include "coder_array_mex.h"
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <algorithm>
#include <cstring>

// Type Definitions
struct struct0_T {
  real_T F0searchLowerBound;
  real_T F0searchUpperBound;
  real_T F0defaultWindowLength;
  real_T F0frameUpdateInterval;
  real_T NofChannelsInOctave;
  real_T IFWindowStretch;
  real_T DisplayPlots;
  real_T IFsmoothingLengthRelToFc;
  real_T IFminimumSmoothingLength;
  real_T IFexponentForNonlinearSum;
  real_T IFnumberOfHarmonicForInitialEstimate;
  real_T refineFftLength;
  real_T refineTimeStretchingFactor;
  real_T refineNumberofHarmonicComponent;
  real_T periodicityFrameUpdateInterval;
  char_T note;
};

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

// Function Declarations
void exstraightsource(coder::array<real_T, 1U> *x, real_T fs,
                      struct0_T *optionalParams,
                      coder::array<real_T, 2U> *f0raw,
                      coder::array<real_T, 2U> *ap, struct0_T *analysisParams);

void exstraightsource_api(const mxArray *const prhs[3], int32_T nlhs,
                          const mxArray *plhs[3]);

void exstraightsource_atexit();

void exstraightsource_initialize();

void exstraightsource_terminate();

void exstraightsource_xil_shutdown();

void exstraightsource_xil_terminate();

#endif
// End of code generation (_coder_exstraightsource_api.h)
