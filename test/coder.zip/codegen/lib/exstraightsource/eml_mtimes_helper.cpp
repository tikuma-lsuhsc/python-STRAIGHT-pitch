//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// eml_mtimes_helper.cpp
//
// Code generation for function 'eml_mtimes_helper'
//

// Include files
#include "eml_mtimes_helper.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
void binary_expand_op_64(coder::array<double, 2U> &in1,
                         const coder::array<double, 2U> &in2, int in3, int in4,
                         const int in5[2], int in6,
                         const coder::array<double, 2U> &in7, const int in8[2],
                         double in9, double in10)
{
  coder::array<double, 2U> b_in2;
  double b_in9;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  loop_ub = in4 - in3;
  b_loop_ub = in2.size(1);
  b_in2.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] = in2[(in3 + i1) + in2.size(0) * i];
    }
  }
  loop_ub = in5[0];
  b_loop_ub = in8[0];
  in1.set_size(loop_ub + b_loop_ub, in6);
  for (int i{0}; i < in6; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + loop_ub * i];
    }
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[(i1 + loop_ub) + in1.size(0) * i] = in7[i1 + b_loop_ub * i];
    }
  }
  b_in9 = in9 / in10 * 2.0 * 3.1415926535897931;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          (in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] -
           in2[i1 * stride_1_0 + in2.size(0) * aux_1_1]) /
          b_in9 * in9;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(loop_ub, b_loop_ub);
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

// End of code generation (eml_mtimes_helper.cpp)
