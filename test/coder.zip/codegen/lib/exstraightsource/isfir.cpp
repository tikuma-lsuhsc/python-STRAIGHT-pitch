//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// isfir.cpp
//
// Code generation for function 'isfir'
//

// Include files
#include "isfir.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace legacy_STRAIGHT {
namespace b_signal {
namespace internal {
boolean_T isfir(const double a_data[], const int a_size[2])
{
  int i;
  int idxNonZero;
  int n_tmp;
  boolean_T exitg1;
  boolean_T firflag;
  n_tmp = a_size[1];
  idxNonZero = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i <= n_tmp - 1)) {
    int b_i;
    b_i = n_tmp - i;
    if (a_data[b_i - 1] != 0.0) {
      idxNonZero = b_i;
      exitg1 = true;
    } else {
      i++;
    }
  }
  if (idxNonZero > 1) {
    idxNonZero = 0;
    for (i = 0; i < n_tmp; i++) {
      if (a_data[i] != 0.0) {
        idxNonZero++;
      }
    }
    firflag = (idxNonZero == 1);
  } else {
    firflag = true;
  }
  return firflag;
}

} // namespace internal
} // namespace b_signal
} // namespace legacy_STRAIGHT

// End of code generation (isfir.cpp)
