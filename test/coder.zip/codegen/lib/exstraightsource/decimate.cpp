//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decimate.cpp
//
// Code generation for function 'decimate'
//

// Include files
#include "decimate.h"
#include "conv.h"
#include "div.h"
#include "dividenowarn.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "fft.h"
#include "find.h"
#include "firls.h"
#include "grpdelay.h"
#include "isfir.h"
#include "islinphase.h"
#include "isstable.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <emmintrin.h>

// Variable Definitions
static const double dv1[31]{0.080000000000000016, 0.090052103662449423,
                            0.11976908948440362,  0.16785218258752421,
                            0.23219992107492521,  0.30999999999999994,
                            0.39785218258752419,  0.49191690689687945,
                            0.58808309310312057,  0.68214781741247577,
                            0.76999999999999991,  0.8478000789250747,
                            0.91214781741247575,  0.9602309105155965,
                            0.98994789633755065,  1.0,
                            0.98994789633755065,  0.9602309105155965,
                            0.91214781741247575,  0.8478000789250747,
                            0.76999999999999991,  0.68214781741247577,
                            0.58808309310312057,  0.49191690689687945,
                            0.39785218258752419,  0.30999999999999994,
                            0.23219992107492521,  0.16785218258752421,
                            0.11976908948440362,  0.090052103662449423,
                            0.080000000000000016};

static const signed char iv1[31]{1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

// Function Definitions
namespace legacy_STRAIGHT {
void decimate(const ::coder::array<creal_T, 2U> &idata, double r,
              ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<creal_T, 2U> z;
  ::coder::array<creal_T, 1U> b_y1;
  ::coder::array<creal_T, 1U> d_b;
  ::coder::array<double, 2U> b_y;
  ::coder::array<double, 2U> b_y_data;
  creal_T c_data[77];
  creal_T den_data[77];
  creal_T gd1_data[77];
  creal_T tmp_data[64];
  creal_T c_y1[62];
  creal_T cr_data[62];
  creal_T itemp[62];
  creal_T b_zf[30];
  creal_T zf[30];
  double y_data[32];
  double b[31];
  double hh_data[31];
  double a_data[16];
  double gd1[8];
  int a_size[2];
  int b_size[2];
  int c_size[2];
  int cr_size[2];
  int den_size[2];
  int gd1_size[2];
  if (r == 1.0) {
    int loop_ub;
    loop_ub = idata.size(1);
    y.set_size(1, idata.size(1));
    for (int i{0}; i < loop_ub; i++) {
      y[i] = idata[i];
    }
  } else {
    creal_T b_b[31];
    creal_T c_b[31];
    double b_dv[4];
    double G;
    double b_re_tmp;
    double y_im;
    double y_re;
    int hh_size[2];
    int b_k;
    int i;
    int ii_data;
    int j;
    int k;
    int loop_ub;
    int mmax;
    int naxpy;
    int niccp;
    signed char b_ii_data;
    boolean_T exitg1;
    boolean_T islinphaseflag;
    G = 1.0 / r;
    b_dv[0] = 0.0;
    b_dv[1] = G;
    b_dv[2] = G;
    b_dv[3] = 1.0;
    eFirls(b_dv, hh_data, hh_size, a_data);
    for (i = 0; i <= 28; i += 2) {
      __m128d b_r;
      b_r = _mm_loadu_pd(&hh_data[i]);
      _mm_storeu_pd(&b[i], _mm_mul_pd(b_r, _mm_loadu_pd(&dv1[i])));
    }
    b[30] = hh_data[30] * dv1[30];
    G = b[0];
    for (k = 0; k < 30; k++) {
      G += b[k + 1];
    }
    y_re = 2.0 * idata[0].re;
    y_im = 2.0 * idata[0].im;
    for (i = 0; i < 31; i++) {
      b_re_tmp = b[i] / G;
      b[i] = b_re_tmp;
      b_b[i].re = b_re_tmp;
      b_b[i].im = 0.0;
      c_b[i].re = y_re - idata[31 - i].re;
      c_b[i].im = y_im - idata[31 - i].im;
    }
    std::memset(&zf[0], 0, 30U * sizeof(creal_T));
    for (k = 0; k < 30; k++) {
      G = c_b[k + 1].re;
      y_re = c_b[k + 1].im;
      for (j = 0; j <= k; j++) {
        ii_data = (j - k) + 30;
        y_im = b_b[ii_data].im;
        b_re_tmp = b_b[ii_data].re;
        zf[j].re += G * b_re_tmp - y_re * y_im;
        zf[j].im += G * y_im + y_re * b_re_tmp;
      }
    }
    loop_ub = idata.size(1);
    d_b.set_size(idata.size(1));
    for (i = 0; i < loop_ub; i++) {
      d_b[i] = idata[i];
    }
    b_y1.set_size(idata.size(1));
    std::memset(&b_zf[0], 0, 30U * sizeof(creal_T));
    if (d_b.size(0) < 30) {
      niccp = d_b.size(0) - 1;
    } else {
      niccp = 29;
    }
    for (k = 0; k <= niccp; k++) {
      b_y1[k] = zf[k];
    }
    i = niccp + 2;
    for (k = i; k <= loop_ub; k++) {
      b_y1[k - 1].re = 0.0;
      b_y1[k - 1].im = 0.0;
    }
    if (d_b.size(0) >= 62) {
      for (k = 0; k < 31; k++) {
        b_k = k + 1;
        G = b_b[k].re;
        y_re = b_b[k].im;
        for (j = b_k; j <= loop_ub; j++) {
          ii_data = (j - k) - 1;
          y_im = d_b[ii_data].im;
          b_re_tmp = d_b[ii_data].re;
          b_y1[j - 1].re = b_y1[j - 1].re + (G * b_re_tmp - y_re * y_im);
          b_y1[j - 1].im = b_y1[j - 1].im + (G * y_im + y_re * b_re_tmp);
        }
      }
    } else {
      if (d_b.size(0) > 31) {
        niccp = d_b.size(0) - 32;
      } else {
        niccp = -1;
      }
      for (k = 0; k <= niccp; k++) {
        G = d_b[k].re;
        y_re = d_b[k].im;
        for (j = 0; j < 31; j++) {
          y_im = b_b[j].im;
          b_re_tmp = b_b[j].re;
          i = k + j;
          b_y1[i].re = b_y1[i].re + (G * b_re_tmp - y_re * y_im);
          b_y1[i].im = b_y1[i].im + (G * y_im + y_re * b_re_tmp);
        }
      }
      naxpy = d_b.size(0) - niccp;
      i = niccp + 2;
      for (k = i; k <= loop_ub; k++) {
        for (j = 0; j <= naxpy - 2; j++) {
          G = d_b[k - 1].re;
          y_re = b_b[j].im;
          y_im = d_b[k - 1].im;
          b_re_tmp = b_b[j].re;
          mmax = (k + j) - 1;
          b_y1[mmax].re = b_y1[mmax].re + (G * b_re_tmp - y_im * y_re);
          b_y1[mmax].im = b_y1[mmax].im + (G * y_re + y_im * b_re_tmp);
        }
        naxpy--;
      }
    }
    if (d_b.size(0) < 30) {
      i = 29 - d_b.size(0);
      for (k = 0; k <= i; k++) {
        b_zf[k] = zf[k + loop_ub];
      }
    }
    if (d_b.size(0) >= 31) {
      niccp = d_b.size(0) - 30;
    } else {
      niccp = 0;
    }
    i = d_b.size(0) - 1;
    for (k = niccp; k <= i; k++) {
      mmax = loop_ub - k;
      naxpy = 30 - mmax;
      for (j = 0; j <= naxpy; j++) {
        G = d_b[k].re;
        ii_data = mmax + j;
        y_re = b_b[ii_data].im;
        y_im = d_b[k].im;
        b_re_tmp = b_b[ii_data].re;
        b_zf[j].re += G * b_re_tmp - y_im * y_re;
        b_zf[j].im += G * y_re + y_im * b_re_tmp;
      }
    }
    y_re = 2.0 * idata[idata.size(1) - 1].re;
    y_im = 2.0 * idata[idata.size(1) - 1].im;
    for (i = 0; i < 62; i++) {
      itemp[i].re = y_re - idata[(idata.size(1) - i) - 2].re;
      itemp[i].im = y_im - idata[(idata.size(1) - i) - 2].im;
    }
    std::copy(&b_zf[0], &b_zf[30], &c_y1[0]);
    std::memset(&c_y1[30], 0, 32U * sizeof(creal_T));
    for (k = 0; k < 31; k++) {
      b_k = k + 1;
      G = b_b[k].re;
      y_re = b_b[k].im;
      for (j = b_k; j < 63; j++) {
        ii_data = (j - k) - 1;
        y_im = itemp[ii_data].im;
        b_re_tmp = itemp[ii_data].re;
        c_y1[j - 1].re += G * b_re_tmp - y_re * y_im;
        c_y1[j - 1].im += G * y_im + y_re * b_re_tmp;
      }
    }
    niccp = 0;
    mmax = 31;
    exitg1 = false;
    while ((!exitg1) && (mmax > 0)) {
      if ((b_b[mmax - 1].re != 0.0) || (b_b[mmax - 1].im != 0.0)) {
        niccp = 1;
        b_ii_data = static_cast<signed char>(mmax);
        exitg1 = true;
      } else {
        mmax--;
      }
    }
    if (niccp == 0) {
      j = 1;
    } else {
      j = b_ii_data;
    }
    a_size[0] = 1;
    a_size[1] = j;
    b_size[0] = 1;
    b_size[1] = j;
    for (i = 0; i < j; i++) {
      b[i] = iv1[i];
      c_b[i] = b_b[i];
    }
    i = j - 1;
    ii_data = (j + j) - 1;
    std::memset(&itemp[0], 0,
                static_cast<unsigned int>(ii_data) * sizeof(creal_T));
    for (k = 0; k <= i; k++) {
      mmax = static_cast<int>(b[(j - k) - 1]);
      for (b_k = 0; b_k <= i; b_k++) {
        niccp = k + b_k;
        itemp[niccp].re += static_cast<double>(mmax) * b_b[b_k].re;
        itemp[niccp].im += static_cast<double>(mmax) * b_b[b_k].im;
      }
    }
    cr_size[0] = 1;
    cr_size[1] = ii_data;
    for (i = 0; i < ii_data; i++) {
      cr_data[i].re = static_cast<double>(i) * itemp[i].re;
      cr_data[i].im = static_cast<double>(i) * itemp[i].im;
    }
    if (ii_data <= 16) {
      den_size[0] = 1;
      den_size[1] = 16;
      std::copy(&cr_data[0], &cr_data[ii_data], &den_data[0]);
      niccp = 16 - ii_data;
      if (niccp - 1 >= 0) {
        std::memset(&den_data[ii_data], 0,
                    static_cast<unsigned int>((niccp + ii_data) - ii_data) *
                        sizeof(creal_T));
      }
      fft(den_data, den_size, gd1_data, gd1_size);
      c_size[0] = 1;
      c_size[1] = 16;
      std::copy(&itemp[0], &itemp[ii_data], &c_data[0]);
      if (niccp - 1 >= 0) {
        std::memset(&c_data[ii_data], 0,
                    static_cast<unsigned int>((niccp + ii_data) - ii_data) *
                        sizeof(creal_T));
      }
      fft(c_data, c_size, den_data, den_size);
      if (gd1_size[1] == den_size[1]) {
        loop_ub = gd1_size[1];
        z.set_size(1, gd1_size[1]);
        for (i = 0; i < loop_ub; i++) {
          double ai;
          double ar;
          ar = gd1_data[i].re;
          ai = gd1_data[i].im;
          y_im = den_data[i].re;
          b_re_tmp = den_data[i].im;
          if (b_re_tmp == 0.0) {
            if (ai == 0.0) {
              z[i].re = ar / y_im;
              z[i].im = 0.0;
            } else if (ar == 0.0) {
              z[i].re = 0.0;
              z[i].im = ai / y_im;
            } else {
              z[i].re = ar / y_im;
              z[i].im = ai / y_im;
            }
          } else if (y_im == 0.0) {
            if (ar == 0.0) {
              z[i].re = ai / b_re_tmp;
              z[i].im = 0.0;
            } else if (ai == 0.0) {
              z[i].re = 0.0;
              z[i].im = -(ar / b_re_tmp);
            } else {
              z[i].re = ai / b_re_tmp;
              z[i].im = -(ar / b_re_tmp);
            }
          } else {
            double brm;
            brm = std::abs(y_im);
            G = std::abs(b_re_tmp);
            if (brm > G) {
              y_re = b_re_tmp / y_im;
              G = y_im + y_re * b_re_tmp;
              z[i].re = (ar + y_re * ai) / G;
              z[i].im = (ai - y_re * ar) / G;
            } else if (G == brm) {
              if (y_im > 0.0) {
                y_re = 0.5;
              } else {
                y_re = -0.5;
              }
              if (b_re_tmp > 0.0) {
                G = 0.5;
              } else {
                G = -0.5;
              }
              z[i].re = (ar * y_re + ai * G) / brm;
              z[i].im = (ai * y_re - ar * G) / brm;
            } else {
              y_re = y_im / b_re_tmp;
              G = b_re_tmp + y_re * y_im;
              z[i].re = (y_re * ar + ai) / G;
              z[i].im = (y_re * ai - ar) / G;
            }
          }
        }
      } else {
        binary_expand_op_17(z, gd1_data, gd1_size, den_data, den_size);
      }
      for (i = 0; i < 8; i++) {
        gd1[i] = z[i].re - (static_cast<double>(j) - 1.0);
      }
    } else {
      niccp = static_cast<int>(std::ceil(static_cast<double>(ii_data) / 16.0))
              << 1;
      mmax = niccp << 3;
      fft(cr_data, cr_size, static_cast<double>(mmax), tmp_data, hh_size);
      gd1_size[0] = 1;
      loop_ub = hh_size[1];
      gd1_size[1] = hh_size[1];
      if (loop_ub - 1 >= 0) {
        std::copy(&tmp_data[0], &tmp_data[loop_ub], &gd1_data[0]);
      }
      cr_size[0] = 1;
      cr_size[1] = ii_data;
      std::copy(&itemp[0], &itemp[ii_data], &cr_data[0]);
      fft(cr_data, cr_size, static_cast<double>(mmax), tmp_data, hh_size);
      den_size[0] = 1;
      loop_ub = hh_size[1];
      den_size[1] = hh_size[1];
      if (loop_ub - 1 >= 0) {
        std::copy(&tmp_data[0], &tmp_data[loop_ub], &den_data[0]);
      }
      if (gd1_size[1] == hh_size[1]) {
        loop_ub = gd1_size[1] - 1;
        for (i = 0; i <= loop_ub; i++) {
          double ai;
          double ar;
          double re;
          ar = gd1_data[i].re;
          ai = gd1_data[i].im;
          y_im = den_data[i].re;
          b_re_tmp = den_data[i].im;
          if (b_re_tmp == 0.0) {
            if (ai == 0.0) {
              re = ar / y_im;
              G = 0.0;
            } else if (ar == 0.0) {
              re = 0.0;
              G = ai / y_im;
            } else {
              re = ar / y_im;
              G = ai / y_im;
            }
          } else if (y_im == 0.0) {
            if (ar == 0.0) {
              re = ai / b_re_tmp;
              G = 0.0;
            } else if (ai == 0.0) {
              re = 0.0;
              G = -(ar / b_re_tmp);
            } else {
              re = ai / b_re_tmp;
              G = -(ar / b_re_tmp);
            }
          } else {
            double brm;
            brm = std::abs(y_im);
            G = std::abs(b_re_tmp);
            if (brm > G) {
              y_re = b_re_tmp / y_im;
              G = y_im + y_re * b_re_tmp;
              re = (ar + y_re * ai) / G;
              G = (ai - y_re * ar) / G;
            } else if (G == brm) {
              if (y_im > 0.0) {
                y_re = 0.5;
              } else {
                y_re = -0.5;
              }
              if (b_re_tmp > 0.0) {
                G = 0.5;
              } else {
                G = -0.5;
              }
              re = (ar * y_re + ai * G) / brm;
              G = (ai * y_re - ar * G) / brm;
            } else {
              y_re = y_im / b_re_tmp;
              G = b_re_tmp + y_re * y_im;
              re = (y_re * ar + ai) / G;
              G = (y_re * ai - ar) / G;
            }
          }
          gd1_data[i].re = re;
          gd1_data[i].im = G;
        }
      } else {
        binary_expand_op_19(gd1_data, gd1_size, den_data, den_size);
      }
      loop_ub = (mmax - 1) / niccp;
      b_y.set_size(1, loop_ub + 1);
      for (i = 0; i <= loop_ub; i++) {
        b_y[i] = static_cast<double>(niccp * i) + 1.0;
      }
      if (b_y.size(1) == 8) {
        for (i = 0; i < 8; i++) {
          gd1[i] = gd1_data[static_cast<int>(b_y[i]) - 1].re -
                   (static_cast<double>(j) - 1.0);
        }
      } else {
        binary_expand_op_18(gd1, gd1_data, b_y, a_size);
      }
    }
    if (b_signal::internal::isfir(b, a_size)) {
      islinphaseflag = b_signal::internal::determineiflinphase(c_b, b_size);
    } else if (b_signal::internal::isstable(b, a_size)) {
      islinphaseflag = false;
    } else {
      islinphaseflag = (b_signal::internal::determineiflinphase(c_b, b_size) &&
                        b_signal::internal::determineiflinphase(b, a_size));
    }
    if (islinphaseflag) {
      eml_find(c_b, b_size, (int *)&ii_data, hh_size);
      b_k = hh_size[1];
      if (hh_size[1] - 1 >= 0) {
        naxpy = ii_data;
      }
      mmax = j;
      niccp = 0;
      hh_size[1] = 1;
      exitg1 = false;
      while ((!exitg1) && (mmax > 0)) {
        if ((b_b[mmax - 1].re != 0.0) || (b_b[mmax - 1].im != 0.0)) {
          niccp = 1;
          ii_data = mmax;
          exitg1 = true;
        } else {
          mmax--;
        }
      }
      if (niccp == 0) {
        hh_size[1] = 0;
      }
      if (hh_size[1] - 1 >= 0) {
        b_ii_data = static_cast<signed char>(ii_data);
      }
      for (k = 0; k < j; k++) {
        y_data[k] = rt_hypotd_snf(b_b[k].re, b_b[k].im);
      }
      b_y_data.set(&y_data[0], 1, j);
      if (coder::internal::maximum(b_y_data) == 0.0) {
        b_ii_data = 1;
      } else {
        if (naxpy > b_ii_data) {
          i = 1;
          mmax = 0;
        } else {
          i = naxpy;
          mmax = b_ii_data;
        }
        b_ii_data = static_cast<signed char>((mmax - i) + 1);
      }
      if (b_k == 0) {
        niccp = 0;
      } else {
        niccp =
            static_cast<int>(std::fmax(static_cast<double>(naxpy) - 1.0, 0.0));
      }
      G = static_cast<double>(niccp) +
          (static_cast<double>(b_ii_data) - 1.0) / 2.0;
      for (i = 0; i < 8; i++) {
        gd1[i] = G;
      }
    }
    niccp = static_cast<int>(std::ceil(static_cast<double>(idata.size(1)) / r));
    G = std::round(gd1[0] + 1.25);
    mmax = div_s32(idata.size(1) - static_cast<int>(G), static_cast<int>(r));
    y.set_size(
        1, static_cast<int>(std::ceil(static_cast<double>(idata.size(1)) / r)));
    for (ii_data = 0; ii_data <= mmax; ii_data++) {
      y[ii_data] =
          b_y1[(static_cast<int>(G) + ii_data * static_cast<int>(r)) - 1];
    }
    k = ((static_cast<int>(r) - idata.size(1)) + static_cast<int>(G)) +
        mmax * static_cast<int>(r);
    i = mmax + 2;
    for (ii_data = i; ii_data <= niccp; ii_data++) {
      y[ii_data - 1] =
          c_y1[(k + ((ii_data - mmax) - 2) * static_cast<int>(r)) - 1];
    }
  }
}

void decimate(const ::coder::array<double, 1U> &idata, double r,
              ::coder::array<double, 1U> &y)
{
  ::coder::array<creal_T, 2U> z;
  ::coder::array<double, 2U> b_b_data;
  ::coder::array<double, 2U> b_y;
  ::coder::array<double, 2U> c_a_data;
  ::coder::array<double, 1U> odata;
  creal_T den_data[77];
  creal_T gd1_data[77];
  creal_T tmp_data[64];
  double b_cr_data[77];
  double c_data[62];
  double cr_data[62];
  double itemp[62];
  double b[31];
  double b_a_data[31];
  double b_data[31];
  double hh_data[31];
  double zf[30];
  double zi[30];
  double a_data[16];
  double gd1[8];
  int a_size[2];
  int b_cr_size[2];
  int b_size[2];
  int c_size[2];
  int cr_size[2];
  int den_size[2];
  int gd1_size[2];
  if (r == 1.0) {
    int naxpy;
    naxpy = idata.size(0);
    y.set_size(idata.size(0));
    for (int i{0}; i < naxpy; i++) {
      y[i] = idata[i];
    }
  } else {
    __m128d b_r;
    __m128d r1;
    double b_dv[4];
    double G;
    double s;
    int hh_size[2];
    int i;
    int k;
    int mmax;
    int n;
    int naxpy;
    int niccp;
    int startidx_data;
    int vectorUB;
    signed char ii_data;
    boolean_T exitg1;
    boolean_T islinphaseflag;
    G = 1.0 / r;
    b_dv[0] = 0.0;
    b_dv[1] = G;
    b_dv[2] = G;
    b_dv[3] = 1.0;
    eFirls(b_dv, hh_data, hh_size, a_data);
    for (i = 0; i <= 28; i += 2) {
      b_r = _mm_loadu_pd(&hh_data[i]);
      _mm_storeu_pd(&b[i], _mm_mul_pd(b_r, _mm_loadu_pd(&dv1[i])));
    }
    b[30] = hh_data[30] * dv1[30];
    G = b[0];
    for (k = 0; k < 30; k++) {
      G += b[k + 1];
    }
    s = 2.0 * idata[0];
    for (i = 0; i < 31; i++) {
      b[i] /= G;
      hh_data[i] = s - idata[31 - i];
    }
    std::memset(&zi[0], 0, 30U * sizeof(double));
    i = idata.size(0);
    odata.set_size(idata.size(0));
    for (k = 0; k < 30; k++) {
      startidx_data = ((k + 1) / 2) << 1;
      vectorUB = startidx_data - 2;
      for (int j{0}; j <= vectorUB; j += 2) {
        b_r = _mm_loadu_pd(&b[(j - k) + 30]);
        r1 = _mm_loadu_pd(&zi[j]);
        _mm_storeu_pd(
            &zi[j],
            _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(hh_data[k + 1]), b_r)));
      }
      for (int j{startidx_data}; j <= k; j++) {
        zi[j] += hh_data[k + 1] * b[(j - k) + 30];
      }
      zf[k] = 0.0;
    }
    if (idata.size(0) < 30) {
      niccp = idata.size(0) - 1;
    } else {
      niccp = 29;
    }
    for (k = 0; k <= niccp; k++) {
      odata[k] = zi[k];
    }
    n = niccp + 2;
    for (k = n; k <= i; k++) {
      odata[k - 1] = 0.0;
    }
    if (idata.size(0) >= 62) {
      for (k = 0; k < 31; k++) {
        niccp = k + 1;
        startidx_data = ((((i - k) / 2) << 1) + k) + 1;
        vectorUB = startidx_data - 2;
        for (int j{niccp}; j <= vectorUB; j += 2) {
          b_r = _mm_loadu_pd(&odata[j - 1]);
          _mm_storeu_pd(
              &odata[j - 1],
              _mm_add_pd(b_r, _mm_mul_pd(_mm_set1_pd(b[k]),
                                         _mm_loadu_pd(&idata[(j - k) - 1]))));
        }
        for (int j{startidx_data}; j <= i; j++) {
          odata[j - 1] = odata[j - 1] + b[k] * idata[(j - k) - 1];
        }
      }
    } else {
      if (idata.size(0) > 31) {
        niccp = idata.size(0) - 32;
      } else {
        niccp = -1;
      }
      for (k = 0; k <= niccp; k++) {
        for (int j{0}; j <= 28; j += 2) {
          b_r = _mm_loadu_pd(&b[j]);
          n = k + j;
          r1 = _mm_loadu_pd(&odata[n]);
          _mm_storeu_pd(&odata[n],
                        _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(idata[k]), b_r)));
        }
        odata[k + 30] = odata[k + 30] + idata[k] * b[30];
      }
      naxpy = idata.size(0) - niccp;
      n = niccp + 2;
      for (k = n; k <= i; k++) {
        for (int j{0}; j <= naxpy - 2; j++) {
          niccp = (k + j) - 1;
          odata[niccp] = odata[niccp] + idata[k - 1] * b[j];
        }
        naxpy--;
      }
    }
    if (idata.size(0) < 30) {
      n = 29 - idata.size(0);
      for (k = 0; k <= n; k++) {
        zf[k] = zi[k + i];
      }
    }
    if (idata.size(0) >= 31) {
      niccp = idata.size(0) - 30;
    } else {
      niccp = 0;
    }
    n = idata.size(0) - 1;
    for (k = niccp; k <= n; k++) {
      mmax = i - k;
      naxpy = 30 - mmax;
      startidx_data = ((31 - mmax) / 2) << 1;
      vectorUB = startidx_data - 2;
      for (int j{0}; j <= vectorUB; j += 2) {
        b_r = _mm_loadu_pd(&b[mmax + j]);
        r1 = _mm_loadu_pd(&zf[j]);
        _mm_storeu_pd(&zf[j],
                      _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(idata[k]), b_r)));
      }
      for (int j{startidx_data}; j <= naxpy; j++) {
        zf[j] += idata[k] * b[mmax + j];
      }
    }
    s = 2.0 * idata[idata.size(0) - 1];
    for (i = 0; i < 62; i++) {
      c_data[i] = s - idata[(idata.size(0) - i) - 2];
    }
    std::copy(&zf[0], &zf[30], &itemp[0]);
    std::memset(&itemp[30], 0, 32U * sizeof(double));
    for (k = 0; k < 31; k++) {
      niccp = k + 1;
      startidx_data = ((((62 - k) / 2) << 1) + k) + 1;
      vectorUB = startidx_data - 2;
      for (int j{niccp}; j <= vectorUB; j += 2) {
        b_r = _mm_loadu_pd(&c_data[(j - k) - 1]);
        r1 = _mm_loadu_pd(&itemp[j - 1]);
        _mm_storeu_pd(&itemp[j - 1],
                      _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(b[k]), b_r)));
      }
      for (int j{startidx_data}; j < 63; j++) {
        itemp[j - 1] += b[k] * c_data[(j - k) - 1];
      }
    }
    niccp = 0;
    mmax = 31;
    exitg1 = false;
    while ((!exitg1) && (mmax > 0)) {
      if (b[mmax - 1] != 0.0) {
        niccp = 1;
        ii_data = static_cast<signed char>(mmax);
        exitg1 = true;
      } else {
        mmax--;
      }
    }
    if (niccp == 0) {
      n = 1;
    } else {
      n = ii_data;
    }
    a_size[0] = 1;
    a_size[1] = n;
    b_size[0] = 1;
    b_size[1] = n;
    for (i = 0; i < n; i++) {
      hh_data[i] = iv1[i];
      b_data[i] = b[i];
    }
    naxpy = n - 1;
    for (i = 0; i <= naxpy; i++) {
      b_a_data[i] = hh_data[(n - i) - 1];
    }
    b_b_data.set(&b_data[0], 1, n);
    c_a_data.set(&b_a_data[0], 1, n);
    conv(b_b_data, c_a_data, b_y);
    c_size[0] = 1;
    naxpy = b_y.size(1);
    c_size[1] = b_y.size(1);
    for (i = 0; i < naxpy; i++) {
      c_data[i] = b_y[i];
    }
    if (c_size[1] - 1 < 0) {
      b_y.set_size(1, 0);
    } else {
      b_y.set_size(1, naxpy);
      niccp = c_size[1] - 1;
      for (i = 0; i <= niccp; i++) {
        b_y[i] = i;
      }
    }
    if (c_size[1] == b_y.size(1)) {
      cr_size[0] = 1;
      cr_size[1] = naxpy;
      startidx_data = (c_size[1] / 2) << 1;
      vectorUB = startidx_data - 2;
      for (i = 0; i <= vectorUB; i += 2) {
        b_r = _mm_loadu_pd(&c_data[i]);
        r1 = _mm_loadu_pd(&b_y[i]);
        _mm_storeu_pd(&cr_data[i], _mm_mul_pd(b_r, r1));
      }
      for (i = startidx_data; i < naxpy; i++) {
        cr_data[i] = c_data[i] * b_y[i];
      }
    } else {
      binary_expand_op_51(cr_data, cr_size, c_data, c_size, b_y);
    }
    if (c_size[1] <= 16) {
      b_cr_size[0] = 1;
      b_cr_size[1] = (cr_size[1] - c_size[1]) + 16;
      naxpy = cr_size[1];
      if (naxpy - 1 >= 0) {
        std::copy(&cr_data[0], &cr_data[naxpy], &b_cr_data[0]);
      }
      niccp = 16 - c_size[1];
      if (niccp - 1 >= 0) {
        std::memset(
            &b_cr_data[cr_size[1]], 0,
            static_cast<unsigned int>((niccp + cr_size[1]) - cr_size[1]) *
                sizeof(double));
      }
      fft(b_cr_data, b_cr_size, gd1_data, gd1_size);
      b_cr_size[0] = 1;
      b_cr_size[1] = 16;
      naxpy = c_size[1];
      if (naxpy - 1 >= 0) {
        std::copy(&c_data[0], &c_data[naxpy], &b_cr_data[0]);
      }
      if (niccp - 1 >= 0) {
        std::memset(&b_cr_data[c_size[1]], 0,
                    static_cast<unsigned int>((niccp + c_size[1]) - c_size[1]) *
                        sizeof(double));
      }
      fft(b_cr_data, b_cr_size, den_data, den_size);
      if (gd1_size[1] == den_size[1]) {
        naxpy = gd1_size[1];
        z.set_size(1, gd1_size[1]);
        for (i = 0; i < naxpy; i++) {
          double ai;
          double ar;
          double bi;
          double br;
          ar = gd1_data[i].re;
          ai = gd1_data[i].im;
          br = den_data[i].re;
          bi = den_data[i].im;
          if (bi == 0.0) {
            if (ai == 0.0) {
              z[i].re = ar / br;
              z[i].im = 0.0;
            } else if (ar == 0.0) {
              z[i].re = 0.0;
              z[i].im = ai / br;
            } else {
              z[i].re = ar / br;
              z[i].im = ai / br;
            }
          } else if (br == 0.0) {
            if (ar == 0.0) {
              z[i].re = ai / bi;
              z[i].im = 0.0;
            } else if (ai == 0.0) {
              z[i].re = 0.0;
              z[i].im = -(ar / bi);
            } else {
              z[i].re = ai / bi;
              z[i].im = -(ar / bi);
            }
          } else {
            double brm;
            brm = std::abs(br);
            G = std::abs(bi);
            if (brm > G) {
              s = bi / br;
              G = br + s * bi;
              z[i].re = (ar + s * ai) / G;
              z[i].im = (ai - s * ar) / G;
            } else if (G == brm) {
              if (br > 0.0) {
                s = 0.5;
              } else {
                s = -0.5;
              }
              if (bi > 0.0) {
                G = 0.5;
              } else {
                G = -0.5;
              }
              z[i].re = (ar * s + ai * G) / brm;
              z[i].im = (ai * s - ar * G) / brm;
            } else {
              s = br / bi;
              G = bi + s * br;
              z[i].re = (s * ar + ai) / G;
              z[i].im = (s * ai - ar) / G;
            }
          }
        }
      } else {
        binary_expand_op_17(z, gd1_data, gd1_size, den_data, den_size);
      }
      for (i = 0; i < 8; i++) {
        gd1[i] = z[i].re - (static_cast<double>(n) - 1.0);
      }
    } else {
      niccp = static_cast<int>(std::ceil(static_cast<double>(c_size[1]) / 16.0))
              << 1;
      mmax = niccp << 3;
      fft(cr_data, cr_size, static_cast<double>(mmax), tmp_data, hh_size);
      gd1_size[0] = 1;
      naxpy = hh_size[1];
      gd1_size[1] = hh_size[1];
      if (naxpy - 1 >= 0) {
        std::copy(&tmp_data[0], &tmp_data[naxpy], &gd1_data[0]);
      }
      cr_size[0] = 1;
      naxpy = c_size[1];
      cr_size[1] = c_size[1];
      std::copy(&c_data[0], &c_data[naxpy], &cr_data[0]);
      fft(cr_data, cr_size, static_cast<double>(mmax), tmp_data, hh_size);
      den_size[0] = 1;
      naxpy = hh_size[1];
      den_size[1] = hh_size[1];
      if (naxpy - 1 >= 0) {
        std::copy(&tmp_data[0], &tmp_data[naxpy], &den_data[0]);
      }
      if (gd1_size[1] == hh_size[1]) {
        naxpy = gd1_size[1] - 1;
        for (i = 0; i <= naxpy; i++) {
          double ai;
          double ar;
          double bi;
          double br;
          double re;
          ar = gd1_data[i].re;
          ai = gd1_data[i].im;
          br = den_data[i].re;
          bi = den_data[i].im;
          if (bi == 0.0) {
            if (ai == 0.0) {
              re = ar / br;
              G = 0.0;
            } else if (ar == 0.0) {
              re = 0.0;
              G = ai / br;
            } else {
              re = ar / br;
              G = ai / br;
            }
          } else if (br == 0.0) {
            if (ar == 0.0) {
              re = ai / bi;
              G = 0.0;
            } else if (ai == 0.0) {
              re = 0.0;
              G = -(ar / bi);
            } else {
              re = ai / bi;
              G = -(ar / bi);
            }
          } else {
            double brm;
            brm = std::abs(br);
            G = std::abs(bi);
            if (brm > G) {
              s = bi / br;
              G = br + s * bi;
              re = (ar + s * ai) / G;
              G = (ai - s * ar) / G;
            } else if (G == brm) {
              if (br > 0.0) {
                s = 0.5;
              } else {
                s = -0.5;
              }
              if (bi > 0.0) {
                G = 0.5;
              } else {
                G = -0.5;
              }
              re = (ar * s + ai * G) / brm;
              G = (ai * s - ar * G) / brm;
            } else {
              s = br / bi;
              G = bi + s * br;
              re = (s * ar + ai) / G;
              G = (s * ai - ar) / G;
            }
          }
          gd1_data[i].re = re;
          gd1_data[i].im = G;
        }
      } else {
        binary_expand_op_19(gd1_data, gd1_size, den_data, den_size);
      }
      naxpy = (mmax - 1) / niccp;
      b_y.set_size(1, naxpy + 1);
      for (i = 0; i <= naxpy; i++) {
        b_y[i] = niccp * i + 1;
      }
      if (b_y.size(1) == 8) {
        for (i = 0; i < 8; i++) {
          gd1[i] = gd1_data[static_cast<int>(b_y[i]) - 1].re -
                   (static_cast<double>(n) - 1.0);
        }
      } else {
        binary_expand_op_18(gd1, gd1_data, b_y, a_size);
      }
    }
    if (b_signal::internal::isfir(hh_data, a_size)) {
      islinphaseflag = b_signal::internal::determineiflinphase(b_data, b_size);
    } else if (b_signal::internal::isstable(hh_data, a_size)) {
      islinphaseflag = false;
    } else {
      islinphaseflag =
          (b_signal::internal::determineiflinphase(b_data, b_size) &&
           b_signal::internal::determineiflinphase(hh_data, a_size));
    }
    if (islinphaseflag) {
      eml_find(b_data, b_size, (int *)&naxpy, hh_size);
      vectorUB = hh_size[1];
      if (hh_size[1] - 1 >= 0) {
        startidx_data = naxpy;
      }
      mmax = n;
      niccp = 0;
      hh_size[1] = 1;
      exitg1 = false;
      while ((!exitg1) && (mmax > 0)) {
        if (b[mmax - 1] != 0.0) {
          niccp = 1;
          naxpy = mmax;
          exitg1 = true;
        } else {
          mmax--;
        }
      }
      if (niccp == 0) {
        hh_size[1] = 0;
      }
      if (hh_size[1] - 1 >= 0) {
        ii_data = static_cast<signed char>(naxpy);
      }
      b_y.set_size(1, n);
      for (k = 0; k < n; k++) {
        b_y[k] = std::abs(b[k]);
      }
      if (coder::internal::maximum(b_y) == 0.0) {
        ii_data = 1;
      } else {
        if (startidx_data > ii_data) {
          i = 1;
          n = 0;
        } else {
          i = startidx_data;
          n = ii_data;
        }
        ii_data = static_cast<signed char>((n - i) + 1);
      }
      if (vectorUB == 0) {
        niccp = 0;
      } else {
        niccp = static_cast<int>(
            std::fmax(static_cast<double>(startidx_data) - 1.0, 0.0));
      }
      G = static_cast<double>(niccp) +
          (static_cast<double>(ii_data) - 1.0) / 2.0;
      for (i = 0; i < 8; i++) {
        gd1[i] = G;
      }
    }
    niccp = static_cast<int>(std::ceil(static_cast<double>(idata.size(0)) / r));
    G = std::round(gd1[0] + 1.25);
    mmax = div_s32(idata.size(0) - static_cast<int>(G), static_cast<int>(r));
    y.set_size(
        static_cast<int>(std::ceil(static_cast<double>(idata.size(0)) / r)));
    for (naxpy = 0; naxpy <= mmax; naxpy++) {
      y[naxpy] = odata[(static_cast<int>(G) + naxpy * static_cast<int>(r)) - 1];
    }
    k = ((static_cast<int>(r) - idata.size(0)) + static_cast<int>(G)) +
        mmax * static_cast<int>(r);
    i = mmax + 2;
    for (naxpy = i; naxpy <= niccp; naxpy++) {
      y[naxpy - 1] =
          itemp[(k + ((naxpy - mmax) - 2) * static_cast<int>(r)) - 1];
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (decimate.cpp)
