//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// correctdpv.cpp
//
// Code generation for function 'correctdpv'
//

// Include files
#include "correctdpv.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
void binary_expand_op(coder::array<double, 1U> &in1,
                      const coder::array<double, 2U> &in2, int in3)
{
  coder::array<double, 1U> b_in2;
  int loop_ub;
  int stride_0_0;
  loop_ub = in2.size(0);
  b_in2.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in2[i] = in2[i + in2.size(0) * in3] + 20.0 * in1[i * stride_0_0];
  }
  in1.set_size(loop_ub);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in2[i];
  }
}

// End of code generation (correctdpv.cpp)
