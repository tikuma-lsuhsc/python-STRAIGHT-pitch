//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// refineF06.h
//
// Code generation for function 'refineF06'
//

#ifndef REFINEF06_H
#define REFINEF06_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void refineF06(const coder::array<double, 1U> &x, double fs,
               const coder::array<double, 2U> &f0raw, double fftl, double eta,
               double nhmx, double shiftm, double nu,
               coder::array<double, 2U> &f0r, coder::array<double, 2U> &ecr);

#endif
// End of code generation (refineF06.h)
