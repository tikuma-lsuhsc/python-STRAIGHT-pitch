//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cat.h
//
// Code generation for function 'cat'
//

#ifndef CAT_H
#define CAT_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_75(double in1[2], const coder::array<double, 2U> &in2,
                         const coder::array<double, 2U> &in3,
                         const coder::array<double, 2U> &in4,
                         const coder::array<double, 2U> &in5,
                         const coder::array<double, 2U> &in6);

void binary_expand_op_76(double in1[2], const coder::array<double, 2U> &in2,
                         const coder::array<double, 2U> &in3,
                         const coder::array<double, 2U> &in4,
                         const coder::array<double, 2U> &in5,
                         const coder::array<double, 2U> &in6);

#endif
// End of code generation (cat.h)
