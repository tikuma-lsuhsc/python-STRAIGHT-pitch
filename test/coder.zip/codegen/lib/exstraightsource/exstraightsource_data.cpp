//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// exstraightsource_data.cpp
//
// Code generation for function 'exstraightsource_data'
//

// Include files
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
unsigned int state[625];

omp_nest_lock_t exstraightsource_nestLockGlobal;

boolean_T isInitialized_exstraightsource{false};

// End of code generation (exstraightsource_data.cpp)
