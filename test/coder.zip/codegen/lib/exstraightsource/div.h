//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// div.h
//
// Code generation for function 'div'
//

#ifndef DIV_H
#define DIV_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op_17(coder::array<creal_T, 2U> &in1,
                         const creal_T in2_data[], const int in2_size[2],
                         const creal_T in3_data[], const int in3_size[2]);

void binary_expand_op_2(coder::array<double, 1U> &in1,
                        const coder::array<double, 2U> &in2, double in3,
                        int in4, const coder::array<double, 2U> &in5);

void binary_expand_op_31(coder::array<creal_T, 2U> &in1,
                         const coder::array<double, 2U> &in2);

void binary_expand_op_9(coder::array<double, 2U> &in1,
                        const coder::array<double, 2U> &in2);

void rdivide(coder::array<creal_T, 2U> &in1,
             const coder::array<creal_T, 2U> &in2,
             const coder::array<creal_T, 2U> &in3);

void rdivide(coder::array<creal_T, 2U> &in1,
             const coder::array<creal_T, 2U> &in2);

#endif
// End of code generation (div.h)
