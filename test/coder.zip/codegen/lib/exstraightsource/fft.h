//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fft.h
//
// Code generation for function 'fft'
//

#ifndef FFT_H
#define FFT_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace legacy_STRAIGHT {
void fft(const creal_T x_data[], const int x_size[2], double varargin_1,
         creal_T y_data[], int y_size[2]);

void fft(const creal_T x_data[], const int x_size[2], creal_T y_data[],
         int y_size[2]);

void fft(const double x_data[], const int x_size[2], double varargin_1,
         creal_T y_data[], int y_size[2]);

void fft(const double x_data[], const int x_size[2], creal_T y_data[],
         int y_size[2]);

void fft(const ::coder::array<creal_T, 2U> &x, double varargin_1,
         ::coder::array<creal_T, 2U> &y);

void fft(const ::coder::array<double, 2U> &x, double varargin_1,
         ::coder::array<creal_T, 2U> &y);

void fft(const ::coder::array<creal_T, 2U> &x, ::coder::array<creal_T, 2U> &y);

void fft(const ::coder::array<double, 2U> &x, ::coder::array<creal_T, 2U> &y);

void fft(const ::coder::array<double, 1U> &x, double varargin_1,
         ::coder::array<creal_T, 1U> &y);

} // namespace legacy_STRAIGHT

#endif
// End of code generation (fft.h)
