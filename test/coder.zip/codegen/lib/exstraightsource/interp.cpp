//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// interp.cpp
//
// Code generation for function 'interp'
//

// Include files
#include "interp.h"
#include "exstraightsource_rtwutil.h"
#include "firls.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Definitions
namespace legacy_STRAIGHT {
void interp(const ::coder::array<double, 2U> &idata, double r,
            ::coder::array<double, 2U> &odata)
{
  __m128d r1;
  __m128d r2;
  ::coder::array<double, 2U> F;
  ::coder::array<double, 2U> M;
  ::coder::array<double, 2U> b_r;
  ::coder::array<double, 1U> a;
  ::coder::array<double, 1U> b;
  ::coder::array<double, 1U> od;
  ::coder::array<double, 1U> yCol;
  ::coder::array<double, 1U> zf;
  ::coder::array<double, 1U> zi;
  double Nband;
  double RL;
  double RN;
  double a2r;
  int b_loop_ub;
  int b_loop_ub_tmp;
  int boffset;
  int i;
  int i1;
  int i2;
  unsigned int k;
  int lb;
  int lb_tmp;
  int loop_ub;
  int loop_ub_tmp;
  int naxpy;
  int niccp;
  int scalarLB;
  int vectorUB;
  signed char zicase;
  RL = r * static_cast<double>(idata.size(1));
  RN = r * 4.0;
  Nband = std::floor(0.5 * r);
  niccp = static_cast<int>(2.0 * Nband);
  M.set_size(1, niccp + 2);
  M[0] = r;
  M[1] = r;
  for (i = 0; i < niccp; i++) {
    M[i + 2] = 0.0;
  }
  a2r = 0.25 / r;
  Nband = 2.0 * Nband + 2.0;
  loop_ub_tmp = static_cast<int>(Nband);
  F.set_size(1, loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    F[i] = 0.0;
  }
  F[1] = a2r;
  k = 0U;
  i = static_cast<int>((Nband - 1.0) / 2.0);
  for (niccp = 0; niccp < i; niccp++) {
    double F_tmp;
    double b_i;
    b_i = static_cast<double>(niccp) * 2.0 + 3.0;
    k++;
    F_tmp = static_cast<double>(k) / r;
    F[static_cast<int>(b_i) - 1] = F_tmp - a2r;
    F[static_cast<int>(static_cast<unsigned int>(b_i))] = F_tmp + a2r;
  }
  if (F[static_cast<int>(Nband) - 1] > 0.5) {
    F[static_cast<int>(Nband) - 1] = 0.5;
  }
  b_r.set_size(1, loop_ub_tmp);
  scalarLB = (F.size(1) / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    r1 = _mm_loadu_pd(&F[i]);
    _mm_storeu_pd(&b_r[i], _mm_mul_pd(_mm_set1_pd(2.0), r1));
  }
  for (i = scalarLB; i < loop_ub_tmp; i++) {
    b_r[i] = 2.0 * F[i];
  }
  eFirls(2.0 * r * 4.0, b_r, M, F, a);
  loop_ub = F.size(1);
  b.set_size(F.size(1));
  for (i = 0; i < loop_ub; i++) {
    b[i] = F[i];
  }
  loop_ub_tmp = static_cast<int>(RL);
  yCol.set_size(loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    yCol[i] = 0.0;
  }
  b_loop_ub = div_s32(static_cast<int>(RL) - 1, static_cast<int>(r)) + 1;
  for (i = 0; i < b_loop_ub; i++) {
    yCol[static_cast<int>(r) * i] = idata[i];
  }
  b_loop_ub = static_cast<int>(2.0 * RN);
  od.set_size(b_loop_ub);
  for (i = 0; i < b_loop_ub; i++) {
    od[i] = 0.0;
  }
  Nband = 2.0 * idata[0];
  niccp = b_loop_ub - 1;
  b_loop_ub_tmp = div_s32(b_loop_ub - 1, static_cast<int>(r)) + 1;
  for (i = 0; i < b_loop_ub_tmp; i++) {
    od[static_cast<int>(r) * i] = Nband - idata[8 - i];
  }
  i = b.size(0) - 1;
  zi.set_size(b.size(0) - 1);
  for (i1 = 0; i1 <= loop_ub - 2; i1++) {
    zi[i1] = 0.0;
  }
  lb_tmp = od.size(0) - b.size(0);
  if (od.size(0) >= b.size(0)) {
    lb = lb_tmp + 1;
  } else {
    lb = 0;
  }
  for (int b_k{lb}; b_k <= niccp; b_k++) {
    boffset = b_loop_ub - b_k;
    naxpy = ((b.size(0) - b_loop_ub) + b_k) + 1;
    scalarLB = ((naxpy - 1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int j{0}; j <= vectorUB; j += 2) {
      r1 = _mm_loadu_pd(&b[boffset + j]);
      r2 = _mm_loadu_pd(&zi[j]);
      _mm_storeu_pd(&zi[j],
                    _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(od[b_k]), r1)));
    }
    for (int j{scalarLB}; j <= naxpy - 2; j++) {
      zi[j] = zi[j] + od[b_k] * b[boffset + j];
    }
  }
  if (zi.size(0) == b.size(0) - 1) {
    zicase = 1;
  } else {
    zicase = 2;
  }
  a.set_size(loop_ub_tmp);
  zf.set_size(b.size(0) - 1);
  for (i1 = 0; i1 <= loop_ub - 2; i1++) {
    zf[i1] = 0.0;
  }
  if (yCol.size(0) < b.size(0) - 1) {
    niccp = yCol.size(0) + 1;
  } else {
    niccp = b.size(0);
  }
  if (zicase == 2) {
    for (int b_k{0}; b_k <= niccp - 2; b_k++) {
      a[b_k] = zi[b_k];
    }
    for (int b_k{niccp}; b_k <= loop_ub_tmp; b_k++) {
      a[b_k - 1] = 0.0;
    }
  } else {
    for (int b_k{0}; b_k <= niccp - 2; b_k++) {
      a[b_k] = zi[b_k];
    }
    for (int b_k{niccp}; b_k <= loop_ub_tmp; b_k++) {
      a[b_k - 1] = 0.0;
    }
  }
  i1 = b.size(0) << 1;
  if (yCol.size(0) >= i1) {
    for (int b_k{0}; b_k <= i; b_k++) {
      niccp = b_k + 1;
      scalarLB = ((((static_cast<int>(RL) - b_k) / 2) << 1) + b_k) + 1;
      vectorUB = scalarLB - 2;
      for (int j{niccp}; j <= vectorUB; j += 2) {
        r1 = _mm_loadu_pd(&yCol[(j - b_k) - 1]);
        r2 = _mm_loadu_pd(&a[j - 1]);
        _mm_storeu_pd(&a[j - 1],
                      _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(b[b_k]), r1)));
      }
      for (int j{scalarLB}; j <= loop_ub_tmp; j++) {
        a[j - 1] = a[j - 1] + b[b_k] * yCol[(j - b_k) - 1];
      }
    }
  } else {
    if (yCol.size(0) > b.size(0)) {
      lb = yCol.size(0) - b.size(0);
    } else {
      lb = 0;
    }
    for (int b_k{0}; b_k < lb; b_k++) {
      scalarLB = ((i + 1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (int j{0}; j <= vectorUB; j += 2) {
        r1 = _mm_loadu_pd(&b[j]);
        i2 = b_k + j;
        r2 = _mm_loadu_pd(&a[i2]);
        _mm_storeu_pd(&a[i2],
                      _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(yCol[b_k]), r1)));
      }
      for (int j{scalarLB}; j <= i; j++) {
        niccp = b_k + j;
        a[niccp] = a[niccp] + yCol[b_k] * b[j];
      }
    }
    naxpy = yCol.size(0) - lb;
    i2 = lb + 1;
    for (int b_k{i2}; b_k <= loop_ub_tmp; b_k++) {
      for (int j{0}; j < naxpy; j++) {
        niccp = (b_k + j) - 1;
        a[niccp] = a[niccp] + yCol[b_k - 1] * b[j];
      }
      naxpy--;
    }
  }
  if (yCol.size(0) < b.size(0) - 1) {
    niccp = (b.size(0) - yCol.size(0)) - 2;
    if (zicase == 2) {
      for (int b_k{0}; b_k <= niccp; b_k++) {
        zf[b_k] = zi[b_k + static_cast<int>(RL)];
      }
    } else {
      for (int b_k{0}; b_k <= niccp; b_k++) {
        zf[b_k] = zi[b_k + static_cast<int>(RL)];
      }
    }
  }
  if (yCol.size(0) >= b.size(0)) {
    lb = (yCol.size(0) - b.size(0)) + 1;
  } else {
    lb = 0;
  }
  i2 = yCol.size(0) - 1;
  for (int b_k{lb}; b_k <= i2; b_k++) {
    boffset = static_cast<int>(RL) - b_k;
    naxpy = (i - static_cast<int>(RL)) + b_k;
    scalarLB = ((naxpy + 1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int j{0}; j <= vectorUB; j += 2) {
      r1 = _mm_loadu_pd(&b[boffset + j]);
      r2 = _mm_loadu_pd(&zf[j]);
      _mm_storeu_pd(&zf[j],
                    _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(yCol[b_k]), r1)));
    }
    for (int j{scalarLB}; j <= naxpy; j++) {
      zf[j] = zf[j] + yCol[b_k] * b[boffset + j];
    }
  }
  loop_ub = a.size(0);
  yCol.set_size(a.size(0));
  for (i2 = 0; i2 < loop_ub; i2++) {
    yCol[i2] = a[i2];
  }
  if (RN + 1.0 > RL) {
    i2 = 1;
  } else {
    i2 = static_cast<int>(RN + 1.0);
  }
  loop_ub = static_cast<int>((static_cast<double>(idata.size(1)) - 4.0) * r);
  for (niccp = 0; niccp < loop_ub; niccp++) {
    yCol[niccp] = a[(i2 + niccp) - 1];
  }
  od.set_size(b_loop_ub);
  for (i2 = 0; i2 < b_loop_ub; i2++) {
    od[i2] = 0.0;
  }
  Nband = 2.0 * idata[idata.size(1) - 1];
  for (i2 = 0; i2 < b_loop_ub_tmp; i2++) {
    od[static_cast<int>(r) * i2] = Nband - idata[(idata.size(1) - i2) - 2];
  }
  a.set_size(b_loop_ub);
  for (i2 = 0; i2 < b_loop_ub; i2++) {
    a[i2] = od[i2];
  }
  k = static_cast<unsigned int>(od.size(0));
  od.set_size(static_cast<int>(k));
  if (a.size(0) < b.size(0) - 1) {
    niccp = a.size(0) + 1;
  } else {
    niccp = b.size(0);
  }
  if (zf.size(0) == b.size(0) - 1) {
    i2 = 1;
  } else {
    i2 = 2;
  }
  if (i2 == 2) {
    for (int b_k{0}; b_k <= niccp - 2; b_k++) {
      od[b_k] = zf[b_k];
    }
    for (int b_k{niccp}; b_k <= b_loop_ub; b_k++) {
      od[b_k - 1] = 0.0;
    }
  } else {
    for (int b_k{0}; b_k <= niccp - 2; b_k++) {
      od[b_k] = zf[b_k];
    }
    for (int b_k{niccp}; b_k <= b_loop_ub; b_k++) {
      od[b_k - 1] = 0.0;
    }
  }
  if (a.size(0) >= i1) {
    for (int b_k{0}; b_k <= i; b_k++) {
      niccp = b_k + 1;
      scalarLB = ((((b_loop_ub - b_k) / 2) << 1) + b_k) + 1;
      vectorUB = scalarLB - 2;
      for (int j{niccp}; j <= vectorUB; j += 2) {
        r1 = _mm_loadu_pd(&a[(j - b_k) - 1]);
        r2 = _mm_loadu_pd(&od[j - 1]);
        _mm_storeu_pd(&od[j - 1],
                      _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(b[b_k]), r1)));
      }
      for (int j{scalarLB}; j <= b_loop_ub; j++) {
        od[j - 1] = od[j - 1] + b[b_k] * a[(j - b_k) - 1];
      }
    }
  } else {
    if (a.size(0) > b.size(0)) {
      lb = lb_tmp;
    } else {
      lb = 0;
    }
    for (int b_k{0}; b_k < lb; b_k++) {
      scalarLB = ((i + 1) / 2) << 1;
      vectorUB = scalarLB - 2;
      for (int j{0}; j <= vectorUB; j += 2) {
        r1 = _mm_loadu_pd(&b[j]);
        i1 = b_k + j;
        r2 = _mm_loadu_pd(&od[i1]);
        _mm_storeu_pd(&od[i1],
                      _mm_add_pd(r2, _mm_mul_pd(_mm_set1_pd(a[b_k]), r1)));
      }
      for (int j{scalarLB}; j <= i; j++) {
        niccp = b_k + j;
        od[niccp] = od[niccp] + a[b_k] * b[j];
      }
    }
    naxpy = a.size(0) - lb;
    i = lb + 1;
    for (int b_k{i}; b_k <= b_loop_ub; b_k++) {
      for (int j{0}; j < naxpy; j++) {
        niccp = (b_k + j) - 1;
        od[niccp] = od[niccp] + a[b_k - 1] * b[j];
      }
      naxpy--;
    }
  }
  Nband = (RL - RN) + 1.0;
  if (Nband > RL) {
    i = 0;
    i1 = 0;
  } else {
    i = static_cast<int>(Nband) - 1;
    i1 = static_cast<int>(RL);
  }
  loop_ub = i1 - i;
  for (i1 = 0; i1 < loop_ub; i1++) {
    yCol[i + i1] = od[i1];
  }
  odata.set_size(1, loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    odata[i] = yCol[i];
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (interp.cpp)
