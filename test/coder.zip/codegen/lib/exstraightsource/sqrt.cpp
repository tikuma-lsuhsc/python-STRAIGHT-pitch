//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sqrt.cpp
//
// Code generation for function 'sqrt'
//

// Include files
#include "sqrt.h"
#include "exstraightsource_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
void b_sqrt(::coder::array<creal_T, 1U> &x)
{
  int nx;
  nx = x.size(0);
  for (int k{0}; k < nx; k++) {
    double absxr;
    double im;
    double re;
    double yr;
    re = x[k].re;
    im = x[k].im;
    if (im == 0.0) {
      yr = std::sqrt(re);
      absxr = 0.0;
    } else if (re == 0.0) {
      yr = std::sqrt(im / 2.0);
      absxr = yr;
    } else if (std::isnan(re)) {
      yr = rtNaN;
      absxr = rtNaN;
    } else if (std::isnan(im)) {
      yr = rtNaN;
      absxr = rtNaN;
    } else if (std::isinf(im)) {
      yr = im;
      absxr = im;
    } else if (std::isinf(re)) {
      yr = re;
      absxr = 0.0;
    } else {
      if ((re > 4.4942328371557893E+307) || (im > 4.4942328371557893E+307)) {
        absxr = re * 0.5;
        yr = rt_hypotd_snf(absxr, im * 0.5);
        if (yr > absxr) {
          yr = std::sqrt(yr) * std::sqrt(absxr / yr + 1.0);
        } else {
          yr = std::sqrt(yr) * 1.4142135623730951;
        }
      } else {
        yr = std::sqrt((rt_hypotd_snf(re, im) + re) * 0.5);
      }
      if (re > 0.0) {
        absxr = 0.5 * (im / yr);
      } else {
        absxr = yr;
        yr = 0.5 * (im / yr);
      }
    }
    x[k].re = yr;
    x[k].im = absxr;
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (sqrt.cpp)
