//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mrdivide_helper.cpp
//
// Code generation for function 'mrdivide_helper'
//

// Include files
#include "mrdivide_helper.h"
#include "exstraightsource_data.h"
#include "exstraightsource_rtwutil.h"
#include "recip.h"
#include "rt_nonfinite.h"
#include "xdlapy3.h"
#include "xnrm2.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
namespace coder {
namespace internal {
void mrdiv(const ::coder::array<creal_T, 2U> &A,
           const ::coder::array<creal_T, 2U> &B, ::coder::array<creal_T, 1U> &Y)
{
  ::coder::array<creal_T, 2U> b_B;
  ::coder::array<creal_T, 2U> b_Y;
  ::coder::array<creal_T, 1U> b_A;
  if ((A.size(0) == 0) || (A.size(1) == 0) || (B.size(1) == 0)) {
    int loop_ub;
    loop_ub = A.size(0);
    Y.set_size(A.size(0));
    for (int k{0}; k < loop_ub; k++) {
      Y[k].re = 0.0;
      Y[k].im = 0.0;
    }
  } else if (B.size(1) == 1) {
    int loop_ub;
    loop_ub = A.size(0);
    Y.set_size(A.size(0));
    for (int k{0}; k < loop_ub; k++) {
      double wj_re;
      double wj_re_tmp;
      wj_re = A[k].re;
      wj_re_tmp = A[k].im;
      if (B[0].im == 0.0) {
        if (wj_re_tmp == 0.0) {
          Y[k].re = wj_re / B[0].re;
          Y[k].im = 0.0;
        } else if (wj_re == 0.0) {
          Y[k].re = 0.0;
          Y[k].im = wj_re_tmp / B[0].re;
        } else {
          Y[k].re = wj_re / B[0].re;
          Y[k].im = wj_re_tmp / B[0].re;
        }
      } else if (B[0].re == 0.0) {
        if (wj_re == 0.0) {
          Y[k].re = wj_re_tmp / B[0].im;
          Y[k].im = 0.0;
        } else if (wj_re_tmp == 0.0) {
          Y[k].re = 0.0;
          Y[k].im = -(wj_re / B[0].im);
        } else {
          Y[k].re = wj_re_tmp / B[0].im;
          Y[k].im = -(wj_re / B[0].im);
        }
      } else {
        double beta1;
        double xnorm_tmp_tmp;
        beta1 = std::abs(B[0].re);
        xnorm_tmp_tmp = std::abs(B[0].im);
        if (beta1 > xnorm_tmp_tmp) {
          double re_tmp;
          xnorm_tmp_tmp = B[0].im / B[0].re;
          re_tmp = B[0].re + xnorm_tmp_tmp * B[0].im;
          Y[k].re = (wj_re + xnorm_tmp_tmp * wj_re_tmp) / re_tmp;
          Y[k].im = (wj_re_tmp - xnorm_tmp_tmp * wj_re) / re_tmp;
        } else if (xnorm_tmp_tmp == beta1) {
          double re_tmp;
          if (B[0].re > 0.0) {
            xnorm_tmp_tmp = 0.5;
          } else {
            xnorm_tmp_tmp = -0.5;
          }
          if (B[0].im > 0.0) {
            re_tmp = 0.5;
          } else {
            re_tmp = -0.5;
          }
          Y[k].re = (wj_re * xnorm_tmp_tmp + wj_re_tmp * re_tmp) / beta1;
          Y[k].im = (wj_re_tmp * xnorm_tmp_tmp - wj_re * re_tmp) / beta1;
        } else {
          double re_tmp;
          xnorm_tmp_tmp = B[0].re / B[0].im;
          re_tmp = B[0].im + xnorm_tmp_tmp * B[0].re;
          Y[k].re = (xnorm_tmp_tmp * wj_re + wj_re_tmp) / re_tmp;
          Y[k].im = (xnorm_tmp_tmp * wj_re_tmp - wj_re) / re_tmp;
        }
      }
    }
  } else {
    double beta1;
    double re;
    double re_tmp;
    double tau_data_im;
    double tau_data_re;
    double wj_re;
    double wj_re_tmp;
    double xnorm_tmp_tmp;
    int b_loop_ub;
    int knt;
    int loop_ub;
    loop_ub = B.size(1);
    b_A.set_size(B.size(1));
    for (int k{0}; k < loop_ub; k++) {
      b_A[k].re = B[k].re;
      b_A[k].im = -B[k].im;
    }
    knt = A.size(1);
    b_loop_ub = A.size(0);
    b_B.set_size(A.size(1), A.size(0));
    for (int k{0}; k < b_loop_ub; k++) {
      for (int i{0}; i < knt; i++) {
        b_B[i + b_B.size(0) * k].re = A[k + A.size(0) * i].re;
        b_B[i + b_B.size(0) * k].im = -A[k + A.size(0) * i].im;
      }
    }
    tau_data_re = 0.0;
    tau_data_im = 0.0;
    for (int i{0}; i < 1; i++) {
      creal_T atmp;
      atmp = b_A[0];
      tau_data_re = 0.0;
      tau_data_im = 0.0;
      xnorm_tmp_tmp = blas::xnrm2(loop_ub - 1, b_A);
      if ((xnorm_tmp_tmp != 0.0) || (b_A[0].im != 0.0)) {
        beta1 = xdlapy3(b_A[0].re, b_A[0].im, xnorm_tmp_tmp);
        if (b_A[0].re >= 0.0) {
          beta1 = -beta1;
        }
        if (std::abs(beta1) < 1.0020841800044864E-292) {
          creal_T b_atmp;
          knt = 0;
          do {
            knt++;
            for (int k{2}; k <= loop_ub; k++) {
              xnorm_tmp_tmp = b_A[k - 1].im;
              re_tmp = b_A[k - 1].re;
              b_A[k - 1].re =
                  9.9792015476736E+291 * re_tmp - 0.0 * xnorm_tmp_tmp;
              b_A[k - 1].im =
                  9.9792015476736E+291 * xnorm_tmp_tmp + 0.0 * re_tmp;
            }
            beta1 *= 9.9792015476736E+291;
            atmp.re *= 9.9792015476736E+291;
            atmp.im *= 9.9792015476736E+291;
          } while ((std::abs(beta1) < 1.0020841800044864E-292) && (knt < 20));
          beta1 = xdlapy3(atmp.re, atmp.im, blas::xnrm2(loop_ub - 1, b_A));
          if (atmp.re >= 0.0) {
            beta1 = -beta1;
          }
          wj_re = beta1 - atmp.re;
          if (0.0 - atmp.im == 0.0) {
            tau_data_re = wj_re / beta1;
          } else if (wj_re == 0.0) {
            tau_data_im = (0.0 - atmp.im) / beta1;
          } else {
            tau_data_re = wj_re / beta1;
            tau_data_im = (0.0 - atmp.im) / beta1;
          }
          b_atmp.re = atmp.re - beta1;
          b_atmp.im = atmp.im;
          atmp = recip(b_atmp);
          for (int k{2}; k <= loop_ub; k++) {
            xnorm_tmp_tmp = b_A[k - 1].im;
            re_tmp = b_A[k - 1].re;
            b_A[k - 1].re = atmp.re * re_tmp - atmp.im * xnorm_tmp_tmp;
            b_A[k - 1].im = atmp.re * xnorm_tmp_tmp + atmp.im * re_tmp;
          }
          for (int k{0}; k < knt; k++) {
            beta1 *= 1.0020841800044864E-292;
          }
          atmp.re = beta1;
          atmp.im = 0.0;
        } else {
          wj_re = beta1 - b_A[0].re;
          if (0.0 - b_A[0].im == 0.0) {
            tau_data_re = wj_re / beta1;
          } else if (wj_re == 0.0) {
            tau_data_im = (0.0 - b_A[0].im) / beta1;
          } else {
            tau_data_re = wj_re / beta1;
            tau_data_im = (0.0 - b_A[0].im) / beta1;
          }
          atmp.re = b_A[0].re - beta1;
          atmp.im = b_A[0].im;
          atmp = recip(atmp);
          for (int k{2}; k <= loop_ub; k++) {
            xnorm_tmp_tmp = b_A[k - 1].im;
            re_tmp = b_A[k - 1].re;
            b_A[k - 1].re = atmp.re * re_tmp - atmp.im * xnorm_tmp_tmp;
            b_A[k - 1].im = atmp.re * xnorm_tmp_tmp + atmp.im * re_tmp;
          }
          atmp.re = beta1;
          atmp.im = 0.0;
        }
      }
      b_A[0] = atmp;
    }
    knt = 0;
    xnorm_tmp_tmp = rt_hypotd_snf(b_A[0].re, b_A[0].im);
    if (!(xnorm_tmp_tmp <=
          std::fmin(1.4901161193847656E-8,
                    2.2204460492503131E-15 * static_cast<double>(b_A.size(0))) *
              xnorm_tmp_tmp)) {
      knt = 1;
    }
    b_Y.set_size(1, A.size(0));
    for (int k{0}; k < b_loop_ub; k++) {
      b_Y[k].re = 0.0;
      b_Y[k].im = 0.0;
    }
    if ((tau_data_re != 0.0) || (-tau_data_im != 0.0)) {
      for (int k{0}; k < b_loop_ub; k++) {
        double b_wj_re_tmp;
        double wj_im;
        double wj_im_tmp;
        b_wj_re_tmp = b_B[b_B.size(0) * k].re;
        wj_re = b_wj_re_tmp;
        wj_im_tmp = b_B[b_B.size(0) * k].im;
        wj_im = wj_im_tmp;
        for (int i{2}; i <= loop_ub; i++) {
          xnorm_tmp_tmp = b_A[i - 1].re;
          re_tmp = b_B[(i + b_B.size(0) * k) - 1].im;
          beta1 = b_A[i - 1].im;
          wj_re_tmp = b_B[(i + b_B.size(0) * k) - 1].re;
          wj_re += xnorm_tmp_tmp * wj_re_tmp + beta1 * re_tmp;
          wj_im += xnorm_tmp_tmp * re_tmp - beta1 * wj_re_tmp;
        }
        re = tau_data_re * wj_re - -tau_data_im * wj_im;
        beta1 = tau_data_re * wj_im + -tau_data_im * wj_re;
        if ((re != 0.0) || (beta1 != 0.0)) {
          b_B[b_B.size(0) * k].re = b_wj_re_tmp - re;
          b_B[b_B.size(0) * k].im = wj_im_tmp - beta1;
          for (int i{2}; i <= loop_ub; i++) {
            xnorm_tmp_tmp = b_A[i - 1].re;
            re_tmp = b_A[i - 1].im;
            b_B[(i + b_B.size(0) * k) - 1].re =
                b_B[(i + b_B.size(0) * k) - 1].re -
                (xnorm_tmp_tmp * re - re_tmp * beta1);
            b_B[(i + b_B.size(0) * k) - 1].im =
                b_B[(i + b_B.size(0) * k) - 1].im -
                (xnorm_tmp_tmp * beta1 + re_tmp * re);
          }
        }
      }
    }
    for (int k{0}; k < b_loop_ub; k++) {
      if (knt - 1 >= 0) {
        b_Y[k] = b_B[b_B.size(0) * k];
      }
      for (int i{knt}; i >= 1; i--) {
        wj_re = b_Y[k].re;
        wj_re_tmp = b_Y[k].im;
        if (b_A[0].im == 0.0) {
          if (wj_re_tmp == 0.0) {
            re = wj_re / b_A[0].re;
            beta1 = 0.0;
          } else if (wj_re == 0.0) {
            re = 0.0;
            beta1 = wj_re_tmp / b_A[0].re;
          } else {
            re = wj_re / b_A[0].re;
            beta1 = wj_re_tmp / b_A[0].re;
          }
        } else if (b_A[0].re == 0.0) {
          if (wj_re == 0.0) {
            re = wj_re_tmp / b_A[0].im;
            beta1 = 0.0;
          } else if (wj_re_tmp == 0.0) {
            re = 0.0;
            beta1 = -(wj_re / b_A[0].im);
          } else {
            re = wj_re_tmp / b_A[0].im;
            beta1 = -(wj_re / b_A[0].im);
          }
        } else {
          beta1 = std::abs(b_A[0].re);
          xnorm_tmp_tmp = std::abs(b_A[0].im);
          if (beta1 > xnorm_tmp_tmp) {
            xnorm_tmp_tmp = b_A[0].im / b_A[0].re;
            re_tmp = b_A[0].re + xnorm_tmp_tmp * b_A[0].im;
            re = (wj_re + xnorm_tmp_tmp * wj_re_tmp) / re_tmp;
            beta1 = (wj_re_tmp - xnorm_tmp_tmp * wj_re) / re_tmp;
          } else if (xnorm_tmp_tmp == beta1) {
            if (b_A[0].re > 0.0) {
              xnorm_tmp_tmp = 0.5;
            } else {
              xnorm_tmp_tmp = -0.5;
            }
            if (b_A[0].im > 0.0) {
              re_tmp = 0.5;
            } else {
              re_tmp = -0.5;
            }
            re = (wj_re * xnorm_tmp_tmp + wj_re_tmp * re_tmp) / beta1;
            beta1 = (wj_re_tmp * xnorm_tmp_tmp - wj_re * re_tmp) / beta1;
          } else {
            xnorm_tmp_tmp = b_A[0].re / b_A[0].im;
            re_tmp = b_A[0].im + xnorm_tmp_tmp * b_A[0].re;
            re = (xnorm_tmp_tmp * wj_re + wj_re_tmp) / re_tmp;
            beta1 = (xnorm_tmp_tmp * wj_re_tmp - wj_re) / re_tmp;
          }
        }
        b_Y[k].re = re;
        b_Y[k].im = beta1;
      }
    }
    Y.set_size(A.size(0));
    for (int k{0}; k < b_loop_ub; k++) {
      Y[k].re = b_Y[k].re;
      Y[k].im = -b_Y[k].im;
    }
  }
}

} // namespace internal
} // namespace coder
} // namespace legacy_STRAIGHT

// End of code generation (mrdivide_helper.cpp)
