//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// isstable.cpp
//
// Code generation for function 'isstable'
//

// Include files
#include "isstable.h"
#include "exstraightsource_rtwutil.h"
#include "poly2rc.h"
#include "rt_nonfinite.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <emmintrin.h>

// Function Definitions
namespace legacy_STRAIGHT {
namespace b_signal {
namespace internal {
boolean_T isstable(const double a_data[], const int a_size[2])
{
  double a2_data[31];
  double temp_a1_data[31];
  double k_data[30];
  double tmp_data[30];
  double a;
  int b_i;
  int i;
  int loop_ub;
  int scalarLB;
  int vectorUB;
  boolean_T errLevdown_data[30];
  boolean_T flag;
  i = 0;
  while ((i < a_size[1]) && (a_data[(a_size[1] - i) - 1] == 0.0)) {
    i++;
  }
  b_i = a_size[1] - i;
  if (b_i < 1) {
    b_i = 0;
  }
  for (i = 0; a_data[i] == 0.0; i++) {
  }
  if (i + 1 > b_i) {
    i = 0;
    b_i = 0;
  }
  a = a_data[i];
  loop_ub = b_i - i;
  scalarLB = (loop_ub / 2) << 1;
  vectorUB = scalarLB - 2;
  for (b_i = 0; b_i <= vectorUB; b_i += 2) {
    _mm_storeu_pd(&a2_data[b_i],
                  _mm_div_pd(_mm_loadu_pd(&a_data[i + b_i]), _mm_set1_pd(a)));
  }
  for (b_i = scalarLB; b_i < loop_ub; b_i++) {
    a2_data[b_i] = a_data[i + b_i] / a;
  }
  if (loop_ub == 1) {
    flag = true;
  } else if (loop_ub == 2) {
    flag = (std::abs(a2_data[1]) < 1.0);
  } else {
    flag = true;
    a = std::abs(a2_data[loop_ub - 1]);
    if (a >= 1.0) {
      flag = false;
    } else {
      int k_size_idx_0;
      int k_size_idx_1;
      boolean_T errFlag;
      boolean_T exitg1;
      errFlag = false;
      if (loop_ub <= 1) {
        k_size_idx_0 = 0;
        k_size_idx_1 = 0;
      } else {
        boolean_T y;
        errFlag = (a2_data[0] == 0.0);
        a = a2_data[0];
        scalarLB = (loop_ub / 2) << 1;
        vectorUB = scalarLB - 2;
        for (b_i = 0; b_i <= vectorUB; b_i += 2) {
          __m128d r;
          r = _mm_loadu_pd(&a2_data[b_i]);
          _mm_storeu_pd(&temp_a1_data[b_i], _mm_div_pd(r, _mm_set1_pd(a)));
        }
        for (b_i = scalarLB; b_i < loop_ub; b_i++) {
          temp_a1_data[b_i] = a2_data[b_i] / a;
        }
        i = loop_ub - 1;
        k_size_idx_0 = loop_ub - 1;
        k_size_idx_1 = 1;
        std::memset(&k_data[0], 0,
                    static_cast<unsigned int>(i) * sizeof(double));
        k_data[loop_ub - 2] = temp_a1_data[loop_ub - 1];
        std::copy(&temp_a1_data[0], &temp_a1_data[loop_ub], &a2_data[0]);
        std::memset(&errLevdown_data[0], 0,
                    static_cast<unsigned int>(loop_ub - 1) * sizeof(boolean_T));
        for (int k{0}; k <= loop_ub - 3; k++) {
          double absknxt2;
          int b_loop_ub;
          int i1;
          int k_tmp;
          k_tmp = loop_ub - k;
          errLevdown_data[k_tmp - 3] = false;
          if (k_tmp < 2) {
            b_i = 0;
            i1 = -1;
          } else {
            b_i = 1;
            i1 = k_tmp - 1;
          }
          if (a2_data[i1] == 1.0) {
            errLevdown_data[k_tmp - 3] = true;
          }
          a = std::abs(a2_data[i1]);
          absknxt2 = a * a;
          i = i1 - b_i;
          if (i < 1) {
            b_loop_ub = -1;
            scalarLB = 0;
            vectorUB = 1;
            i = -1;
          } else {
            b_loop_ub = i - 1;
            scalarLB = i - 1;
            vectorUB = -1;
            i = 0;
          }
          if (b_loop_ub + 1 == div_s32(i - scalarLB, vectorUB) + 1) {
            a = a2_data[i1];
            i = b_loop_ub + 2;
            tmp_data[0] = 1.0;
            for (i1 = 0; i1 <= b_loop_ub; i1++) {
              tmp_data[i1 + 1] =
                  (a2_data[b_i + i1] -
                   a * a2_data[(b_i + scalarLB) + vectorUB * i1]) /
                  (1.0 - absknxt2);
            }
            if (i - 1 >= 0) {
              std::copy(&tmp_data[0], &tmp_data[i], &a2_data[0]);
            }
          } else {
            binary_expand_op_23(a2_data, b_i + 1, b_loop_ub, i1, scalarLB,
                                vectorUB, i, absknxt2);
          }
          k_data[k_tmp - 3] = a2_data[k_tmp - 2];
        }
        y = false;
        i = 1;
        exitg1 = false;
        while ((!exitg1) && (i <= loop_ub - 1)) {
          if (errLevdown_data[i - 1]) {
            y = true;
            exitg1 = true;
          } else {
            i++;
          }
        }
        errFlag = (y || errFlag);
      }
      if (errFlag) {
        flag = false;
      } else {
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i <= k_size_idx_0 * k_size_idx_1 - 1)) {
          if (std::isnan(k_data[i]) || (std::abs(k_data[i]) >= 1.0)) {
            flag = false;
            exitg1 = true;
          } else {
            i++;
          }
        }
      }
    }
  }
  return flag;
}

} // namespace internal
} // namespace b_signal
} // namespace legacy_STRAIGHT

// End of code generation (isstable.cpp)
