//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sum.cpp
//
// Code generation for function 'sum'
//

// Include files
#include "sum.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace legacy_STRAIGHT {
void sum(const ::coder::array<double, 2U> &x, ::coder::array<double, 2U> &y)
{
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int npages_tmp;
    y.set_size(1, x.size(1));
    npages_tmp = x.size(1);
    for (int firstBlockLength{0}; firstBlockLength < npages_tmp;
         firstBlockLength++) {
      y[firstBlockLength] = 0.0;
    }
  } else {
    int firstBlockLength;
    int lastBlockLength;
    int nblocks;
    int npages_tmp;
    npages_tmp = x.size(1);
    y.set_size(1, x.size(1));
    if (x.size(0) <= 1024) {
      firstBlockLength = x.size(0);
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = static_cast<int>(static_cast<unsigned int>(x.size(0)) >> 10);
      lastBlockLength = x.size(0) - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    for (int xi{0}; xi < npages_tmp; xi++) {
      int xpageoffset;
      xpageoffset = xi * x.size(0);
      y[xi] = x[xpageoffset];
      for (int k{2}; k <= firstBlockLength; k++) {
        y[xi] = y[xi] + x[(xpageoffset + k) - 1];
      }
      for (int ib{2}; ib <= nblocks; ib++) {
        double bsum;
        int hi;
        int xblockoffset;
        xblockoffset = xpageoffset + ((ib - 1) << 10);
        bsum = x[xblockoffset];
        if (ib == nblocks) {
          hi = lastBlockLength;
        } else {
          hi = 1024;
        }
        for (int k{2}; k <= hi; k++) {
          bsum += x[(xblockoffset + k) - 1];
        }
        y[xi] = y[xi] + bsum;
      }
    }
  }
}

creal_T sum(const ::coder::array<creal_T, 1U> &x)
{
  creal_T y;
  if (x.size(0) == 0) {
    y.re = 0.0;
    y.im = 0.0;
  } else {
    int firstBlockLength;
    int lastBlockLength;
    int nblocks;
    if (x.size(0) <= 1024) {
      firstBlockLength = x.size(0);
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = static_cast<int>(static_cast<unsigned int>(x.size(0)) >> 10);
      lastBlockLength = x.size(0) - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    y = x[0];
    for (int k{2}; k <= firstBlockLength; k++) {
      y.re += x[k - 1].re;
      y.im += x[k - 1].im;
    }
    for (int ib{2}; ib <= nblocks; ib++) {
      double bsum_im;
      double bsum_re;
      int hi;
      firstBlockLength = (ib - 1) << 10;
      bsum_re = x[firstBlockLength].re;
      bsum_im = x[firstBlockLength].im;
      if (ib == nblocks) {
        hi = lastBlockLength;
      } else {
        hi = 1024;
      }
      for (int k{2}; k <= hi; k++) {
        int bsum_re_tmp;
        bsum_re_tmp = (firstBlockLength + k) - 1;
        bsum_re += x[bsum_re_tmp].re;
        bsum_im += x[bsum_re_tmp].im;
      }
      y.re += bsum_re;
      y.im += bsum_im;
    }
  }
  return y;
}

} // namespace legacy_STRAIGHT

// End of code generation (sum.cpp)
