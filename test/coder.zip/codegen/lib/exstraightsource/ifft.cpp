//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ifft.cpp
//
// Code generation for function 'ifft'
//

// Include files
#include "ifft.h"
#include "FFTImplementationCallback.h"
#include "exstraightsource_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
namespace legacy_STRAIGHT {
void ifft(const ::coder::array<creal_T, 2U> &x, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int N2blue;
    y.set_size(x.size(0), x.size(1));
    N2blue = x.size(0) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x.size(0) & (x.size(0) - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x.size(0), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::c_generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig(
          x, x.size(0), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::dobluesteinfft(
          x, N2blue, x.size(0), costab, sintab, sintabinv, y);
    }
  }
}

void ifft(const ::coder::array<double, 2U> &x, ::coder::array<creal_T, 2U> &y)
{
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nRows;
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int N2blue;
    y.set_size(x.size(0), x.size(1));
    N2blue = x.size(0) * x.size(1);
    for (nRows = 0; nRows < N2blue; nRows++) {
      y[nRows].re = 0.0;
      y[nRows].im = 0.0;
    }
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x.size(0) & (x.size(0) - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x.size(0), useRadix2, nRows);
    coder::internal::fft::FFTImplementationCallback::c_generate_twiddle_tables(
        nRows, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::b_r2br_r2dit_trig(
          x, x.size(0), costab, sintab, y);
    } else {
      coder::internal::fft::FFTImplementationCallback::b_dobluesteinfft(
          x, N2blue, x.size(0), costab, sintab, sintabinv, y);
    }
  }
}

void ifft(const ::coder::array<creal_T, 1U> &x, ::coder::array<creal_T, 1U> &y)
{
  ::coder::array<creal_T, 1U> b_fv;
  ::coder::array<creal_T, 1U> fv;
  ::coder::array<creal_T, 1U> wwc;
  ::coder::array<double, 2U> costab;
  ::coder::array<double, 2U> sintab;
  ::coder::array<double, 2U> sintabinv;
  int nfft_tmp;
  int rt;
  nfft_tmp = x.size(0);
  if (x.size(0) == 0) {
    y.set_size(0);
  } else {
    int N2blue;
    boolean_T useRadix2;
    useRadix2 = ((x.size(0) & (x.size(0) - 1)) == 0);
    N2blue = coder::internal::fft::FFTImplementationCallback::get_algo_sizes(
        x.size(0), useRadix2, rt);
    coder::internal::fft::FFTImplementationCallback::c_generate_twiddle_tables(
        rt, useRadix2, costab, sintab, sintabinv);
    if (useRadix2) {
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          x, x.size(0), costab, sintab, y);
      if (y.size(0) > 1) {
        double nt_re;
        nt_re = 1.0 / static_cast<double>(y.size(0));
        rt = y.size(0);
        for (int nInt2{0}; nInt2 < rt; nInt2++) {
          y[nInt2].re = nt_re * y[nInt2].re;
          y[nInt2].im = nt_re * y[nInt2].im;
        }
      }
    } else {
      double b_re_tmp;
      double nt_im;
      double nt_re;
      double re_tmp;
      int nInt2;
      int nInt2m1_tmp;
      nInt2m1_tmp = (x.size(0) + x.size(0)) - 1;
      wwc.set_size(nInt2m1_tmp);
      rt = 0;
      wwc[x.size(0) - 1].re = 1.0;
      wwc[x.size(0) - 1].im = 0.0;
      nInt2 = x.size(0) << 1;
      for (int k{0}; k <= nfft_tmp - 2; k++) {
        int b_y;
        b_y = ((k + 1) << 1) - 1;
        if (nInt2 - rt <= b_y) {
          rt += b_y - nInt2;
        } else {
          rt += b_y;
        }
        nt_im = 3.1415926535897931 * static_cast<double>(rt) /
                static_cast<double>(nfft_tmp);
        wwc[(x.size(0) - k) - 2].re = std::cos(nt_im);
        wwc[(x.size(0) - k) - 2].im = -std::sin(nt_im);
      }
      nInt2 = nInt2m1_tmp - 1;
      for (int k{nInt2}; k >= nfft_tmp; k--) {
        wwc[k] = wwc[(nInt2m1_tmp - k) - 1];
      }
      y.set_size(x.size(0));
      for (int k{0}; k < nfft_tmp; k++) {
        rt = (nfft_tmp + k) - 1;
        nt_re = wwc[rt].re;
        nt_im = wwc[rt].im;
        re_tmp = x[k].im;
        b_re_tmp = x[k].re;
        y[k].re = nt_re * b_re_tmp + nt_im * re_tmp;
        y[k].im = nt_re * re_tmp - nt_im * b_re_tmp;
      }
      nInt2 = x.size(0) + 1;
      for (int k{nInt2}; k <= nfft_tmp; k++) {
        y[k - 1].re = 0.0;
        y[k - 1].im = 0.0;
      }
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          y, N2blue, costab, sintab, fv);
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          wwc, N2blue, costab, sintab, b_fv);
      rt = fv.size(0);
      b_fv.set_size(fv.size(0));
      for (nInt2 = 0; nInt2 < rt; nInt2++) {
        nt_re = fv[nInt2].re;
        nt_im = b_fv[nInt2].im;
        re_tmp = fv[nInt2].im;
        b_re_tmp = b_fv[nInt2].re;
        b_fv[nInt2].re = nt_re * b_re_tmp - re_tmp * nt_im;
        b_fv[nInt2].im = nt_re * nt_im + re_tmp * b_re_tmp;
      }
      coder::internal::fft::FFTImplementationCallback::r2br_r2dit_trig_impl(
          b_fv, N2blue, costab, sintabinv, fv);
      if (fv.size(0) > 1) {
        nt_re = 1.0 / static_cast<double>(fv.size(0));
        rt = fv.size(0);
        for (nInt2 = 0; nInt2 < rt; nInt2++) {
          fv[nInt2].re = nt_re * fv[nInt2].re;
          fv[nInt2].im = nt_re * fv[nInt2].im;
        }
      }
      for (int k{nfft_tmp}; k <= nInt2m1_tmp; k++) {
        double ar;
        nt_re = wwc[k - 1].re;
        nt_im = fv[k - 1].im;
        re_tmp = wwc[k - 1].im;
        b_re_tmp = fv[k - 1].re;
        ar = nt_re * b_re_tmp + re_tmp * nt_im;
        nt_re = nt_re * nt_im - re_tmp * b_re_tmp;
        if (nt_re == 0.0) {
          nInt2 = k - nfft_tmp;
          y[nInt2].re = ar / static_cast<double>(nfft_tmp);
          y[nInt2].im = 0.0;
        } else if (ar == 0.0) {
          nInt2 = k - nfft_tmp;
          y[nInt2].re = 0.0;
          y[nInt2].im = nt_re / static_cast<double>(nfft_tmp);
        } else {
          nInt2 = k - nfft_tmp;
          y[nInt2].re = ar / static_cast<double>(nfft_tmp);
          y[nInt2].im = nt_re / static_cast<double>(nfft_tmp);
        }
      }
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (ifft.cpp)
