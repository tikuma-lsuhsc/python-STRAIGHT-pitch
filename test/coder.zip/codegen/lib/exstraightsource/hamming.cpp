//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// hamming.cpp
//
// Code generation for function 'hamming'
//

// Include files
#include "hamming.h"
#include "exstraightsource_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <emmintrin.h>

// Function Definitions
namespace legacy_STRAIGHT {
void hamming(double varargin_1, ::coder::array<double, 1U> &w)
{
  ::coder::array<double, 2U> y;
  ::coder::array<double, 1U> b_w;
  double n;
  double r;
  if (varargin_1 == std::floor(varargin_1)) {
    n = varargin_1;
  } else {
    n = std::round(varargin_1);
  }
  if (std::isnan(n) || std::isinf(n)) {
    r = rtNaN;
  } else if (n == 0.0) {
    r = 0.0;
  } else {
    r = std::fmod(n, 2.0);
    if (r == 0.0) {
      r = 0.0;
    }
  }
  if (r == 0.0) {
    __m128d b_r;
    int b_loop_ub;
    int loop_ub;
    int nx_tmp;
    int scalarLB;
    int vectorUB;
    r = n / 2.0;
    if (std::isnan(n / 2.0 - 1.0)) {
      y.set_size(1, 1);
      y[0] = rtNaN;
    } else if (r - 1.0 < 0.0) {
      y.set_size(1, 0);
    } else {
      y.set_size(1, static_cast<int>(r - 1.0) + 1);
      loop_ub = static_cast<int>(r - 1.0);
      for (int i{0}; i <= loop_ub; i++) {
        y[i] = i;
      }
    }
    loop_ub = y.size(1);
    w.set_size(y.size(1));
    scalarLB = (y.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i{0}; i <= vectorUB; i += 2) {
      b_r = _mm_loadu_pd(&y[i]);
      _mm_storeu_pd(&w[i], _mm_mul_pd(_mm_set1_pd(6.2831853071795862),
                                      _mm_div_pd(b_r, _mm_set1_pd(n - 1.0))));
    }
    for (int i{scalarLB}; i < loop_ub; i++) {
      w[i] = 6.2831853071795862 * (y[i] / (n - 1.0));
    }
    nx_tmp = w.size(0);
    for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
      w[scalarLB] = std::cos(w[scalarLB]);
    }
    scalarLB = (w.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int i{0}; i <= vectorUB; i += 2) {
      b_r = _mm_loadu_pd(&w[i]);
      _mm_storeu_pd(&w[i], _mm_sub_pd(_mm_set1_pd(0.54),
                                      _mm_mul_pd(_mm_set1_pd(0.46), b_r)));
    }
    for (int i{scalarLB}; i < nx_tmp; i++) {
      w[i] = 0.54 - 0.46 * w[i];
    }
    scalarLB = w.size(0) - 1;
    loop_ub = w.size(0) + w.size(0);
    b_w.set_size(loop_ub);
    b_loop_ub = w.size(0);
    for (int i{0}; i < b_loop_ub; i++) {
      b_w[i] = w[i];
    }
    for (int i{0}; i <= scalarLB; i++) {
      b_w[i + w.size(0)] = w[scalarLB - i];
    }
    w.set_size(loop_ub);
    for (int i{0}; i < loop_ub; i++) {
      w[i] = b_w[i];
    }
  } else {
    __m128d b_r;
    int b_loop_ub;
    int i;
    int loop_ub;
    int nx_tmp;
    int scalarLB;
    int vectorUB;
    r = (n + 1.0) / 2.0;
    if (std::isnan(r - 1.0)) {
      y.set_size(1, 1);
      y[0] = rtNaN;
    } else if (r - 1.0 < 0.0) {
      y.set_size(1, 0);
    } else {
      y.set_size(1, static_cast<int>(r - 1.0) + 1);
      loop_ub = static_cast<int>(r - 1.0);
      for (i = 0; i <= loop_ub; i++) {
        y[i] = i;
      }
    }
    loop_ub = y.size(1);
    w.set_size(y.size(1));
    scalarLB = (y.size(1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      b_r = _mm_loadu_pd(&y[i]);
      _mm_storeu_pd(&w[i], _mm_mul_pd(_mm_set1_pd(6.2831853071795862),
                                      _mm_div_pd(b_r, _mm_set1_pd(n - 1.0))));
    }
    for (i = scalarLB; i < loop_ub; i++) {
      w[i] = 6.2831853071795862 * (y[i] / (n - 1.0));
    }
    nx_tmp = w.size(0);
    for (scalarLB = 0; scalarLB < nx_tmp; scalarLB++) {
      w[scalarLB] = std::cos(w[scalarLB]);
    }
    scalarLB = (w.size(0) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (i = 0; i <= vectorUB; i += 2) {
      b_r = _mm_loadu_pd(&w[i]);
      _mm_storeu_pd(&w[i], _mm_sub_pd(_mm_set1_pd(0.54),
                                      _mm_mul_pd(_mm_set1_pd(0.46), b_r)));
    }
    for (i = scalarLB; i < nx_tmp; i++) {
      w[i] = 0.54 - 0.46 * w[i];
    }
    if (w.size(0) - 1 < 1) {
      i = 0;
      scalarLB = 1;
      nx_tmp = -1;
    } else {
      i = w.size(0) - 2;
      scalarLB = -1;
      nx_tmp = 0;
    }
    loop_ub = div_s32(nx_tmp - i, scalarLB);
    b_loop_ub = (w.size(0) + loop_ub) + 1;
    b_w.set_size(b_loop_ub);
    vectorUB = w.size(0);
    for (nx_tmp = 0; nx_tmp < vectorUB; nx_tmp++) {
      b_w[nx_tmp] = w[nx_tmp];
    }
    for (nx_tmp = 0; nx_tmp <= loop_ub; nx_tmp++) {
      b_w[nx_tmp + w.size(0)] = w[i + scalarLB * nx_tmp];
    }
    w.set_size(b_loop_ub);
    for (i = 0; i < b_loop_ub; i++) {
      w[i] = b_w[i];
    }
  }
}

} // namespace legacy_STRAIGHT

// End of code generation (hamming.cpp)
